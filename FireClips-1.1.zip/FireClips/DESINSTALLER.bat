@echo off
setlocal EnableExtensions
title FireClips - desinstallation
set "ROOT=%LOCALAPPDATA%\FireClips"

rem run from a temporary copy so that this file can delete its own folder
if "%~1"=="--from-temp" goto :run
copy /y "%~f0" "%TEMP%\fireclips-uninstall.bat" >nul
call "%TEMP%\fireclips-uninstall.bat" --from-temp
exit /b
:run

echo.
echo  Desinstaller FireClips ?  (Uninstall FireClips?)
echo.
echo  Seront supprimes : le programme, les reglages, les VODs analysees (cache).
echo  Tes clips exportes (dossier Videos\FireClips) ne sont PAS supprimes.
echo  (Your exported clips are NOT deleted.)
echo.
choice /C ON /M "Continuer / Continue - O = oui/yes, N = non/no"
if errorlevel 2 exit /b 0

powershell -NoProfile -NonInteractive -Command "Get-Process python,pythonw -ErrorAction SilentlyContinue | Where-Object { $_.Path -like ($env:LOCALAPPDATA + '\FireClips\venv\*') } | Stop-Process -Force" >nul 2>nul
timeout /t 2 /nobreak >nul
powershell -NoProfile -NonInteractive -Command "foreach ($f in 'Desktop','Programs','Startup') { $p = Join-Path ([Environment]::GetFolderPath($f)) 'FireClips.lnk'; if (Test-Path $p) { Remove-Item -Force $p } }" >nul 2>nul
rmdir /s /q "%ROOT%"
echo.
if exist "%ROOT%" (
  echo  [!] Certains fichiers sont encore utilises. Redemarre le PC puis relance la desinstallation.
) else (
  echo  FireClips est desinstalle. / FireClips is uninstalled.
)
echo.
pause
