"""The detection signals, each turned into one value per second between 0 and 1.

chat_activity   bursts of chat messages compared to the usual chat speed at that time
chat_laughs     messages with laugh emotes / words (KEKW, mdr, ptdr, xD...) and "clip" requests
laughter        laughter heard in the audio (YAMNet sound classifier)
loudness        yelling / sudden loud reactions
voice_keywords  words said on stream that often come with funny moments (editable list)
clips           clips made by viewers on this VOD
ai              funny moments found by the AI in the transcript (built in scoring.py)
"""
from __future__ import annotations

import logging
import math
import os
import re
import threading
from pathlib import Path
from typing import Callable, Optional

import numpy as np

from . import paths
from .util import strip_accents

log = logging.getLogger("fireclips.signals")

# --------------------------------------------------------------------------- keyword matching

_BUILTIN_LAUGH = [
    r"(?:h+a+|a+h+)(?:[\s,!.]*(?:h+a+|a+h+))+[ah]*",  # haha, ahah, ha ha ha, AHAHAHA
    r"h+i+(?:[\s,!.]*h+i+)+", r"h+e+(?:[\s,!.]*h+e+)+",  # hihi, héhé
    r"x+d+", r"l+o+l+", r"lmf?a+o+", r"rofl", r"m+d+r+", r"p+t+d+r+",
    r"\U0001F602+", r"\U0001F923+", r"\U0001F480+",
]


def _norm(text: str) -> str:
    return strip_accents(text or "").lower()


def keyword_regex(keywords: list[str], builtin: bool = False) -> Optional[re.Pattern]:
    """One regex for a keyword list. Letters may repeat ('mdr' also finds 'MDRRR', 'lol' finds
    'loool'); accents and case are ignored; keywords match whole words only."""
    parts = []
    for kw in keywords or []:
        k = _norm(kw.strip())
        if not k:
            continue
        pieces = []
        for ch in k:
            if ch.isspace():
                pieces.append(r"\s+")
            elif ch.isalnum():
                pieces.append(re.escape(ch) + "+")
            else:
                pieces.append(re.escape(ch))
        parts.append("".join(pieces))
    if builtin:
        parts += _BUILTIN_LAUGH
    if not parts:
        return None
    return re.compile(r"(?<![\w])(?:" + "|".join(parts) + r")(?![\w])", re.I)


# --------------------------------------------------------------------------- helpers

def _moving_avg(x: np.ndarray, w: int) -> np.ndarray:
    if w <= 1 or len(x) == 0:
        return x.astype(np.float64)
    k = np.ones(w) / w
    return np.convolve(x, k, mode="same")


def _moving_max(x: np.ndarray, w: int) -> np.ndarray:
    if w <= 1 or len(x) == 0:
        return x
    pad = w // 2
    xp = np.pad(x, (pad, w - 1 - pad), mode="edge")
    return np.lib.stride_tricks.sliding_window_view(xp, w).max(axis=1)


def rolling_median(x: np.ndarray, window_s: int, bin_s: int = 10, q: float = 0.5) -> np.ndarray:
    """Median (or another quantile q) of x over a long window, computed on bins so it stays fast
    for 8 h VODs."""
    n = len(x)
    if n == 0:
        return x
    nb = math.ceil(n / bin_s)
    xb = np.pad(x, (0, nb * bin_s - n), mode="edge").reshape(nb, bin_s).mean(axis=1)
    half = max(1, window_s // bin_s // 2)
    xp = np.pad(xb, (half, half), mode="edge")
    win = np.lib.stride_tricks.sliding_window_view(xp, 2 * half + 1)
    med = np.median(win, axis=1) if q == 0.5 else np.quantile(win, q, axis=1)
    return np.repeat(med, bin_s)[:n]


def _excess(rate: np.ndarray, base: np.ndarray, window: float, floor: float) -> np.ndarray:
    """How unusual a rate is compared to its baseline (a z-score that works for small chats)."""
    b = np.maximum(base, floor)
    sd = np.sqrt(b / window + (0.3 * b) ** 2)
    return (rate - b) / sd


def _squash(z: np.ndarray, k: float = 4.0) -> np.ndarray:
    return 1.0 - np.exp(-np.maximum(z, 0.0) / k)


# --------------------------------------------------------------------------- chat

def chat_signals(msgs: list, duration: float, delay: float, laugh_kw: list[str], clip_kw: list[str]) -> dict:
    """Per-second chat activity / laugh signals plus the raw numbers used to explain them."""
    n = int(math.ceil(duration)) + 1
    counts = np.zeros(n)
    laughs = np.zeros(n)
    clipreq = np.zeros(n)
    laugh_re = keyword_regex(laugh_kw, builtin=True)
    clip_re = keyword_regex(clip_kw)
    seen: set = set()
    for off, user, text in msgs:
        t = int(off - delay)
        if t < 0 or t >= n:
            continue
        key = (user, int(off // 5))
        if key in seen:
            continue
        seen.add(key)
        counts[t] += 1
        txt = _norm(text)
        if laugh_re is not None and laugh_re.search(txt):
            laughs[t] += 1
        if clip_re is not None and clip_re.search(txt):
            clipreq[t] += 1
    W = 10
    rate = _moving_avg(counts, W)
    base = rolling_median(rate, 600)
    floor_rate = max(0.02, float(np.mean(counts)) * 0.25)
    z_act = _excess(rate, base, W, floor_rate)
    activity = _squash(z_act, 4.0)

    weighted = laughs + 1.5 * clipreq
    lrate = _moving_avg(weighted, W)
    lbase = rolling_median(lrate, 600)
    z_l = _excess(lrate, lbase, W, 0.01)
    laugh_sig = _squash(z_l, 4.0)
    # need at least two laughing people around
    laugh_sig[_moving_avg(weighted, W) * W < 1.9] = 0.0
    return {
        "chat_activity": activity.astype(np.float32),
        "chat_laughs": laugh_sig.astype(np.float32),
        "raw": {"rate": rate.astype(np.float32), "base": base.astype(np.float32),
                "laughs": laughs.astype(np.float32), "clipreq": clipreq.astype(np.float32)},
    }


def chat_excerpt(msgs: list, start: float, end: float, limit: int = 4, maxlen: int = 28,
                 only: Optional[re.Pattern] = None) -> list[str]:
    """The most repeated short messages in a time range (shown to the AI and in reasons).
    `only`: keep only messages matching this regex (e.g. laughing ones)."""
    from collections import Counter
    c: Counter = Counter()
    for off, _u, text in msgs:
        if start <= off <= end:
            t = (text or "").strip()
            if 0 < len(t) <= maxlen and (only is None or only.search(_norm(t))):
                c[t] += 1
    return [m for m, _ in c.most_common(limit)]


# --------------------------------------------------------------------------- audio (loudness + laughter)

LAUGH_CLASSES = (13, 14, 15, 16, 17, 18)       # Laughter, Baby laughter, Giggle, Snicker, Belly laugh, Chuckle
SHOUT_CLASSES = (6, 7, 8, 9, 11)               # Shout, Bellow, Whoop, Yell, Screaming
HOP = 8000                                     # 0.5 s at 16 kHz
WIN = 15600                                    # YAMNet window (0.975 s)


def _yamnet_session():
    import onnxruntime as ort
    try:
        ort.disable_telemetry_events()  # no usage data sent anywhere
    except Exception:  # noqa: BLE001
        pass
    so = ort.SessionOptions()
    so.intra_op_num_threads = max(1, min(4, (os.cpu_count() or 4) // 2))
    so.log_severity_level = 3
    return ort.InferenceSession(str(paths.ASSETS / "yamnet.onnx"), so, providers=["CPUExecutionProvider"])


def compute_audio_features(audio_path: Path, duration: float, out_path: Path,
                           progress: Callable[[float, str], None] = lambda f, m="": None,
                           cancel: Optional[threading.Event] = None, use_yamnet: bool = True) -> Path:
    """Loudness (dB) every 0.5 s plus laughter / shout probabilities from YAMNet."""
    from .media import iter_pcm
    n_hops = int(math.ceil(max(duration, 1.0) / 0.5)) + 2
    db = np.full(n_hops, -90.0, dtype=np.float32)
    laugh = np.zeros(n_hops, dtype=np.float32)
    shout = np.zeros(n_hops, dtype=np.float32)
    sess = None
    if use_yamnet:
        try:
            sess = _yamnet_session()
            in_name = sess.get_inputs()[0].name
        except Exception as e:  # noqa: BLE001
            log.warning("laughter model unavailable: %s", e)
            sess = None
    buf = np.zeros(0, dtype=np.float32)
    buf_start = 0       # absolute sample index of buf[0]
    h = 0               # next hop to process
    total = 0
    for block in iter_pcm(audio_path, 16000, 60.0, cancel):
        buf = np.concatenate([buf, block.astype(np.float32) / 32768.0])
        total += len(block)
        while h < n_hops and (h * HOP + WIN) <= buf_start + len(buf):
            a = h * HOP - buf_start
            seg = buf[a:a + HOP]
            rms = float(np.sqrt(np.mean(seg * seg))) if len(seg) else 0.0
            db[h] = 20 * math.log10(rms + 1e-9)
            if sess is not None:
                w = buf[a:a + WIN]
                if float(np.sqrt(np.mean(w * w))) > 0.003:
                    sc = sess.run(None, {in_name: w})[0][0]
                    laugh[h] = float(max(sc[i] for i in LAUGH_CLASSES))
                    shout[h] = float(max(sc[i] for i in SHOUT_CLASSES))
            h += 1
        drop = h * HOP - buf_start
        if drop > 0:
            buf = buf[drop:]
            buf_start += drop
        progress(min(0.99, total / 16000 / max(1.0, duration)), "")
    # tail (last window shorter than YAMNet needs)
    while h < n_hops and h * HOP < buf_start + len(buf):
        a = h * HOP - buf_start
        seg = buf[a:a + HOP]
        rms = float(np.sqrt(np.mean(seg * seg))) if len(seg) else 0.0
        db[h] = 20 * math.log10(rms + 1e-9)
        h += 1
    np.savez_compressed(out_path, hop=0.5, db=db, laugh=laugh, shout=shout, has_yamnet=sess is not None)
    progress(1.0, "")
    return out_path


def _per_second(x: np.ndarray, n: int) -> np.ndarray:
    m = len(x) // 2
    y = x[: m * 2].reshape(m, 2).max(axis=1) if m else np.zeros(0)
    if len(y) < n:
        y = np.pad(y, (0, n - len(y)), constant_values=(y.min() if len(y) else 0))
    return y[:n]


def audio_signals(features_path: Path, duration: float) -> dict:
    n = int(math.ceil(duration)) + 1
    with np.load(features_path) as f:
        db = _per_second(f["db"].astype(np.float64), n)
        laugh = _per_second(f["laugh"].astype(np.float64), n)
        shout = _per_second(f["shout"].astype(np.float64), n)
        has_yam = bool(f["has_yamnet"]) if "has_yamnet" in f else True
    # compare with the usual "active" level around (85th percentile over 5 min), so that normal
    # talking over game sound is not counted, only real yelling / loud reactions
    ref_level = rolling_median(db, 300, q=0.85)
    loud = np.clip((db - ref_level - 4.0) / 8.0, 0, 1)
    loud[db < -42] = 0
    shout_s = np.clip((shout - 0.15) / 0.5, 0, 1)
    loudness = np.maximum(loud, 0.8 * shout_s)
    laughter = np.clip((_moving_max(laugh, 3) - 0.12) / 0.5, 0, 1)
    out = {"loudness": loudness.astype(np.float32), "raw": {"db": db, "laugh": laugh, "shout": shout}}
    if has_yam:
        out["laughter"] = laughter.astype(np.float32)
    return out


# --------------------------------------------------------------------------- transcript keywords

def voice_keyword_signal(transcript: dict, duration: float, keywords: list[str]) -> tuple[np.ndarray, list]:
    n = int(math.ceil(duration)) + 1
    hits = np.zeros(n)
    found: list = []
    rx = keyword_regex(keywords, builtin=True)
    if rx is None:
        return hits.astype(np.float32), found
    for seg in transcript.get("segments", []):
        text = _norm(seg.get("t", ""))
        for m in rx.finditer(text):
            # position of the match: interpolate inside the segment
            frac = m.start() / max(1, len(text))
            t = seg["s"] + frac * max(0.0, seg["e"] - seg["s"])
            i = int(t)
            if 0 <= i < n:
                hits[i] += 1
                found.append((round(t, 1), m.group(0)))
    sig = np.clip(_moving_avg(hits, 10) * 10 / 2.0, 0, 1)
    return sig.astype(np.float32), found


# --------------------------------------------------------------------------- viewer clips

def clips_signal(clips: list, duration: float) -> np.ndarray:
    n = int(math.ceil(duration)) + 1
    sig = np.zeros(n)
    count = np.zeros(n)
    for c in clips:
        a = int(max(0, c["offset"]))
        b = int(min(n, c["offset"] + max(5.0, c.get("duration", 30))))
        if b <= a:
            continue
        v = min(1.0, 0.6 + 0.1 * math.log2(1 + max(0, c.get("views", 0))))
        sig[a:b] = np.maximum(sig[a:b], v)
        count[a:b] += 1
    sig = np.minimum(1.0, sig + 0.15 * np.maximum(0, count - 1))
    return sig.astype(np.float32)
