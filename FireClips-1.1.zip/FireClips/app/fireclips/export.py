"""Cutting the chosen moments into MP4 clips with ffmpeg: 16:9 and/or 9:16 (blurred background
or crop), optional TikTok-style subtitles, NVIDIA encoder when available."""
from __future__ import annotations

import logging
import re
import shutil
import threading
from datetime import datetime
from pathlib import Path
from typing import Callable, Optional

from . import media, paths, subtitles, tools
from .errors import UserError
from .store import VodRef
from .transcribe import find_transcript
from .util import fmt_tag, read_json, run_streaming, sanitize_filename, unique_path

log = logging.getLogger("fireclips.export")


def vod_date(meta: dict) -> str:
    s = meta.get("created_at") or ""
    try:
        dt = datetime.fromisoformat(s.replace("Z", "+00:00")).astimezone()
        return dt.strftime("%Y-%m-%d")
    except ValueError:
        return s[:10] or datetime.now().strftime("%Y-%m-%d")


def vod_folder_name(meta: dict) -> str:
    title = sanitize_filename(meta.get("title") or meta.get("key") or "VOD", 50)
    return f"{vod_date(meta)} {title}".strip()


def clip_filename(meta: dict, moment: dict, fmt: str) -> str:
    title = sanitize_filename(moment.get("title") or "moment", 70).strip("« »\"'")
    title = sanitize_filename(title, 70)
    tag = "9x16" if fmt == "vertical" else "16x9"
    return f"{vod_date(meta)}_{fmt_tag(moment['start'])}_{title}_{tag}.mp4"


def _encoder_args(cfg, height: int) -> tuple[list, str]:
    choice = cfg.get("encoder") or "auto"
    use_nvenc = choice == "nvenc" or (choice == "auto" and tools.nvenc_available())
    if use_nvenc:
        return (["-c:v", "h264_nvenc", "-preset", "p5", "-tune", "hq", "-rc", "vbr", "-cq", "21", "-b:v", "0",
                 "-maxrate", "25M", "-bufsize", "50M", "-profile:v", "high", "-pix_fmt", "yuv420p"], "nvenc")
    return (["-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-profile:v", "high",
             "-pix_fmt", "yuv420p"], "x264")


def webcam_layout(cfg) -> tuple[list[float], int, int]:
    """Webcam rectangle in the source picture (x, y, w, h as fractions), height of the webcam
    band in the 9:16 clip, horizontal position (0..100) of the game part."""
    try:
        x, y, w, h = (float(v) for v in (cfg.get("webcam_rect") or [0.70, 0.03, 0.28, 0.30])[:4])
    except (TypeError, ValueError):
        x, y, w, h = 0.70, 0.03, 0.28, 0.30
    w = max(0.05, min(1.0, w))
    h = max(0.05, min(1.0, h))
    x = max(0.0, min(1.0 - w, x))
    y = max(0.0, min(1.0 - h, y))
    split = max(15, min(60, int(cfg.get("webcam_split") or 35)))
    pos = max(0, min(100, int(cfg.get("webcam_game_pos") if cfg.get("webcam_game_pos") is not None else 50)))
    return [x, y, w, h], split, pos


def build_filter(fmt: str, info: dict, cfg, with_subs: bool) -> tuple[str, int, int]:
    src_h = int(info.get("height") or 1080)
    if fmt == "vertical":
        W, H = 1080, 1920
        style = cfg.get("vertical_style") or "blur"
        if style == "crop":
            pos = max(0, min(100, int(cfg.get("crop_position") or 50))) / 100.0
            chain = (f"[0:v]crop=w='min(iw,ih*9/16)':h=ih:x='(iw-min(iw,ih*9/16))*{pos:.3f}':y=0,"
                     f"scale={W}:{H}:flags=lanczos,setsar=1[v0]")
        elif style == "webcam":
            (x, y, w, h), split, pos = webcam_layout(cfg)
            top = int(round(H * split / 100 / 2)) * 2
            bot = H - top
            gw = f"min(iw,ih*{W}/{bot})"
            chain = (f"[0:v]split=2[cam][game];"
                     f"[cam]crop=w=iw*{w:.4f}:h=ih*{h:.4f}:x=iw*{x:.4f}:y=ih*{y:.4f},"
                     f"scale={W}:{top}:force_original_aspect_ratio=increase:flags=lanczos,crop={W}:{top}[c];"
                     f"[game]crop=w='{gw}':h=ih:x='(iw-{gw})*{pos / 100:.3f}':y=0,"
                     f"scale={W}:{bot}:force_original_aspect_ratio=increase:flags=lanczos,crop={W}:{bot}[g];"
                     f"[c][g]vstack=inputs=2,setsar=1[v0]")
        else:
            chain = (f"[0:v]split=2[bg][fg];"
                     f"[bg]scale=270:480:force_original_aspect_ratio=increase,crop=270:480,gblur=sigma=12,"
                     f"scale={W}:{H},eq=brightness=-0.07:saturation=1.1[bgb];"
                     f"[fg]scale={W}:-2:flags=lanczos[fgs];"
                     f"[bgb][fgs]overlay=(W-w)/2:(H-h)/2,setsar=1[v0]")
    else:
        H = 1080 if src_h >= 1000 else (720 if src_h >= 700 else max(360, src_h - src_h % 2))
        W = int(round(H * 16 / 9 / 2)) * 2
        chain = (f"[0:v]scale={W}:{H}:force_original_aspect_ratio=decrease:flags=lanczos,"
                 f"pad={W}:{H}:(ow-iw)/2:(oh-ih)/2,setsar=1[v0]")
    if with_subs:
        chain += ";[v0]subtitles=subs.ass:fontsdir=fonts[v]"
    else:
        chain += ";[v0]null[v]"
    return chain, W, H


def title_position(fmt: str, info: dict, cfg, W: int, H: int) -> int:
    """Where the burned-in title goes (centre height in the clip)."""
    if fmt != "vertical":
        return int(H * 0.09)
    style = cfg.get("vertical_style") or "blur"
    if style == "webcam":
        _r, split, _p = webcam_layout(cfg)
        return int(H * split / 100) + int(H * 0.055)
    if style == "crop":
        return int(H * 0.12)
    sw, sh = float(info.get("width") or 16), float(info.get("height") or 9)
    band = (H - W * sh / max(1.0, sw)) / 2
    return int(band / 2) if band > 160 else int(H * 0.12)


def clip_words(ref: VodRef, moment: dict, a: float, b: float) -> list:
    """The words shown as subtitles: the transcript, or the text you corrected for this clip."""
    tp = find_transcript(ref.dir)
    transcript = read_json(tp, None) if tp else None
    custom = (moment.get("subs_text") or "").strip() if moment.get("subs_text") is not None else None
    if custom is None:
        return subtitles.words_from_transcript(transcript, a, b)
    ra, rb = (float(x) for x in (moment.get("subs_range") or [a, b]))
    base = subtitles.words_from_transcript(transcript, ra, rb)
    base = [w for w in base if w[1] > ra and w[0] < rb]
    timed = subtitles.retime(base, custom, ra, rb) if custom else []
    # the clip may have been made longer after the text was corrected: keep the transcript there
    outside = [w for w in subtitles.words_from_transcript(transcript, a, b) if w[1] <= ra + 0.05 or w[0] >= rb - 0.05]
    words = sorted(outside + timed, key=lambda w: w[0])
    return [w for w in words if w[1] > a and w[0] < b]


def export_moment(ref: VodRef, cfg, moment: dict, fmt: str, out_dir: Path,
                  progress: Callable[[float, str], None], cancel: Optional[threading.Event] = None) -> Path:
    a, b = float(moment["start"]), float(moment["end"])
    if b - a < 1.0:
        raise UserError("err_clip_too_short")
    progress(0.0, "source")
    src = media.get_segment(ref, cfg, a, b, "export", lambda f, m="": progress(0.4 * f, "source"), cancel)
    src_path = Path(src["path"])
    rel = max(0.0, a - float(src["vod_start"]))
    dur = b - a
    info = tools.probe(src_path)
    if not info.get("has_video"):
        raise UserError("err_no_video")

    with_subs = bool(cfg.get("subtitles"))
    with_title = bool(cfg.get("title_overlay")) and bool(subtitles.clean_title(moment.get("title") or "")) \
        and (fmt == "vertical" or bool(cfg.get("title_overlay_landscape")))
    work = ref.p("tmp", f"export_{moment.get('id', 'm')}_{fmt}")
    shutil.rmtree(work, ignore_errors=True)
    work.mkdir(parents=True, exist_ok=True)
    filt, W, H = build_filter(fmt, info, cfg, with_subs or with_title)
    if with_subs or with_title:
        words = clip_words(ref, moment, a, b) if with_subs else []
        if not words and not with_title:
            filt = filt.replace("subtitles=subs.ass:fontsdir=fonts", "null")
        else:
            ass = subtitles.build_ass(words, a, b, W, H, uppercase=bool(cfg.get("subtitle_uppercase")),
                                      size_pct=int(cfg.get("subtitle_size") or 100),
                                      highlight=cfg.get("subtitle_highlight") or "#FFE14D",
                                      position_pct=int(cfg.get("subtitle_position") or 68) if fmt == "vertical" else None,
                                      max_words=int(cfg.get("subtitle_words") or 3),
                                      title=(moment.get("title") or "") if with_title else "",
                                      title_y=title_position(fmt, info, cfg, W, H))
            (work / "subs.ass").write_text(ass, encoding="utf-8")
            fonts = work / "fonts"
            fonts.mkdir(exist_ok=True)
            for f in (paths.ASSETS / "fonts").glob("*.ttf"):
                shutil.copy2(f, fonts / f.name)

    out_dir.mkdir(parents=True, exist_ok=True)
    final = unique_path(out_dir / clip_filename(ref.meta, moment, fmt))
    tmp_out = work / "out.mp4"
    ff = tools.require("ffmpeg")
    fade_out = max(0.0, dur - 0.25)
    title = (moment.get("title") or "").strip()

    def cmd_for(enc_args: list) -> list:
        cmd = [ff, "-y", "-hide_banner", "-nostdin", "-v", "error", "-ss", f"{rel:.3f}", "-i", str(src_path),
               "-t", f"{dur:.3f}", "-filter_complex", filt, "-map", "[v]"]
        if info.get("has_audio"):
            cmd += ["-map", "0:a:0", "-af", f"afade=t=in:d=0.12,afade=t=out:st={fade_out:.3f}:d=0.25",
                    "-c:a", "aac", "-b:a", "192k", "-ar", "48000"]
        cmd += enc_args + ["-movflags", "+faststart", "-metadata", f"title={title}",
                           "-metadata", f"comment=FireClips {ref.meta.get('vod_id') or ''} @ {fmt_tag(a)}",
                           "-progress", "pipe:1", "-nostats", str(tmp_out)]
        return cmd

    pat = re.compile(r"out_time_(?:us|ms)=(\d+)")

    def on_line(line: str) -> None:
        m = pat.search(line)
        if m:
            t = int(m.group(1)) / 1_000_000
            progress(0.4 + 0.6 * min(1.0, t / max(0.1, dur)), "encode")

    enc_args, enc_name = _encoder_args(cfg, H)
    code, last = run_streaming(cmd_for(enc_args), on_line, cwd=str(work), cancel=cancel)
    if code != 0 and enc_name == "nvenc":
        log.warning("NVENC failed, using the processor: %s", "\n".join(last[-5:]))
        enc_args, enc_name = (["-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p"], "x264")
        code, last = run_streaming(cmd_for(enc_args), on_line, cwd=str(work), cancel=cancel)
    if code != 0 or not tmp_out.exists():
        raise UserError("err_export_failed", "\n".join(last[-8:]))
    shutil.move(str(tmp_out), str(final))
    shutil.rmtree(work, ignore_errors=True)
    progress(1.0, "done")
    return final
