"""Background worker: the window starts this in a separate process for every long job, so the
interface never freezes and a crash in a job cannot take the app down.

    python -m fireclips.worker analyze  --key tw_123
    python -m fireclips.worker export   --key tw_123 --items '[...]' --overrides '{...}'
    python -m fireclips.worker segment  --key tw_123 --start 10 --end 40
    python -m fireclips.worker albion   --key tw_123     (fetch the Albion kills again)
    python -m fireclips.worker albion-check --overrides '{"albion_links": [...]}'
    python -m fireclips.worker selfcheck --plain        (used by the installer)

Talks to the window with one JSON object per line on stdout.
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
import threading
import time
import traceback
from pathlib import Path

from . import __version__, paths
from .config import Config, from_snapshot
from .errors import UserError
from .i18n import set_language, tr
from .util import Cancelled, setup_logging

log = logging.getLogger("fireclips.worker")
_plain = False
_out_lock = threading.Lock()


def emit(ev: str, **data) -> None:
    data["ev"] = ev
    if _plain:
        _plain_print(data)
        return
    line = json.dumps(data, ensure_ascii=False, default=str)
    with _out_lock:
        try:
            sys.stdout.write(line + "\n")
            sys.stdout.flush()
        except (OSError, AttributeError, ValueError):
            pass


_last_plain = {"t": 0.0, "pct": -1}


def _plain_print(d: dict) -> None:
    ev = d.get("ev")
    if ev == "progress":
        pct = int(100 * float(d.get("frac", d.get("overall", 0))))
        now = time.time()
        if pct != _last_plain["pct"] and (now - _last_plain["t"] > 1.0 or pct >= 100):
            _last_plain.update(t=now, pct=pct)
            print(f"   ... {pct} %", flush=True)
    elif ev in ("log", "result", "check"):
        msg = d.get("msg") or d.get("text") or ""
        if msg:
            print("   " + msg, flush=True)
    elif ev == "warning":
        print("   ! " + tr(d.get("code", ""), **(d.get("fmt") or {})), flush=True)
    elif ev == "error":
        print("   X " + tr(d.get("code", "err_unexpected"), **(d.get("fmt") or {})), flush=True)
        if d.get("detail"):
            print("     " + str(d["detail"])[-600:], flush=True)


def _lower_priority() -> None:
    try:
        import psutil
        p = psutil.Process()
        if sys.platform == "win32":
            p.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
        else:
            p.nice(5)
    except Exception:  # noqa: BLE001
        pass


def _cfg(args) -> Config:
    cfg = Config()
    if getattr(args, "overrides", None):
        try:
            snap = cfg.snapshot()
            snap.update(json.loads(args.overrides))
            cfg = from_snapshot(snap)
        except ValueError:
            pass
    set_language(cfg.get("language") or "fr")
    return cfg


def _ref(cfg, args):
    from .store import Library
    work = Path(args.work) if getattr(args, "work", None) else cfg.work_dir
    return Library(work).ref(args.key)


# --------------------------------------------------------------------------- commands

def cmd_analyze(args) -> int:
    from . import pipeline
    cfg = _cfg(args)
    ref = _ref(cfg, args)
    if not ref.dir.exists():
        emit("error", code="err_unexpected", detail=f"unknown VOD {args.key}", fmt={})
        return 1
    try:
        pipeline.analyze(ref, cfg, emit)
        return 0
    except Cancelled:
        return 2
    except Exception:  # noqa: BLE001 - already reported by the pipeline
        return 1


def cmd_transcribe(args) -> int:
    """Child process for the transcription only (so that a graphics card problem or a crash
    can be detected and retried on the processor)."""
    from . import transcribe
    opts = json.loads(args.opts)
    ref_dir = Path(args.work) / "vods" / args.key
    try:
        transcribe.run_transcription(ref_dir, Path(args.audio), float(args.duration), opts,
                                     lambda f, d="": emit("progress", frac=round(f, 4), detail=d),
                                     lambda m: emit("log", msg=m))
        return 0
    except Cancelled:
        return 2
    except UserError as e:
        emit("error", code=e.code, kind="other", detail=e.detail)
        return 1
    except BaseException as e:  # noqa: BLE001
        kind = transcribe.classify_error(e)
        emit("error", code="err_transcribe_failed", kind=kind, detail=f"{type(e).__name__}: {e}"[-1500:])
        log.error("transcription failed: %s", traceback.format_exc())
        return 4 if kind == "oom" else (3 if kind == "cuda" else 1)


def cmd_segment(args) -> int:
    from . import media
    cfg = _cfg(args)
    ref = _ref(cfg, args)
    try:
        seg = media.get_segment(ref, cfg, float(args.start), float(args.end), args.purpose,
                                lambda f, m="": emit("progress", frac=round(f, 3), detail=m))
        emit("result", **seg)
        return 0
    except UserError as e:
        emit("error", code=e.code, detail=e.detail, fmt=e.fmt)
        return 1
    except Exception as e:  # noqa: BLE001
        emit("error", code="err_unexpected", detail=traceback.format_exc()[-2000:], fmt={})
        return 1


def cmd_export(args) -> int:
    from . import export
    cfg = _cfg(args)
    ref = _ref(cfg, args)
    items = json.loads(args.items)
    formats = [f for f in (args.formats or "").split(",") if f in ("landscape", "vertical")]
    if not formats:
        formats = ["vertical"]
    out_dir = Path(args.out) if args.out else cfg.output_dir / export.vod_folder_name(ref.meta)
    jobs = [(it, f) for it in items for f in formats]
    done = []
    failures = 0
    for i, (it, fmt) in enumerate(jobs):
        def prog(f, m="", i=i):
            emit("progress", frac=round((i + f) / len(jobs), 4), item=i, total=len(jobs), detail=m)
        try:
            path = export.export_moment(ref, cfg, it, fmt, out_dir, prog)
            done.append(str(path))
            emit("exported", id=it.get("id"), fmt=fmt, path=str(path))
        except Cancelled:
            return 2
        except UserError as e:
            failures += 1
            emit("warning", code=e.code, detail=e.detail, fmt=e.fmt, id=it.get("id"))
        except Exception:  # noqa: BLE001
            failures += 1
            emit("warning", code="err_export_failed", detail=traceback.format_exc()[-2000:], fmt={}, id=it.get("id"))
    emit("done", files=done, folder=str(out_dir), failures=failures)
    return 0 if done or not jobs else 1


def cmd_albion(args) -> int:
    """Fetch the Albion kills of a VOD again, then update its ranking."""
    from . import albion, scoring
    cfg = _cfg(args)
    ref = _ref(cfg, args)
    if not ref.dir.exists():
        emit("error", code="err_unexpected", detail=f"unknown VOD {args.key}", fmt={})
        return 1
    links = albion.links_for_vod(cfg, ref.meta)
    if not links:
        emit("error", code="err_albion_no_link", detail="", fmt={"channel": ref.meta.get("login") or ""})
        return 1
    try:
        res = albion.fetch_for_vod(ref, cfg, links, lambda f: emit("progress", frac=round(0.9 * f, 4)),
                                   lambda m: emit("log", msg=m))
        if ref.moments() is not None:
            doc = scoring.compute_and_save(ref, cfg)
            ref.set_state(n_kills=sum(1 for k in doc.get("kills") or [] if not k.get("ignored")))
        emit("progress", frac=1.0)
        fails = [e for e in res.get("errors") or [] if e.get("code") != "warn_albion_failed"]
        for e in fails:
            emit("warning", code=e.get("code") or "warn_albion_failed", detail=str(e.get("detail") or ""),
                 fmt={"name": e.get("player", "")})
        if res.get("partial"):
            emit("warning", code="warn_albion_partial", detail="", fmt={})
        emit("result", n=len(res["events"]), partial=bool(res.get("partial")),
             errors=len(res.get("errors") or []), players=res.get("players") or [])
        return 0
    except albion.AlbionError as e:
        emit("error", code=e.code, detail=e.detail, fmt=e.fmt)
        return 1
    except Exception:  # noqa: BLE001
        emit("error", code="err_unexpected", detail=traceback.format_exc()[-2000:], fmt={})
        return 1


def cmd_albion_check(args) -> int:
    """Find the Albion players of the settings (name -> id, guild, fame)."""
    from . import albion
    cfg = _cfg(args)
    root = albion.data_root(cfg)
    out = []
    for link in albion.clean_links(cfg.get("albion_links")):
        try:
            info = albion.resolve_player(root, link["region"], link["player"], max_age=0)
            out.append(dict(link, ok=True, name=info["name"], guild=info.get("guild", ""),
                            kill_fame=info.get("kill_fame", 0), death_fame=info.get("death_fame", 0), id=info["id"]))
        except albion.AlbionError as e:
            out.append(dict(link, ok=False, code=e.code, detail=e.detail))
    emit("result", players=out)
    return 0


def cmd_test_ai(args) -> int:
    from . import llm
    cfg = _cfg(args)
    try:
        answer = llm.test_provider(cfg)
        emit("result", text=answer)
        return 0
    except UserError as e:
        emit("error", code=e.code, detail=e.detail, fmt=e.fmt)
        return 1
    except Exception as e:  # noqa: BLE001
        emit("error", code="err_ai_request", detail=str(e), fmt={})
        return 1


def cmd_ollama_pull(args) -> int:
    from . import llm
    cfg = _cfg(args)
    prov = llm.OllamaProvider(cfg.get("ollama_url") or "", args.model or cfg.get("ollama_model") or "")
    if not prov.available():
        emit("error", code="err_ollama_down", detail="", fmt={})
        return 1
    try:
        prov.pull(lambda f, s="": emit("progress", frac=round(f, 4), detail=s))
        emit("result", text=prov.model)
        return 0
    except UserError as e:
        emit("error", code=e.code, detail=e.detail, fmt=e.fmt)
        return 1


def cmd_download_model(args) -> int:
    from . import transcribe
    cfg = _cfg(args)
    name = args.model
    if not name or name == "auto":
        name = transcribe.auto_settings(cfg)["model"]
    emit("log", msg=tr("plain_model", name=name, size=transcribe.MODELS.get(name, {}).get("mb", "?")))
    try:
        transcribe.download_model(name, lambda f, m="": emit("progress", frac=round(f, 4)))
        emit("result", text=name, msg=tr("plain_ok"))
        return 0
    except UserError as e:
        emit("error", code=e.code, detail=e.detail, fmt=e.fmt)
        return 1


def cmd_selfcheck(args) -> int:
    """Check that everything needed is installed and working."""
    from . import tools, transcribe
    cfg = _cfg(args)
    ok = True

    def line(good: bool, text: str):
        nonlocal ok
        ok = ok and good
        emit("check", ok=good, msg=("OK   " if good else "!!   ") + text)

    for t in ("ffmpeg", "ffprobe", "tdcli", "ytdlp"):
        p = tools.find(t)
        line(p is not None, f"{t}: {p or tr('check_missing')}")
    g = tools.best_gpu()
    if g:
        line(True, f"GPU: {g.name} ({g.vram_mb} Mo), driver {g.driver}")
    else:
        emit("check", ok=True, msg="--   " + tr("check_no_gpu"))
    opts = transcribe.auto_settings(cfg)
    line(transcribe.model_ready(opts["model"]), f"Whisper {opts['model']}: "
         + (tr("check_ready") if transcribe.model_ready(opts["model"]) else tr("check_missing")))
    if g and transcribe.model_ready(opts["model"]):
        try:
            import numpy as np
            tr_ = transcribe.Transcriber(dict(opts, batch_size=1))
            tr_.load()
            tr_.transcribe_window(np.zeros(16000 * 2, dtype=np.int16))
            line(True, tr("check_cuda_ok", compute=tr_.opts["compute_type"]))
        except Exception as e:  # noqa: BLE001
            line(False, tr("check_cuda_fail") + f" ({type(e).__name__}: {str(e)[:200]})")
    try:
        from .signals import _yamnet_session
        _yamnet_session()
        line(True, tr("check_laugh_ok"))
    except Exception as e:  # noqa: BLE001
        line(False, f"YAMNet: {e}")
    if g and tools.find("ffmpeg"):
        line(tools.nvenc_available() or True, "NVENC: " + (tr("check_ready") if tools.nvenc_available()
                                                        else tr("check_nvenc_no")))
    emit("result", ok=ok, text="OK" if ok else "PROBLEM")
    return 0 if ok else 1


def cmd_update_tools(args) -> int:
    """Update yt-dlp and TwitchDownloaderCLI (Twitch changes often break old versions)."""
    from . import tools
    from .util import run_streaming
    _cfg(args)
    ok = True
    yt = tools.find("ytdlp")
    if yt:
        code, last = run_streaming([yt, "-U"], lambda l: emit("log", msg="yt-dlp: " + l))
        ok = ok and code == 0
    td = tools.find("tdcli")
    if td:
        code, last = run_streaming([td, "update", "--force"], lambda l: emit("log", msg="TwitchDownloaderCLI: " + l))
        ok = ok and code == 0
    emit("result", ok=ok)
    return 0 if ok else 1


def main(argv=None) -> int:
    global _plain
    ap = argparse.ArgumentParser(prog="fireclips.worker")
    ap.add_argument("command")
    ap.add_argument("--key")
    ap.add_argument("--work")
    ap.add_argument("--audio")
    ap.add_argument("--duration")
    ap.add_argument("--opts")
    ap.add_argument("--start")
    ap.add_argument("--end")
    ap.add_argument("--purpose", default="preview")
    ap.add_argument("--items")
    ap.add_argument("--formats")
    ap.add_argument("--out")
    ap.add_argument("--model")
    ap.add_argument("--overrides")
    ap.add_argument("--plain", action="store_true")
    args = ap.parse_args(argv)
    _plain = args.plain
    import os
    os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")
    os.environ.setdefault("DO_NOT_TRACK", "1")
    setup_logging("worker")
    paths.ensure_dirs()
    if args.command in ("analyze", "transcribe", "export"):
        _lower_priority()
    cmds = {"analyze": cmd_analyze, "transcribe": cmd_transcribe, "segment": cmd_segment, "export": cmd_export,
            "test-ai": cmd_test_ai, "ollama-pull": cmd_ollama_pull, "download-model": cmd_download_model,
            "selfcheck": cmd_selfcheck, "update-tools": cmd_update_tools, "albion": cmd_albion,
            "albion-check": cmd_albion_check}
    fn = cmds.get(args.command)
    if fn is None:
        emit("error", code="err_unexpected", detail=f"unknown command {args.command}", fmt={})
        return 1
    log.info("worker %s %s (v%s)", args.command, args.key or "", __version__)
    return fn(args)


if __name__ == "__main__":
    sys.exit(main())
