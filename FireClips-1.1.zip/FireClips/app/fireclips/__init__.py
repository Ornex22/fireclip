"""FireClips - finds the funniest moments in Twitch VODs and turns them into clips."""

__version__ = "1.1.0"
APP_NAME = "FireClips"
