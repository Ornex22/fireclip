"""Trigger phrases ("phrases-clés"): say a sentence on stream, for example
« Twitch clip me the last 5 min », and FireClips makes a clip of the 5 minutes before it.

The phrase is looked for in the transcript once the VOD is analysed (after the stream). The
search is fuzzy, because the transcription may write "Twitch, clip me the last five minutes",
"Twitch clipe les 5 dernières minutes" or "twitchclip me de last 5 min". A duration said in
the sentence ("the last 2 minutes", "les 30 dernières secondes", "la dernière minute") replaces
the default duration of the phrase.
"""
from __future__ import annotations

import re
from difflib import SequenceMatcher
from functools import lru_cache
from typing import Optional

from .util import strip_accents

_NUMBERS = {
    "zero": 0, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9,
    "ten": 10, "eleven": 11, "twelve": 12, "thirteen": 13, "fourteen": 14, "fifteen": 15, "sixteen": 16,
    "seventeen": 17, "eighteen": 18, "nineteen": 19, "twenty": 20, "thirty": 30, "forty": 40, "fourty": 40,
    "fifty": 50, "sixty": 60, "ninety": 90,
    "un": 1, "une": 1, "deux": 2, "trois": 3, "quatre": 4, "cinq": 5, "six": 6, "sept": 7, "huit": 8, "neuf": 9,
    "dix": 10, "onze": 11, "douze": 12, "treize": 13, "quatorze": 14, "quinze": 15, "seize": 16, "vingt": 20,
    "trente": 30, "quarante": 40, "cinquante": 50, "soixante": 60,
    "a": 1, "an": 1, "couple": 2, "few": 3, "quelques": 3,
}
_TENS = {20, 30, 40, 50, 60, 90}
_UNITS = {"min": 60, "mins": 60, "minute": 60, "minutes": 60, "mn": 60, "mns": 60, "m": 60,
          "sec": 1, "secs": 1, "second": 1, "seconds": 1, "seconde": 1, "secondes": 1, "s": 1,
          "h": 3600, "hr": 3600, "hrs": 3600, "hour": 3600, "hours": 3600, "heure": 3600, "heures": 3600}
_SINGULAR = {"min", "minute", "mn", "m", "sec", "second", "seconde", "s", "h", "hour", "heure", "hr"}
# words that can sit between the number and the unit ("5 dernières minutes", "5 last minutes")
_FILLERS = {"dernieres", "derniere", "last", "past", "petites", "petite", "bonnes", "bonne", "full", "of", "de"}
_HALF = {"half", "demi", "demie"}


def tokens(text: str) -> list[str]:
    """Lowercase words without accents or punctuation; '5min' -> '5', 'min'."""
    t = strip_accents((text or "").lower())
    t = re.sub(r"(\d)([a-z])", r"\1 \2", t)
    t = re.sub(r"([a-z])(\d)", r"\1 \2", t)
    t = re.sub(r"[’'`´\-]", " ", t)
    t = re.sub(r"[^a-z0-9 ]+", " ", t)
    return t.split()


def _number_at(toks: list[str], i: int) -> tuple[Optional[float], int]:
    """A number written in digits or words starting at toks[i]: (value, tokens used)."""
    if i >= len(toks):
        return None, 0
    t = toks[i]
    if t.isdigit():
        return float(t), 1
    if t in _NUMBERS:
        v = _NUMBERS[t]
        if v in _TENS and i + 1 < len(toks):
            nxt = toks[i + 1]
            if nxt == "et" and i + 2 < len(toks) and toks[i + 2] in ("un", "une"):   # vingt et un
                return float(v + 1), 3
            if nxt in _NUMBERS and 0 < _NUMBERS[nxt] < 10 and nxt not in ("a", "an", "un", "une"):
                return float(v + _NUMBERS[nxt]), 2
        return float(v), 1
    return None, 0


def _with_half(toks: list[str], secs: float, unit: float, stop: int) -> tuple[float, int]:
    """'... minute et demie' / '... minute and a half' / '2 minutes 30'."""
    if stop + 1 < len(toks) and toks[stop] in ("et", "and"):
        if toks[stop + 1] in _HALF:
            return secs + unit / 2, stop + 2
        if stop + 2 < len(toks) and toks[stop + 1] == "a" and toks[stop + 2] in _HALF:
            return secs + unit / 2, stop + 3
    if unit == 60 and stop < len(toks) and toks[stop].isdigit() and int(toks[stop]) < 60:
        return secs + int(toks[stop]), stop + 1
    return secs, stop


def parse_duration(toks: list[str], start: int = 0, limit: int = 12) -> Optional[tuple[float, int, int]]:
    """First duration in toks[start:start+limit]: (seconds, first token, end token) or None.
    "5 min", "five minutes", "les 5 dernières minutes", "30 sec", "la dernière minute",
    "une minute et demie", "half a minute", "2 minutes 30"."""
    end = min(len(toks), start + limit)
    i = start
    while i < end:
        val, used = _number_at(toks, i)
        j = i + used
        if val is not None:
            k = j
            while k < end and toks[k] in _FILLERS:
                k += 1
            if k < end and toks[k] in _UNITS and not (toks[i] in ("a", "an", "un", "une") and toks[k] not in _SINGULAR):
                unit = _UNITS[toks[k]]
                secs, stop = _with_half(toks, val * unit, unit, k + 1)
                return secs, i, stop
        t = toks[i]
        # "half a minute", "une demi minute"
        if t in _HALF:
            k = i + 1
            if k < end and toks[k] in ("a", "an"):
                k += 1
            if k < end and toks[k] in _UNITS:
                return _UNITS[toks[k]] / 2, i, k + 1
        # "the last minute" / "la dernière minute" (one minute, no number said)
        if t in ("last", "derniere", "past") and i + 1 < end and toks[i + 1] in _SINGULAR and toks[i + 1] in _UNITS:
            unit = _UNITS[toks[i + 1]]
            secs, stop = _with_half(toks, float(unit), unit, i + 2)
            return secs, i, stop
        if t in _SINGULAR and t in _UNITS and t not in ("m", "s", "h") and i > 0 and toks[i - 1] in ("derniere", "last"):
            unit = _UNITS[t]
            secs, stop = _with_half(toks, float(unit), unit, i + 1)
            return secs, i - 1, stop
        i += 1
    return None


def phrase_key(text: str) -> tuple[list[str], Optional[float]]:
    """The words to look for (the phrase without its duration) and the duration it contains."""
    toks = tokens(text)
    d = parse_duration(toks, 0, len(toks))
    if d is None:
        return toks, None
    secs, a, b = d
    key = toks[:a] + toks[b:]
    # "les 5 dernières minutes": the filler words belong to the duration
    while key and key[-1] in _FILLERS | {"les", "the", "la", "le"} and len(key) > 2:
        key = key[:-1]
    return key, secs


@lru_cache(maxsize=50000)
def _similar(a: str, b: str) -> bool:
    if a == b:
        return True
    if not a or not b or a[0] != b[0]:
        return False
    if len(a) >= 4 and len(b) >= 4 and a[:4] == b[:4]:
        return True
    return SequenceMatcher(None, a, b).ratio() >= 0.72


def transcript_tokens(transcript: Optional[dict]) -> list[tuple[float, float, str]]:
    """Every word of the transcript as normalised tokens with their times."""
    from .subtitles import words_from_transcript
    out = []
    for s, e, text in words_from_transcript(transcript, float("-inf"), float("inf")):
        toks = tokens(text)
        if not toks:
            continue
        step = (e - s) / len(toks)
        for i, t in enumerate(toks):
            out.append((s + i * step, s + (i + 1) * step, t))
    return out


def find(transcript: Optional[dict], phrases: list, max_seconds: float = 600.0,
         words: Optional[list] = None) -> list[dict]:
    """All the times a trigger phrase was said. Returns
    [{"said_at", "said_end", "seconds", "spoken", "phrase", "heard", "match"}] sorted by time."""
    W = words if words is not None else transcript_tokens(transcript)
    if not W:
        return []
    toks = [w[2] for w in W]
    found: list[dict] = []
    for ph in phrases or []:
        if isinstance(ph, str):
            ph = {"text": ph}
        text = str(ph.get("text") or "").strip()
        if not text:
            continue
        key, in_phrase = phrase_key(text)
        if len(key) < 2:
            continue
        try:
            default = float(ph.get("seconds") or in_phrase or 300)
        except (TypeError, ValueError):
            default = 300.0
        k = len(key)
        key_s = " ".join(key)
        need = 0.86 if k <= 3 else 0.78
        # "twitch clip ..." could be said in a normal sentence: when the phrase contains a duration,
        # a duration (or at least "minutes" / "secondes") must be said right after for it to count
        need_duration = in_phrase is not None
        anchors = (key[0], key[1])
        best_at: dict[int, tuple] = {}
        for i, t in enumerate(toks):
            for shift, anchor in enumerate(anchors):
                if not _similar(t, anchor):
                    continue
                st = i - shift
                if st < 0:
                    continue
                for L in (k - 1, k, k + 1, k + 2):
                    if L < 2 or st + L > len(toks):
                        continue
                    cand = " ".join(toks[st:st + L])
                    r = SequenceMatcher(None, key_s, cand, autojunk=False).ratio()
                    if r >= need and (st not in best_at or r > best_at[st][0]):
                        best_at[st] = (r, L)
        for st, (r, L) in best_at.items():
            said_at, said_end = W[st][0], W[st + L - 1][1]
            d = parse_duration(toks, st, L + 8)
            seconds, spoken = default, False
            if d is not None:
                secs, a, b = d
                if W[min(len(W) - 1, a)][0] - said_end <= 6.0 and secs >= 5:
                    seconds, spoken = secs, True
                    said_end = max(said_end, W[b - 1][1])
            if need_duration and not spoken:
                # the number was not understood ("the last fife minutes"): a time unit right after
                # the phrase is enough, with the phrase's own duration
                unit_at = next((j for j in range(st + L, min(len(toks), st + L + 5))
                                if toks[j] in _UNITS and len(toks[j]) >= 3), None)
                if unit_at is None or W[unit_at][0] - said_end > 6.0:
                    continue
            seconds = max(5.0, min(float(max_seconds or 600), seconds))
            found.append({"said_at": round(said_at, 2), "said_end": round(said_end, 2), "seconds": seconds,
                          "spoken": spoken, "phrase": text, "match": round(r, 3),
                          "heard": " ".join(toks[st:st + L])})
    # the same moment found several times (overlapping windows, two similar phrases): keep the best
    found.sort(key=lambda f: (-f["match"], f["said_at"]))
    kept: list[dict] = []
    for f in found:
        if all(abs(f["said_at"] - g["said_at"]) > 8.0 for g in kept):
            kept.append(f)
    kept.sort(key=lambda f: f["said_at"])
    return kept
