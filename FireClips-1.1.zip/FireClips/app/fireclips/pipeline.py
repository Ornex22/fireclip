"""The analysis of one VOD, step by step. Every step saves its result, so if the PC crashes or
the app is closed, "Resume" continues from the last finished step (and the transcription
from the last finished 10-minute piece)."""
from __future__ import annotations

import json
import logging
import os
import subprocess
import sys
import threading
import time
import traceback
from pathlib import Path
from typing import Callable, Optional

from . import albion, llm, media, paths, scoring, signals, store, transcribe, twitch
from .errors import UserError
from .store import VodRef
from .util import Cancelled, kill_tree, no_window_flags, read_json, write_json

log = logging.getLogger("fireclips.pipeline")

Emit = Callable[..., None]

STEPS = [("info", 2), ("download", 12), ("transcribe", 55), ("audio", 4), ("chat", 4), ("ai", 20), ("rank", 3)]
_TOTAL = sum(w for _, w in STEPS)


class Reporter:
    def __init__(self, emit: Emit, ref: VodRef):
        self.emit = emit
        self.ref = ref
        self.warnings: list[dict] = []
        self._last = 0.0
        self._last_state = 0.0

    def progress(self, step: str, frac: float, detail: str = "") -> None:
        before = 0
        weight = 1
        for name, w in STEPS:
            if name == step:
                weight = w
                break
            before += w
        overall = min(0.999, (before + weight * max(0.0, min(1.0, frac))) / _TOTAL)
        now = time.time()
        if now - self._last < 0.25 and frac < 1.0:
            return
        self._last = now
        self.emit("progress", step=step, frac=round(frac, 4), overall=round(overall, 4), detail=detail)
        if now - self._last_state > 5:
            self._last_state = now
            try:
                self.ref.set_state(step=step, progress=round(overall, 4))
            except OSError:
                pass

    def warn(self, code: str, detail: str = "", **fmt) -> None:
        w = {"code": code, "detail": detail[:2000], "fmt": fmt}
        self.warnings.append(w)
        self.emit("warning", **w)
        log.warning("%s %s", code, detail[:500])

    def log(self, msg: str) -> None:
        self.emit("log", msg=msg)
        log.info(msg)


def worker_env() -> dict:
    env = dict(os.environ)
    env["PYTHONPATH"] = str(paths.PACKAGE_DIR.parent) + os.pathsep + env.get("PYTHONPATH", "")
    env["PYTHONUNBUFFERED"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    return env


# --------------------------------------------------------------------------- steps

def step_info(ref: VodRef, cfg, rep: Reporter) -> dict:
    meta = ref.meta
    rep.progress("info", 0.1)
    if ref.kind == "local":
        lp = ref.local_path
        if not lp or not lp.exists():
            raise UserError("err_local_missing", str(lp))
        if not meta.get("duration"):
            meta["duration"] = media.media_duration(lp)
            ref.save_meta(meta)
        if not meta.get("recording_start"):
            # when the recording started (for the Albion kills): OBS file name or file date
            start = albion.local_recording_start(lp, float(meta.get("duration") or 0))
            if start:
                meta["recording_start"] = start
                meta["created_at"] = albion.iso(start)
                ref.save_meta(meta)
    else:
        try:
            info = twitch.get_video_info(ref.vod_id, cfg.get("twitch_oauth") or "")
            meta.update({k: v for k, v in info.items() if v not in (None, "")})
            ref.save_meta(meta)
            if (info.get("status") or "").upper() == "RECORDING":
                rep.warn("warn_still_live")
        except twitch.TwitchError as e:
            if e.code == "err_vod_not_found":
                raise
            rep.warn("warn_info_failed", str(e))
            fallback = media.chat_video_info(ref)
            if fallback:
                meta.update(fallback)
                ref.save_meta(meta)
    rep.progress("info", 1.0)
    return ref.meta


def step_download(ref: VodRef, cfg, rep: Reporter, cancel) -> Path:
    if ref.kind == "local":
        rep.progress("download", 1.0)
        return ref.local_path
    mode = cfg.get("download_mode") or "audio"
    prog = lambda f, m="": rep.progress("download", f, m)  # noqa: E731
    if mode == "full":
        path = media.download_full(ref, cfg, prog, cancel)
    else:
        path = media.download_audio(ref, cfg, prog, cancel)
    rep.progress("download", 1.0)
    return path


def fetch_chat_and_clips(ref: VodRef, cfg, rep: Reporter, cancel) -> None:
    if ref.kind != "twitch":
        return
    try:
        msgs = media.download_chat(ref, cfg, lambda f, m="": rep.emit("side", what="chat", frac=round(f, 3)), cancel)
        rep.log(f"chat: {len(msgs)} messages")
        if len(msgs) < 20:
            rep.warn("warn_chat_small", count=len(msgs))
    except Cancelled:
        return
    except Exception as e:  # noqa: BLE001
        rep.warn("warn_chat_failed", str(e))
    if ref.p("clips.json").exists():
        return
    try:
        m = ref.meta
        login = m.get("login") or m.get("display_name") or ""
        if login:
            clips = twitch.get_vod_clips(ref.vod_id, login, m.get("created_at") or "")
            write_json(ref.p("clips.json"), clips)
            rep.log(f"viewer clips: {len(clips)}")
    except Exception as e:  # noqa: BLE001
        rep.warn("warn_clips_failed", str(e))


def fetch_albion(ref: VodRef, cfg, rep: Reporter, cancel) -> None:
    """Kills / assists / deaths of the linked Albion players during this VOD (albion.json)."""
    links = albion.links_for_vod(cfg, ref.meta)
    if not links:
        return
    old = ref.albion()
    start = albion.vod_start(ref.meta) or 0
    end = start + float(ref.meta.get("duration") or 0)
    if old and time.time() - end > 14 * 86400:
        return   # an old VOD: the API does not know more than last time
    try:
        res = albion.fetch_for_vod(ref, cfg, links, lambda f: rep.emit("side", what="albion", frac=round(f, 3)),
                                   rep.log, cancel)
        rep.log(f"albion: {len(res['events'])} events")
        fails = [e for e in res.get("errors") or [] if e.get("code") != "warn_albion_failed"]
        for e in fails:
            rep.warn(e.get("code") or "warn_albion_failed", str(e.get("detail") or ""), name=e.get("player", ""))
        if not fails and res.get("errors") and not res.get("events"):
            rep.warn("warn_albion_failed", "; ".join(str(e.get("detail")) for e in res["errors"])[:1500])
        if res.get("partial"):
            rep.warn("warn_albion_partial")
    except Cancelled:
        return
    except albion.AlbionError as e:
        rep.warn("warn_albion_failed", f"{e.code}: {e.detail}")
    except Exception as e:  # noqa: BLE001
        rep.warn("warn_albion_failed", str(e))
        log.exception("albion")


def run_audio_features(ref: VodRef, audio: Path, duration: float, rep: Reporter, cancel) -> None:
    out = ref.p("audio_features.npz")
    if out.exists():
        return
    try:
        signals.compute_audio_features(audio, duration, out,
                                       lambda f, m="": rep.emit("side", what="audio", frac=round(f, 3)), cancel)
    except Cancelled:
        return
    except Exception as e:  # noqa: BLE001
        rep.warn("warn_audio_failed", str(e))
        log.exception("audio features")


def _run_transcribe_child(ref: VodRef, work_dir: Path, audio: Path, duration: float, opts: dict, rep: Reporter,
                          cancel) -> tuple[int, str]:
    cmd = [sys.executable, "-m", "fireclips.worker", "transcribe", "--key", ref.key, "--work", str(work_dir),
           "--audio", str(audio), "--duration", str(duration), "--opts", json.dumps(opts)]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, stdin=subprocess.DEVNULL,
                            env=worker_env(), cwd=str(paths.PACKAGE_DIR.parent), creationflags=no_window_flags())
    err_tail: list[str] = []

    def read_err():
        assert proc.stderr is not None
        for raw in proc.stderr:
            line = raw.decode("utf-8", "replace").rstrip()
            if line:
                err_tail.append(line)
                del err_tail[:-40]

    t = threading.Thread(target=read_err, daemon=True)
    t.start()
    kind = ""
    try:
        assert proc.stdout is not None
        for raw in proc.stdout:
            if cancel is not None and cancel.is_set():
                kill_tree(proc.pid)
                raise Cancelled()
            try:
                ev = json.loads(raw.decode("utf-8", "replace"))
            except ValueError:
                continue
            e = ev.get("ev")
            if e == "progress":
                rep.progress("transcribe", float(ev.get("frac", 0)), ev.get("detail", ""))
            elif e == "log":
                rep.log(ev.get("msg", ""))
            elif e == "error":
                kind = ev.get("kind", "") or kind
                err_tail.append(ev.get("detail", "") or ev.get("code", ""))
        code = proc.wait()
    except BaseException:
        kill_tree(proc.pid)
        raise
    t.join(2)
    if code != 0 and not kind:
        kind = "cuda" if opts.get("device") == "cuda" else "other"
    return code, kind + "|" + "\n".join(err_tail[-12:])


def step_transcribe(ref: VodRef, cfg, rep: Reporter, audio: Path, duration: float, cancel) -> Path:
    opts = transcribe.auto_settings(cfg)
    existing = transcribe.transcript_path(ref.dir, opts["model"])
    if existing.exists():
        rep.progress("transcribe", 1.0)
        return existing
    if not transcribe.model_ready(opts["model"]):
        rep.log(f"downloading whisper model {opts['model']}")
        transcribe.download_model(opts["model"], lambda f, m="": rep.progress("transcribe", 0.0, f"model:{int(f * 100)}"),
                                  cancel)
    work_dir = ref.dir.parent.parent
    queue = [opts]
    if opts["device"] == "cuda":
        queue.append(dict(opts, batch_size=2, compute_type="int8_float16"))
        if (cfg.get("whisper_device") or "auto") == "auto":
            queue.append(dict(opts, device="cpu", model="small", compute_type="int8", batch_size=4, beam_size=1))
    last = ""
    gpu_error = ""
    n = 0
    while queue:
        o = queue.pop(0)
        n += 1
        if o["model"] != opts["model"] and not transcribe.model_ready(o["model"]):
            try:
                transcribe.download_model(o["model"], lambda f, m="": rep.progress("transcribe", 0.0,
                                                                                    f"model:{int(f * 100)}"), cancel)
            except Exception as e:  # noqa: BLE001
                last = str(e)
                continue
        code, info = _run_transcribe_child(ref, work_dir, audio, duration, o, rep, cancel)
        if code == 0:
            p = transcribe.transcript_path(ref.dir, o["model"])
            if p.exists():
                if o["device"] == "cpu" and opts["device"] == "cuda":
                    rep.warn("warn_gpu_fallback", gpu_error[-600:])
                return p
        kind, detail = info.split("|", 1)
        last = detail
        rep.log(f"transcription attempt {n} failed ({kind}): {detail[-300:]}")
        if code == 2:
            raise Cancelled()
        if o["device"] == "cpu":
            break
        gpu_error = detail
        if kind != "oom":
            # driver / library problem: a smaller batch will not help, go straight to the processor
            queue = [q for q in queue if q["device"] != "cuda"]
    raise UserError("err_transcribe_failed", last[-1500:])


def step_ai(ref: VodRef, cfg, rep: Reporter, transcript_file: Path, cancel) -> None:
    provider = cfg.get("ai_provider") or "none"
    if provider == "none":
        write_json(ref.p("ai_moments.json"), {"provider": "none", "model": "", "moments": []})
        rep.progress("ai", 1.0)
        return
    transcript = read_json(transcript_file, {}) or {}
    chat = read_json(ref.p("chat_compact.json"), None)
    game_events = albion.map_events(ref.albion(), albion.vod_offset(cfg, ref.albion_settings()),
                                    float(ref.meta.get("duration") or 0))
    try:
        res = llm.analyze(ref, transcript, chat, cfg, lambda f, m="": rep.progress("ai", f, m), rep.log, cancel,
                          game_events=game_events)
        write_json(ref.p("ai_moments.json"), res)
        rep.log(f"AI ({res['provider']} {res['model']}): {len(res['moments'])} moments")
        if res.get("failed_pieces"):
            rep.warn("warn_ai_partial", count=res["failed_pieces"])
    except Cancelled:
        raise
    except UserError as e:
        rep.warn(e.code, e.detail, **e.fmt)
        prev = read_json(ref.p("ai_moments.json"), None)
        if prev is None:
            write_json(ref.p("ai_moments.json"), {"provider": "none", "model": "", "moments": [], "error": e.code})
    except Exception as e:  # noqa: BLE001
        rep.warn("err_ai_request", str(e))
        log.exception("AI step")
    rep.progress("ai", 1.0)


# --------------------------------------------------------------------------- main entry

def analyze(ref: VodRef, cfg, emit: Emit, cancel: Optional[threading.Event] = None) -> dict:
    cancel = cancel or threading.Event()
    rep = Reporter(emit, ref)
    ref.set_state(status="running", pid=os.getpid(), started_at=time.time(), error=None, warnings=[], step="info",
                  progress=0.0)
    side: Optional[threading.Thread] = None
    feat: Optional[threading.Thread] = None
    alb: Optional[threading.Thread] = None
    try:
        meta = step_info(ref, cfg, rep)
        if ref.kind == "twitch":
            side = threading.Thread(target=fetch_chat_and_clips, args=(ref, cfg, rep, cancel), daemon=True)
            side.start()
        alb = threading.Thread(target=fetch_albion, args=(ref, cfg, rep, cancel), daemon=True)
        alb.start()
        audio = step_download(ref, cfg, rep, cancel)
        duration = media.media_duration(audio) or float(meta.get("duration") or 0)
        if duration <= 0:
            raise UserError("err_decode_audio", str(audio))
        if abs(duration - float(meta.get("duration") or 0)) > 2:
            meta = ref.meta
            meta["duration"] = duration
            ref.save_meta(meta)
        feat = threading.Thread(target=run_audio_features, args=(ref, audio, duration, rep, cancel), daemon=True)
        feat.start()
        tfile = step_transcribe(ref, cfg, rep, audio, duration, cancel)
        rep.progress("audio", 0.0)
        while feat.is_alive():
            feat.join(0.5)
            if cancel.is_set():
                raise Cancelled()
        rep.progress("audio", 1.0)
        rep.progress("chat", 0.0)
        for t in (side, alb):
            while t is not None and t.is_alive():
                t.join(0.5)
                if cancel.is_set():
                    raise Cancelled()
        rep.progress("chat", 1.0)
        step_ai(ref, cfg, rep, tfile, cancel)
        rep.progress("rank", 0.2)
        doc = scoring.compute_and_save(ref, cfg)
        rep.progress("rank", 1.0)
        if cfg.get("delete_after"):
            freed = store.free_media(ref)
            rep.log(f"freed {freed / 1e6:.0f} MB")
        ref.set_state(status="done", finished_at=time.time(), progress=1.0, step="done",
                      n_moments=len(doc["moments"]), warnings=rep.warnings, error=None,
                      n_kills=sum(1 for k in doc.get("kills") or [] if not k.get("ignored")))
        try:
            keep = int(cfg.get("keep_vods") or 0)
            if keep > 0:
                store.Library(ref.dir.parent.parent).prune(keep, protect=(ref.key,))
        except Exception:  # noqa: BLE001
            pass
        emit("done", n=len(doc["moments"]), warnings=len(rep.warnings))
        return doc
    except Cancelled:
        cancel.set()
        ref.set_state(status="interrupted", warnings=rep.warnings)
        emit("cancelled")
        raise
    except UserError as e:
        cancel.set()
        ref.set_state(status="error", error={"code": e.code, "detail": e.detail[:3000], "fmt": e.fmt},
                      warnings=rep.warnings)
        emit("error", code=e.code, detail=e.detail[:3000], fmt=e.fmt)
        raise
    except Exception as e:  # noqa: BLE001
        cancel.set()
        tb = traceback.format_exc()
        log.error("analysis failed: %s", tb)
        ref.set_state(status="error", error={"code": "err_unexpected", "detail": tb[-3000:], "fmt": {}},
                      warnings=rep.warnings)
        emit("error", code="err_unexpected", detail=tb[-3000:], fmt={})
        raise
