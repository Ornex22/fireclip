"""AI analysis of the transcript: Claude (Anthropic), OpenAI (or any OpenAI-compatible service)
or a local model through Ollama. The AI reads the transcript piece by piece and returns the
funny moments with a title, a score and a short reason. Answers are cached, so re-running an
analysis never pays twice for the same piece."""
from __future__ import annotations

import hashlib
import json
import logging
import re
import threading
import time
from typing import Callable, Optional

import requests

from .errors import UserError
from .util import Cancelled, fmt_hms, parse_time, read_json, write_json

log = logging.getLogger("fireclips.llm")

PROMPT_VERSION = 3
CATEGORIES = ["joke", "banter", "fail", "rage", "absurd", "story", "reaction", "other"]

SCHEMA = {
    "type": "object",
    "properties": {
        "moments": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "start": {"type": "string", "description": "H:MM:SS of the first transcript line of the moment"},
                    "end": {"type": "string", "description": "H:MM:SS of the last transcript line of the moment"},
                    "title": {"type": "string", "description": "short catchy clip title"},
                    "score": {"type": "integer", "description": "funniness from 0 to 10"},
                    "category": {"type": "string", "enum": CATEGORIES},
                    "reason": {"type": "string", "description": "one short sentence: why it is funny"},
                },
                "required": ["start", "end", "title", "score", "category", "reason"],
                "additionalProperties": False,
            },
        }
    },
    "required": ["moments"],
    "additionalProperties": False,
}


class AIError(UserError):
    pass


# --------------------------------------------------------------------------- providers

def _post(url: str, headers: dict, body: dict, timeout: float, cancel: Optional[threading.Event]) -> requests.Response:
    if cancel is not None and cancel.is_set():
        raise Cancelled()
    try:
        return requests.post(url, headers=headers, json=body, timeout=timeout)
    except requests.RequestException as e:
        raise AIError("err_ai_network", str(e)) from e


def _extract_json(text: str) -> dict:
    text = (text or "").strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text)
    try:
        return json.loads(text)
    except ValueError:
        m = re.search(r"\{.*\}", text, re.S)
        if m:
            try:
                return json.loads(m.group(0))
            except ValueError:
                pass
    raise AIError("err_ai_bad_answer", text[:300])


def _err_text(r: requests.Response) -> str:
    try:
        d = r.json()
        if isinstance(d, dict):
            e = d.get("error")
            if isinstance(e, dict):
                return str(e.get("message") or e)
            if e:
                return str(e)
        return json.dumps(d)[:500]
    except ValueError:
        return (r.text or "")[:500]


class Provider:
    name = "?"
    retries = 4

    def __init__(self, model: str):
        self.model = model

    def _call(self, system: str, user: str, schema: dict, max_tokens: int, cancel) -> dict:
        raise NotImplementedError

    def complete_json(self, system: str, user: str, schema: dict = SCHEMA, max_tokens: int = 3000,
                      cancel: Optional[threading.Event] = None) -> dict:
        delay = 3.0
        for attempt in range(self.retries):
            try:
                return self._call(system, user, schema, max_tokens, cancel)
            except AIError as e:
                retryable = e.code in ("err_ai_busy", "err_ai_network")
                if not retryable or attempt == self.retries - 1:
                    raise
                wait = float(e.fmt.get("retry_after") or delay)
                log.info("AI busy/unreachable (%s), retrying in %.0fs", e.code, wait)
                end = time.time() + min(90.0, wait)
                while time.time() < end:
                    if cancel is not None and cancel.is_set():
                        raise Cancelled()
                    time.sleep(0.25)
                delay = min(60.0, delay * 2.5)
        raise AIError("err_ai_busy")

    def _http_error(self, r: requests.Response) -> AIError:
        msg = _err_text(r)
        low = msg.lower()
        if r.status_code in (401, 403):
            return AIError("err_ai_key", msg)
        if r.status_code == 404 or "model" in low and ("not found" in low or "does not exist" in low):
            return AIError("err_ai_model", msg, model=self.model)
        if r.status_code == 429:
            if any(k in low for k in ("credit", "billing", "quota", "spend", "insufficient")):
                return AIError("err_ai_quota", msg)
            ra = r.headers.get("retry-after")
            try:
                ra_v = float(ra) if ra else 0.0
            except ValueError:
                ra_v = 0.0
            return AIError("err_ai_busy", msg, retry_after=ra_v)
        if r.status_code >= 500 or r.status_code == 529:
            return AIError("err_ai_busy", msg)
        if r.status_code == 402 or "credit balance" in low:
            return AIError("err_ai_quota", msg)
        return AIError("err_ai_request", f"HTTP {r.status_code}: {msg}")


class AnthropicProvider(Provider):
    name = "anthropic"
    URL = "https://api.anthropic.com/v1/messages"

    def __init__(self, key: str, model: str):
        super().__init__(model or "claude-sonnet-5-5")
        if not key.strip():
            raise AIError("err_ai_no_key")
        self.key = key.strip()
        self.use_schema = True

    def _call(self, system, user, schema, max_tokens, cancel):
        body = {"model": self.model, "max_tokens": max_tokens, "system": system,
                "messages": [{"role": "user", "content": user}]}
        if self.use_schema:
            body["output_config"] = {"format": {"type": "json_schema", "schema": schema}}
        else:
            body["system"] = system + "\n\nAnswer with the JSON object only."
        headers = {"x-api-key": self.key, "anthropic-version": "2023-06-01", "content-type": "application/json"}
        r = _post(self.URL, headers, body, 180, cancel)
        if r.status_code == 400 and "output_config" in body and "output_config" in _err_text(r):
            self.use_schema = False
            return self._call(system, user, schema, max_tokens, cancel)
        if r.status_code != 200:
            raise self._http_error(r)
        data = r.json()
        if data.get("stop_reason") == "refusal":
            return {"moments": []}
        text = "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")
        return _extract_json(text)


class OpenAIProvider(Provider):
    name = "openai"

    def __init__(self, key: str, model: str, base_url: str = "https://api.openai.com/v1"):
        super().__init__(model or "gpt-6-luna")
        self.base = (base_url or "https://api.openai.com/v1").rstrip("/")
        self.key = key.strip()
        if not self.key and "api.openai.com" in self.base:
            raise AIError("err_ai_no_key")
        self.params = {"reasoning_effort": "low", "max_completion_tokens": None, "schema": True}

    def _call(self, system, user, schema, max_tokens, cancel):
        body: dict = {"model": self.model,
                      "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}]}
        if self.params["schema"]:
            body["response_format"] = {"type": "json_schema",
                                       "json_schema": {"name": "funny_moments", "schema": schema, "strict": True}}
        else:
            body["response_format"] = {"type": "json_object"}
            body["messages"][0]["content"] = system + "\n\nAnswer with a JSON object only."
        if self.params["max_completion_tokens"] is not False:
            body["max_completion_tokens"] = max_tokens
        else:
            body["max_tokens"] = max_tokens
        if self.params["reasoning_effort"]:
            body["reasoning_effort"] = self.params["reasoning_effort"]
        headers = {"Authorization": f"Bearer {self.key}", "Content-Type": "application/json"}
        r = _post(self.base + "/chat/completions", headers, body, 240, cancel)
        if r.status_code == 400:
            # some models / compatible services refuse some parameters: drop the one named in the
            # error (looking at what THIS request sent, other requests may run at the same time)
            low = _err_text(r).lower()
            changed = False
            if "reasoning_effort" in low and "reasoning_effort" in body:
                self.params["reasoning_effort"] = None
                changed = True
            elif "max_completion_tokens" in low and "max_completion_tokens" in body:
                self.params["max_completion_tokens"] = False
                changed = True
            elif ("response_format" in low or "json_schema" in low) and \
                    body.get("response_format", {}).get("type") == "json_schema":
                self.params["schema"] = False
                changed = True
            if changed:
                return self._call(system, user, schema, max_tokens, cancel)
        if r.status_code != 200:
            raise self._http_error(r)
        data = r.json()
        try:
            content = data["choices"][0]["message"].get("content") or ""
        except (KeyError, IndexError, TypeError):
            raise AIError("err_ai_bad_answer", json.dumps(data)[:300])
        return _extract_json(content)


class OllamaProvider(Provider):
    name = "ollama"
    retries = 3

    def __init__(self, url: str, model: str, num_ctx: int = 8192):
        super().__init__(model or "qwen3.5:9b")
        self.base = (url or "http://localhost:11434").rstrip("/")
        self.num_ctx = num_ctx
        self.think_param = True
        self.schema_ok = True

    def available(self) -> bool:
        try:
            return requests.get(self.base + "/api/version", timeout=4).status_code == 200
        except requests.RequestException:
            return False

    def installed_models(self) -> list[str]:
        r = requests.get(self.base + "/api/tags", timeout=10)
        r.raise_for_status()
        return [m.get("name", "") for m in r.json().get("models", [])]

    def has_model(self) -> bool:
        names = self.installed_models()
        want = self.model if ":" in self.model else self.model + ":latest"
        return any(n == want or n == self.model for n in names)

    def pull(self, progress: Callable[[float, str], None], cancel: Optional[threading.Event] = None) -> None:
        with requests.post(self.base + "/api/pull", json={"model": self.model, "stream": True}, stream=True,
                           timeout=(10, 600)) as r:
            if r.status_code != 200:
                raise AIError("err_ai_model", _err_text(r), model=self.model)
            for raw in r.iter_lines():
                if cancel is not None and cancel.is_set():
                    raise Cancelled()
                if not raw:
                    continue
                try:
                    ev = json.loads(raw)
                except ValueError:
                    continue
                if ev.get("error"):
                    raise AIError("err_ai_model", ev["error"], model=self.model)
                tot, done = ev.get("total"), ev.get("completed")
                if tot and done is not None:
                    progress(min(0.99, done / tot), ev.get("status", ""))
                if ev.get("status") == "success":
                    progress(1.0, "success")

    def unload(self) -> None:
        try:
            requests.post(self.base + "/api/chat", json={"model": self.model, "messages": [], "keep_alive": 0},
                          timeout=10)
        except requests.RequestException:
            pass

    def _call(self, system, user, schema, max_tokens, cancel):
        body = {"model": self.model, "stream": False, "keep_alive": "3m",
                "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
                "options": {"num_ctx": self.num_ctx, "temperature": 0.3, "num_predict": max_tokens},
                "format": schema if self.schema_ok else "json"}
        if self.think_param:
            body["think"] = False
        try:
            r = _post(self.base + "/api/chat", {"Content-Type": "application/json"}, body, 900, cancel)
        except AIError as e:
            raise AIError("err_ollama_down", e.detail) from e
        if r.status_code == 400:
            low = _err_text(r).lower()
            if "think" in low and "think" in body:
                self.think_param = False
                return self._call(system, user, schema, max_tokens, cancel)
            if "format" in low and isinstance(body.get("format"), dict):
                self.schema_ok = False
                return self._call(system, user, schema, max_tokens, cancel)
        if r.status_code == 404:
            raise AIError("err_ai_model", _err_text(r), model=self.model)
        if r.status_code != 200:
            raise self._http_error(r)
        return _extract_json((r.json().get("message") or {}).get("content", ""))


def make_provider(cfg) -> Optional[Provider]:
    p = cfg.get("ai_provider") or "none"
    if p == "anthropic":
        return AnthropicProvider(cfg.get("anthropic_key") or "", cfg.get("anthropic_model") or "")
    if p == "openai":
        return OpenAIProvider(cfg.get("openai_key") or "", cfg.get("openai_model") or "",
                              cfg.get("openai_base_url") or "")
    if p == "ollama":
        return OllamaProvider(cfg.get("ollama_url") or "", cfg.get("ollama_model") or "")
    return None


def test_provider(cfg, cancel=None) -> str:
    """Tiny request to check the key / model / server. Returns a short answer or raises AIError."""
    prov = make_provider(cfg)
    if prov is None:
        raise AIError("err_ai_none")
    if isinstance(prov, OllamaProvider):
        if not prov.available():
            raise AIError("err_ollama_down")
        if not prov.has_model():
            raise AIError("err_ollama_no_model", model=prov.model)
    schema = {"type": "object", "properties": {"ok": {"type": "boolean"}, "joke": {"type": "string"}},
              "required": ["ok", "joke"], "additionalProperties": False}
    out = prov.complete_json("You answer in JSON.", "Say ok=true and give a very short joke about gaming in French.",
                             schema, max_tokens=300, cancel=cancel)
    return str(out.get("joke") or out)


# --------------------------------------------------------------------------- transcript -> prompt

def transcript_lines(transcript: dict, max_len: float = 12.0) -> list[tuple[float, float, str]]:
    """Group Whisper segments into lines of at most ~12 s."""
    lines: list[list] = []
    for seg in transcript.get("segments", []):
        s, e, t = float(seg["s"]), float(seg["e"]), (seg.get("t") or "").strip()
        if not t:
            continue
        if lines and (e - lines[-1][0] <= max_len) and (s - lines[-1][1] < 1.5) \
                and not re.search(r"[.!?…]$", lines[-1][2]):
            lines[-1][1] = e
            lines[-1][2] += " " + t
        else:
            lines.append([s, e, t])
    return [(a, b, c) for a, b, c in lines]


def chunk_lines(lines: list, chunk_s: float, overlap_s: float) -> list[list]:
    if not lines:
        return []
    chunks, i = [], 0
    while i < len(lines):
        start = lines[i][0]
        j = i
        while j < len(lines) and lines[j][0] < start + chunk_s:
            j += 1
        chunks.append(lines[i:j])
        if j >= len(lines):
            break
        # next chunk starts overlap_s before the end of this one
        back = j
        while back > i + 1 and lines[back - 1][0] > lines[j - 1][0] - overlap_s:
            back -= 1
        i = max(back, i + 1)
    return chunks


def _chat_note(chat: list, a: float, b: float, delay: float, laugh_re) -> str:
    lo, hi = a + delay - 2, b + delay + 8
    msgs = [m for m in chat if lo <= m[0] <= hi]
    if len(msgs) < 3:
        return ""
    from .signals import _norm, chat_excerpt
    n_laugh = sum(1 for m in msgs if laugh_re is not None and laugh_re.search(_norm(m[2])))
    per_s = len(msgs) / max(1.0, hi - lo)
    return f"{len(msgs)}|{n_laugh}|{per_s:.2f}|" + " / ".join(f'"{x}"' for x in chat_excerpt(chat, lo, hi, 3))


def _event_line(e: dict) -> str:
    from .albion import fmt_fame, opponent
    opp = opponent(e)
    who = opp.get("name", "?") + (f" ({opp['guild']})" if opp.get("guild") else "")
    me = e.get("player") or "the streamer"
    fame = fmt_fame(e.get("fame") or 0, "en")
    if e.get("role") == "kill":
        return f"<<Albion kill: {me} killed {who}, {fame} fame>>"
    if e.get("role") == "assist":
        return f"<<Albion assist: {me} helped kill {who}, {fame} fame>>"
    return f"<<Albion death: {me} was killed by {who}, lost {fame} fame>>"


def _game_line(meta: dict) -> str:
    game = (meta.get("game") or "").strip()
    if not game or "albion" in game.lower():
        return "mostly plays Albion Online (PvP: ZvZ fights, ganking, small-scale, Hellgates, corrupted dungeons, mists)"
    return f"is playing {game} in this VOD"


def build_messages(cfg, meta: dict, chunk: list, idx: int, total: int, chat: Optional[list],
                   base_rate: float, events: Optional[list] = None) -> tuple[str, str]:
    from .signals import keyword_regex
    ui_lang = "French" if (cfg.get("language") or "fr") == "fr" else "English"
    title_lang = "French" if (cfg.get("ai_title_language") or "fr") == "fr" else "English"
    streamer = (cfg.get("streamer_name") or meta.get("display_name") or "the streamer").strip()
    extra = (cfg.get("ai_context") or "").strip()
    is_ollama = (cfg.get("ai_provider") == "ollama")
    k = 4 if is_ollama else 6
    show_chat = bool(cfg.get("ai_show_chat")) and bool(chat)
    events = [e for e in (events or []) if chunk and chunk[0][0] - 5 <= e["off"] <= chunk[-1][1] + 5]
    system = f"""You are a senior short-form video editor. You review Twitch livestreams and pick the moments that will make people laugh, to cut them into TikTok / YouTube Shorts / Reels clips.

About the stream:
- Streamer: {streamer}, a French Twitch streamer who {_game_line(meta)}.
- Language: mostly French, sometimes English, with gamer slang, Twitch emotes, swearing, and voice chat with teammates.
- You get an automatic transcript of the stream audio as "[H:MM:SS] text" lines. It contains recognition mistakes and no speaker names (teammates on voice chat can appear).""" + ("""
- Some lines end with <<chat: N msgs, L laughs, "most repeated messages">>: how the Twitch chat reacted a few seconds after that line. Lots of laughs (KEKW, LUL, mdr, ptdr, xD...) is a strong hint that something funny just happened.""" if show_chat else "") + ("""
- Lines like [H:MM:SS] <<Albion kill / assist / death: ...>> are real in-game events from the Albion Online killboard at that time. They tell you what happens in the game. A normal kill is not funny by itself, but a death right after bragging, a fight lost in a ridiculous way or a crazy play with a hilarious reaction can make great clips.""" if events else "") + (f"""
- Notes from the streamer: {extra}""" if extra else "") + f"""

Find the FUNNY moments in the excerpt:
- jokes, puns, witty comebacks and one-liners
- banter, teasing and trash talk with chat or teammates
- fails, blunders and embarrassing deaths (misclicks, getting baited, terrible decisions)
- rage, tilt and over-the-top reactions
- absurd, unexpected or weird situations; funny stories and anecdotes
- self-deprecation, awkward moments, great comedic timing

Rules:
- Each moment must work on its own as a short clip: start at the setup (enough context to understand it), end right after the punchline or the reaction.
- Aim for 15 to 60 seconds; never longer than {int(cfg.get('max_clip_len') or 90)} seconds.
- Skip routine gameplay callouts, sponsor reads, greetings, music and waiting time unless something genuinely funny happens.
- Be honest and selective. Score funniness from 0 to 10: 9-10 hilarious with viral potential, 7-8 very funny, 5-6 amusing. Never return a moment below 5.
- Return at most {k} moments for this excerpt, best first, or an empty list if nothing is funny.
- start = the timestamp of the first line of the moment, end = the timestamp of the last line of the moment, copied exactly from the transcript.
- title: a short catchy clip title in {title_lang} (max 8 words, no hashtags, no emojis), like a TikTok caption.
- reason: one short sentence in {ui_lang} explaining why it is funny.
- category: joke, banter, fail, rage, absurd, story, reaction or other."""

    delay = float(cfg.get("chat_delay") or 6)
    laugh_re = keyword_regex(cfg.get("laugh_keywords") or [], builtin=True) if show_chat else None
    out_lines = []
    pending = sorted(events, key=lambda e: e["off"])
    for a, b, text in chunk:
        while pending and pending[0]["off"] < a:
            ev = pending.pop(0)
            out_lines.append(f"[{fmt_hms(max(0.0, ev['off']))}] {_event_line(ev)}")
        line = f"[{fmt_hms(a)}] {text}"
        if show_chat:
            note = _chat_note(chat, a, b, delay, laugh_re)
            if note:
                n, nl, per_s, top = note.split("|", 3)
                if int(nl) >= 2 or float(per_s) > max(0.3, 3 * base_rate):
                    line += f"  <<chat: {n} msgs, {nl} laughs, {top}>>"
        out_lines.append(line)
    for ev in pending:
        out_lines.append(f"[{fmt_hms(max(0.0, ev['off']))}] {_event_line(ev)}")
    date = (meta.get("created_at") or "")[:10]
    user = (f'VOD: "{meta.get("title", "")}" ({date})\n'
            f"Excerpt {idx + 1}/{total}: {fmt_hms(chunk[0][0])} to {fmt_hms(chunk[-1][1])}\n\n"
            "Transcript:\n" + "\n".join(out_lines))
    return system, user


def _snap(ts, chunk: list, use_end: bool) -> Optional[float]:
    t = parse_time(ts)
    if t is None:
        return None
    best = min(chunk, key=lambda ln: abs(ln[0] - t))
    if abs(best[0] - t) > 60:
        return None
    return best[1] if use_end else best[0]


def parse_moments(answer: dict, chunk: list, max_len: float) -> list[dict]:
    out = []
    for m in (answer or {}).get("moments") or []:
        if not isinstance(m, dict):
            continue
        a = _snap(m.get("start"), chunk, False)
        b = _snap(m.get("end"), chunk, True)
        if a is None:
            continue
        if b is None or b <= a:
            b = next((ln[1] for ln in chunk if ln[0] >= a), a + 15)
        if b - a > max_len + 30:
            b = a + max_len
        try:
            score = float(m.get("score", 0))
        except (TypeError, ValueError):
            score = 0
        score = max(0.0, min(10.0, score))
        if score < 5:
            continue
        cat = str(m.get("category") or "other").lower()
        out.append({"start": round(a, 2), "end": round(b, 2), "score": score,
                    "title": str(m.get("title") or "").strip()[:120],
                    "category": cat if cat in CATEGORIES else "other",
                    "reason": str(m.get("reason") or "").strip()[:300]})
    return out


def dedupe(moments: list[dict]) -> list[dict]:
    moments = sorted(moments, key=lambda m: -m["score"])
    kept: list[dict] = []
    for m in moments:
        dup = False
        for k in kept:
            inter = min(k["end"], m["end"]) - max(k["start"], m["start"])
            if inter > 0 and inter / max(1e-6, min(k["end"] - k["start"], m["end"] - m["start"])) > 0.5:
                dup = True
                break
        if not dup:
            kept.append(m)
    return sorted(kept, key=lambda m: m["start"])


def analyze(ref, transcript: dict, chat: Optional[list], cfg, progress: Callable[[float, str], None],
            emit_log: Callable[[str], None], cancel: Optional[threading.Event] = None,
            game_events: Optional[list] = None) -> dict:
    """Run the AI over the whole transcript. Returns {"provider", "model", "moments": [...]}."""
    prov = make_provider(cfg)
    if prov is None:
        return {"provider": "none", "model": "", "moments": []}
    if isinstance(prov, OllamaProvider):
        if not prov.available():
            raise AIError("err_ollama_down")
        if not prov.has_model():
            emit_log(f"pulling ollama model {prov.model}")
            prov.pull(lambda f, s: progress(0.0, f"pull:{int(f * 100)}"), cancel)
        chunk_s, overlap = 480.0, 45.0
    else:
        chunk_s, overlap = 900.0, 60.0
    lines = transcript_lines(transcript)
    chunks = chunk_lines(lines, chunk_s, overlap)
    meta = ref.meta
    base_rate = 0.0
    if chat:
        dur = float(meta.get("duration") or (chat[-1][0] if chat else 1)) or 1.0
        base_rate = len(chat) / dur
    cache_dir = ref.p("ai")
    cache_dir.mkdir(parents=True, exist_ok=True)
    max_len = float(cfg.get("max_clip_len") or 90)
    found: list[dict] = []
    failures = 0
    fatal = ("err_ai_key", "err_ai_no_key", "err_ai_quota", "err_ai_model", "err_ollama_down", "err_ai_request")
    stop = threading.Event()

    def one(i: int, ch: list) -> list[dict]:
        if stop.is_set() or (cancel is not None and cancel.is_set()):
            raise Cancelled()
        system, user = build_messages(cfg, meta, ch, i, len(chunks), chat, base_rate, game_events)
        key = hashlib.sha1(json.dumps([prov.name, prov.model, PROMPT_VERSION, system, user],
                                      ensure_ascii=False).encode("utf-8")).hexdigest()[:20]
        cf = cache_dir / f"{key}.json"
        answer = read_json(cf, None)
        if answer is None:
            answer = prov.complete_json(system, user, SCHEMA, 3000 if prov.name != "ollama" else 1500, cancel)
            write_json(cf, answer)
        out = parse_moments(answer, ch, max_len)
        for m in out:
            m["chunk"] = i
        return out

    # online AIs: a few pieces at the same time (faster); local AI: one at a time
    from concurrent.futures import ThreadPoolExecutor, as_completed
    workers = 1 if isinstance(prov, OllamaProvider) else 3
    done = 0
    try:
        with ThreadPoolExecutor(max_workers=workers) as ex:
            futs = {ex.submit(one, i, ch): i for i, ch in enumerate(chunks)}
            try:
                for fut in as_completed(futs):
                    i = futs[fut]
                    try:
                        found.extend(fut.result())
                    except AIError as e:
                        if e.code in fatal:
                            raise
                        failures += 1
                        emit_log(f"AI piece {i + 1} failed: {e}")
                        if failures >= 3 and failures > len(chunks) // 3:
                            raise
                    done += 1
                    progress(done / max(1, len(chunks)), f"{done}/{len(chunks)}")
                    if cancel is not None and cancel.is_set():
                        raise Cancelled()
            except BaseException:
                stop.set()
                for f in futs:
                    f.cancel()
                raise
    finally:
        if isinstance(prov, OllamaProvider):
            prov.unload()  # give the graphics card memory back (for games!)
    return {"provider": prov.name, "model": prov.model, "moments": dedupe(found), "failed_pieces": failures}
