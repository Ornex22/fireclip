"""Albion Online killboard: the kills, assists and deaths of a player, placed in a VOD.

FireClips uses the public Albion Online API (no account or key needed):

    Europe    https://gameinfo-ams.albiononline.com/api/gameinfo
    Americas  https://gameinfo.albiononline.com/api/gameinfo
    Asia      https://gameinfo-sgp.albiononline.com/api/gameinfo

    /search?q=NAME                        players whose name starts with NAME
    /players/ID/kills   /players/ID/deaths    ONLY the 10 latest kills / deaths
    /players/ID/topkills?range=week       best kills of the week (also lastWeek, month, lastMonth)
    /events?guildId=G&limit=51&offset=N   kills made by a guild, newest first, 51 per page
    /battles?guildId=G&range=week         group fights of a guild
    /events/battle/B?limit=51&offset=N    every kill / death of one fight (assists included)

Because the API forgets older kills quickly, FireClips also writes down the player's kills and
deaths every 2 minutes while it is open (the "collector", see ui/albion_ui.py). Everything is
kept in <work folder>/albion/<server>_<player id>/<day>.json, one file per day (UTC).

A kill happens at an exact time (TimeStamp, UTC). The VOD started at its "created_at" time, so
the kill is at   kill time - VOD start + stream delay   seconds into the VOD.
"""
from __future__ import annotations

import logging
import math
import os
import re
import threading
import time
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Iterable, Optional

import requests

from . import __version__
from .errors import UserError
from .util import Cancelled, read_json, write_json

log = logging.getLogger("fireclips.albion")

REGIONS = {
    "europe": {"api": "https://gameinfo-ams.albiononline.com/api/gameinfo", "kb1": "eu"},
    "americas": {"api": "https://gameinfo.albiononline.com/api/gameinfo", "kb1": ""},
    "asia": {"api": "https://gameinfo-sgp.albiononline.com/api/gameinfo", "kb1": ""},
}
RENDER_URL = os.environ.get("FIRECLIPS_ALBION_RENDER", "https://render.albiononline.com/v1").rstrip("/")
UA = f"FireClips/{__version__} (Twitch clip tool)"
ROLES = ("kill", "assist", "death")
SLOTS = ("MainHand", "OffHand", "Head", "Armor", "Shoes", "Cape", "Bag", "Mount", "Potion", "Food")
GEAR_SLOTS = ("MainHand", "OffHand", "Head", "Armor", "Shoes", "Cape", "Mount", "Food", "Potion")


class AlbionError(UserError):
    """An Albion API problem with a message that can be shown to the user (code = i18n key)."""


# --------------------------------------------------------------------------- HTTP

_tls = threading.local()


def _session() -> requests.Session:
    s = getattr(_tls, "session", None)
    if s is None:
        s = requests.Session()
        s.headers["User-Agent"] = UA
        s.headers["Accept"] = "application/json"
        _tls.session = s
    return s


def api_base(region: str) -> str:
    env = os.environ.get("FIRECLIPS_ALBION_API")
    if env:
        return env.rstrip("/")
    return REGIONS.get(region or "europe", REGIONS["europe"])["api"]


def _sleep(seconds: float, cancel: Optional[threading.Event]) -> None:
    end = time.time() + seconds
    while time.time() < end:
        if cancel is not None and cancel.is_set():
            raise Cancelled()
        time.sleep(min(0.2, max(0.0, end - time.time())))


def api_get(region: str, path: str, params: Optional[dict] = None, timeout: float = 25.0, retries: int = 3,
            cancel: Optional[threading.Event] = None):
    """GET one API endpoint and return the decoded JSON (None for "not found" / empty answers).
    The Albion API is often slow or briefly down: retried a few times."""
    url = api_base(region) + path
    last = ""
    for attempt in range(retries):
        if cancel is not None and cancel.is_set():
            raise Cancelled()
        try:
            r = _session().get(url, params=params, timeout=timeout)
            if r.status_code == 404:
                return None
            if r.status_code in (408, 429, 500, 502, 503, 504):
                last = f"HTTP {r.status_code}"
            elif r.status_code != 200:
                raise AlbionError("err_albion_api", f"{url}: HTTP {r.status_code} {r.text[:200]}")
            else:
                if not r.content.strip():
                    return None
                return r.json()
        except AlbionError:
            raise
        except (requests.RequestException, ValueError) as e:
            last = f"{type(e).__name__}: {e}"
        if attempt < retries - 1:
            _sleep(min(10.0, 1.5 * (attempt + 1) ** 1.6), cancel)
    raise AlbionError("err_albion_network", f"{url}: {last}")


# --------------------------------------------------------------------------- time

_TS_RE = re.compile(r"^\s*(\d{4})-(\d\d)-(\d\d)[T ](\d\d):(\d\d):(\d\d)(?:[.,](\d+))?\s*(Z|[+-]\d\d:?\d\d)?\s*$")


def parse_ts(s) -> Optional[float]:
    """'2026-10-18T20:32:57.585398100Z' -> seconds since 1970 (UTC). Accepts any number of
    decimals (the Albion API sends 7) and a missing time zone (= UTC)."""
    if s is None or s == "":
        return None
    if isinstance(s, (int, float)):
        return float(s)
    m = _TS_RE.match(str(s))
    if not m:
        return None
    y, mo, d, h, mi, se = (int(x) for x in m.groups()[:6])
    frac = float("0." + m.group(7)) if m.group(7) else 0.0
    try:
        t = datetime(y, mo, d, h, mi, se, tzinfo=timezone.utc).timestamp() + frac
    except ValueError:
        return None
    tz = m.group(8)
    if tz and tz != "Z":
        sign = -1 if tz[0] == "-" else 1
        digits = tz[1:].replace(":", "")
        t -= sign * (int(digits[:2]) * 3600 + int(digits[2:4]) * 60)
    return t


def iso(t: float) -> str:
    return datetime.fromtimestamp(t, timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


_OBS_NAME = re.compile(r"(20\d\d)-(\d\d)-(\d\d)[ _T](\d\d)[-_.h:](\d\d)[-_.m:](\d\d)")


def local_recording_start(path: Path, duration: float) -> Optional[float]:
    """When a local recording started: from an OBS-style file name ("2026-10-18 20-31-12.mkv",
    local time) or else from the file date (OBS writes the file until the end)."""
    m = _OBS_NAME.search(Path(path).name)
    if m:
        try:
            return datetime(*(int(x) for x in m.groups())).timestamp()   # naive = local time
        except ValueError:
            pass
    try:
        mtime = Path(path).stat().st_mtime
    except OSError:
        return None
    return mtime - max(0.0, float(duration or 0))


def vod_start(meta: dict) -> Optional[float]:
    """Start of the VOD (seconds since 1970, UTC)."""
    if meta.get("kind") == "local":
        if meta.get("recording_start"):
            return float(meta["recording_start"])
        lp = meta.get("local_path")
        return local_recording_start(Path(lp), float(meta.get("duration") or 0)) if lp else None
    return parse_ts(meta.get("created_at"))


# --------------------------------------------------------------------------- events

def _person(p: Optional[dict], with_damage: bool = False) -> dict:
    p = p or {}
    eq = {}
    for slot, it in (p.get("Equipment") or {}).items():
        if isinstance(it, dict) and it.get("Type"):
            eq[slot] = [str(it["Type"]), int(it.get("Quality") or 1)]
    out = {"id": str(p.get("Id") or ""), "name": str(p.get("Name") or "?"), "guild": str(p.get("GuildName") or ""),
           "alliance": str(p.get("AllianceTag") or p.get("AllianceName") or ""),
           "ip": int(round(float(p.get("AverageItemPower") or 0))), "eq": eq}
    if with_damage:
        out["dmg"] = int(round(float(p.get("DamageDone") or 0)))
        out["heal"] = int(round(float(p.get("SupportHealingDone") or 0)))
    return out


def trim_event(ev: dict) -> Optional[dict]:
    """Keep only what FireClips shows (an API event is ~30 KB with everyone's lifetime stats)."""
    if not isinstance(ev, dict):
        return None
    try:
        eid = int(ev.get("EventId"))
    except (TypeError, ValueError):
        return None
    t = parse_ts(ev.get("TimeStamp"))
    if t is None:
        return None
    victim = _person(ev.get("Victim"))
    inv = []
    for it in (ev.get("Victim") or {}).get("Inventory") or []:
        if isinstance(it, dict) and it.get("Type"):
            inv.append([str(it["Type"]), int(it.get("Count") or 1), int(it.get("Quality") or 1)])
    victim["inv"] = inv[:64]
    parts = [_person(p, True) for p in (ev.get("Participants") or []) if isinstance(p, dict)][:60]
    group = [{"id": str(g.get("Id") or ""), "name": str(g.get("Name") or "")}
             for g in (ev.get("GroupMembers") or []) if isinstance(g, dict)][:60]
    return {"id": eid, "t": round(t, 3), "ts": str(ev.get("TimeStamp")),
            "fame": int(ev.get("TotalVictimKillFame") or 0),
            "killer": _person(ev.get("Killer")), "victim": victim, "participants": parts, "group": group,
            "n_part": int(ev.get("numberOfParticipants") or len(parts)),
            "n_group": int(ev.get("groupMemberCount") or len(group)),
            "area": str(ev.get("KillArea") or ""), "battle": int(ev.get("BattleId") or 0)}


def role_of(e: dict, pid: str) -> Optional[str]:
    """kill (the player got the kill) | death | assist (did damage / healing) | None."""
    if not pid:
        return None
    if e.get("killer", {}).get("id") == pid:
        return "kill"
    if e.get("victim", {}).get("id") == pid:
        return "death"
    for p in e.get("participants") or []:
        if p.get("id") == pid:
            return "assist"
    return None


# --------------------------------------------------------------------------- local store

@contextmanager
def _file_lock(path: Path, timeout: float = 10.0):
    """Tiny cross-process lock (the window and the background worker can both write)."""
    lock = Path(str(path) + ".lock")
    lock.parent.mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    got = False
    while True:
        try:
            fd = os.open(str(lock), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.close(fd)
            got = True
            break
        except FileExistsError:
            try:
                if time.time() - lock.stat().st_mtime > 30:     # left by a crashed process
                    lock.unlink()
                    continue
            except OSError:
                pass
            if time.time() - t0 > timeout:
                break
            time.sleep(0.05)
        except OSError:
            break
    try:
        yield
    finally:
        if got:
            try:
                lock.unlink()
            except OSError:
                pass


def data_root(cfg) -> Path:
    return Path(cfg.work_dir) / "albion"


class EventStore:
    """All the events of one player that FireClips has seen, one JSON file per UTC day."""

    def __init__(self, root: Path, region: str, player_id: str):
        safe = re.sub(r"[^A-Za-z0-9_-]", "", player_id or "unknown")
        self.dir = Path(root) / f"{region}_{safe}"

    def _file(self, t: float) -> Path:
        return self.dir / (time.strftime("%Y-%m-%d", time.gmtime(t)) + ".json")

    def add(self, events: Iterable[dict]) -> int:
        """Add events (trimmed); returns how many were new."""
        by_file: dict[Path, list] = {}
        for e in events:
            if e and e.get("t"):
                by_file.setdefault(self._file(e["t"]), []).append(e)
        new = 0
        for f, evs in by_file.items():
            with _file_lock(f):
                cur = read_json(f, {}) or {}
                changed = False
                for e in evs:
                    k = str(e["id"])
                    old = cur.get(k)
                    if old is None:
                        new += 1
                    if old is None or len(e.get("participants") or []) > len(old.get("participants") or []):
                        cur[k] = e
                        changed = True
                if changed:
                    write_json(f, cur, indent=None)
        return new

    def between(self, t0: float, t1: float) -> list[dict]:
        out = []
        day = math.floor(t0 / 86400) * 86400
        while day <= t1:
            f = self.dir / (time.strftime("%Y-%m-%d", time.gmtime(day)) + ".json")
            for e in (read_json(f, {}) or {}).values():
                if t0 <= float(e.get("t") or 0) <= t1:
                    out.append(e)
            day += 86400
        out.sort(key=lambda e: e["t"])
        return out

    # the collector's visits ("polls"): used to know if a whole stream was watched
    def note_poll(self, t: float) -> None:
        f = self.dir / "polls.json"
        with _file_lock(f):
            polls = read_json(f, []) or []
            polls.append(round(t))
            write_json(f, polls[-8000:], indent=None)

    def polls(self) -> list[float]:
        return [float(x) for x in (read_json(self.dir / "polls.json", []) or [])]

    def watched(self, t0: float, t1: float, max_gap: float = 900.0) -> bool:
        """True if the collector looked often enough during [t0, t1] to have seen everything."""
        p = sorted(x for x in self.polls() if t0 - max_gap <= x <= t1 + max_gap)
        if not p or p[0] > t0 + 120 or p[-1] < t1 - 60:
            return False
        return all(b - a <= max_gap for a, b in zip(p, p[1:]))

    def prune(self, keep_days: int = 120) -> None:
        if not self.dir.is_dir():
            return
        limit = time.strftime("%Y-%m-%d", time.gmtime(time.time() - keep_days * 86400))
        for f in self.dir.glob("20*.json"):
            if f.stem < limit:
                try:
                    f.unlink()
                except OSError:
                    pass


# --------------------------------------------------------------------------- players

def search_players(region: str, name: str, cancel=None) -> list[dict]:
    data = api_get(region, "/search", {"q": name}, cancel=cancel) or {}
    return [p for p in (data.get("players") or []) if isinstance(p, dict)]


def resolve_player(root: Path, region: str, name: str, cancel=None, max_age: float = 3 * 86400) -> dict:
    """Albion player id (and guild) for a name on a server, remembered in players.json."""
    name = (name or "").strip()
    if not name:
        raise AlbionError("err_albion_player", "", name=name)
    root = Path(root)
    cache_f = root / "players.json"
    key = f"{region}:{name.lower()}"
    cache = read_json(cache_f, {}) or {}
    c = cache.get(key)
    if c and time.time() - float(c.get("checked") or 0) < max_age:
        return c
    try:
        players = search_players(region, name, cancel)
    except AlbionError:
        if c:
            return c   # API down: the answer from last time is still good
        raise
    exact = [p for p in players if p.get("Name") == name] or \
        [p for p in players if str(p.get("Name") or "").lower() == name.lower()]
    if not exact:
        raise AlbionError("err_albion_player", name, name=name, region=region)
    p = max(exact, key=lambda x: int(x.get("KillFame") or 0))
    info = {"id": str(p.get("Id")), "name": str(p.get("Name")), "guild": str(p.get("GuildName") or ""),
            "guild_id": str(p.get("GuildId") or ""), "alliance": str(p.get("AllianceName") or ""),
            "kill_fame": int(p.get("KillFame") or 0), "death_fame": int(p.get("DeathFame") or 0),
            "region": region, "checked": time.time()}
    with _file_lock(cache_f):
        cache = read_json(cache_f, {}) or {}
        cache[key] = info
        write_json(cache_f, cache)
    return info


def cached_player(root: Path, region: str, name: str) -> Optional[dict]:
    return (read_json(Path(root) / "players.json", {}) or {}).get(f"{region}:{(name or '').strip().lower()}")


def clean_links(links) -> list[dict]:
    out = []
    for l in links or []:
        if not isinstance(l, dict):
            continue
        player = str(l.get("player") or "").strip()
        if not player:
            continue
        region = str(l.get("region") or "europe").lower()
        if region not in REGIONS:
            region = "europe"
        ch = str(l.get("channel") or "").strip()
        try:
            from .twitch import clean_login
            ch = clean_login(ch) if ch else ""
        except Exception:  # noqa: BLE001 - a strange channel name: keep it as typed
            ch = ch.lower().lstrip("@")
        out.append({"player": player, "region": region, "channel": ch})
    return out


def links_for_vod(cfg, meta: dict) -> list[dict]:
    """The Albion players linked to the channel of this VOD."""
    links = clean_links(cfg.get("albion_links"))
    if not links:
        return []
    login = str(meta.get("login") or "").lower()
    if meta.get("kind", "twitch") == "twitch" and login:
        return [l for l in links if l["channel"] == login]
    # a local recording (or unknown channel): it is the user's own stream
    mine = str(cfg.get("channel") or "").strip().lower()
    sel = [l for l in links if mine and l["channel"] == mine]
    return sel or links


# --------------------------------------------------------------------------- fetching

def _ranges(t0: float, now: float) -> list[str]:
    age = now - t0
    if age < 15 * 86400:
        return ["week", "lastWeek"]
    if age < 62 * 86400:
        return ["month", "lastMonth"]
    return []


def fetch_player_window(root: Path, link: dict, t0: float, t1: float,
                        progress: Callable[[float], None] = lambda f: None,
                        log_fn: Callable[[str], None] = lambda m: None,
                        cancel: Optional[threading.Event] = None) -> dict:
    """Everything the API still knows about one player between t0 and t1 (seconds, UTC), merged
    with what the collector already wrote down. Returns {"player", "events", "stats", "errors",
    "partial"}."""
    region = link.get("region") or "europe"
    info = resolve_player(root, region, link["player"], cancel)
    pid, gid = info["id"], info.get("guild_id") or ""
    store = EventStore(root, region, pid)
    got: dict[int, dict] = {}
    stats: dict[str, int] = {}
    errors: list[str] = []
    now = time.time()
    latest: dict[str, list[float]] = {}
    guild_reached_start = False

    def take(src: str, raw) -> list:
        evs = [x for x in (raw or []) if isinstance(x, dict)] if isinstance(raw, list) else []
        n = 0
        for ev in evs:
            e = trim_event(ev)
            if e is None or role_of(e, pid) is None:
                continue
            if e["id"] not in got or len(e["participants"]) > len(got[e["id"]]["participants"]):
                got[e["id"]] = e
            n += 1
        stats[src] = stats.get(src, 0) + n
        return evs

    def safe(fn, what: str):
        try:
            return fn()
        except AlbionError as e:
            errors.append(f"{what}: {e.detail or e.code}")
            log.info("albion %s failed: %s", what, e.detail)
            return None

    progress(0.05)
    # 1) the 10 latest kills and deaths
    for kind in ("kills", "deaths"):
        raw = safe(lambda kind=kind: api_get(region, f"/players/{pid}/{kind}", cancel=cancel), kind)
        evs = take(kind, raw)
        latest[kind] = [t for t in (parse_ts(x.get("TimeStamp")) for x in evs) if t]
    progress(0.2)
    # 2) kills of the guild, newest first, until before the start of the VOD (not needed when the
    #    collector was watching during the whole stream: it already has every kill and death)
    watched_before = store.watched(t0, t1)
    if gid and now - t0 < 20 * 86400 and not watched_before:
        for page in range(12):
            raw = safe(lambda page=page: api_get(region, "/events", {"guildId": gid, "limit": 51, "offset": page * 51},
                                                 cancel=cancel), "guild events")
            if not raw:
                break
            evs = take("guild", raw)
            ts = [t for t in (parse_ts(x.get("TimeStamp")) for x in evs) if t]
            if not ts or min(ts) <= t0 - 300:
                guild_reached_start = True
                break
            if len(evs) < 51:
                guild_reached_start = True   # nothing older is kept by the API
                break
            progress(0.2 + 0.25 * (page + 1) / 12)
    progress(0.45)
    # 3) group fights of the guild during the VOD (assists, teammates' kills, deaths in fights)
    if gid:
        battles: dict = {}
        for rng in _ranges(t0, now):
            for page in range(4):     # newest first: stop once the fights are older than the VOD
                raw = safe(lambda rng=rng, page=page: api_get(region, "/battles", {
                    "guildId": gid, "range": rng, "sort": "recent", "limit": 51, "offset": page * 51},
                    cancel=cancel), "battles")
                got_b = [b for b in (raw or []) if isinstance(b, dict) and b.get("id") is not None]
                for b in got_b:
                    battles[b["id"]] = b
                starts = [t for t in (parse_ts(b.get("startTime")) for b in got_b) if t]
                if len(got_b) < 51 or not starts or min(starts) < t0:
                    break
        todo = []
        for bid, b in battles.items():
            bs, be = parse_ts(b.get("startTime")), parse_ts(b.get("endTime"))
            if bs is None or be is None or be < t0 - 120 or bs > t1 + 120:
                continue
            players = b.get("players") or {}
            if isinstance(players, dict) and pid not in players:
                continue
            todo.append(bid)
        for i, bid in enumerate(todo[:60]):
            for page in range(10):
                raw = safe(lambda page=page, bid=bid: api_get(region, f"/events/battle/{bid}",
                                                              {"offset": page * 51, "limit": 51}, cancel=cancel),
                           f"battle {bid}")
                evs = take("battles", raw)
                if len(evs) < 51:
                    break
            progress(0.45 + 0.3 * (i + 1) / max(1, len(todo)))
    progress(0.75)
    # 4) best kills of the week / month (sorted by fame: the big ones are never missed)
    for rng in _ranges(t0, now):
        for kind in ("topkills", "solokills"):
            raw = safe(lambda rng=rng, kind=kind: api_get(region, f"/players/{pid}/{kind}",
                                                          {"range": rng, "limit": 51, "offset": 0}, cancel=cancel), kind)
            take(kind, raw)
    progress(0.9)
    new = store.add(got.values())
    events = [e for e in store.between(t0 - 120, t1 + 120) if role_of(e, pid)]
    # Could some events be missing? (the API keeps only the 10 latest kills / deaths)
    watched = store.watched(t0, t1)
    partial = False
    if not watched:
        k = latest.get("kills") or []
        d = latest.get("deaths") or []
        if len(k) >= 10 and min(k) > t0 + 60 and not guild_reached_start:
            partial = True
        if len(d) >= 10 and min(d) > t0 + 60:
            partial = True
    progress(1.0)
    log_fn(f"albion {info['name']}: {len(events)} events in the VOD ({new} new), sources {stats}")
    return {"player": info, "events": events, "stats": stats, "errors": errors, "partial": partial,
            "watched": watched}


def poll_latest(root: Path, link: dict, cancel=None) -> int:
    """One collector visit: the 10 latest kills and deaths of the player go into the store.
    Returns the number of new events."""
    region = link.get("region") or "europe"
    info = resolve_player(root, region, link["player"], cancel)
    pid = info["id"]
    store = EventStore(root, region, pid)
    found = []
    for kind in ("kills", "deaths"):
        raw = api_get(region, f"/players/{pid}/{kind}", retries=2, cancel=cancel) or []
        for ev in raw if isinstance(raw, list) else []:
            e = trim_event(ev)
            if e is not None and role_of(e, pid):
                found.append(e)
    new = store.add(found)
    store.note_poll(time.time())
    return new


def fetch_for_vod(ref, cfg, links: Optional[list] = None, progress: Callable[[float], None] = lambda f: None,
                  log_fn: Callable[[str], None] = lambda m: None, cancel=None) -> dict:
    """Fetch the events of the linked players during this VOD and save them in albion.json."""
    meta = ref.meta
    links = links if links is not None else links_for_vod(cfg, meta)
    start = vod_start(meta)
    duration = float(meta.get("duration") or 0)
    if start is None or duration <= 0:
        raise AlbionError("err_albion_no_time", ref.key)
    t0, t1 = start - 60, start + duration + 120
    root = data_root(cfg)
    old = read_json(ref.p("albion.json"), None) or {}
    doc = {"version": 1, "fetched_at": time.time(), "vod_start": start, "window": [t0, t1],
           "players": [], "events": [], "errors": [], "partial": False}
    for i, link in enumerate(links):
        def prog(f, i=i):
            progress((i + f) / max(1, len(links)))
        try:
            res = fetch_player_window(root, link, t0, t1, prog, log_fn, cancel)
        except AlbionError as e:
            doc["errors"].append({"player": link["player"], "code": e.code, "detail": e.detail})
            # the API is down (or the name is wrong): keep what was already known for this player
            known = cached_player(root, link["region"], link["player"])
            kept: dict = {}
            for ev in old.get("events") or []:
                if str(ev.get("player", "")).lower() == link["player"].lower():
                    kept[ev["id"]] = dict(ev)
            if known:
                for ev in EventStore(root, link["region"], known["id"]).between(t0 - 120, t1 + 120):
                    if role_of(ev, known["id"]) and ev["id"] not in kept:
                        kept[ev["id"]] = dict(ev, role=role_of(ev, known["id"]), pid=known["id"],
                                              player=known["name"], region=link["region"])
            doc["events"] += list(kept.values())
            if kept:
                doc["partial"] = True
            continue
        p = res["player"]
        doc["players"].append({"name": p["name"], "id": p["id"], "region": link["region"], "guild": p.get("guild", ""),
                               "channel": link.get("channel", ""), "stats": res["stats"],
                               "partial": res["partial"], "watched": res["watched"]})
        doc["errors"] += [{"player": link["player"], "code": "warn_albion_failed", "detail": x} for x in res["errors"]]
        doc["partial"] = doc["partial"] or res["partial"]
        for e in res["events"]:
            e = dict(e)
            e["role"] = role_of(e, p["id"])
            e["pid"] = p["id"]
            e["player"] = p["name"]
            e["region"] = link["region"]
            doc["events"].append(e)
    # the same event can belong to two linked players (duo): keep it once, for the first player
    seen = set()
    uniq = []
    for e in sorted(doc["events"], key=lambda e: e["t"]):
        if e["id"] in seen:
            continue
        seen.add(e["id"])
        uniq.append(e)
    doc["events"] = uniq
    write_json(ref.p("albion.json"), doc, indent=None)
    return doc


# --------------------------------------------------------------------------- events in the VOD

def vod_offset(cfg, ref_settings: Optional[dict]) -> float:
    """Stream delay (seconds) + the correction made for this VOD."""
    base = float(cfg.get("albion_offset") or 0)
    extra = float((ref_settings or {}).get("offset") or 0)
    return base + extra


def map_events(doc: Optional[dict], offset: float, duration: float) -> list[dict]:
    """Events of albion.json with their position in the VOD ("off", seconds)."""
    if not doc or not doc.get("events"):
        return []
    start = float(doc.get("vod_start") or 0)
    out = []
    for e in doc["events"]:
        if e.get("role") not in ROLES:
            continue
        off = float(e["t"]) - start + offset
        if -30 <= off <= duration + 30:
            m = dict(e)
            m["off"] = round(off, 2)
            out.append(m)
    out.sort(key=lambda e: e["off"])
    return out


def event_strength(e: dict) -> float:
    """0..1 for the scoring signal: bigger fame = bigger moment; deaths count (often funny)."""
    fame = max(1000.0, float(e.get("fame") or 0))
    v = max(0.3, min(1.0, 0.4 + 0.2 * math.log10(fame / 10000.0)))
    if e.get("role") == "assist":
        v *= 0.8
    return v


def fmt_fame(n: float, lang: str = "fr") -> str:
    n = float(n or 0)
    if n >= 1e9:
        s = f"{n / 1e9:.1f} " + ("Md" if lang == "fr" else "B")
    elif n >= 1e6:
        s = f"{n / 1e6:.1f}M" if n < 1e8 else f"{n / 1e6:.0f}M"
    elif n >= 1e3:
        s = f"{n / 1e3:.0f}k"
    else:
        s = f"{n:.0f}"
    if lang == "fr":
        s = s.replace(".", ",")
    return s


def opponent(e: dict) -> dict:
    """The other side of the event: the victim of a kill/assist, the killer of a death."""
    return e["killer"] if e.get("role") == "death" else e["victim"]


def pretty_item(type_code: str) -> str:
    """'T6_MAIN_FIRESTAFF_CRYSTAL@3' -> 'T6.3 Firestaff Crystal'."""
    t = str(type_code or "")
    m = re.match(r"T(\d)_(.*?)(?:@(\d))?$", t)
    if not m:
        return t.replace("_", " ").title()
    tier, name, ench = m.group(1), m.group(2), m.group(3)
    name = re.sub(r"^(MAIN|2H|OFF|HEAD|ARMOR|SHOES|CAPEITEM|CAPE|BAG|MOUNT|POTION|MEAL)_", "", name)
    name = name.replace("_", " ").title()
    return f"T{tier}.{ench}" + " " + name if ench and ench != "0" else f"T{tier} {name}"


def weapon(e_person: dict) -> str:
    mh = (e_person.get("eq") or {}).get("MainHand")
    return pretty_item(mh[0]) if mh else ""


def killboard_url(region: str, event_id) -> str:
    kb = REGIONS.get(region or "europe", {}).get("kb1")
    return f"https://killboard-1.com/{kb}/event/{event_id}" if kb else ""


def item_icon_url(type_code: str, quality: int = 1, size: int = 64) -> str:
    return f"{RENDER_URL}/item/{type_code}.png?quality={max(1, min(5, int(quality or 1)))}&size={int(size)}"


def icon_file(root: Path, type_code: str, quality: int = 1, size: int = 64) -> Path:
    safe = re.sub(r"[^A-Za-z0-9_@-]", "_", type_code or "x")
    return Path(root) / "icons" / f"{safe}_q{int(quality or 1)}_{int(size)}.png"


def fetch_icon(root: Path, type_code: str, quality: int = 1, size: int = 64) -> Optional[Path]:
    """Download an item picture once (render.albiononline.com) and keep it."""
    f = icon_file(root, type_code, quality, size)
    if f.exists() and f.stat().st_size > 0:
        return f
    miss = f.with_suffix(".missing")
    if miss.exists() and time.time() - miss.stat().st_mtime < 86400:
        return None
    try:
        r = _session().get(item_icon_url(type_code, quality, size), timeout=15)
        if r.status_code == 200 and r.content[:4] == b"\x89PNG":
            f.parent.mkdir(parents=True, exist_ok=True)
            tmp = f.with_suffix(".tmp")
            tmp.write_bytes(r.content)
            os.replace(tmp, f)
            return f
        f.parent.mkdir(parents=True, exist_ok=True)
        miss.write_text(str(r.status_code), encoding="utf-8")
    except (requests.RequestException, OSError) as e:
        log.info("icon %s: %s", type_code, e)
    return None


# --------------------------------------------------------------------------- kill clips

def build_clips(events: list[dict], cfg, duration: float, tr: Callable, lang: str = "fr",
                snap: Optional[Callable] = None, text_between: Optional[Callable] = None) -> list[dict]:
    """Turn the events of a VOD into clips. Events below the fame threshold (or of a type that is
    switched off) become single "ignored" clips that are hidden unless asked for. Kills close to
    each other (a fight) are grouped in one clip."""
    types = set(cfg.get("albion_types") or ["kill", "assist"])
    min_fame = float(cfg.get("albion_min_fame") or 0)
    before = float(cfg.get("albion_before") if cfg.get("albion_before") is not None else 25)
    after = float(cfg.get("albion_after") if cfg.get("albion_after") is not None else 8)
    gap = float(cfg.get("albion_group_gap") or 0)
    max_span = max(60.0, float(cfg.get("max_clip_len") or 90))
    inside = [e for e in events if -5 <= e["off"] <= duration + 5]
    kept = [e for e in inside if e["role"] in types and float(e.get("fame") or 0) >= min_fame]
    kept_ids = {e["id"] for e in kept}
    groups: list[list[dict]] = []
    for e in kept:
        if groups and gap > 0 and e["off"] - groups[-1][-1]["off"] <= gap and e["off"] - groups[-1][0]["off"] <= max_span:
            groups[-1].append(e)
        else:
            groups.append([e])
    clips = [_clip(g, False, before, after, duration, tr, lang, snap, text_between) for g in groups]
    clips += [_clip([e], True, before, after, duration, tr, lang, snap, text_between)
              for e in inside if e["id"] not in kept_ids]
    clips.sort(key=lambda c: c["start"])
    return clips


def _clip(g: list[dict], ignored: bool, before: float, after: float, duration: float, tr: Callable, lang: str,
          snap, text_between) -> dict:
    a = max(0.0, g[0]["off"] - before)
    b = min(duration, g[-1]["off"] + after) if duration > 0 else g[-1]["off"] + after
    if b - a < 3:
        b = a + 3
    if snap is not None:
        a2, b2 = snap(a, b)
        # never cut the kill itself out
        if a2 <= g[0]["off"] - 2 and b2 >= g[-1]["off"] + 1:
            a, b = a2, b2
    kills = [e for e in g if e["role"] == "kill"]
    assists = [e for e in g if e["role"] == "assist"]
    deaths = [e for e in g if e["role"] == "death"]
    win = kills + assists
    fame = sum(int(e.get("fame") or 0) for e in (win or deaths))
    kind = "death" if not win else ("mixed" if deaths else "kill" if kills else "assist")
    f = fmt_fame(fame, lang)
    if len(g) == 1:
        e = g[0]
        opp = opponent(e)
        if e["role"] == "kill":
            title = tr("kill_title_kill", victim=opp["name"], fame=f)
        elif e["role"] == "assist":
            title = tr("kill_title_assist", victim=opp["name"], fame=f)
        else:
            title = tr("kill_title_death", killer=opp["name"], fame=f)
    else:
        names = []
        for e in win or deaths:
            n = opponent(e)["name"]
            if n not in names:
                names.append(n)
        who = ", ".join(names[:2]) + ("…" if len(names) > 2 else "")
        if win:
            title = tr("kill_title_multi", n=len(win), names=who, fame=f)
        else:
            title = tr("kill_title_deaths", n=len(deaths), names=who, fame=f)
    reasons = [{"kind": "albion_event", "role": e["role"], "name": opponent(e)["name"],
                "guild": opponent(e).get("guild", ""), "fame": int(e.get("fame") or 0), "at": e["off"]} for e in g]
    return {
        "id": f"k{g[0]['id']}",
        "start": round(a, 2), "end": round(b, 2), "peak": round(g[0]["off"], 1),
        "kind": kind, "fame": fame, "score": float(fame), "title": title, "category": "albion_" + kind,
        "events": [e["id"] for e in g], "n_kills": len(kills), "n_assists": len(assists), "n_deaths": len(deaths),
        "ignored": ignored, "auto_check": not ignored, "sources": ["albion"], "reasons": reasons,
        "transcript": text_between(a, b) if text_between else "",
        "opponent": opponent(g[0])["name"] if g else "",
        "ip": (g[0]["victim"] if g[0]["role"] != "death" else g[0]["killer"]).get("ip", 0),
        "my_ip": (g[0]["killer"] if g[0]["role"] == "kill" else g[0]["victim"] if g[0]["role"] == "death"
                  else next((p for p in g[0].get("participants", []) if p.get("id") == g[0].get("pid")), {})).get("ip", 0),
        "weapon": weapon(opponent(g[0])),
    }
