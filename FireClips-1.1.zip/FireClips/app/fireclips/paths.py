"""Where FireClips keeps its files.

Installed layout (Windows), everything under %LOCALAPPDATA%\\FireClips:
    app\\fireclips\\      the program (this package)
    venv\\                Python environment
    tools\\               ffmpeg, TwitchDownloaderCLI, yt-dlp
    models\\              Whisper models
    work\\                per-VOD cache (audio, transcript, results)  [changeable]
    logs\\                log files
    settings.json         user settings
Exported clips go to the user's Videos folder by default (changeable).
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

from . import APP_NAME

IS_WINDOWS = sys.platform == "win32"
PACKAGE_DIR = Path(__file__).resolve().parent
ASSETS = PACKAGE_DIR / "assets"


def _install_root() -> Path:
    env = os.environ.get("FIRECLIPS_HOME")
    if env:
        return Path(env)
    # Installed: <root>/app/fireclips/paths.py
    root = PACKAGE_DIR.parent.parent
    if (root / "venv").is_dir() or (root / "tools").is_dir():
        return root
    if IS_WINDOWS:
        return Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / APP_NAME
    return Path.home() / ".fireclips"


ROOT = _install_root()
TOOLS = ROOT / "tools"
MODELS = ROOT / "models"
LOGS = ROOT / "logs"
CONFIG_FILE = ROOT / "settings.json"


def _known_videos_folder() -> Path:
    """The real 'Videos' folder (follows OneDrive/folder redirection on Windows)."""
    if IS_WINDOWS:
        try:
            import ctypes
            from ctypes import wintypes
            import uuid

            class GUID(ctypes.Structure):
                _fields_ = [("Data1", wintypes.DWORD), ("Data2", wintypes.WORD),
                            ("Data3", wintypes.WORD), ("Data4", ctypes.c_ubyte * 8)]

            u = uuid.UUID("{18989B1D-99B5-455B-841C-AB7C74E4DDFC}")  # FOLDERID_Videos
            guid = GUID(u.fields[0], u.fields[1], u.fields[2],
                        (ctypes.c_ubyte * 8).from_buffer_copy(u.bytes[8:]))
            out = ctypes.c_wchar_p()
            shell32 = ctypes.windll.shell32
            if shell32.SHGetKnownFolderPath(ctypes.byref(guid), 0, None, ctypes.byref(out)) == 0:
                p = Path(out.value)
                ctypes.windll.ole32.CoTaskMemFree(out)
                return p
        except Exception:
            pass
    return Path.home() / "Videos"


def default_output_dir() -> Path:
    return _known_videos_folder() / APP_NAME


def default_work_dir() -> Path:
    return ROOT / "work"


def ensure_dirs() -> None:
    for d in (ROOT, LOGS, MODELS):
        try:
            d.mkdir(parents=True, exist_ok=True)
        except OSError:
            pass
