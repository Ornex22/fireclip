"""The VOD library: one folder per analysed VOD inside the work folder.

vods/<key>/
    meta.json         what this VOD is (Twitch id or local file, title, date, duration)
    state.json        analysis status (for the list and for resuming after a crash)
    audio.m4a         downloaded audio (audio-first mode)        | vod.mp4 (full mode)
    chat.json         raw chat replay (TwitchDownloader format)  -> chat_compact.json
    clips.json        clips made by viewers
    transcript/<model>/chunk_*.json  + transcript_<model>.json
    audio_features.npz
    ai/               AI answers cache, ai_moments.json
    moments.json      ranked moments (and Albion kill clips)
    edits.json        your changes to the moments (start/end, title, ticks, subtitles)
    albion.json       Albion Online kills / deaths during the VOD   albion_edits.json  your changes to them
    albion_vod.json   timing correction for this VOD
    segments/         small video pieces for preview / export
"""
from __future__ import annotations

import hashlib
import shutil
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from .util import pid_alive, read_json, write_json


@dataclass
class VodRef:
    key: str
    dir: Path

    @property
    def meta(self) -> dict:
        return read_json(self.dir / "meta.json", {}) or {}

    def save_meta(self, meta: dict) -> None:
        write_json(self.dir / "meta.json", meta)

    @property
    def kind(self) -> str:
        return self.meta.get("kind", "twitch")

    @property
    def vod_id(self) -> str:
        return self.meta.get("vod_id", "")

    @property
    def local_path(self) -> Optional[Path]:
        p = self.meta.get("local_path")
        return Path(p) if p else None

    # files
    def p(self, *parts) -> Path:
        return self.dir.joinpath(*parts)

    def audio_file(self) -> Optional[Path]:
        """The file used as the audio source (downloaded audio, full VOD or local video)."""
        if self.kind == "local":
            lp = self.local_path
            return lp if lp and lp.exists() else None
        m = self.meta
        for name in (m.get("audio_file"), "audio.m4a", "vod.mp4"):
            if name and (self.dir / name).exists() and (self.dir / (Path(name).stem + ".done")).exists():
                return self.dir / name
        return None

    def video_file(self) -> Optional[Path]:
        """A local file containing the whole video, if there is one."""
        if self.kind == "local":
            lp = self.local_path
            return lp if lp and lp.exists() else None
        f = self.dir / "vod.mp4"
        return f if f.exists() and (self.dir / "vod.done").exists() else None

    # state
    @property
    def state(self) -> dict:
        return read_json(self.dir / "state.json", {}) or {}

    def set_state(self, **kw) -> None:
        st = self.state
        st.update(kw)
        st["updated_at"] = time.time()
        write_json(self.dir / "state.json", st)

    def status(self) -> str:
        """queued | running | done | error | interrupted (crash / app closed) | paused (by you) | new"""
        st = self.state
        s = st.get("status", "new")
        if s == "running" and not pid_alive(int(st.get("pid") or 0)):
            return "interrupted"
        return s

    def moments(self) -> Optional[dict]:
        return read_json(self.dir / "moments.json", None)

    def edits(self) -> dict:
        return read_json(self.dir / "edits.json", {}) or {}

    def save_edits(self, edits: dict) -> None:
        write_json(self.dir / "edits.json", edits)

    def albion_edits(self) -> dict:
        return read_json(self.dir / "albion_edits.json", {}) or {}

    def save_albion_edits(self, edits: dict) -> None:
        write_json(self.dir / "albion_edits.json", edits)

    def albion(self) -> Optional[dict]:
        return read_json(self.dir / "albion.json", None)

    def albion_settings(self) -> dict:
        return read_json(self.dir / "albion_vod.json", {}) or {}

    def save_albion_settings(self, d: dict) -> None:
        write_json(self.dir / "albion_vod.json", d)


class Library:
    def __init__(self, work_dir: Path):
        self.root = Path(work_dir) / "vods"

    def ref(self, key: str) -> VodRef:
        return VodRef(key, self.root / key)

    def for_twitch(self, vod_id: str) -> VodRef:
        ref = self.ref(f"tw_{vod_id}")
        ref.dir.mkdir(parents=True, exist_ok=True)
        if not (ref.dir / "meta.json").exists():
            ref.save_meta({"key": ref.key, "kind": "twitch", "vod_id": str(vod_id), "added_at": time.time()})
        return ref

    def for_local(self, path: Path) -> VodRef:
        path = Path(path).resolve()
        h = hashlib.sha1(str(path).lower().encode("utf-8")).hexdigest()[:10]
        ref = self.ref(f"local_{h}")
        ref.dir.mkdir(parents=True, exist_ok=True)
        if not (ref.dir / "meta.json").exists():
            try:
                mtime = path.stat().st_mtime
            except OSError:
                mtime = time.time()
            ref.save_meta({"key": ref.key, "kind": "local", "local_path": str(path), "title": path.stem,
                           "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(mtime)),
                           "file_mtime": mtime, "added_at": time.time()})
        return ref

    def all(self) -> list[VodRef]:
        if not self.root.is_dir():
            return []
        refs = [VodRef(p.name, p) for p in self.root.iterdir() if p.is_dir() and (p / "meta.json").exists()]

        def sort_key(r: VodRef):
            m = r.meta
            return m.get("created_at") or "", m.get("added_at") or 0

        refs.sort(key=sort_key, reverse=True)
        return refs

    def delete(self, ref: VodRef) -> None:
        shutil.rmtree(ref.dir, ignore_errors=True)

    def prune(self, keep: int, protect: tuple = ()) -> list[str]:
        """Delete VODs beyond the `keep` most recent ones. Returns deleted keys."""
        if keep <= 0:
            return []
        deleted = []
        for r in self.all()[keep:]:
            if r.key in protect or r.status() in ("running", "queued"):
                continue
            self.delete(r)
            deleted.append(r.key)
        return deleted


def free_media(ref: VodRef) -> int:
    """Delete the big downloaded files of a VOD (keeps transcript and results). Returns bytes freed."""
    freed = 0
    for name in ("audio.m4a", "vod.mp4", "audio.done", "vod.done"):
        f = ref.dir / name
        if f.exists():
            try:
                freed += f.stat().st_size
                f.unlink()
            except OSError:
                pass
    m = ref.meta
    af = m.get("audio_file")
    if af and (ref.dir / af).exists():
        try:
            freed += (ref.dir / af).stat().st_size
            (ref.dir / af).unlink()
            (ref.dir / (Path(af).stem + ".done")).unlink(missing_ok=True)
        except OSError:
            pass
    seg = ref.dir / "segments"
    if seg.is_dir():
        for f in seg.iterdir():
            try:
                freed += f.stat().st_size
            except OSError:
                pass
        shutil.rmtree(seg, ignore_errors=True)
    shutil.rmtree(ref.dir / "tmp", ignore_errors=True)
    return freed
