"""Getting audio, video and chat: downloads from Twitch, local files, and audio decoding."""
from __future__ import annotations

import logging
import re
import shutil
import subprocess
import threading
from pathlib import Path
from typing import Callable, Iterator, Optional

import numpy as np

from . import tools
from .errors import UserError, classify_tool_error
from .store import VodRef
from .util import Cancelled, popen, read_json, run_streaming, write_json

log = logging.getLogger("fireclips.media")

Progress = Callable[[float, str], None]


def _noop(_f: float, _m: str = "") -> None:
    pass


# --------------------------------------------------------------------------- TwitchDownloaderCLI

_TD_STATUS = re.compile(r"\[STATUS\]\s*-\s*(.*?)(\d{1,3})%(?:\s*\[(\d)/(\d)\])?")
# share of each TwitchDownloader video step (info, download, verify, finalize)
_TD_VIDEO_STEPS = {1: (0.0, 0.02), 2: (0.02, 0.90), 3: (0.90, 0.93), 4: (0.93, 1.0)}


def _td_common(cfg, work: Path) -> list:
    args = ["--banner=false", "--collision", "Overwrite"]
    tmp = work / "tmp"
    tmp.mkdir(parents=True, exist_ok=True)
    args += ["--temp-path", str(tmp)]
    return args


def _td_oauth(cfg) -> list:
    tok = (cfg.get("twitch_oauth") or "").strip()
    if tok:
        tok = tok.replace("OAuth ", "").replace("oauth:", "").strip()
        return ["--oauth", tok]
    return []


def _td_video_progress(progress: Progress, label: str) -> Callable[[str], None]:
    def on_line(line: str) -> None:
        m = _TD_STATUS.search(line)
        if not m:
            return
        pct = min(100, int(m.group(2))) / 100.0
        step = int(m.group(3)) if m.group(3) else 2
        lo, hi = _TD_VIDEO_STEPS.get(step, (0.0, 1.0))
        progress(lo + (hi - lo) * pct, label)
    return on_line


def _run_tdcli_video(cfg, vod_id: str, out: Path, work: Path, quality: Optional[str], progress: Progress,
                     cancel, begin: Optional[float] = None, end: Optional[float] = None, threads: int = 8,
                     label: str = "") -> None:
    td = tools.require("tdcli")
    ffmpeg = tools.require("ffmpeg")
    cmd = [td, "videodownload", "--id", vod_id, "-o", str(out), "-t", str(threads),
           "--ffmpeg-path", str(ffmpeg)] + _td_common(cfg, work) + _td_oauth(cfg)
    if quality:
        cmd += ["-q", quality]
    if begin is not None:
        cmd += ["-b", f"{max(0.0, begin):.3f}"]
    if end is not None:
        cmd += ["-e", f"{end:.3f}"]
    code, last = run_streaming(cmd, _td_video_progress(progress, label), cwd=str(work), cancel=cancel)
    if code != 0 or not out.exists() or out.stat().st_size < 1024:
        log.warning("TwitchDownloaderCLI failed (%s): %s", code, "\n".join(last[-15:]))
        raise UserError(classify_tool_error(last), "\n".join(last[-8:]))


def _run_ytdlp(url: str, out_template: Path, fmt: str, progress: Progress, cancel, label: str,
               sections: Optional[str] = None) -> Path:
    yt = tools.require("ytdlp")
    ffmpeg = tools.require("ffmpeg")
    cmd = [yt, "-f", fmt, "-o", str(out_template), "--newline", "--no-warnings", "--no-playlist",
           "-N", "8", "--ffmpeg-location", str(ffmpeg), "--force-overwrites", "--no-part"]
    if sections:
        cmd += ["--download-sections", sections]
    cmd.append(url)
    pat = re.compile(r"\[download\]\s+([\d.]+)%")

    def on_line(line: str) -> None:
        m = pat.search(line)
        if m:
            progress(min(1.0, float(m.group(1)) / 100.0), label)

    code, last = run_streaming(cmd, on_line, cwd=str(out_template.parent), cancel=cancel)
    stem = out_template.name.split(".%(ext)s")[0]
    found = sorted(p for p in out_template.parent.glob(stem + ".*")
                   if p.suffix.lower() in (".m4a", ".mp4", ".ts", ".aac", ".mkv", ".webm", ".mp3"))
    if code != 0 or not found:
        raise UserError(classify_tool_error(last), "\n".join(last[-8:]))
    return found[0]


# --------------------------------------------------------------------------- audio / full VOD


def download_audio(ref: VodRef, cfg, progress: Progress = _noop, cancel=None) -> Path:
    """Download only the audio of a Twitch VOD (small and fast). Falls back to yt-dlp."""
    existing = ref.audio_file()
    if existing:
        return existing
    label = "audio"
    out = ref.p("audio_dl.m4a")
    try:
        _run_tdcli_video(cfg, ref.vod_id, out, ref.dir, "audio", progress, cancel, label=label)
        final = ref.p("audio.m4a")
        out.replace(final)
    except Cancelled:
        raise
    except Exception as e:  # noqa: BLE001
        log.warning("audio download with TwitchDownloaderCLI failed, trying yt-dlp: %s", e)
        if tools.find("ytdlp") is None:
            raise
        got = _run_ytdlp(f"https://www.twitch.tv/videos/{ref.vod_id}", ref.p("audio_dl.%(ext)s"),
                         "bestaudio/worst", progress, cancel, label)
        final = ref.p("audio" + got.suffix.lower())
        got.replace(final)
    ref.p(final.stem + ".done").write_text("ok", encoding="utf-8")
    m = ref.meta
    m["audio_file"] = final.name
    ref.save_meta(m)
    return final


def download_full(ref: VodRef, cfg, progress: Progress = _noop, cancel=None) -> Path:
    """Download the whole VOD video (big)."""
    vf = ref.video_file()
    if vf:
        return vf
    out = ref.p("vod_dl.mp4")
    quality = cfg.get("export_quality") or "best"
    try:
        _run_tdcli_video(cfg, ref.vod_id, out, ref.dir, quality, progress, cancel, threads=10, label="video")
    except Cancelled:
        raise
    except Exception as e:  # noqa: BLE001
        log.warning("full download with TwitchDownloaderCLI failed, trying yt-dlp: %s", e)
        if tools.find("ytdlp") is None:
            raise
        got = _run_ytdlp(f"https://www.twitch.tv/videos/{ref.vod_id}", ref.p("vod_dl.%(ext)s"),
                         "best[vcodec!=none]/best", progress, cancel, "video")
        if got.suffix.lower() != ".mp4":
            remux = ref.p("vod_dl.mp4")
            ff = tools.require("ffmpeg")
            code, last = run_streaming([ff, "-y", "-v", "error", "-i", str(got), "-c", "copy", str(remux)],
                                       cancel=cancel)
            if code != 0:
                raise UserError("err_download_failed", "\n".join(last[-5:]))
            got.unlink(missing_ok=True)
            got = remux
        out = got
    final = ref.p("vod.mp4")
    out.replace(final)
    ref.p("vod.done").write_text("ok", encoding="utf-8")
    m = ref.meta
    m["audio_file"] = "vod.mp4"
    ref.save_meta(m)
    return final


# --------------------------------------------------------------------------- chat


def download_chat(ref: VodRef, cfg, progress: Progress = _noop, cancel=None) -> list:
    """Download the chat replay and return it as [[offset_seconds, user, text], ...]."""
    compact = ref.p("chat_compact.json")
    data = read_json(compact, None)
    if isinstance(data, list):
        return data
    raw = ref.p("chat.json")
    if not raw.exists():
        td = tools.require("tdcli")
        tmp = ref.p("chat_dl.json")
        cmd = [td, "chatdownload", "--id", ref.vod_id, "-o", str(tmp), "-t", "4"] + _td_common(cfg, ref.dir)
        pat = re.compile(r"\[STATUS\]\s*-\s*Downloading\s+(\d{1,3})%")

        def on_line(line: str) -> None:
            m = pat.search(line)
            if m:
                progress(min(100, int(m.group(1))) / 100.0, "chat")

        code, last = run_streaming(cmd, on_line, cwd=str(ref.dir), cancel=cancel)
        if code != 0 or not tmp.exists():
            raise UserError(classify_tool_error(last), "\n".join(last[-8:]))
        tmp.replace(raw)
    msgs = compact_chat(raw)
    write_json(compact, msgs, indent=None)
    return msgs


def compact_chat(raw_path: Path) -> list:
    data = read_json(raw_path, {}) or {}
    out = []
    for c in data.get("comments") or []:
        try:
            off = float(c.get("content_offset_seconds"))
        except (TypeError, ValueError):
            continue
        commenter = c.get("commenter") or {}
        user = commenter.get("name") or commenter.get("display_name") or commenter.get("_id") or "?"
        msg = c.get("message") or {}
        body = msg.get("body")
        if body is None:
            body = "".join((f.get("text") or "") for f in (msg.get("fragments") or []))
        out.append([round(off, 2), str(user), str(body)])
    out.sort(key=lambda x: x[0])
    return out


def chat_video_info(ref: VodRef) -> dict:
    """VOD information stored inside the chat file (fallback when the Twitch API is unreachable)."""
    data = read_json(ref.p("chat.json"), {}) or {}
    v = data.get("video") or {}
    s = data.get("streamer") or {}
    out = {}
    if v.get("title"):
        out["title"] = v["title"]
    if v.get("created_at"):
        out["created_at"] = v["created_at"]
    length = v.get("length") or (v.get("end") or 0) - (v.get("start") or 0)
    if length and length > 0:
        out["duration"] = float(length)
    if s.get("login") or s.get("name"):
        out["login"] = s.get("login") or s.get("name")
        out["display_name"] = s.get("name") or s.get("login")
    return out


# --------------------------------------------------------------------------- audio decoding


def decode_pcm(path: Path, start: float = 0.0, duration: Optional[float] = None, sr: int = 16000) -> np.ndarray:
    """Decode part of a media file to mono 16-bit PCM."""
    ff = tools.require("ffmpeg")
    cmd = [ff, "-nostdin", "-v", "error"]
    if start > 0:
        cmd += ["-ss", f"{start:.3f}"]
    if duration is not None:
        cmd += ["-t", f"{max(0.01, duration):.3f}"]
    cmd += ["-i", str(path), "-vn", "-ac", "1", "-ar", str(sr), "-f", "s16le", "-"]
    proc = popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = proc.communicate()
    if proc.returncode != 0 and not out:
        raise UserError("err_decode_audio", err.decode("utf-8", "replace")[-400:])
    return np.frombuffer(out, dtype=np.int16).copy()


def iter_pcm(path: Path, sr: int = 16000, block_seconds: float = 60.0,
             cancel: Optional[threading.Event] = None) -> Iterator[np.ndarray]:
    """Stream a whole file as mono int16 blocks (keeps memory low for 8 h VODs)."""
    ff = tools.require("ffmpeg")
    cmd = [ff, "-nostdin", "-v", "error", "-i", str(path), "-vn", "-ac", "1", "-ar", str(sr), "-f", "s16le", "-"]
    proc = popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, bufsize=1 << 20)
    block_bytes = int(sr * block_seconds) * 2
    try:
        assert proc.stdout is not None
        while True:
            if cancel is not None and cancel.is_set():
                raise Cancelled()
            buf = bytearray()
            while len(buf) < block_bytes:
                chunk = proc.stdout.read(block_bytes - len(buf))
                if not chunk:
                    break
                buf += chunk
            if not buf:
                break
            if len(buf) % 2:
                buf = buf[:-1]
            yield np.frombuffer(bytes(buf), dtype=np.int16)
            if len(buf) < block_bytes:
                break
    finally:
        try:
            proc.kill()
        except Exception:
            pass
        proc.wait()


def media_duration(path: Path) -> float:
    return float(tools.probe(path).get("duration") or 0.0)


# --------------------------------------------------------------------------- segments (preview / export)


def _quality_rank(q: str) -> int:
    q = (q or "").lower()
    if q in ("best", "source", "chunked", ""):
        return 10_000
    m = re.match(r"(\d+)p(\d+)?", q)
    if not m:
        return 0
    return int(m.group(1)) * 10 + (1 if (m.group(2) or "30") not in ("30", "") else 0)


def align_offset(segment: Path, reference: Path, approx_start: float, sr: int = 8000) -> tuple[float, float]:
    """Find exactly where a downloaded segment starts in the VOD by matching its sound with the
    full audio track. Returns (start_in_vod, confidence 0..1)."""
    try:
        seg = decode_pcm(segment, 0, 12.0, sr).astype(np.float32)
        lead = 6.0
        ref = decode_pcm(reference, max(0.0, approx_start - lead), 12.0 + 2 * lead, sr).astype(np.float32)
    except Exception as e:  # noqa: BLE001
        log.info("alignment decode failed: %s", e)
        return approx_start, 0.0
    ref_start = max(0.0, approx_start - lead)
    if len(seg) < sr * 2 or len(ref) < len(seg):
        return approx_start, 0.0
    seg -= seg.mean()
    ref -= ref.mean()
    if float(np.abs(seg).max()) < 50:  # silence: nothing to match
        return approx_start, 0.0
    n = len(ref) + len(seg)
    nfft = 1 << (n - 1).bit_length()
    corr = np.fft.irfft(np.fft.rfft(ref, nfft) * np.conj(np.fft.rfft(seg, nfft)), nfft)[: len(ref) - len(seg) + 1]
    # normalise by the energy of the reference window at each lag
    csum = np.concatenate([[0.0], np.cumsum(ref.astype(np.float64) ** 2)])
    energy = np.sqrt(np.maximum(csum[len(seg):] - csum[:-len(seg)], 1e-9))[: len(corr)]
    norm = corr / (energy * np.sqrt(float((seg.astype(np.float64) ** 2).sum())) + 1e-9)
    lag = int(np.argmax(norm))
    conf = float(norm[lag])
    start = ref_start + lag / sr
    if conf < 0.45 or abs(start - approx_start) > lead - 0.2:
        return approx_start, conf
    return start, conf


def get_segment(ref: VodRef, cfg, start: float, end: float, purpose: str = "preview",
                progress: Progress = _noop, cancel=None) -> dict:
    """A playable file covering [start, end] of the VOD.

    Returns {"path", "vod_start", "duration", "full"}: VOD time t is at file time t - vod_start.
    """
    vf = ref.video_file()
    if vf:
        dur = float(ref.meta.get("duration") or 0) or media_duration(vf)
        return {"path": str(vf), "vod_start": 0.0, "duration": dur, "full": True}
    if ref.kind == "local":
        raise UserError("err_local_missing", str(ref.local_path))

    quality = cfg.get("preview_quality") if purpose == "preview" else cfg.get("export_quality")
    quality = quality or "best"
    need_rank = 0 if purpose == "preview" else _quality_rank(quality)
    seg_dir = ref.p("segments")
    seg_dir.mkdir(parents=True, exist_ok=True)

    # reuse a cached piece that already covers the range
    for meta_file in sorted(seg_dir.glob("*.json")):
        m = read_json(meta_file, {}) or {}
        f = seg_dir / m.get("file", "")
        if not f.exists():
            continue
        if m.get("vod_start", 1e18) <= start + 0.05 and m.get("vod_start", 0) + m.get("duration", 0) >= end - 0.05:
            if _quality_rank(m.get("quality", "")) >= need_rank:
                return {"path": str(f), "vod_start": m["vod_start"], "duration": m["duration"], "full": False}

    margin = 12.0 if purpose == "preview" else 3.0
    vod_len = float(ref.meta.get("duration") or 0) or 1e9
    a = max(0.0, (int((start - margin) // 5)) * 5.0)
    b = min(vod_len, (int((end + margin) // 5) + 1) * 5.0)
    name = f"{purpose}_{re.sub(r'[^0-9a-z]', '', quality.lower()) or 'q'}_{int(a * 1000)}_{int(b * 1000)}"
    out = seg_dir / (name + ".mp4")
    tmp = seg_dir / (name + "_dl.mp4")
    try:
        _run_tdcli_video(cfg, ref.vod_id, tmp, ref.dir, quality, progress, cancel, begin=a, end=b, threads=4,
                         label="segment")
    except Cancelled:
        raise
    except Exception as e:  # noqa: BLE001
        log.warning("segment download with TwitchDownloaderCLI failed, trying yt-dlp: %s", e)
        if tools.find("ytdlp") is None:
            raise
        h = re.match(r"(\d+)p", quality or "")
        fmt = f"best[height<={h.group(1)}]/best" if h else "best"
        got = _run_ytdlp(f"https://www.twitch.tv/videos/{ref.vod_id}", seg_dir / (name + "_dl.%(ext)s"), fmt,
                         progress, cancel, "segment", sections=f"*{a:.2f}-{b:.2f}")
        if got != tmp:
            got.replace(tmp)
    tmp.replace(out)
    info = tools.probe(out)
    dur = float(info.get("duration") or (b - a))
    vod_start, conf = a, 0.0
    audio = ref.audio_file()
    if audio is not None and info.get("has_audio"):
        vod_start, conf = align_offset(out, audio, a)
    meta = {"file": out.name, "vod_start": round(vod_start, 3), "duration": dur, "quality": quality,
            "requested": [a, b], "align_conf": round(conf, 3)}
    write_json(seg_dir / (name + ".json"), meta)
    return {"path": str(out), "vod_start": meta["vod_start"], "duration": dur, "full": False}


def cleanup_segments(ref: VodRef, keep_purpose: Optional[str] = None) -> None:
    seg_dir = ref.p("segments")
    if not seg_dir.is_dir():
        return
    for f in seg_dir.iterdir():
        if keep_purpose and f.name.startswith(keep_purpose):
            continue
        try:
            f.unlink()
        except OSError:
            pass


def copy_tree_free(src: Path, dst: Path) -> None:
    shutil.copytree(src, dst, dirs_exist_ok=True)
