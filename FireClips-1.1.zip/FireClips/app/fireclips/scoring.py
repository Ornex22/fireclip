"""Combine all the signals into one score per moment and build the ranked list.

score = weighted average of the signals (weights from the settings), 0..100.
Candidates come from: AI moments, peaks of the "reaction" signals (chat, laughter, yelling,
keywords, Albion kills) and clips made by viewers. Overlapping candidates are merged, context
is added around peaks (20 s before / 10 s after by default) and clip edges are moved so that
they do not cut a word in half.

Also built here: the clips asked for with a trigger phrase (always shown first) and the Albion
kill clips of the "Kills Albion" tab.
"""
from __future__ import annotations

import math
import time
from typing import Optional

import numpy as np

from . import albion as A
from . import signals as S
from . import triggers as TR
from .store import VodRef
from .transcribe import find_transcript
from .util import fmt_time, read_json, write_json

REACTION = ("chat_activity", "chat_laughs", "laughter", "loudness", "voice_keywords", "clips", "albion")


def load_inputs(ref: VodRef, cfg=None) -> dict:
    meta = ref.meta
    tp = find_transcript(ref.dir)
    transcript = read_json(tp, None) if tp else None
    chat = read_json(ref.p("chat_compact.json"), None)
    clips = read_json(ref.p("clips.json"), None)
    ai = read_json(ref.p("ai_moments.json"), None)
    feats = ref.p("audio_features.npz")
    duration = float(meta.get("duration") or 0)
    if not duration and transcript:
        duration = float(transcript.get("duration") or 0)
    inp = {"meta": meta, "transcript": transcript, "chat": chat, "clips": clips, "ai": ai,
           "features": feats if feats.exists() else None, "duration": duration,
           "albion": ref.albion(), "albion_vod": ref.albion_settings()}
    if cfg is not None and transcript:
        inp["triggers"] = _cached_triggers(ref, tp, transcript, cfg)
    return inp


def _cached_triggers(ref: VodRef, tp, transcript: dict, cfg) -> list:
    """Looking for the trigger phrases in an 8 h transcript takes about a second: remember it."""
    import hashlib
    import json
    phrases = cfg.get("trigger_phrases") or []
    try:
        mtime = tp.stat().st_mtime
    except OSError:
        mtime = 0
    key = hashlib.sha1(json.dumps([tp.name, mtime, phrases, cfg.get("trigger_max_seconds"), 2],
                                  sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()[:16]
    cache = read_json(ref.p("triggers.json"), {}) or {}
    if cache.get("key") == key:
        return cache.get("found") or []
    found = TR.find(transcript, phrases, float(cfg.get("trigger_max_seconds") or 600)) if phrases else []
    try:
        write_json(ref.p("triggers.json"), {"key": key, "found": found})
    except OSError:
        pass
    return found


def albion_events(inp: dict, cfg) -> list:
    """Kills / assists / deaths of the linked Albion players, placed in the VOD."""
    doc = inp.get("albion")
    if not doc:
        return []
    return A.map_events(doc, A.vod_offset(cfg, inp.get("albion_vod")), max(1.0, inp["duration"]))


def build_signals(inp: dict, cfg) -> tuple[dict, dict]:
    dur = max(1.0, inp["duration"])
    n = int(math.ceil(dur)) + 1
    sig: dict = {}
    extra: dict = {}
    chat = inp.get("chat")
    if chat and len(chat) >= 20:
        cs = S.chat_signals(chat, dur, float(cfg.get("chat_delay") or 6), cfg.get("laugh_keywords") or [],
                            cfg.get("clip_keywords") or [])
        sig["chat_activity"] = cs["chat_activity"]
        sig["chat_laughs"] = cs["chat_laughs"]
        extra["chat_raw"] = cs["raw"]
    if inp.get("features") is not None:
        try:
            a = S.audio_signals(inp["features"], dur)
            sig["loudness"] = a["loudness"]
            if "laughter" in a:
                sig["laughter"] = a["laughter"]
        except Exception:  # noqa: BLE001 - a broken features file must not stop the ranking
            pass
    tr = inp.get("transcript")
    if tr and tr.get("segments"):
        vk, found = S.voice_keyword_signal(tr, dur, cfg.get("voice_keywords") or [])
        sig["voice_keywords"] = vk
        extra["voice_found"] = found
    clips = inp.get("clips")
    if clips:
        sig["clips"] = S.clips_signal(clips, dur)
    events = inp.get("albion_events")
    if events is None:
        events = albion_events(inp, cfg)
    if events:
        arr = np.zeros(n, dtype=np.float32)
        for e in events:
            a, b = int(max(0, e["off"] - 12)), int(min(n, e["off"] + 7))
            if b > a:
                arr[a:b] = np.maximum(arr[a:b], A.event_strength(e))
        sig["albion"] = arr
    ai = inp.get("ai")
    if ai and ai.get("provider") not in (None, "none"):
        arr = np.zeros(n, dtype=np.float32)
        for m in ai.get("moments", []):
            a, b = int(max(0, m["start"])), int(min(n, math.ceil(m["end"]) + 1))
            arr[a:b] = np.maximum(arr[a:b], m["score"] / 10.0)
        sig["ai"] = arr
    for k in list(sig):
        if len(sig[k]) < n:
            sig[k] = np.pad(sig[k], (0, n - len(sig[k])))
        sig[k] = sig[k][:n]
    return sig, extra


def _weights(cfg, available) -> dict:
    w = cfg.get("weights") or {}
    return {k: max(0.0, float(w.get(k, 0))) for k in available}


def _combined(sig: dict, w: dict, keys) -> np.ndarray:
    keys = [k for k in keys if k in sig and w.get(k, 0) > 0]
    if not keys:
        n = len(next(iter(sig.values()))) if sig else 1
        return np.zeros(n)
    tot = sum(w[k] for k in keys)
    return sum(sig[k] * (w[k] / tot) for k in keys)


def _pick_peaks(r: np.ndarray, min_value: float, min_gap: int, limit: int) -> list[int]:
    order = np.argsort(-r)
    taken: list[int] = []
    for i in order:
        if r[i] < min_value or len(taken) >= limit:
            break
        if all(abs(int(i) - t) >= min_gap for t in taken):
            taken.append(int(i))
    return taken


def _best_window(S_all: np.ndarray, a: float, b: float, length: float) -> tuple[float, float]:
    ia, ib, L = int(a), int(math.ceil(b)), int(round(length))
    seg = S_all[ia:ib]
    if len(seg) <= L or L <= 0:
        return a, b
    cs = np.concatenate([[0.0], np.cumsum(seg)])
    sums = cs[L:] - cs[:-L]
    j = int(np.argmax(sums))
    return float(ia + j), float(ia + j + L)


def _words(transcript: Optional[dict]) -> list:
    if not transcript:
        return []
    out = []
    for seg in transcript.get("segments", []):
        for w in seg.get("w", []):
            out.append((float(w[1]), float(w[2]), w[0]))
    out.sort()
    return out


def _snap(start: float, end: float, words: list, segs: list, duration: float) -> tuple[float, float]:
    """Move clip edges so they fall between words, preferably at a sentence start / end."""
    if segs:
        cand = [s for s in segs if start - 3.0 <= s[0] <= start + 1.0]
        if cand:
            start = min(cand, key=lambda s: abs(s[0] - start))[0] - 0.25
        cand = [s for s in segs if end - 1.5 <= s[1] <= end + 3.0]
        if cand:
            end = min(cand, key=lambda s: abs(s[1] - end))[1] + 0.35
    for ws, we, _t in words:
        if ws < start < we:
            start = ws - 0.15
        if ws < end < we:
            end = we + 0.2
    return max(0.0, start), min(duration, end)


def _text_between(transcript: Optional[dict], a: float, b: float, limit: int = 900) -> str:
    if not transcript:
        return ""
    parts = []
    for seg in transcript.get("segments", []):
        if seg["e"] < a or seg["s"] > b:
            continue
        words = [w[0] for w in seg.get("w", []) if a - 0.2 <= w[1] <= b]
        parts.append("".join(words).strip() if words else seg.get("t", ""))
    text = " ".join(p for p in parts if p)
    return text[:limit] + ("…" if len(text) > limit else "")


def rank(inp: dict, cfg) -> dict:
    from .i18n import language, tr
    t0 = time.time()
    dur = max(1.0, inp["duration"])
    events = albion_events(inp, cfg)
    inp = dict(inp, albion_events=events)
    sig, extra = build_signals(inp, cfg)
    available = sorted(sig)
    w = _weights(cfg, available)
    wsum = sum(w.values()) or 1.0
    S_all = _combined(sig, w, available) if sig else np.zeros(int(math.ceil(dur)) + 1)
    R = _combined(sig, w, [k for k in REACTION if k in sig])
    R5 = np.convolve(R, np.ones(5) / 5, mode="same") if len(R) else R

    top_n = int(cfg.get("top_n") or 20)
    pre = float(cfg.get("context_before") or 20)
    post = float(cfg.get("context_after") or 10)
    min_len = float(cfg.get("min_clip_len") or 15)
    max_len = max(min_len + 5, float(cfg.get("max_clip_len") or 90))
    transcript = inp.get("transcript")
    words = _words(transcript)
    segs = [(float(s["s"]), float(s["e"])) for s in (transcript or {}).get("segments", [])]

    # ---- candidates
    cands: list[dict] = []
    ai = inp.get("ai") or {}
    for m in ai.get("moments", []) if "ai" in sig else []:
        cands.append({"start": m["start"] - 2.0, "end": m["end"] + 2.0, "peak": None, "src": {"ai"},
                      "ai": m})
    if len(R5):
        for p in _pick_peaks(R5, 0.12, 30, 4 * top_n):
            cands.append({"start": p - pre, "end": p + post, "peak": float(p), "src": {"reaction"}})
    for c in inp.get("clips") or []:
        p = c["offset"] + max(5.0, c.get("duration", 30)) - 5.0
        cands.append({"start": p - pre, "end": p + post, "peak": p, "src": {"clip"}})
    for c in cands:
        c["start"] = max(0.0, c["start"])
        c["end"] = min(dur, c["end"])

    def score_span(a: float, b: float) -> tuple[float, dict]:
        ia, ib = int(max(0, a - 2)), int(min(len(S_all), b + 4))
        vals = {}
        tot = 0.0
        for k in available:
            arr = sig[k][ia:ib]
            v = float(arr.max()) if len(arr) else 0.0
            vals[k] = round(v, 3)
            tot += w[k] * v
        return 100.0 * tot / wsum, vals

    for c in cands:
        c["score"], c["vals"] = score_span(c["start"], c["end"])
    cands.sort(key=lambda c: -c["score"])

    # ---- greedy selection + merging
    chosen: list[dict] = []
    for c in cands:
        placed = False
        trimmed = False
        for m in chosen:
            inter = min(m["end"], c["end"]) - max(m["start"], c["start"])
            if inter <= -2.0:
                continue
            union = max(m["end"], c["end"]) - min(m["start"], c["start"])
            if union <= max_len + 5:
                m["start"], m["end"] = min(m["start"], c["start"]), max(m["end"], c["end"])
                m["src"] |= c["src"]
                if c.get("ai") and (not m.get("ai") or c["ai"]["score"] > m["ai"]["score"]):
                    m["ai"] = c["ai"]
                if m.get("peak") is None and c.get("peak") is not None:
                    m["peak"] = c["peak"]
                placed = True
                break
            if inter > 0.3 * (c["end"] - c["start"]):
                placed = True  # mostly covered by a better moment
                break
            if inter > 0:
                trimmed = True
                if c["start"] < m["start"]:
                    c["end"] = m["start"]
                else:
                    c["start"] = m["end"]
        if not placed and (not trimmed or c["end"] - c["start"] >= min_len * 0.6) and c["end"] > c["start"]:
            chosen.append(dict(c))
        if len(chosen) >= 3 * top_n:
            break

    # ---- finalize each moment
    out = []
    raw = extra.get("chat_raw")
    chat = inp.get("chat") or []
    delay = float(cfg.get("chat_delay") or 6)
    for m in chosen:
        a, b = m["start"], m["end"]
        if m.get("ai"):
            # the AI chose where the story starts: do not add unrelated talk before it
            a = max(a, m["ai"]["start"] - 3.0)
        if b - a > max_len:
            a, b = _best_window(S_all, a, b, max_len)
        if b - a < min_len:
            need = min_len - (b - a)
            b = min(dur, b + need * 0.6)
            a = max(0.0, a - (min_len - (b - a)))
            if b - a < min_len:
                b = min(dur, a + min_len)
        a, b = _snap(a, b, words, segs, dur)
        score, vals = score_span(a, b)
        reasons = []
        if m.get("ai"):
            am = m["ai"]
            reasons.append({"kind": "ai", "value": vals.get("ai", am["score"] / 10), "score": am["score"],
                            "text": am.get("reason", ""), "category": am.get("category", "")})
        if vals.get("chat_activity", 0) >= 0.3 and raw is not None:
            ia, ib = int(a), int(min(len(raw["rate"]), b + 4))
            rate = float(raw["rate"][ia:ib].max()) if ib > ia else 0
            base = float(max(0.02, raw["base"][ia:ib].mean())) if ib > ia else 1
            reasons.append({"kind": "chat_activity", "value": vals["chat_activity"], "ratio": round(rate / base, 1)})
        if vals.get("chat_laughs", 0) >= 0.3 and raw is not None:
            ia, ib = int(a), int(min(len(raw["laughs"]), b + 4))
            n_l = int(raw["laughs"][ia:ib].sum() + raw["clipreq"][ia:ib].sum())
            laugh_rx = S.keyword_regex((cfg.get("laugh_keywords") or []) + (cfg.get("clip_keywords") or []),
                                       builtin=True)
            top = S.chat_excerpt(chat, a + delay - 2, b + delay + 6, 3, only=laugh_rx)
            reasons.append({"kind": "chat_laughs", "value": vals["chat_laughs"], "count": n_l, "top": top})
        overlapping = [c for c in (inp.get("clips") or []) if c["offset"] < b and c["offset"] + c.get("duration", 30) > a]
        if overlapping:
            reasons.append({"kind": "clips", "value": vals.get("clips", 1.0), "count": len(overlapping),
                            "views": int(sum(c.get("views", 0) for c in overlapping))})
        if vals.get("laughter", 0) >= 0.35:
            reasons.append({"kind": "laughter", "value": vals["laughter"]})
        if vals.get("loudness", 0) >= 0.4:
            reasons.append({"kind": "loudness", "value": vals["loudness"]})
        if vals.get("voice_keywords", 0) >= 0.3:
            kws = sorted({k for t, k in extra.get("voice_found", []) if a - 1 <= t <= b + 1})
            reasons.append({"kind": "voice_keywords", "value": vals["voice_keywords"], "words": kws[:5]})
        near = [e for e in events if a - 2 <= e["off"] <= b + 2]
        if near:
            reasons.append(_albion_reason(near, vals.get("albion", 0)))
        reasons.sort(key=lambda r: -(w.get(r["kind"], 0) * float(r.get("value", 0))))

        title = ""
        category = ""
        if m.get("ai"):
            title = m["ai"].get("title", "")
            category = m["ai"].get("category", "")
        if not title and overlapping:
            best = max(overlapping, key=lambda c: c.get("views", 0))
            title = (best.get("title") or "").strip()
        excerpt = _text_between(transcript, a, b)
        if not title:
            pk = m.get("peak") if m.get("peak") is not None else (a + b) / 2
            setup = _text_between(transcript, max(a, pk - 12), pk + 2, 200).split()
            title = ("« " + " ".join(setup[:9]) + ("… »" if len(setup) > 9 else " »")) if setup else ""
        out.append({
            "id": f"m{int(a * 10)}",
            "start": round(a, 2), "end": round(b, 2),
            "peak": round(m["peak"], 1) if m.get("peak") is not None else None,
            "score": round(score, 1),
            "title": title, "category": category,
            "sources": sorted(m["src"]), "signals": vals, "reasons": reasons,
            "transcript": excerpt,
        })

    out.sort(key=lambda x: -x["score"])
    min_score = float(cfg.get("min_score") or 0)
    shown = [m for m in out if m["score"] >= min_score][:top_n]
    for i, m in enumerate(shown, 1):
        m["rank"] = i

    # ---- clips asked for on stream with a trigger phrase: always kept, shown first
    trig = _trigger_moments(inp.get("triggers") or [], inp, cfg, words, segs, dur, score_span, events, tr)
    shown = trig + shown

    # ---- Albion kill clips (second tab)
    kills = A.build_clips(events, cfg, dur, tr, language(),
                          snap=lambda x, y: _snap(x, y, words, segs, dur),
                          text_between=lambda x, y: _text_between(transcript, x, y)) if events else []
    # small overview of the whole VOD for the timeline (one value per 10 s)
    step = 10
    nb = int(math.ceil(len(S_all) / step))
    timeline = (np.pad(S_all, (0, nb * step - len(S_all))).reshape(nb, step).max(axis=1) * 100).round(1).tolist()
    return {
        "version": 2,
        "computed_at": time.time(),
        "duration": dur,
        "available": available,
        "weights": w,
        "moments": shown,
        "kills": kills,
        "albion_info": _albion_info(inp.get("albion"), events),
        "timeline_events": [[round(e["off"], 1), e["role"]] for e in events],
        "candidates": len(out),
        "timeline_step": step,
        "timeline": timeline,
        "elapsed": round(time.time() - t0, 2),
    }


def _albion_reason(near: list, value: float) -> dict:
    return {"kind": "albion", "value": value,
            "kills": sum(1 for e in near if e["role"] == "kill"),
            "assists": sum(1 for e in near if e["role"] == "assist"),
            "deaths": sum(1 for e in near if e["role"] == "death"),
            "fame": int(sum(int(e.get("fame") or 0) for e in near if e["role"] != "death")),
            "death_fame": int(sum(int(e.get("fame") or 0) for e in near if e["role"] == "death")),
            "names": [A.opponent(e)["name"] for e in near][:4]}


def _albion_info(doc, events) -> dict:
    if not doc:
        return {}
    return {"fetched_at": doc.get("fetched_at"), "players": doc.get("players") or [],
            "partial": bool(doc.get("partial")), "errors": len(doc.get("errors") or []),
            "n_events": len(events)}


def _trigger_moments(found: list, inp: dict, cfg, words, segs, dur: float, score_span, events, tr) -> list:
    include = bool(cfg.get("trigger_include_phrase"))
    ai_moments = (inp.get("ai") or {}).get("moments") or []
    out = []
    for f in found:
        end = (f["said_end"] + 0.6) if include else (f["said_at"] - 0.25)
        end = max(1.0, min(dur, end))
        start = max(0.0, end - float(f["seconds"]))
        # start on a sentence / between two words
        cand = [s for s in segs if start - 4.0 <= s[0] <= start + 1.5]
        if cand:
            start = max(0.0, min(cand, key=lambda s: abs(s[0] - start))[0] - 0.25)
        for ws, we, _t in words:
            if ws < start < we:
                start = max(0.0, ws - 0.15)
                break
        if end - start < 3:
            continue
        score, vals = score_span(start, end)
        inside = [m for m in ai_moments if m["start"] >= start - 1 and m["end"] <= end + 1]
        best = max(inside, key=lambda m: m["score"]) if inside else None
        minutes = float(f["seconds"]) / 60.0
        if abs(minutes - 1) < 0.05:
            span = tr("trigger_span_1min")
        elif minutes >= 1:
            span = tr("trigger_span_min", n=(f"{minutes:.0f}" if abs(minutes - round(minutes)) < 0.05
                                             else f"{minutes:.1f}".replace(".", ",")))
        else:
            span = tr("trigger_span_sec", n=f"{float(f['seconds']):.0f}")
        title = (best.get("title") or "") if best else ""
        title = title or tr("trigger_title", span=span)
        reasons = [{"kind": "trigger", "heard": f.get("heard", ""), "phrase": f.get("phrase", ""),
                    "at": f["said_at"], "seconds": f["seconds"], "spoken": f.get("spoken", False), "span": span}]
        if best:
            reasons.append({"kind": "ai", "value": vals.get("ai", best["score"] / 10), "score": best["score"],
                            "text": best.get("reason", ""), "category": best.get("category", "")})
        near = [e for e in events if start - 2 <= e["off"] <= end + 2]
        if near:
            reasons.append(_albion_reason(near, vals.get("albion", 0)))
        out.append({
            "id": f"t{int(f['said_at'] * 10)}",
            "start": round(start, 2), "end": round(end, 2), "peak": round(f["said_at"], 1),
            "score": round(score, 1), "title": title, "category": "trigger", "trigger": True,
            "auto_check": True, "rank": 0, "sources": ["trigger"], "signals": vals, "reasons": reasons,
            "transcript": _text_between(inp.get("transcript"), start, end, limit=1500),
        })
    return out


DETECTION_KEYS = ("top_n", "min_score", "min_clip_len", "max_clip_len", "context_before", "context_after",
                  "chat_delay", "weights", "laugh_keywords", "clip_keywords", "voice_keywords",
                  "trigger_phrases", "trigger_include_phrase", "trigger_max_seconds",
                  "albion_min_fame", "albion_types", "albion_before", "albion_after", "albion_group_gap",
                  "albion_offset", "language")


def settings_fingerprint(cfg) -> str:
    import hashlib
    import json
    data = json.dumps({k: cfg.get(k) for k in DETECTION_KEYS}, sort_keys=True, ensure_ascii=False)
    return hashlib.sha1(data.encode("utf-8")).hexdigest()[:12]


def compute_and_save(ref: VodRef, cfg) -> dict:
    doc = rank(load_inputs(ref, cfg), cfg)
    doc["settings_fp"] = settings_fingerprint(cfg)
    write_json(ref.p("moments.json"), doc, indent=None)
    return doc


def reason_label(r: dict, tr) -> str:
    """Human text for one reason (tr = translation function)."""
    k = r.get("kind")
    if k == "ai":
        s = tr("why_ai", score=f"{r.get('score', 0):.0f}")
        return s + (f" — {r['text']}" if r.get("text") else "")
    if k == "chat_activity":
        return tr("why_chat", ratio=r.get("ratio", 0))
    if k == "chat_laughs":
        top = ", ".join(r.get("top") or [])
        return tr("why_laughs", count=r.get("count", 0)) + (f" ({top})" if top else "")
    if k == "clips":
        return tr("why_clips", count=r.get("count", 0), views=r.get("views", 0))
    if k == "laughter":
        return tr("why_laughter")
    if k == "loudness":
        return tr("why_loud")
    if k == "voice_keywords":
        return tr("why_words", words=", ".join(f"« {x} »" for x in r.get("words") or []))
    if k == "trigger":
        return tr("why_trigger", heard=r.get("heard", ""), at=fmt_time(r.get("at", 0)), span=r.get("span", ""))
    if k == "albion":
        from .i18n import language
        parts = []
        lang = language()
        if r.get("kills"):
            parts.append(tr("why_alb_kills", n=r["kills"], fame=A.fmt_fame(r.get("fame", 0), lang)))
        if r.get("assists"):
            parts.append(tr("why_alb_assists", n=r["assists"]))
        if r.get("deaths"):
            parts.append(tr("why_alb_deaths", n=r["deaths"]))
        names = ", ".join(r.get("names") or [])
        return " · ".join(parts) + (f" ({names})" if names else "")
    if k == "albion_event":
        from .i18n import language
        f = A.fmt_fame(r.get("fame", 0), language())
        who = r.get("name", "") + (f" [{r['guild']}]" if r.get("guild") else "")
        key = {"kill": "why_alb_kill", "assist": "why_alb_assist", "death": "why_alb_death"}.get(r.get("role"), "why_alb_kill")
        return tr(key, who=who, fame=f, at=fmt_time(r.get("at", 0)))
    return k or ""


def apply_edits(doc: dict, edits: dict, key: str = "moments") -> list[dict]:
    """Moments (or kill clips, key="kills") with the user's changes (start/end/title/ticks)
    applied. Edits made on an older ranking are matched to the new moments by overlap."""
    moments = [dict(m) for m in doc.get(key, [])]
    used = set()
    for m in moments:
        e = edits.get(m["id"])
        if e is None:
            best, best_iou = None, 0.0
            for k, ed in edits.items():
                if k in used or "orig" not in ed:
                    continue
                oa, ob = ed["orig"]
                inter = min(ob, m["end"]) - max(oa, m["start"])
                union = max(ob, m["end"]) - min(oa, m["start"])
                iou = inter / union if union > 0 else 0
                if iou > best_iou:
                    best, best_iou = k, iou
            if best is not None and best_iou >= 0.5:
                e = edits[best]
                used.add(best)
        else:
            used.add(m["id"])
        if e:
            for key in ("start", "end", "title", "checked", "exported", "subs_text", "subs_range"):
                if key in e:
                    m[key] = e[key]
            m["edited"] = any(k in e for k in ("start", "end", "title"))
        if "checked" not in (e or {}):
            m["checked"] = bool(m.get("auto_check"))
    return moments


def label_time(sec: float) -> str:
    return fmt_time(sec)
