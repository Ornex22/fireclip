"""TikTok-style burned-in subtitles (ASS format): big bold words, a few at a time, the word
being said highlighted in colour, with a small "pop" when a new group appears."""
from __future__ import annotations

import re
from typing import Optional

FONT_NAME = "Montserrat ExtraBold"


def _ass_time(t: float) -> str:
    t = max(0.0, t)
    cs = int(round(t * 100))
    h, cs = divmod(cs, 360000)
    m, cs = divmod(cs, 6000)
    s, cs = divmod(cs, 100)
    return f"{h}:{m:02d}:{s:02d}.{cs:02d}"


def _ass_color(hex_rgb: str, alpha: int = 0) -> str:
    h = (hex_rgb or "#FFFFFF").lstrip("#")
    if len(h) != 6 or not re.fullmatch(r"[0-9a-fA-F]{6}", h):
        h = "FFFFFF"
    r, g, b = h[0:2], h[2:4], h[4:6]
    return f"&H{alpha:02X}{b}{g}{r}".upper()


def _tag_color(hex_rgb: str) -> str:
    """Colour for an override tag: &HBBGGRR& (no alpha byte)."""
    return _ass_color(hex_rgb)[4:].join(("&H", "&"))


def _clean_word(w: str, upper: bool) -> str:
    w = w.strip()
    w = w.replace("{", "(").replace("}", ")").replace("\\", "/")
    w = re.sub(r"[,.;:…]+$", "", w)         # keep ? and ! (they carry the tone)
    w = re.sub(r"^[,.;:]+", "", w)
    return w.upper() if upper else w


def make_cards(words: list, max_words: int = 3, max_chars: int = 18) -> list[list]:
    """Group (start, end, text) words into small cards shown one after the other."""
    cards: list[list] = []
    cur: list = []
    for i, (s, e, t) in enumerate(words):
        if not t:
            continue
        if cur:
            prev_s, prev_e, prev_t = cur[-1]
            chars = sum(len(x[2]) + 1 for x in cur) + len(t)
            if (len(cur) >= max_words or s - prev_e > 0.6 or re.search(r"[.!?…]$", prev_t.strip())
                    or chars > max_chars):
                cards.append(cur)
                cur = []
        cur.append((s, e, t))
    if cur:
        cards.append(cur)
    return cards


def build_ass(words: list, clip_start: float, clip_end: float, width: int, height: int,
              uppercase: bool = True, size_pct: int = 100, highlight: str = "#FFE14D",
              position_pct: Optional[int] = None, max_words: int = 3, title: str = "",
              title_y: Optional[int] = None) -> str:
    """words: [(start, end, text)] in VOD time. Returns the .ass file content (clip time).
    title: shown for the whole clip, centred at height title_y (TikTok-style caption)."""
    vertical = height > width
    base = 128 if vertical else 84
    size = max(24, int(base * size_pct / 100 * (height / (1920 if vertical else 1080))))
    outline = max(3, int(size * 0.09))
    shadow = max(1, int(size * 0.035))
    if position_pct is None:
        position_pct = 68 if vertical else 84
    y = int(height * position_pct / 100)
    x = width // 2
    max_chars = 16 if vertical else 30
    tsize = max(20, int((76 if vertical else 54) * size_pct / 100 * (height / (1920 if vertical else 1080))))
    toutline = max(3, int(tsize * 0.1))
    tmargin = int(width * 0.07)
    white = _ass_color("#FFFFFF")
    tag_white = _tag_color("#FFFFFF")
    tag_hi = _tag_color(highlight)
    header = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {width}
PlayResY: {height}
WrapStyle: 0
ScaledBorderAndShadow: yes
YCbCr Matrix: TV.709

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Pop,{FONT_NAME},{size},{white},{white},&H00000000,&H90000000,0,0,0,0,100,100,1,0,1,{outline},{shadow},5,60,60,40,1
Style: Title,{FONT_NAME},{tsize},{white},{white},&H00000000,&HA0000000,0,0,0,0,100,100,0,0,1,{toutline},{shadow},5,{tmargin},{tmargin},40,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    inside = [(max(s, clip_start), min(e, clip_end), t) for (s, e, t) in words
              if e > clip_start + 0.05 and s < clip_end - 0.05]
    cleaned = [(s - clip_start, e - clip_start, _clean_word(t, uppercase)) for s, e, t in inside]
    cleaned = [w for w in cleaned if w[2]]
    cards = make_cards(cleaned, max_words=max_words, max_chars=max_chars)
    lines = []
    clip_len = clip_end - clip_start
    for ci, card in enumerate(cards):
        next_start = cards[ci + 1][0][0] if ci + 1 < len(cards) else clip_len
        card_end = min(next_start, card[-1][1] + 0.35, clip_len)
        for wi, (s, e, _t) in enumerate(card):
            ev_start = s
            ev_end = card[wi + 1][0] if wi + 1 < len(card) else card_end
            if ev_end - ev_start < 0.04:
                continue
            parts = []
            for wj, (_s2, _e2, t2) in enumerate(card):
                if wj == wi:
                    parts.append(f"{{\\1c{tag_hi}}}{t2}{{\\1c{tag_white}}}")
                else:
                    parts.append(t2)
            pop = "\\fscx112\\fscy112\\t(0,90,\\fscx100\\fscy100)" if wi == 0 else ""
            text = f"{{\\an5\\pos({x},{y}){pop}}}" + " ".join(parts)
            lines.append(f"Dialogue: 0,{_ass_time(ev_start)},{_ass_time(ev_end)},Pop,,0,0,0,,{text}")
    t = clean_title(title)
    if t:
        ty = int(title_y if title_y is not None else height * (0.12 if vertical else 0.09))
        lines.append(f"Dialogue: 1,{_ass_time(0)},{_ass_time(clip_len)},Title,,0,0,0,,"
                     f"{{\\an5\\pos({x},{ty})\\fad(150,0)}}{t}")
    return header + "\n".join(lines) + "\n"


def clean_title(title: str) -> str:
    """A clip title for the burned-in caption (no ASS codes, no surrounding quotes)."""
    t = re.sub("[\U0001F000-\U0001FAFF☀-➿️‍]", "", title or "")   # no emoji in the font
    t = re.sub(r"\s+", " ", t).strip().strip("«»\"' ").strip()
    t = t.replace("{", "(").replace("}", ")").replace("\\", "/")
    return t[:90]


def words_from_transcript(transcript: Optional[dict], a: float, b: float) -> list:
    out = []
    if not transcript:
        return out
    for seg in transcript.get("segments", []):
        if seg["e"] < a - 1 or seg["s"] > b + 1:
            continue
        ws = seg.get("w") or []
        if ws:
            for w in ws:
                text = w[0]
                # Whisper splits "aujourd'hui" / "j'ai" into pieces: glue pieces without a leading
                # space back onto the previous word
                if out and text and not text[0].isspace() and float(w[1]) - out[-1][1] < 0.6:
                    ps, pe, pt = out[-1]
                    out[-1] = (ps, max(pe, float(w[2])), pt + text)
                    continue
                out.append((float(w[1]), float(w[2]), text))
        else:  # no word timings: spread the words evenly over the segment
            toks = (seg.get("t") or "").split()
            if not toks:
                continue
            step = (seg["e"] - seg["s"]) / len(toks)
            for i, tk in enumerate(toks):
                out.append((seg["s"] + i * step, seg["s"] + (i + 1) * step, tk))
    out.sort()
    return out


def _norm_tok(w: str) -> str:
    from .util import strip_accents
    return re.sub(r"[^\w]", "", strip_accents(w.lower()))


def retime(words: list, new_text: str, a: float, b: float) -> list:
    """Put the user's corrected text on the timing of the original words.
    words: [(start, end, text)] of the clip [a, b]; new_text: what the subtitles should say.
    Words that did not change keep their exact timing; changed / added words share the time of
    the words they replace (or of the gap where they were added)."""
    from difflib import SequenceMatcher
    new_words: list[str] = []
    for w in (new_text or "").split():
        if new_words and not re.search(r"\w", w):      # "ARMURE !" -> "ARMURE!" (French spacing)
            new_words[-1] += w
        elif w.strip():
            new_words.append(w)
    if not new_words:
        return []
    orig = [(float(s), float(e), t) for s, e, t in words if e > a and s < b]
    if not orig:
        # nothing was said (or not understood): spread the text over the clip
        step = (b - a) / len(new_words)
        return [(a + i * step, a + (i + 1) * step, " " + w) for i, w in enumerate(new_words)]
    o_tok = [_norm_tok(t) for _s, _e, t in orig]
    n_tok = [_norm_tok(w) for w in new_words]
    out: list = [None] * len(new_words)
    sm = SequenceMatcher(None, o_tok, n_tok, autojunk=False)
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if j2 <= j1:
            continue
        if tag == "equal":
            for k in range(j2 - j1):
                s0, e0, _t = orig[i1 + k]
                out[j1 + k] = (s0, e0, " " + new_words[j1 + k])
            continue
        if i2 > i1:                       # replaced words: same time span
            t0, t1 = orig[i1][0], orig[i2 - 1][1]
        else:                             # added words: in the gap between the neighbours
            t0 = orig[i1 - 1][1] if i1 > 0 else max(a, orig[0][0] - 0.3 * (j2 - j1))
            t1 = orig[i1][0] if i1 < len(orig) else min(b, t0 + 0.3 * (j2 - j1))
            if t1 - t0 < 0.12 * (j2 - j1):
                t1 = t0 + 0.12 * (j2 - j1)
        chars = [max(1, len(new_words[j])) for j in range(j1, j2)]
        tot = float(sum(chars))
        pos = t0
        for n, j in enumerate(range(j1, j2)):
            d = (t1 - t0) * chars[n] / tot
            out[j] = (pos, pos + d, " " + new_words[j])
            pos += d
    res = [w for w in out if w is not None]
    res.sort(key=lambda w: w[0])
    return res
