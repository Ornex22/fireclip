"""Start the FireClips window:  python -m fireclips  [--minimized]"""
from __future__ import annotations

import getpass
import sys
import traceback


def main() -> int:
    from PySide6.QtCore import QCoreApplication, Qt
    from PySide6.QtNetwork import QLocalServer, QLocalSocket
    from PySide6.QtWidgets import QApplication, QMessageBox

    from . import __version__, paths
    from .config import Config
    from .i18n import set_language, tr
    from .util import setup_logging

    paths.ensure_dirs()
    log = setup_logging("fireclips")
    log.info("FireClips %s starting (%s)", __version__, sys.executable)

    QCoreApplication.setAttribute(Qt.AA_ShareOpenGLContexts)
    app = QApplication(sys.argv)
    app.setApplicationName("FireClips")
    app.setOrganizationName("FireClips")
    app.setQuitOnLastWindowClosed(False)

    # one window only: a second launch brings the first one to the front
    server_name = "FireClips-" + "".join(c for c in getpass.getuser() if c.isalnum())
    sock = QLocalSocket()
    sock.connectToServer(server_name)
    if sock.waitForConnected(300):
        sock.write(b"show")
        sock.flush()
        sock.waitForBytesWritten(300)
        return 0
    QLocalServer.removeServer(server_name)
    server = QLocalServer()
    server.listen(server_name)

    from .ui import theme
    theme.apply(app)
    cfg = Config()
    set_language(cfg["language"])

    def excepthook(etype, value, tb):
        text = "".join(traceback.format_exception(etype, value, tb))
        log.error("unhandled error: %s", text)
        try:
            QMessageBox.critical(None, "FireClips", tr("err_unexpected") + "\n\n" + text[-1500:])
        except Exception:  # noqa: BLE001
            pass
    sys.excepthook = excepthook

    if not cfg["first_run_done"]:
        from .ui.settings_dialog import WelcomeDialog
        while True:
            dlg = WelcomeDialog(cfg)
            r = dlg.exec()
            if r == 2:            # language changed: show it again in the new language
                set_language(cfg["language"])
                continue
            break
        if not cfg["first_run_done"]:
            cfg["first_run_done"] = True
            cfg.save()

    from .ui.main_window import MainWindow
    win = MainWindow(cfg, start_minimized="--minimized" in sys.argv)

    def on_conn():
        c = server.nextPendingConnection()
        if c is not None:
            c.waitForReadyRead(200)
            win.bring_to_front()
            c.disconnectFromServer()
    server.newConnection.connect(on_conn)
    code = app.exec()
    server.close()
    return code


if __name__ == "__main__":
    sys.exit(main())
