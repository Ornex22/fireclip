"""Find and probe the external programs FireClips relies on."""
from __future__ import annotations

import json
import os
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from . import paths
from .util import IS_WINDOWS, read_json, run, write_json

EXE = ".exe" if IS_WINDOWS else ""


class ToolMissing(RuntimeError):
    def __init__(self, tool: str):
        super().__init__(tool)
        self.tool = tool


_CANDIDATES = {
    "ffmpeg": ["ffmpeg/ffmpeg", "ffmpeg/bin/ffmpeg", "ffmpeg"],
    "ffprobe": ["ffmpeg/ffprobe", "ffmpeg/bin/ffprobe", "ffprobe"],
    "tdcli": ["TwitchDownloaderCLI", "TwitchDownloader/TwitchDownloaderCLI"],
    "ytdlp": ["yt-dlp"],
}
_PATH_NAMES = {"ffmpeg": "ffmpeg", "ffprobe": "ffprobe", "tdcli": "TwitchDownloaderCLI", "ytdlp": "yt-dlp"}
_ENV = {"ffmpeg": "FIRECLIPS_FFMPEG", "ffprobe": "FIRECLIPS_FFPROBE", "tdcli": "FIRECLIPS_TDCLI",
        "ytdlp": "FIRECLIPS_YTDLP"}


def find(tool: str) -> Optional[Path]:
    env = os.environ.get(_ENV[tool])
    if env and Path(env).exists():
        return Path(env)
    for rel in _CANDIDATES[tool]:
        p = paths.TOOLS / (rel + EXE)
        if p.is_file():
            return p
    w = shutil.which(_PATH_NAMES[tool])
    return Path(w) if w else None


def require(tool: str) -> Path:
    p = find(tool)
    if not p:
        raise ToolMissing(tool)
    return p


# --------------------------------------------------------------------------- GPU


@dataclass
class Gpu:
    name: str
    vram_mb: int
    driver: str = ""
    compute_cap: float = 0.0


_gpu_cache: Optional[list] = None


def gpus() -> list[Gpu]:
    """NVIDIA GPUs reported by nvidia-smi (empty list when none / no driver)."""
    global _gpu_cache
    if _gpu_cache is not None:
        return _gpu_cache
    found: list[Gpu] = []
    smi = shutil.which("nvidia-smi")
    if not smi and IS_WINDOWS:
        for cand in (Path(os.environ.get("SystemRoot", r"C:\Windows")) / "System32" / "nvidia-smi.exe",
                     Path(r"C:\Program Files\NVIDIA Corporation\NVSMI\nvidia-smi.exe")):
            if cand.exists():
                smi = str(cand)
                break
    if smi:
        for fields in ("name,memory.total,driver_version,compute_cap", "name,memory.total,driver_version"):
            try:
                r = run([smi, f"--query-gpu={fields}", "--format=csv,noheader,nounits"], timeout=15)
            except Exception:
                break
            if r.returncode != 0:
                continue
            for line in r.stdout.splitlines():
                parts = [p.strip() for p in line.split(",")]
                if len(parts) < 3:
                    continue
                try:
                    cc = float(parts[3]) if len(parts) > 3 else 0.0
                except ValueError:
                    cc = 0.0
                try:
                    vram = int(float(parts[1]))
                except ValueError:
                    vram = 0
                found.append(Gpu(parts[0], vram, parts[2], cc))
            break
    _gpu_cache = found
    return found


def best_gpu() -> Optional[Gpu]:
    g = gpus()
    return max(g, key=lambda x: x.vram_mb) if g else None


# --------------------------------------------------------------------------- ffmpeg helpers


def probe(path: Path) -> dict:
    """Basic information about a media file: duration, width, height, fps, has_audio, vcodec."""
    ffprobe = require("ffprobe")
    r = run([ffprobe, "-v", "error", "-print_format", "json", "-show_format", "-show_streams", str(path)],
            timeout=60)
    info = {"duration": 0.0, "width": 0, "height": 0, "fps": 0.0, "has_audio": False, "has_video": False,
            "vcodec": ""}
    try:
        data = json.loads(r.stdout or "{}")
    except ValueError:
        return info
    fmt = data.get("format", {})
    try:
        info["duration"] = float(fmt.get("duration") or 0)
    except ValueError:
        pass
    for s in data.get("streams", []):
        if s.get("codec_type") == "video" and not info["has_video"]:
            if (s.get("disposition") or {}).get("attached_pic"):
                continue
            info["has_video"] = True
            info["width"] = int(s.get("width") or 0)
            info["height"] = int(s.get("height") or 0)
            info["vcodec"] = s.get("codec_name", "")
            fr = s.get("avg_frame_rate") or s.get("r_frame_rate") or "0/1"
            try:
                a, b = fr.split("/")
                info["fps"] = float(a) / float(b) if float(b) else 0.0
            except ValueError:
                pass
            if not info["duration"]:
                try:
                    info["duration"] = float(s.get("duration") or 0)
                except ValueError:
                    pass
        elif s.get("codec_type") == "audio":
            info["has_audio"] = True
    return info


_nvenc_cache: dict = {}


def nvenc_available() -> bool:
    """True if ffmpeg can encode H.264 on the NVIDIA GPU (tested once, then remembered)."""
    ffmpeg = find("ffmpeg")
    if not ffmpeg:
        return False
    g = best_gpu()
    if not g:
        return False
    key = f"{ffmpeg}|{g.name}|{g.driver}"
    if key in _nvenc_cache:
        return _nvenc_cache[key]
    cache_file = paths.ROOT / "cache" / "nvenc.json"
    saved = read_json(cache_file, {}) or {}
    if key in saved:
        _nvenc_cache[key] = bool(saved[key])
        return _nvenc_cache[key]
    ok = False
    try:
        r = run([ffmpeg, "-hide_banner", "-v", "error", "-f", "lavfi", "-i", "color=black:s=640x360:d=0.5",
                 "-c:v", "h264_nvenc", "-f", "null", "-"], timeout=60)
        ok = r.returncode == 0
    except Exception:
        ok = False
    _nvenc_cache[key] = ok
    saved[key] = ok
    try:
        write_json(cache_file, saved)
    except OSError:
        pass
    return ok
