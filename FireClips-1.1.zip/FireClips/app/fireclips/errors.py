"""Errors that carry a translatable message for the user."""
from __future__ import annotations


class UserError(RuntimeError):
    """`code` is an i18n key; `fmt` are values inserted in the message; `detail` is technical info."""

    def __init__(self, code: str, detail: str = "", **fmt):
        super().__init__(f"{code}: {detail}" if detail else code)
        self.code = code
        self.detail = detail
        self.fmt = fmt


def classify_tool_error(lines: list[str]) -> str:
    """Turn the last lines printed by TwitchDownloaderCLI / yt-dlp / ffmpeg into an i18n key."""
    text = "\n".join(lines).lower()
    if "insufficient access" in text or "oauth may be required" in text or "subscriber" in text \
            or "unauthorized_entitlements" in text or "vod_manifest_restricted" in text:
        return "err_vod_sub_only"
    if "invalid vod" in text or "deleted/expired" in text or "does not exist" in text or "404" in text:
        return "err_vod_not_found"
    if "not enough space" in text or "no space left" in text or "disk full" in text:
        return "err_disk_full"
    if ("no such host" in text or "name or service not known" in text or "timed out" in text
            or "connection" in text or "httprequestexception" in text or "unable to download" in text):
        return "err_network"
    return "err_download_failed"
