"""Speech-to-text with faster-whisper (GPU when possible), in resumable 10-minute pieces."""
from __future__ import annotations

import logging
import os
import re
import threading
import time
from pathlib import Path
from typing import Callable, Optional

import numpy as np

from . import paths, tools
from .errors import UserError
from .util import Cancelled, IS_WINDOWS, dir_size, fmt_hms, read_json, write_json

log = logging.getLogger("fireclips.transcribe")

MODELS = {
    "small": {"repo": "Systran/faster-whisper-small", "mb": 484},
    "medium": {"repo": "Systran/faster-whisper-medium", "mb": 1530},
    "large-v3-turbo": {"repo": "mobiuslabsgmbh/faster-whisper-large-v3-turbo", "mb": 1620},
    "large-v3": {"repo": "Systran/faster-whisper-large-v3", "mb": 3090},
}
ALLOW = ["config.json", "preprocessor_config.json", "model.bin", "tokenizer.json", "vocabulary.*"]

WINDOW = 600.0      # seconds of audio per piece
MARGIN = 20.0       # extra audio so that sentences are not cut at the end of a piece
SR = 16000

# Whisper sometimes "hears" these sentences in silence or music: drop them.
_HALLUCINATIONS = [
    r"sous-titr\w* (r[ée]alis[ée]s? )?par", r"amara\.org", r"merci d'avoir regard[ée]", r"abonnez-vous",
    r"thanks? for watching", r"subtitles by", r"sous-titrage", r"^\W*merci\W*$", r"^\W*\.+\W*$",
    r"like and subscribe", r"n'oubliez pas de vous abonner", r"www\.\w+\.(com|fr|org)",
]
_HALLU_RE = re.compile("|".join(_HALLUCINATIONS), re.I)


# --------------------------------------------------------------------------- CUDA libraries (Windows)

def setup_cuda_dlls() -> list[str]:
    """Make the NVIDIA libraries installed with pip (cuBLAS, cuDNN) findable. Must run before
    faster_whisper / ctranslate2 are imported."""
    added: list[str] = []
    try:
        import nvidia  # namespace package from nvidia-cublas-cu12 / nvidia-cudnn-cu12
        roots = list(getattr(nvidia, "__path__", []))
    except ImportError:
        roots = []
    for root in roots:
        for sub in ("cublas", "cudnn", "cuda_runtime", "cuda_nvrtc"):
            for name in ("bin", "lib"):
                d = os.path.join(root, sub, name)
                if os.path.isdir(d) and d not in added:
                    added.append(d)
    if added:
        os.environ["PATH"] = os.pathsep.join(added) + os.pathsep + os.environ.get("PATH", "")
        if IS_WINDOWS and hasattr(os, "add_dll_directory"):
            for d in added:
                try:
                    os.add_dll_directory(d)
                except OSError:
                    pass
    return added


# --------------------------------------------------------------------------- models

def model_dir(name: str) -> Path:
    return paths.MODELS / "whisper" / name


def model_ready(name: str) -> bool:
    d = model_dir(name)
    return (d / "model.bin").is_file() and (d / "config.json").is_file() and (d / "tokenizer.json").is_file()


def download_model(name: str, progress: Callable[[float, str], None], cancel: Optional[threading.Event] = None) -> Path:
    """Download a Whisper model from Hugging Face (once)."""
    if model_ready(name):
        return model_dir(name)
    info = MODELS.get(name)
    if not info:
        raise UserError("err_model_unknown", name)
    os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")
    os.environ.setdefault("HF_HUB_DISABLE_SYMLINKS_WARNING", "1")
    os.environ.setdefault("HF_HUB_DISABLE_PROGRESS_BARS", "1")
    from huggingface_hub import snapshot_download  # imported late: heavy
    target = model_dir(name)
    tmp = target.with_name(name + ".part")
    tmp.mkdir(parents=True, exist_ok=True)
    expected = info["mb"] * 1024 * 1024
    try:
        from huggingface_hub import HfApi
        mi = HfApi().model_info(info["repo"], files_metadata=True)
        total = 0
        for s in mi.siblings or []:
            fn = s.rfilename
            if any(Path(fn).match(p) for p in ALLOW) and getattr(s, "size", None):
                total += int(s.size)
        if total > 0:
            expected = total
    except Exception as e:  # noqa: BLE001
        log.info("model size lookup failed: %s", e)

    err: list[BaseException] = []

    def worker():
        try:
            snapshot_download(info["repo"], local_dir=str(tmp), allow_patterns=ALLOW)
        except BaseException as e:  # noqa: BLE001
            err.append(e)

    th = threading.Thread(target=worker, daemon=True)
    th.start()
    while th.is_alive():
        if cancel is not None and cancel.is_set():
            raise Cancelled()
        progress(min(0.99, dir_size(tmp) / max(1, expected)), name)
        th.join(1.0)
    if err:
        raise UserError("err_model_download", str(err[0]))
    if not (tmp / "model.bin").is_file():
        raise UserError("err_model_download", "model.bin missing")
    if target.exists():
        import shutil
        shutil.rmtree(target, ignore_errors=True)
    tmp.replace(target)
    progress(1.0, name)
    return target


def auto_settings(cfg) -> dict:
    """Pick model / device / precision / batch size from the settings and the graphics card."""
    gpu = tools.best_gpu()
    want_device = cfg.get("whisper_device") or "auto"
    device = "cuda" if (gpu and want_device in ("auto", "cuda")) else "cpu"
    vram = gpu.vram_mb if gpu else 0
    model = cfg.get("whisper_model") or "auto"
    if model == "auto":
        if device == "cuda" and vram >= 3500:
            model = "large-v3-turbo"
        else:
            model = "small"
    if device == "cuda":
        if vram >= 9500:
            batch = 16
        elif vram >= 7000:
            batch = 12
        elif vram >= 5000:
            batch = 8
        elif vram >= 3500:
            batch = 4
        else:
            batch = 2
        if model == "large-v3":
            batch = max(2, batch // 2)
        compute = "float16" if vram >= 5000 else "int8_float16"
        beam = 5
    else:
        batch = 4
        compute = "int8"
        beam = 1
    return {"model": model, "device": device, "compute_type": compute, "batch_size": batch, "beam_size": beam,
            "language": cfg.get("whisper_language") or "auto", "vocab": cfg.get("whisper_vocab") or "",
            "gpu": gpu.name if gpu else "", "vram_mb": vram}


# --------------------------------------------------------------------------- language restriction

class _OnlyLanguages:
    """Wraps the CTranslate2 Whisper model so that language detection can only answer FR or EN
    (short clips are otherwise sometimes detected as Portuguese, German...)."""

    def __init__(self, inner, langs=("fr", "en")):
        self._inner = inner
        self._allowed = {f"<|{l}|>" for l in langs}

    def detect_language(self, *args, **kwargs):
        res = self._inner.detect_language(*args, **kwargs)
        out = []
        for langs in res:
            keep = [x for x in langs if x[0] in self._allowed]
            out.append(keep or langs)
        return out

    def __getattr__(self, name):
        return getattr(self._inner, name)


# --------------------------------------------------------------------------- transcription

def _pick_compute(device: str, wanted: str) -> str:
    try:
        import ctranslate2
        supported = set(ctranslate2.get_supported_compute_types(device))
    except Exception:  # noqa: BLE001
        return wanted
    order = [wanted, "float16", "int8_float16", "int8", "int8_float32", "float32"]
    for c in order:
        if c in supported:
            return c
    return "default"


class Transcriber:
    def __init__(self, opts: dict, emit_log: Callable[[str], None] = lambda m: None):
        self.opts = dict(opts)
        self.emit_log = emit_log
        self.pipe = None
        self.model = None

    def load(self) -> None:
        if self.opts["device"] == "cuda":
            setup_cuda_dlls()
        try:
            import onnxruntime  # used by the voice detector inside faster-whisper
            onnxruntime.disable_telemetry_events()
        except Exception:  # noqa: BLE001
            pass
        from faster_whisper import BatchedInferencePipeline, WhisperModel
        name = self.opts["model"]
        path = model_dir(name) if model_ready(name) else Path(self.opts.get("model_path") or "")
        if not (Path(path) / "model.bin").is_file():
            raise UserError("err_model_missing", name)
        compute = _pick_compute(self.opts["device"], self.opts["compute_type"])
        threads = max(1, min(8, (os.cpu_count() or 4) - 1))
        log.info("loading whisper %s on %s (%s)", name, self.opts["device"], compute)
        self.model = WhisperModel(str(path), device=self.opts["device"], compute_type=compute,
                                  cpu_threads=threads, num_workers=1)
        self.opts["compute_type"] = compute
        if self.opts.get("language", "auto") == "auto" and getattr(self.model.model, "is_multilingual", True):
            self.model.model = _OnlyLanguages(self.model.model)
        self.pipe = BatchedInferencePipeline(model=self.model)

    def _run(self, audio: np.ndarray, on_part=None) -> tuple[list, str]:
        lang = self.opts.get("language", "auto")
        kwargs = dict(word_timestamps=True, batch_size=int(self.opts["batch_size"]),
                      beam_size=int(self.opts.get("beam_size", 5)), vad_filter=True)
        if lang in ("fr", "en"):
            kwargs["language"] = lang
        else:
            kwargs["multilingual"] = True
        # The "vocabulary" is NOT given to Whisper as a prompt: with mixed French / English speech a
        # prompt can make it skip whole sentences. Words are corrected afterwards (_apply_vocab).
        segments, info = self.pipe.transcribe(audio, **kwargs)
        out = []
        total = max(1.0, len(audio) / SR)
        for seg in segments:          # segments arrive as they are decoded
            out.append(seg)
            if on_part is not None:
                on_part(min(1.0, float(seg.end) / total))
        return out, getattr(info, "language", "") or ""

    def transcribe_window(self, audio_i16: np.ndarray, on_part=None) -> tuple[list, str]:
        audio = audio_i16.astype(np.float32) / 32768.0
        while True:
            try:
                return self._run(audio, on_part)
            except RuntimeError as e:
                msg = str(e).lower()
                if "out of memory" in msg and int(self.opts["batch_size"]) > 1:
                    self.opts["batch_size"] = max(1, int(self.opts["batch_size"]) // 2)
                    self.emit_log(f"GPU memory full, batch size -> {self.opts['batch_size']}")
                    continue
                raise


_STARTERS = set("""on bon non oui ouais il ils elle elles je j'ai tu vous nous mais et alors donc ah oh bah
euh hein attends attendez allez ok okay merci ça c'est là voilà putain wow quoi pourquoi comment qui
regarde regardez bref enfin franchement sérieux sérieusement what so and but the i we you yes no well
oh hey yo let's okay wait guys""".split())


def _fix_junction_words(words: list, gap: float = 1.2) -> list:
    """faster-whisper glues speech pieces together before decoding; the first word after a long
    pause is sometimes dated at the end of the previous piece ("...sur Albion On" | "part avec").
    Move such a word next to the sentence it really starts."""
    out = [list(w) for w in words]
    for i in range(1, len(out) - 1):
        w, prev, nxt = out[i], out[i - 1], out[i + 1]
        if nxt[1] - w[2] < gap:
            continue
        txt = w[0].strip()
        if not txt or not txt[0].isupper() or re.search(r"[.!?…]$", txt):
            continue
        if re.search(r"[.!?…]$", prev[0].strip()):
            continue
        if txt.lower().strip(",.!?") not in _STARTERS:
            continue
        dur = min(0.35, max(0.12, w[2] - w[1]))
        w[1], w[2] = round(nxt[1] - dur - 0.02, 2), round(nxt[1] - 0.02, 2)
    out.sort(key=lambda x: x[1])
    return out


def _split_words(words: list, max_len: float = 14.0, gap: float = 0.9) -> list[list]:
    """The batched decoder returns long segments: cut them into sentences using the word timings
    (at . ! ? or at pauses), which gives the AI and the subtitles one line per sentence."""
    pieces: list[list] = []
    cur: list = []
    for w in words:
        if cur:
            prev = cur[-1]
            if (w[1] - prev[2] > gap or w[2] - cur[0][1] > max_len
                    or re.search(r"[.!?…]$", prev[0].strip())
                    or (re.search(r",$", prev[0].strip()) and w[2] - cur[0][1] > max_len * 0.6)):
                pieces.append(cur)
                cur = []
        cur.append(w)
    if cur:
        pieces.append(cur)
    return pieces


def _repetitive(text: str) -> bool:
    import zlib
    b = text.encode("utf-8")
    return len(b) > 60 and len(b) / max(1, len(zlib.compress(b))) > 2.4


def _clean_segments(segs: list, offset: float, vocab: str) -> list[dict]:
    out = []
    vocab_norm = re.sub(r"\W+", " ", vocab.lower()).strip()
    for s in segs:
        text = (s.text or "").strip()
        if not text:
            continue
        if getattr(s, "avg_logprob", 0) < -1.3 and getattr(s, "no_speech_prob", 0) > 0.5:
            continue
        words = [[w.word, round(float(w.start) + offset, 2), round(float(w.end) + offset, 2)]
                 for w in (s.words or []) if (w.word or "").strip()]
        if words:
            words = _fix_junction_words(words)
            pieces = _split_words(words)
        else:
            pieces = [[[" " + text, round(float(s.start) + offset, 2), round(float(s.end) + offset, 2)]]]
        for p in pieces:
            ptext = "".join(x[0] for x in p).strip()
            if not ptext or _HALLU_RE.search(ptext) or _repetitive(ptext):
                continue
            if vocab_norm and re.sub(r"\W+", " ", ptext.lower()).strip() == vocab_norm:
                continue
            out.append({"s": p[0][1], "e": p[-1][2], "t": ptext, "w": p if words else []})
    return out


def _vocab_terms(vocab: str) -> list[str]:
    terms = []
    for part in re.split(r"[,;\n]+", vocab or ""):
        for w in part.split():
            w = w.strip(" .!?:;\"'()")
            if len(w) >= 3 and w not in terms:
                terms.append(w)
    return terms


def _norm_word(w: str) -> str:
    from .util import strip_accents
    return re.sub(r"[^a-z0-9]", "", strip_accents(w.lower()))


def _apply_vocab(segments: list[dict], vocab: str) -> None:
    """Write the words of the vocabulary list the right way ("zvz" -> "ZvZ", "Gobriate" ->
    "Gobriates"), keeping punctuation and plurals."""
    from difflib import SequenceMatcher
    terms = [(t, _norm_word(t)) for t in _vocab_terms(vocab)]
    terms = [(t, n) for t, n in terms if n]
    if not terms:
        return

    def fix(word: str) -> str:
        m = re.match(r"^(\s*[\"'«(]*)(.*?)([\"'».,!?;:)…]*)$", word, re.S)
        if not m:
            return word
        pre, core, post = m.groups()
        n = _norm_word(core)
        if len(n) < 3:
            return word
        for t, tn in terms:
            if n == tn:
                return pre + t + post
            if n == tn + "s" or n == tn + "es":
                return pre + t + core[len(t):] + post if core.lower().startswith(t.lower()) else pre + t + "s" + post
            if len(n) >= 5 and len(tn) >= 5 and n[0] == tn[0] and SequenceMatcher(None, n, tn).ratio() >= 0.86:
                return pre + t + post
        return word

    for seg in segments:
        ws = seg.get("w") or []
        if ws:
            for w in ws:
                w[0] = fix(w[0])
            seg["t"] = "".join(w[0] for w in ws).strip()
        else:
            seg["t"] = " ".join(fix(x) for x in seg.get("t", "").split())


def _missing_speech(audio: np.ndarray, segs: list[dict], offset: float) -> list[tuple[float, float]]:
    """Stretches where the voice detector hears speech but Whisper wrote nothing (seconds from
    the start of this piece of audio)."""
    from bisect import bisect_left, bisect_right
    from faster_whisper.vad import VadOptions, get_speech_timestamps
    regions = get_speech_timestamps(audio, VadOptions(max_speech_duration_s=30, min_silence_duration_ms=160))
    mids = sorted(((float(w[1]) + float(w[2])) / 2 - offset) for sg in segs for w in (sg.get("w") or []))
    plain = [(sg["s"] - offset, sg["e"] - offset) for sg in segs if not sg.get("w")]
    out: list[tuple[float, float]] = []
    for r in regions:
        a, b = r["start"] / SR, r["end"] / SR
        if b - a < 1.5:
            continue
        n = bisect_right(mids, b + 0.3) - bisect_left(mids, a - 0.3)
        if any(x < b and y > a for x, y in plain):
            continue
        if n == 0 or (b - a >= 4.0 and n / (b - a) < 0.25):
            if out and a - out[-1][1] < 1.0 and b - out[-1][0] <= 28:
                out[-1] = (out[-1][0], b)
            else:
                out.append((a, b))
    return out[:25]


def _fill_gaps(tr: "Transcriber", audio_i16: np.ndarray, segs: list[dict], offset: float, vocab: str,
               cancel: Optional[threading.Event] = None) -> list[dict]:
    """Whisper sometimes skips a sentence or two (mixed languages, music...). Decode those
    stretches again on their own."""
    audio = audio_i16.astype(np.float32) / 32768.0
    extra: list[dict] = []
    for a, b in _missing_speech(audio, segs, offset):
        if cancel is not None and cancel.is_set():
            raise Cancelled()
        s0 = max(0.0, a - 0.25)
        sub = audio[int(s0 * SR):int((b + 0.25) * SR)]
        if len(sub) < SR:
            continue
        found, _lang = tr._run(sub)
        for sg in _clean_segments(found, offset + s0, ""):
            overlap = any(min(sg["e"], o["e"]) - max(sg["s"], o["s"]) > 0.5 * (sg["e"] - sg["s"]) for o in segs + extra)
            if not overlap:
                extra.append(sg)
    return extra


def transcript_path(vod_dir: Path, model: str) -> Path:
    return vod_dir / f"transcript_{model}.json"


def find_transcript(vod_dir: Path) -> Optional[Path]:
    """The best finished transcript available for this VOD."""
    order = ["large-v3", "large-v3-turbo", "medium", "small"]
    found = [p for p in vod_dir.glob("transcript_*.json")]
    if not found:
        return None
    found.sort(key=lambda p: order.index(p.stem[len("transcript_"):]) if p.stem[len("transcript_"):] in order else 99)
    return found[0]


def run_transcription(vod_dir: Path, audio_path: Path, duration: float, opts: dict,
                      progress: Callable[[float, str], None], emit_log: Callable[[str], None],
                      cancel: Optional[threading.Event] = None) -> Path:
    """Transcribe the whole audio, 10 minutes at a time. Already finished pieces are kept, so a
    crash or a restart continues where it stopped."""
    from .media import decode_pcm

    name = opts["model"]
    final = transcript_path(vod_dir, name)
    if final.exists():
        return final
    cdir = vod_dir / "transcript" / name
    cdir.mkdir(parents=True, exist_ok=True)
    index_file = cdir / "index.json"
    index = read_json(index_file, None) or {"next": 0.0, "chunks": [], "languages": {}}
    start = float(index.get("next", 0.0))

    tr = Transcriber(opts, emit_log)
    tr.load()
    emit_log(f"whisper {name} on {opts['device']} ({tr.opts['compute_type']}), batch {tr.opts['batch_size']}")
    t0 = time.time()
    done_at_start = start
    while start < duration - 0.5:
        if cancel is not None and cancel.is_set():
            raise Cancelled()
        win_end = min(duration, start + WINDOW + MARGIN)
        audio = decode_pcm(audio_path, start, win_end - start, SR)
        if len(audio) < SR * 0.5:
            break
        real_end = start + len(audio) / SR
        win_len = real_end - start

        def on_part(f: float, start=start, win_len=win_len) -> None:
            pos = start + f * win_len
            elapsed_ = time.time() - t0
            speed_ = (pos - done_at_start) / max(1e-6, elapsed_)
            remaining_ = (duration - pos) / speed_ if speed_ > 0 else 0
            progress(min(0.999, pos / max(1.0, duration)), f"eta:{int(remaining_)}")

        segs, lang = tr.transcribe_window(audio, on_part)
        segs = _clean_segments(segs, start, opts.get("vocab", ""))
        try:
            extra = _fill_gaps(tr, audio, segs, start, opts.get("vocab", ""), cancel)
            if extra:
                emit_log(f"re-transcribed {len(extra)} missed bit(s) near {fmt_hms(start)}")
                segs = sorted(segs + extra, key=lambda x: x["s"])
        except Cancelled:
            raise
        except Exception as e:  # noqa: BLE001 - the safety net must never break the transcription
            log.warning("gap check failed: %s", e)
        _apply_vocab(segs, opts.get("vocab", ""))
        last_piece = real_end >= duration - 0.5 or win_end >= duration
        if last_piece:
            keep = segs
            nxt = duration
        else:
            cut = start + WINDOW
            keep = [s for s in segs if s["s"] < cut]
            while keep and keep[-1]["e"] > real_end - 1.0:
                keep.pop()
            nxt = keep[-1]["e"] if keep else cut
            if nxt <= start + 30:
                nxt = cut
        fname = f"chunk_{int(start * 1000):010d}.json"
        write_json(cdir / fname, {"start": start, "end": nxt, "language": lang, "segments": keep}, indent=None)
        index["chunks"].append(fname)
        index["languages"][lang] = index["languages"].get(lang, 0) + 1
        index["next"] = nxt
        write_json(index_file, index)
        start = nxt
        elapsed = time.time() - t0
        speed = (start - done_at_start) / max(1e-6, elapsed)
        remaining = (duration - start) / speed if speed > 0 else 0
        progress(min(1.0, start / max(1.0, duration)), f"eta:{int(remaining)}")

    # merge pieces
    segments: list = []
    for fname in sorted(set(index["chunks"])):
        piece = read_json(cdir / fname, {}) or {}
        segments.extend(piece.get("segments") or [])
    segments.sort(key=lambda s: s["s"])
    langs = index.get("languages") or {}
    main_lang = max(langs, key=langs.get) if langs else ""
    write_json(final, {"model": name, "language": main_lang, "duration": duration, "segments": segments},
               indent=None)
    return final


def classify_error(e: BaseException) -> str:
    """'oom' | 'cuda' | 'other' - used to decide whether to retry on the processor."""
    msg = f"{type(e).__name__}: {e}".lower()
    if "out of memory" in msg:
        return "oom"
    if any(k in msg for k in ("cuda", "cublas", "cudnn", "nvidia", "gpu", "device", "dll")):
        return "cuda"
    return "other"
