"""User settings, stored in settings.json next to the program."""
from __future__ import annotations

import copy
import threading
from pathlib import Path

from . import paths
from .util import read_json, write_json

SIGNALS = ("ai", "chat_activity", "chat_laughs", "clips", "laughter", "loudness", "voice_keywords", "albion")

DEFAULTS: dict = {
    "version": 1,
    "language": "fr",                 # interface language: fr / en
    "first_run_done": False,

    # Folders ("" = default location)
    "output_dir": "",
    "work_dir": "",

    # Download
    "download_mode": "audio",         # audio = audio first (fast) | full = whole VOD video
    "export_quality": "best",         # best | 1080p60 | 720p60 | 720p30 | 480p30
    "preview_quality": "720p",
    "delete_after": False,            # delete downloaded audio/video once the analysis is done
    "twitch_oauth": "",               # only for subscriber-only VODs

    # Automatic mode
    "mode": "manual",                 # manual | auto
    "channel": "",
    "auto_check_minutes": 5,
    "auto_wait_minutes": 10,          # wait after the stream ends before analysing
    "auto_backfill": 1,               # when auto mode starts, also analyse the N latest VODs
    "keep_vods": 20,                  # keep the N most recent VODs in the list (0 = keep all)
    "auto_since": "",                 # when auto mode was switched on (VODs after that are analysed)
    "auto_done": [],                  # VOD ids already handled by auto mode
    "start_with_windows": False,
    "minimize_to_tray": True,

    # Detection
    "top_n": 20,
    "min_score": 20,
    "min_clip_len": 15,
    "max_clip_len": 90,
    "context_before": 20,
    "context_after": 10,
    "chat_delay": 6,                  # chat reacts a few seconds after the moment
    "weights": {"ai": 35, "chat_activity": 15, "chat_laughs": 15, "clips": 15,
                "laughter": 10, "loudness": 5, "voice_keywords": 5, "albion": 5},
    "laugh_keywords": ["KEKW", "KEKL", "LUL", "LULW", "OMEGALUL", "ICANT", "pepeLaugh", "LMAO",
                       "LMFAO", "lol", "mdr", "ptdr", "xD", "jpp", "haha", "ahah", "hihi",
                       "jsuis mort", "je suis mort", "\U0001F602", "\U0001F923", "\U0001F480"],
    "clip_keywords": ["clip", "clipé", "clippé", "clipez", "clippez", "clip it", "clip ça", "clipped"],
    "voice_keywords": ["mdr", "ptdr", "haha", "ahah", "hihi", "c'est pas possible", "je suis mort",
                       "oh non", "putain", "bordel", "wtf", "oh my god", "omg", "j'en peux plus",
                       "c'est quoi ça", "mais non", "nooon"],

    # Trigger phrases: say one on stream and the minutes before it become a clip
    "trigger_phrases": [{"text": "Twitch clip me the last 5 minutes", "seconds": 300},
                        {"text": "Twitch clip les 5 dernières minutes", "seconds": 300}],
    "trigger_include_phrase": False,  # keep the trigger sentence at the end of the clip
    "trigger_max_seconds": 600,       # never longer than this (a misheard "2 hours"...)
    "trigger_auto_export": True,      # export these clips by themselves after the analysis

    # Albion Online (kills tab)
    "albion_links": [{"player": "Fire", "region": "europe", "channel": "elfirefemale"}],
    "albion_min_fame": 100000,        # kills below this PvP fame are ignored
    "albion_types": ["kill", "assist"],   # kill | assist | death
    "albion_before": 25,              # seconds of the fight before the kill
    "albion_after": 8,
    "albion_group_gap": 20,           # kills closer than this become one clip (0 = never group)
    "albion_offset": 0,               # stream delay (OBS) in seconds
    "albion_auto_export": True,       # export the kill clips above the threshold after the analysis
    "albion_collect": True,           # note the kills every 2 minutes while FireClips is open
    "albion_show_ignored": False,

    # Transcription
    "whisper_model": "auto",          # auto | small | large-v3-turbo | large-v3
    "whisper_language": "auto",       # auto (FR+EN) | fr | en
    "whisper_device": "auto",         # auto | cuda | cpu
    "whisper_vocab": "Albion Online, Gobriates, zerg, ZvZ, gank, dive, Hellgate, KEKW",

    # AI
    "ai_provider": "none",            # none | anthropic | openai | ollama
    "anthropic_key": "",
    "anthropic_model": "claude-sonnet-5-5",
    "openai_key": "",
    "openai_model": "gpt-6-luna",
    "openai_base_url": "https://api.openai.com/v1",
    "ollama_url": "http://localhost:11434",
    "ollama_model": "qwen3.5:9b",
    "streamer_name": "Fire",
    "ai_context": "",                 # extra instructions for the AI
    "ai_title_language": "fr",
    "ai_show_chat": True,             # give the AI the chat reactions next to the transcript

    # Export
    "export_landscape": False,        # 16:9
    "export_vertical": True,          # 9:16
    "vertical_style": "blur",         # blur | crop | webcam (webcam on top, game below)
    "crop_position": 50,              # 0 = left .. 100 = right
    "webcam_rect": [0.70, 0.03, 0.28, 0.30],   # webcam in the stream picture: x, y, width, height (0..1)
    "webcam_split": 35,               # % of the 9:16 height used by the webcam
    "webcam_game_pos": 50,            # game part: 0 = left .. 100 = right
    "title_overlay": False,           # clip title written at the top of the 9:16 clip
    "title_overlay_landscape": False,
    "subtitles": True,
    "subtitle_uppercase": True,
    "subtitle_size": 100,             # percent
    "subtitle_highlight": "#FFE14D",
    "subtitle_position": 68,          # vertical position in % of height (9:16)
    "subtitle_words": 3,              # max words shown at once
    "encoder": "auto",                # auto | nvenc | cpu
    "open_folder_after_export": True,
}


def _clean_list(key: str, v: list, dv: list) -> list:
    if key == "trigger_phrases":
        out = []
        for x in v:
            if isinstance(x, str):
                x = {"text": x}
            if isinstance(x, dict) and str(x.get("text") or "").strip():
                try:
                    secs = max(5, min(3600, int(float(x.get("seconds") or 300))))
                except (TypeError, ValueError):
                    secs = 300
                out.append({"text": str(x["text"]).strip(), "seconds": secs})
        return out
    if key == "albion_links":
        return [{"player": str(x.get("player") or "").strip(), "region": str(x.get("region") or "europe"),
                 "channel": str(x.get("channel") or "").strip()} for x in v if isinstance(x, dict)]
    if dv and isinstance(dv[0], (int, float)) and not isinstance(dv[0], bool):
        try:
            vals = [float(x) for x in v]
            return vals if len(vals) == len(dv) else list(dv)
        except (TypeError, ValueError):
            return list(dv)
    return [str(x) for x in v if str(x).strip()]


class Config:
    """Thread-safe settings store with defaults."""

    def __init__(self, path: Path = paths.CONFIG_FILE):
        self.path = Path(path)
        self._lock = threading.RLock()
        self.data = copy.deepcopy(DEFAULTS)
        self.load()

    def load(self) -> None:
        raw = read_json(self.path, {}) or {}
        with self._lock:
            data = copy.deepcopy(DEFAULTS)
            for k, v in raw.items():
                if k not in DEFAULTS:
                    continue
                dv = DEFAULTS[k]
                if isinstance(dv, dict) and isinstance(v, dict):
                    merged = dict(dv)
                    merged.update({kk: vv for kk, vv in v.items() if kk in dv})
                    data[k] = merged
                elif isinstance(dv, bool):
                    data[k] = bool(v)
                elif isinstance(dv, (int, float)) and not isinstance(dv, bool):
                    try:
                        data[k] = type(dv)(v)
                    except (TypeError, ValueError):
                        pass
                elif isinstance(dv, list):
                    if isinstance(v, list):
                        data[k] = _clean_list(k, v, dv)
                else:
                    data[k] = "" if v is None else str(v)
            self.data = data

    def save(self) -> None:
        with self._lock:
            write_json(self.path, self.data)

    def __getitem__(self, key):
        with self._lock:
            return self.data[key]

    def __setitem__(self, key, value):
        with self._lock:
            self.data[key] = value

    def get(self, key, default=None):
        with self._lock:
            return self.data.get(key, default)

    def update(self, values: dict) -> None:
        with self._lock:
            self.data.update(values)

    def snapshot(self) -> dict:
        with self._lock:
            return copy.deepcopy(self.data)

    # Resolved folders ------------------------------------------------------
    @property
    def output_dir(self) -> Path:
        return Path(self["output_dir"]) if self["output_dir"] else paths.default_output_dir()

    @property
    def work_dir(self) -> Path:
        return Path(self["work_dir"]) if self["work_dir"] else paths.default_work_dir()


def from_snapshot(snap: dict) -> Config:
    """A Config built from a dict (used by the background worker)."""
    c = Config.__new__(Config)
    c.path = paths.CONFIG_FILE
    c._lock = threading.RLock()
    c.data = copy.deepcopy(DEFAULTS)
    c.data.update(snap or {})
    w = dict(DEFAULTS["weights"])
    w.update((snap or {}).get("weights", {}) or {})
    c.data["weights"] = w
    return c
