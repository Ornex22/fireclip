"""The main window: VOD list (left), the clips of the selected VOD in two tabs — the AI moments
(part 1, any Twitch stream) and the Albion kills (part 2) — the player with start/end editing
(right) and the export bar (bottom)."""
from __future__ import annotations

import json
import logging
import threading
from datetime import datetime
from pathlib import Path
from typing import Optional

from PySide6.QtCore import QObject, QRunnable, Qt, QThreadPool, QTimer, QUrl, Signal
from PySide6.QtGui import QAction, QDesktopServices, QKeySequence, QShortcut
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QComboBox, QDialog, QDialogButtonBox,
                               QFileDialog, QFrame, QHBoxLayout, QHeaderView, QLabel, QLineEdit, QListWidget,
                               QListWidgetItem, QMainWindow, QMenu, QMessageBox, QPlainTextEdit, QProgressBar,
                               QPushButton, QSplitter, QStackedWidget, QSystemTrayIcon, QTableView, QTabWidget,
                               QToolButton, QVBoxLayout, QWidget)

from .. import __version__, albion, export, paths, scoring, store, tools, twitch
from ..config import Config
from ..i18n import tr
from ..store import Library, VodRef
from ..util import fmt_duration, open_in_explorer
from . import theme
from .albion_ui import AlbionCollector, AlbionPanel, IconCache
from .auto import AutoWatcher, set_autostart
from .edit_dialogs import SubtitleDialog, WebcamLayoutDialog
from .jobs import Job, JobManager
from .moments import MomentsModel, MomentsProxy
from .player import PlayerPanel
from .settings_dialog import SettingsDialog
from .widgets import Banner, ScoreDelegate, TimelineWidget, VodItemWidget

log = logging.getLogger("fireclips.ui")

STATUS_COLORS = {"done": theme.GOOD, "running": theme.ACCENT_2, "queued": theme.MUTED, "error": theme.BAD,
                 "interrupted": theme.WARN, "new": theme.MUTED}
TAB_MOMENTS, TAB_ALBION = 0, 1
_RESCORE_LOCK = threading.Lock()


class _Sig(QObject):
    done = Signal(object, object)


class _Task(QRunnable):
    def __init__(self, fn, tag, sig: _Sig):
        super().__init__()
        self.fn, self.tag, self.sig = fn, tag, sig

    def run(self):
        try:
            res = self.fn()
        except Exception as e:  # noqa: BLE001
            log.exception("background task")
            res = e
        self.sig.done.emit(self.tag, res)


def vod_title(ref: VodRef) -> str:
    m = ref.meta
    return m.get("title") or (f"VOD {m.get('vod_id')}" if m.get("vod_id") else ref.key)


def vod_sub(ref: VodRef) -> str:
    m = ref.meta
    parts = []
    s = m.get("created_at") or ""
    try:
        parts.append(datetime.fromisoformat(s.replace("Z", "+00:00")).astimezone().strftime("%d/%m/%Y %H:%M"))
    except ValueError:
        pass
    if m.get("duration"):
        parts.append(fmt_duration(float(m["duration"])))
    parts.append(tr("src_local_file") if m.get("kind") == "local" else "Twitch")
    return " · ".join(parts)


def export_item(m: dict) -> dict:
    """What the export worker needs to know about one clip."""
    d = {"id": m["id"], "start": m["start"], "end": m["end"], "title": m.get("title") or ""}
    if m.get("subs_text") is not None:
        d["subs_text"] = m["subs_text"]
        d["subs_range"] = m.get("subs_range") or [m["start"], m["end"]]
    return d


class DetailsDialog(QDialog):
    def __init__(self, title: str, text: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(720, 420)
        lay = QVBoxLayout(self)
        ed = QPlainTextEdit(text)
        ed.setReadOnly(True)
        lay.addWidget(ed)
        bb = QDialogButtonBox(QDialogButtonBox.Close)
        copy = bb.addButton(tr("btn_copy"), QDialogButtonBox.ActionRole)
        copy.clicked.connect(lambda: QApplication.clipboard().setText(text))
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)


class MainWindow(QMainWindow):
    def __init__(self, cfg: Config, start_minimized: bool = False):
        super().__init__()
        self.cfg = cfg
        self.lib = Library(cfg.work_dir)
        self.jobs = JobManager(self)
        self.jobs.job_event.connect(self._on_job_event)
        self.jobs.job_finished.connect(self._on_job_finished)
        self.jobs.changed.connect(self._refresh_export_bar)
        self.current: Optional[VodRef] = None
        self.doc: Optional[dict] = None
        self.edits: dict = {}
        self.kedits: dict = {}
        self.segments: dict[str, list] = {}
        self.preview_job: Optional[Job] = None
        self.export_job: Optional[Job] = None
        self._quitting = False
        self._tray_hint_shown = False
        self._sig = _Sig()
        self._sig.done.connect(self._on_task_done)
        self._save_timer = QTimer(self)
        self._save_timer.setSingleShot(True)
        self._save_timer.setInterval(400)
        self._save_timer.timeout.connect(self._save_edits)
        self.icons = IconCache(lambda: albion.data_root(self.cfg), self)

        self.setWindowTitle(f"FireClips {__version__}")
        self.setWindowIcon(theme.app_icon())
        self.resize(1440, 900)
        self.setMinimumSize(1100, 700)
        self._build()
        self._build_tray()
        self.collector = AlbionCollector(cfg, self)
        self.collector.status.connect(self.alb.set_collector_status)
        self.watcher = AutoWatcher(cfg, lambda: self.lib, self)
        self.watcher.new_vods.connect(self._auto_new_vods)
        self.watcher.status.connect(self._auto_status)
        self.watcher.live_changed.connect(self.collector.set_live)
        self.watcher.apply()
        self.collector.apply()
        self.refresh_vods()
        self._refresh_timer = QTimer(self)
        self._refresh_timer.timeout.connect(self.refresh_vods)
        self._refresh_timer.start(4000)
        self._status_line()
        if start_minimized and self.tray is not None:
            QTimer.singleShot(0, self.hide)
        else:
            self.show()
        # select the most recent VOD, restart analyses that were cut by a crash / shutdown
        QTimer.singleShot(50, self._select_first)
        QTimer.singleShot(1500, self._resume_unfinished)

    # ================================================================== UI construction
    def _build(self) -> None:
        root = QWidget()
        self.setCentralWidget(root)
        outer = QVBoxLayout(root)
        outer.setContentsMargins(14, 12, 14, 8)
        outer.setSpacing(10)

        # ---- header
        head = QHBoxLayout()
        brand = QLabel("🔥 FireClips")
        brand.setObjectName("Brand")
        head.addWidget(brand)
        head.addSpacing(12)
        self.url = QLineEdit()
        self.url.setObjectName("BigInput")
        self.url.setPlaceholderText(tr("main_url_ph"))
        self.url.returnPressed.connect(self.analyze_url)
        head.addWidget(self.url, 1)
        self.btn_analyze = QPushButton(tr("btn_analyze"))
        self.btn_analyze.setObjectName("Primary")
        self.btn_analyze.clicked.connect(self.analyze_url)
        head.addWidget(self.btn_analyze)
        b = QPushButton(tr("btn_local"))
        b.setToolTip(tr("btn_local_tip"))
        b.clicked.connect(self.analyze_local)
        head.addWidget(b)
        head.addSpacing(10)
        self.auto_chip = QPushButton("")
        self.auto_chip.setObjectName("Flat")
        self.auto_chip.clicked.connect(lambda: self.open_settings("auto"))
        head.addWidget(self.auto_chip)
        b = QToolButton()
        b.setText("⚙")
        b.setToolTip(tr("btn_settings"))
        b.clicked.connect(lambda: self.open_settings("general"))
        head.addWidget(b)
        b = QToolButton()
        b.setText("?")
        b.setToolTip(tr("btn_help"))
        b.clicked.connect(self.open_help)
        head.addWidget(b)
        outer.addLayout(head)

        # ---- body
        split = QSplitter(Qt.Horizontal)
        split.setChildrenCollapsible(False)
        outer.addWidget(split, 1)

        left = QFrame()
        left.setObjectName("Panel")
        lv = QVBoxLayout(left)
        lv.setContentsMargins(10, 10, 10, 10)
        t = QLabel(tr("main_vods"))
        t.setObjectName("Title")
        lv.addWidget(t)
        self.vod_list = QListWidget()
        self.vod_list.setContextMenuPolicy(Qt.CustomContextMenu)
        self.vod_list.customContextMenuRequested.connect(self._vod_menu)
        self.vod_list.currentItemChanged.connect(self._on_vod_selected)
        self.vod_list.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.vod_list.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        lv.addWidget(self.vod_list, 1)
        self.vod_hint = QLabel(tr("main_vods_hint"))
        self.vod_hint.setObjectName("Muted")
        self.vod_hint.setWordWrap(True)
        self.vod_hint.setStyleSheet("font-size: 8.5pt;")
        lv.addWidget(self.vod_hint)
        left.setMinimumWidth(230)
        left.setMaximumWidth(360)
        split.addWidget(left)

        mid_split = QSplitter(Qt.Horizontal)
        mid_split.setChildrenCollapsible(False)
        split.addWidget(mid_split)
        split.setStretchFactor(1, 1)

        center = QWidget()
        cv = QVBoxLayout(center)
        cv.setContentsMargins(0, 0, 0, 0)
        cv.setSpacing(8)
        self.banner = Banner()
        self.banner.btn.clicked.connect(self._banner_clicked)
        cv.addWidget(self.banner)
        self.moments_title = QLabel(tr("main_moments"))
        self.moments_title.setObjectName("Title")
        cv.addWidget(self.moments_title)

        self.center_stack = QStackedWidget()
        cv.addWidget(self.center_stack, 1)
        # page 0: empty
        empty = QLabel(tr("main_empty"))
        empty.setAlignment(Qt.AlignCenter)
        empty.setWordWrap(True)
        empty.setObjectName("Muted")
        empty.setStyleSheet("font-size: 12pt; padding: 40px;")
        self.empty_lbl = empty
        self.center_stack.addWidget(empty)
        # page 1: running
        run = QFrame()
        run.setObjectName("Panel")
        rv = QVBoxLayout(run)
        rv.setContentsMargins(30, 30, 30, 30)
        rv.addStretch(1)
        self.run_title = QLabel("")
        self.run_title.setObjectName("Title")
        self.run_title.setAlignment(Qt.AlignCenter)
        self.run_title.setWordWrap(True)
        rv.addWidget(self.run_title)
        self.run_bar = QProgressBar()
        self.run_bar.setObjectName("Big")
        self.run_bar.setRange(0, 1000)
        self.run_bar.setTextVisible(True)
        rv.addWidget(self.run_bar)
        self.run_step = QLabel("")
        self.run_step.setAlignment(Qt.AlignCenter)
        self.run_step.setWordWrap(True)
        rv.addWidget(self.run_step)
        self.run_side = QLabel("")
        self.run_side.setObjectName("Muted")
        self.run_side.setAlignment(Qt.AlignCenter)
        rv.addWidget(self.run_side)
        self.run_hint = QLabel(tr("main_run_hint"))
        self.run_hint.setObjectName("Muted")
        self.run_hint.setWordWrap(True)
        self.run_hint.setAlignment(Qt.AlignCenter)
        rv.addWidget(self.run_hint)
        row = QHBoxLayout()
        row.addStretch(1)
        self.btn_cancel_run = QPushButton(tr("btn_pause"))
        self.btn_cancel_run.clicked.connect(self._cancel_current)
        row.addWidget(self.btn_cancel_run)
        row.addStretch(1)
        rv.addLayout(row)
        rv.addStretch(2)
        self.center_stack.addWidget(run)
        # page 2: error / interrupted
        err = QFrame()
        err.setObjectName("ErrorBox")
        ev = QVBoxLayout(err)
        ev.setContentsMargins(30, 30, 30, 30)
        ev.addStretch(1)
        self.err_title = QLabel("")
        self.err_title.setObjectName("Title")
        self.err_title.setWordWrap(True)
        self.err_title.setAlignment(Qt.AlignCenter)
        ev.addWidget(self.err_title)
        self.err_text = QLabel("")
        self.err_text.setWordWrap(True)
        self.err_text.setAlignment(Qt.AlignCenter)
        ev.addWidget(self.err_text)
        row = QHBoxLayout()
        row.addStretch(1)
        self.btn_resume = QPushButton(tr("btn_resume"))
        self.btn_resume.setObjectName("Primary")
        self.btn_resume.clicked.connect(lambda: self.current and self.start_analysis(self.current))
        self.btn_err_details = QPushButton(tr("btn_details"))
        self.btn_err_details.clicked.connect(self._show_error_details)
        self.btn_err_settings = QPushButton(tr("btn_settings"))
        self.btn_err_settings.clicked.connect(lambda: self.open_settings("ai"))
        row.addWidget(self.btn_resume)
        row.addWidget(self.btn_err_details)
        row.addWidget(self.btn_err_settings)
        row.addStretch(1)
        ev.addLayout(row)
        ev.addStretch(2)
        self.center_stack.addWidget(err)

        # page 3: the two tabs
        self.results = QTabWidget()
        self.results.setDocumentMode(True)
        self.center_stack.addWidget(self.results)
        # -- tab 1: AI moments
        mpage = QWidget()
        mv = QVBoxLayout(mpage)
        mv.setContentsMargins(0, 6, 0, 0)
        mv.setSpacing(8)
        hdr = QHBoxLayout()
        self.moments_info = QLabel("")
        self.moments_info.setObjectName("Muted")
        hdr.addWidget(self.moments_info)
        hdr.addStretch(1)
        self.btn_all = QPushButton(tr("btn_check_all"))
        self.btn_all.setObjectName("Flat")
        self.btn_all.clicked.connect(lambda: self.model.set_all_checked(True))
        self.btn_none = QPushButton(tr("btn_check_none"))
        self.btn_none.setObjectName("Flat")
        self.btn_none.clicked.connect(lambda: self.model.set_all_checked(False))
        hdr.addWidget(self.btn_all)
        hdr.addWidget(self.btn_none)
        hdr.addWidget(QLabel(tr("main_show")))
        self.top_combo = QComboBox()
        for n in (10, 20, 50):
            self.top_combo.addItem(tr("main_top", n=n), n)
        i = self.top_combo.findData(int(self.cfg["top_n"]))
        if i < 0:
            self.top_combo.addItem(tr("main_top", n=self.cfg["top_n"]), int(self.cfg["top_n"]))
            i = self.top_combo.count() - 1
        self.top_combo.setCurrentIndex(i)
        self.top_combo.currentIndexChanged.connect(self._top_changed)
        hdr.addWidget(self.top_combo)
        mv.addLayout(hdr)
        self.timeline = TimelineWidget()
        self.timeline.clicked.connect(self._timeline_clicked)
        mv.addWidget(self.timeline)
        self.moments_stack = QStackedWidget()
        mv.addWidget(self.moments_stack, 1)
        self.model = MomentsModel(self)
        self.model.checked_changed.connect(self._on_checked)
        self.model.title_edited.connect(self._on_title_edited)
        self.proxy = MomentsProxy(self)
        self.proxy.setSourceModel(self.model)
        self.table = QTableView()
        self.table.setModel(self.proxy)
        self.table.setSortingEnabled(True)
        self.table.sortByColumn(4, Qt.DescendingOrder)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setAlternatingRowColors(True)
        self.table.verticalHeader().hide()
        self.table.verticalHeader().setDefaultSectionSize(34)
        self.table.setShowGrid(False)
        self.table.setWordWrap(False)
        self.table.setEditTriggers(QAbstractItemView.EditKeyPressed | QAbstractItemView.SelectedClicked)
        self.table.setItemDelegateForColumn(4, ScoreDelegate(self.table))
        hh = self.table.horizontalHeader()
        for col, mode, w in ((0, QHeaderView.Fixed, 34), (1, QHeaderView.Fixed, 38), (2, QHeaderView.Fixed, 74),
                             (3, QHeaderView.Fixed, 60), (4, QHeaderView.Fixed, 74),
                             (5, QHeaderView.Stretch, 0), (6, QHeaderView.Interactive, 200)):
            hh.setSectionResizeMode(col, mode)
            if w:
                hh.resizeSection(col, w)
        self.table.selectionModel().currentRowChanged.connect(self._on_row)
        self.table.doubleClicked.connect(lambda idx: idx.column() != 5 and self.player.play_clip())
        self.moments_stack.addWidget(self.table)
        self.no_moments = QLabel(tr("main_no_moments"))
        self.no_moments.setAlignment(Qt.AlignCenter)
        self.no_moments.setWordWrap(True)
        self.no_moments.setObjectName("Muted")
        self.no_moments.setStyleSheet("font-size: 11pt; padding: 30px;")
        self.moments_stack.addWidget(self.no_moments)
        self.results.addTab(mpage, tr("tab_moments"))
        # -- tab 2: Albion kills
        self.alb = AlbionPanel(self.cfg, self.icons)
        self.alb.selection_changed.connect(self._on_kill_selected)
        self.alb.checked_changed.connect(self._on_kills_checked)
        self.alb.filters_changed.connect(self._albion_filters_changed)
        self.alb.offset_changed.connect(self._albion_offset_changed)
        self.alb.refresh_requested.connect(self._albion_refresh)
        self.alb.settings_requested.connect(lambda: self.open_settings("albion"))
        self.alb.play_requested.connect(lambda: self.player.play_clip())
        self.results.addTab(self.alb, tr("tab_albion"))
        self.results.currentChanged.connect(self._on_results_tab)
        mid_split.addWidget(center)

        self.player = PlayerPanel()
        self.player.range_changed.connect(self._on_range_changed)
        self.player.title_changed.connect(self._on_player_title)
        self.player.need_segment.connect(self._fetch_preview)
        self.player.edit_subs.connect(self._edit_subtitles)
        self.player.setMinimumWidth(400)
        mid_split.addWidget(self.player)
        mid_split.setStretchFactor(0, 3)
        mid_split.setStretchFactor(1, 2)
        mid_split.setSizes([720, 470])
        split.setSizes([260, 1180])

        # ---- export bar
        bar = QFrame()
        bar.setObjectName("Panel")
        bl = QHBoxLayout(bar)
        bl.setContentsMargins(12, 8, 12, 8)
        bl.addWidget(QLabel("<b>" + tr("exp_title") + "</b>"))
        self.chk_land = QCheckBox("16:9")
        self.chk_land.setChecked(self.cfg["export_landscape"])
        self.chk_vert = QCheckBox("9:16")
        self.chk_vert.setChecked(self.cfg["export_vertical"])
        self.vstyle = QComboBox()
        self.vstyle.addItem(tr("vs_blur"), "blur")
        self.vstyle.addItem(tr("vs_crop"), "crop")
        self.vstyle.addItem(tr("vs_webcam"), "webcam")
        self.vstyle.setCurrentIndex(max(0, self.vstyle.findData(self.cfg["vertical_style"])))
        self.btn_webcam = QToolButton()
        self.btn_webcam.setText("🎥")
        self.btn_webcam.setToolTip(tr("btn_webcam_tip"))
        self.btn_webcam.clicked.connect(self._open_webcam_layout)
        self.chk_subs = QCheckBox(tr("exp_subs"))
        self.chk_subs.setChecked(self.cfg["subtitles"])
        self.chk_title = QCheckBox(tr("exp_title_overlay"))
        self.chk_title.setToolTip(tr("exp_title_overlay_tip"))
        self.chk_title.setChecked(self.cfg["title_overlay"])
        for w in (self.chk_land, self.chk_vert, self.chk_subs, self.chk_title):
            w.toggled.connect(self._export_opts_changed)
        self.vstyle.currentIndexChanged.connect(self._export_opts_changed)
        bl.addWidget(self.chk_land)
        bl.addWidget(self.chk_vert)
        bl.addWidget(self.vstyle)
        bl.addWidget(self.btn_webcam)
        bl.addWidget(self.chk_subs)
        bl.addWidget(self.chk_title)
        bl.addSpacing(10)
        self.exp_bar = QProgressBar()
        self.exp_bar.setRange(0, 1000)
        self.exp_bar.setFixedWidth(200)
        self.exp_bar.hide()
        self.exp_lbl = QLabel("")
        self.exp_lbl.setObjectName("Muted")
        bl.addWidget(self.exp_bar)
        bl.addWidget(self.exp_lbl, 1)
        self.btn_open_out = QToolButton()
        self.btn_open_out.setText("📂")
        self.btn_open_out.setToolTip(tr("btn_open_clips"))
        self.btn_open_out.clicked.connect(self._open_output)
        bl.addWidget(self.btn_open_out)
        self.btn_export = QPushButton(tr("btn_export", n=0))
        self.btn_export.setObjectName("Primary")
        self.btn_export.clicked.connect(self.export_checked)
        bl.addWidget(self.btn_export)
        outer.addWidget(bar)
        self.status = self.statusBar()

        for table, model in ((self.table, self.model), (self.alb.table, self.alb.model)):
            for key, fn in (("Space", self._toggle_current_check), ("Return", self.player.play_clip)):
                sc = QShortcut(QKeySequence(key), table, activated=fn)
                sc.setContext(Qt.WidgetShortcut)   # only when that list has the focus
        self._show_center(0)
        self._export_opts_changed(save=False)

    def _build_tray(self) -> None:
        self.tray = None
        if not QSystemTrayIcon.isSystemTrayAvailable():
            return
        self.tray = QSystemTrayIcon(theme.app_icon(), self)
        self.tray.setToolTip("FireClips")
        menu = QMenu()
        a = QAction(tr("tray_open"), self)
        a.triggered.connect(self.bring_to_front)
        menu.addAction(a)
        a = QAction(tr("tray_quit"), self)
        a.triggered.connect(self.quit_app)
        menu.addAction(a)
        self.tray.setContextMenu(menu)
        self.tray.activated.connect(lambda r: r == QSystemTrayIcon.Trigger and self.bring_to_front())
        self.tray.show()

    # ================================================================== VOD list
    def _select_first(self) -> None:
        if self.vod_list.count() and self.vod_list.currentRow() < 0:
            self.vod_list.setCurrentRow(0)

    def refresh_vods(self) -> None:
        refs = self.lib.all()
        keys = [r.key for r in refs]
        cur_key = self.current.key if self.current else None
        existing = {self.vod_list.item(i).data(Qt.UserRole): self.vod_list.item(i) for i in range(self.vod_list.count())}
        if list(existing) != keys:
            self.vod_list.blockSignals(True)
            self.vod_list.clear()
            for r in refs:
                it = QListWidgetItem()
                it.setData(Qt.UserRole, r.key)
                w = VodItemWidget()
                it.setSizeHint(w.sizeHint())
                self.vod_list.addItem(it)
                self.vod_list.setItemWidget(it, w)
            if cur_key in keys:
                self.vod_list.setCurrentRow(keys.index(cur_key))
            self.vod_list.blockSignals(False)
            if cur_key and cur_key not in keys:
                self.current = None
                self._load_current()
        for i, r in enumerate(refs):
            it = self.vod_list.item(i)
            w = self.vod_list.itemWidget(it)
            if w is None:
                continue
            status, text, prog = self._vod_status(r)
            w.set(vod_title(r), vod_sub(r), text, STATUS_COLORS.get(status, theme.MUTED), prog)
        self.vod_hint.setVisible(not refs)

    def _vod_status(self, r: VodRef) -> tuple[str, str, Optional[float]]:
        job = self.jobs.analysis_job(r.key)
        if job is not None:
            if job.running:
                pct = int(100 * job.progress)
                step = tr("step_" + job.step) if job.step else ""
                return "running", f"⏳ {step} {pct} %", job.progress
            return "queued", "🕒 " + tr("status_queued"), None
        st = r.state
        s = r.status()
        if s == "done":
            n = st.get("n_moments", 0)
            warn = len(st.get("warnings") or [])
            kills = st.get("n_kills")
            return "done", ("✔ " + tr("status_done", n=n) + (f" · ⚔ {kills}" if kills else "")
                            + (f"  ⚠ {warn}" if warn else "")), None
        if s == "error":
            return "error", "✖ " + tr("status_error"), None
        if s in ("interrupted", "running", "paused"):
            return "interrupted", "⏸ " + tr("status_interrupted"), float(st.get("progress") or 0)
        return "new", tr("status_new"), None

    def _on_vod_selected(self, cur, _prev) -> None:
        if cur is None:
            return
        key = cur.data(Qt.UserRole)
        if self.current is not None and self.current.key == key:
            return
        self._save_edits()
        self.player.release()
        self.jobs.cancel_previews()
        self.current = self.lib.ref(key)
        self._load_current()

    def _vod_menu(self, pos) -> None:
        it = self.vod_list.itemAt(pos)
        if it is None:
            return
        ref = self.lib.ref(it.data(Qt.UserRole))
        menu = QMenu(self)
        running = self.jobs.analysis_job(ref.key) is not None
        if running:
            menu.addAction(tr("menu_pause"), lambda: self.pause_analysis(ref.key))
        else:
            status = ref.status()
            if status == "done":
                menu.addAction(tr("menu_rerun_ai"), lambda: self._rerun_ai(ref))
                menu.addAction(tr("menu_redo_all"), lambda: self._redo_all(ref))
                if albion.links_for_vod(self.cfg, ref.meta):
                    menu.addAction(tr("menu_albion_refresh"), lambda: self._albion_refresh(ref))
            else:
                menu.addAction(tr("menu_resume"), lambda: self.start_analysis(ref))
        menu.addSeparator()
        menu.addAction(tr("menu_open_clips"), lambda: open_in_explorer(self._out_dir(ref)))
        menu.addAction(tr("menu_open_work"), lambda: open_in_explorer(ref.dir))
        if ref.kind == "twitch":
            menu.addAction(tr("menu_open_twitch"), lambda: QDesktopServices.openUrl(QUrl(twitch.vod_url(ref.vod_id))))
        menu.addAction(tr("menu_free"), lambda: self._free_space(ref))
        menu.addSeparator()
        a = menu.addAction(tr("menu_delete"), lambda: self._delete_vod(ref))
        a.setEnabled(not running)
        menu.exec(self.vod_list.mapToGlobal(pos))

    def _rerun_ai(self, ref: VodRef) -> None:
        """Ask the AI again (fresh answers, not the cached ones). Transcript is kept."""
        import shutil
        shutil.rmtree(ref.p("ai"), ignore_errors=True)
        ref.p("ai_moments.json").unlink(missing_ok=True)
        self.start_analysis(ref, select=True)

    def _redo_all(self, ref: VodRef) -> None:
        if QMessageBox.question(self, "FireClips", tr("confirm_redo_all")) != QMessageBox.Yes:
            return
        import shutil
        for p in list(ref.dir.glob("transcript*")) + [ref.p("ai"), ref.p("ai_moments.json"), ref.p("triggers.json"),
                                                       ref.p("audio_features.npz"), ref.p("moments.json")]:
            if p.is_dir():
                shutil.rmtree(p, ignore_errors=True)
            elif p.exists():
                p.unlink()
        self.start_analysis(ref)

    def _free_space(self, ref: VodRef) -> None:
        if self.current and self.current.key == ref.key:
            self.player.release()
        self.segments.pop(ref.key, None)
        freed = store.free_media(ref)
        self.status.showMessage(tr("freed", size=f"{freed / 1e6:.0f} Mo"), 6000)

    def _delete_vod(self, ref: VodRef) -> None:
        if QMessageBox.question(self, "FireClips", tr("confirm_delete", title=vod_title(ref))) != QMessageBox.Yes:
            return
        if self.current and self.current.key == ref.key:
            self.player.release()
            self.current = None
        self.lib.delete(ref)
        self.refresh_vods()
        self._load_current()

    # ================================================================== analysis
    def analyze_url(self) -> None:
        text = self.url.text().strip()
        if not text:
            self.url.setFocus()
            return
        kind, val = twitch.parse_input(text)
        if kind == "vod":
            ref = self.lib.for_twitch(val)
            self.url.clear()
            self.start_analysis(ref, select=True)
        elif kind == "channel":
            QMessageBox.information(self, "FireClips", tr("msg_channel_link", channel=val))
        elif kind == "clip":
            QMessageBox.information(self, "FireClips", tr("msg_clip_link"))
        else:
            QMessageBox.warning(self, "FireClips", tr("msg_bad_link"))

    def analyze_local(self) -> None:
        f, _ = QFileDialog.getOpenFileName(self, tr("btn_local"), str(Path.home() / "Videos"),
                                           tr("file_filter") + " (*.mp4 *.mkv *.mov *.flv *.ts *.webm *.avi)")
        if f:
            ref = self.lib.for_local(Path(f))
            self.start_analysis(ref, select=True)

    def start_analysis(self, ref: VodRef, select: bool = False) -> None:
        if self.jobs.analysis_job(ref.key) is not None:
            if select:
                self._select_key(ref.key)
            return
        if ref.status() != "done":
            ref.set_state(status="queued")
        job = Job("analyze", ["--key", ref.key, "--work", str(self.cfg.work_dir)], key=ref.key)
        self.jobs.submit(job, "analysis")
        self.refresh_vods()
        if select or (self.current and self.current.key == ref.key):
            self._select_key(ref.key)
            self._load_current()

    def _select_key(self, key: str) -> None:
        for i in range(self.vod_list.count()):
            if self.vod_list.item(i).data(Qt.UserRole) == key:
                self.vod_list.setCurrentRow(i)
                return

    def _cancel_current(self) -> None:
        if self.current:
            self.pause_analysis(self.current.key)

    def pause_analysis(self, key: str) -> None:
        job = self.jobs.analysis_job(key)
        if job is not None:
            job.setProperty("user_paused", True)
        self.jobs.cancel_key(key)
        ref = self.lib.ref(key)
        if ref.dir.exists() and ref.status() in ("queued", "running", "interrupted"):
            ref.set_state(status="paused", pid=0)
        self.refresh_vods()

    def _resume_unfinished(self) -> None:
        """Analyses that were running or waiting when the app (or the PC) stopped start again."""
        for r in self.lib.all():
            if r.status() in ("interrupted", "queued") and self.jobs.analysis_job(r.key) is None:
                self.start_analysis(r)

    def _auto_new_vods(self, vods: list) -> None:
        for v in vods:
            ref = self.lib.for_twitch(v["vod_id"])
            m = ref.meta
            m.update({k: v[k] for k in ("title", "created_at", "duration") if v.get(k)})
            ref.save_meta(m)
            self.start_analysis(ref)
        self.refresh_vods()
        if self.tray and vods:
            self.tray.showMessage("FireClips", tr("tray_auto_started", n=len(vods)), theme.app_icon(), 5000)

    def _auto_status(self, text: str, kind: str) -> None:
        color = {"good": theme.GOOD, "live": theme.BAD, "bad": theme.WARN, "off": theme.MUTED}.get(kind, theme.MUTED)
        self.auto_chip.setText("● " + text)
        self.auto_chip.setStyleSheet(f"color: {color};")

    # ================================================================== job events
    def _on_job_event(self, job: Job, ev: dict) -> None:
        e = ev.get("ev")
        if job.kind == "analyze" and self.current and job.key == self.current.key:
            if e == "progress":
                self._update_running(job)
            elif e == "side":
                what = ev.get("what")
                self.run_side.setText(tr("side_" + what, pct=int(100 * float(ev.get("frac", 0)))))
            elif e == "warning":
                self._show_warnings([ev])
        elif job.kind == "export":
            if e == "progress":
                self.exp_bar.setValue(int(1000 * float(ev.get("frac", 0))))
                self.exp_lbl.setText(tr("exp_progress", i=int(ev.get("item", 0)) + 1, n=ev.get("total", 1)))
            elif e == "exported":
                self._mark_exported(job.key, ev.get("id"), ev.get("path"))
            elif e == "warning":
                job.setProperty("had_warning", True)
        elif job.kind == "albion" and e == "progress" and self.current and job.key == self.current.key:
            self.alb.btn_refresh.setText(tr("alb_refreshing", pct=int(100 * float(ev.get("frac", 0)))))

    def _on_job_finished(self, job: Job) -> None:
        if job.kind == "analyze":
            self.refresh_vods()
            ref = self.lib.ref(job.key)
            if self.current and self.current.key == job.key:
                self._load_current()
            if job.exit_code == 0:
                self._note_kill_count(ref)
                self._auto_export(ref)
                if self.tray and (not self.isVisible() or self.isMinimized()):
                    n = (ref.state or {}).get("n_moments", 0)
                    self.tray.showMessage("FireClips", tr("tray_done", n=n, title=vod_title(ref)), theme.app_icon(),
                                          8000)
        elif job.kind == "export":
            self._export_finished(job)
        elif job.kind == "segment":
            self._preview_finished(job)
        elif job.kind == "albion":
            self._albion_finished(job)

    def _update_running(self, job: Job) -> None:
        self.run_bar.setValue(int(1000 * job.progress))
        self.run_bar.setFormat(f"{int(100 * job.progress)} %")
        step = tr("step_" + job.step) if job.step else ""
        detail = job.detail or ""
        extra = ""
        if detail.startswith("eta:"):
            secs = int(detail[4:] or 0)
            extra = " — " + tr("eta", time=fmt_duration(secs)) if secs > 0 else ""
        elif detail.startswith("model:"):
            extra = " — " + tr("downloading_model", pct=detail[6:])
        elif detail.startswith("pull:"):
            extra = " — " + tr("ollama_pulling", model=self.cfg["ollama_model"], pct=detail[5:])
        elif job.step == "ai" and "/" in detail:
            extra = " — " + tr("ai_pieces", done=detail)
        self.run_step.setText(f"{step}{extra}")

    # ================================================================== loading a VOD
    def _show_center(self, page: int) -> None:
        self.center_stack.setCurrentIndex(page)

    def _load_current(self) -> None:
        self.banner.show_text("")
        ref = self.current
        if ref is None:
            self.moments_title.setText(tr("main_moments"))
            self.model.set_items([])
            self.alb.set_vod(None, None, [], [], None, 0.0)
            self.player.show_moment(None)
            self._show_center(0)
            self.empty_lbl.setText(tr("main_empty"))
            return
        self.moments_title.setText(vod_title(ref))
        job = self.jobs.analysis_job(ref.key)
        st = ref.state
        if job is not None:
            self.run_title.setText(tr("run_title", title=vod_title(ref)))
            if job.running:
                self._update_running(job)
            else:
                self.run_bar.setValue(0)
                self.run_step.setText(tr("status_queued"))
            self.run_side.setText("")
            self._show_center(1)
            self.player.show_moment(None)
            return
        status = ref.status()
        if status == "paused":
            status = "interrupted"
        if status in ("error", "interrupted"):
            err = st.get("error") or {}
            if status == "error":
                self.err_title.setText(tr("err_title"))
                self.err_text.setText(tr(err.get("code", "err_unexpected"), **(err.get("fmt") or {})))
                self.btn_err_details.setVisible(bool(err.get("detail")))
                self.btn_err_settings.setVisible(err.get("code", "").startswith("err_ai") or
                                                 err.get("code") in ("err_vod_sub_only",))
            else:
                self.err_title.setText(tr("interrupted_title"))
                self.err_text.setText(tr("interrupted_text", pct=int(100 * float(st.get("progress") or 0))))
                self.btn_err_details.setVisible(False)
                self.btn_err_settings.setVisible(False)
            self._show_center(2)
            self.player.show_moment(None)
            return
        doc = ref.moments()
        if doc is None:
            self._show_center(0)
            self.empty_lbl.setText(tr("main_not_analysed"))
            self.player.show_moment(None)
            return
        if doc.get("settings_fp") != scoring.settings_fingerprint(self.cfg) or doc.get("version", 1) < 2:
            self._rescore(ref)
        self._apply_doc(ref, doc)

    def _apply_doc(self, ref: VodRef, doc: dict) -> None:
        keep = self._current_item()
        keep_id = keep["id"] if keep else None
        self.doc = doc
        self.edits = ref.edits()
        self.kedits = ref.albion_edits()
        orig = {m["id"]: (m["start"], m["end"]) for m in doc.get("moments", [])}
        items = scoring.apply_edits(doc, self.edits)
        for m in items:
            m["orig"] = list(orig.get(m["id"], (m["start"], m["end"])))
        korig = {k["id"]: (k["start"], k["end"]) for k in doc.get("kills", [])}
        kitems = scoring.apply_edits(doc, self.kedits, "kills")
        for k in kitems:
            k["orig"] = list(korig.get(k["id"], (k["start"], k["end"])))
        self.model.set_items(items)
        self.table.sortByColumn(self.table.horizontalHeader().sortIndicatorSection(),
                                self.table.horizontalHeader().sortIndicatorOrder())
        n = len(items)
        n_trig = sum(1 for m in items if m.get("trigger"))
        self.moments_title.setText(vod_title(ref))
        self.moments_info.setText(tr("n_moments", n=n - n_trig) + (f" · 🎯 {tr('n_triggers', n=n_trig)}" if n_trig else ""))
        self.timeline.set_data(doc.get("timeline"), doc.get("timeline_step"), doc.get("duration"),
                               [(m["start"], m["end"], m.get("rank", 0)) for m in items], doc.get("timeline_events"))
        self.moments_stack.setCurrentIndex(0 if n else 1)
        links = albion.links_for_vod(self.cfg, ref.meta)
        self.alb.set_vod(ref, doc, kitems, links, ref.albion(), float(ref.albion_settings().get("offset") or 0))
        self._update_tab_titles()
        self._show_center(3)
        self._show_warnings((ref.state or {}).get("warnings") or [], doc)
        if keep_id and keep_id.startswith("k") and self.results.currentIndex() == TAB_ALBION:
            self.alb.select_id(keep_id)
        elif n:
            row = self.model.row_of(keep_id) if keep_id else -1
            if row >= 0:
                self.table.selectRow(self.proxy.mapFromSource(self.model.index(row, 1)).row())
            else:
                self.table.selectRow(0)
        self._on_results_tab(self.results.currentIndex())
        self._refresh_export_bar()

    def _update_tab_titles(self) -> None:
        n = len(self.model.items)
        self.results.setTabText(TAB_MOMENTS, tr("tab_moments") + (f" ({n})" if n else ""))
        k = self.alb.visible_count()
        self.results.setTabText(TAB_ALBION, tr("tab_albion") + (f" ({k})" if k else ""))

    def _show_warnings(self, warnings: list, doc: Optional[dict] = None) -> None:
        texts = []
        seen = set()
        for w in warnings:
            code = w.get("code", "")
            if code in seen:
                continue
            seen.add(code)
            texts.append(tr(code, **(w.get("fmt") or {})))
        if doc is not None and "ai" not in doc.get("available", []) and self.cfg["ai_provider"] == "none":
            texts.append(tr("hint_no_ai"))
            self._banner_action = "ai"
            self.banner.show_text("⚠ " + "<br>⚠ ".join(texts), tr("btn_settings_ai"))
            return
        self._banner_action = None
        self.banner.show_text(("⚠ " + "<br>⚠ ".join(texts)) if texts else "")

    def _banner_clicked(self) -> None:
        if getattr(self, "_banner_action", None) == "ai":
            self.open_settings("ai")

    def _show_error_details(self) -> None:
        if not self.current:
            return
        err = (self.current.state or {}).get("error") or {}
        DetailsDialog(tr("btn_details"), str(err.get("detail", "")), self).exec()

    def _rescore(self, ref: VodRef) -> None:
        snap = self.cfg.snapshot()
        self._rescore_seq = getattr(self, "_rescore_seq", 0) + 1
        seq = self._rescore_seq

        def work():
            from ..config import from_snapshot
            with _RESCORE_LOCK:
                if seq != self._rescore_seq:
                    return None          # a newer ranking was asked for meanwhile: skip this one
                return scoring.compute_and_save(ref, from_snapshot(snap))
        QThreadPool.globalInstance().start(_Task(work, ("rescore", ref.key, seq), self._sig))

    def _on_task_done(self, tag, res) -> None:
        if isinstance(tag, tuple) and tag[0] == "rescore":
            if isinstance(res, Exception):
                self.status.showMessage(tr("rescore_failed"), 6000)
                return
            if res is None or tag[2] != getattr(self, "_rescore_seq", 0):
                return      # an older ranking, replaced by a newer one
            if self.current and self.current.key == tag[1]:
                self._save_edits()
                self._apply_doc(self.current, res)
                self.status.showMessage(tr("rescored"), 4000)
                self._note_kill_count(self.current, res)

    def _note_kill_count(self, ref: VodRef, doc: Optional[dict] = None) -> None:
        doc = doc or ref.moments() or {}
        n = sum(1 for k in doc.get("kills", []) if not k.get("ignored"))
        if (ref.state or {}).get("n_kills") != n:
            try:
                ref.set_state(n_kills=n)
            except OSError:
                pass

    def _top_changed(self) -> None:
        n = int(self.top_combo.currentData())
        if n != int(self.cfg["top_n"]):
            self.cfg["top_n"] = n
            self.cfg.save()
            if self.current and self.current.moments() is not None:
                self._rescore(self.current)

    # ================================================================== moments / kills / player
    def _current_item(self) -> Optional[dict]:
        if self.results.currentIndex() == TAB_ALBION:
            return self.alb.current()
        idx = self.table.currentIndex()
        if not idx.isValid():
            return None
        row = self.proxy.mapToSource(idx).row()
        return self.model.items[row] if 0 <= row < len(self.model.items) else None

    def _edits_for(self, mid: str) -> dict:
        return self.kedits if str(mid).startswith("k") else self.edits

    def _model_for(self, mid: str):
        return self.alb.model if str(mid).startswith("k") else self.model

    def _duration(self) -> float:
        return float((self.doc or {}).get("duration") or 0)

    def _on_results_tab(self, i: int) -> None:
        m = self._current_item()
        self.player.show_moment(m, self._duration())
        self.timeline.set_current((m["start"], m["end"]) if m and i == TAB_MOMENTS else None)

    def _on_row(self, cur, _prev) -> None:
        if self.results.currentIndex() != TAB_MOMENTS:
            return
        m = self._current_item()
        self.player.show_moment(m, self._duration())
        self.timeline.set_current((m["start"], m["end"]) if m else None)

    def _on_kill_selected(self, k) -> None:
        if self.results.currentIndex() == TAB_ALBION:
            self.player.show_moment(k, self._duration())

    def _timeline_clicked(self, t: float) -> None:
        best, dist = None, 1e18
        for i, m in enumerate(self.model.items):
            d = 0 if m["start"] <= t <= m["end"] else min(abs(m["start"] - t), abs(m["end"] - t))
            if d < dist:
                best, dist = i, d
        if best is not None:
            idx = self.proxy.mapFromSource(self.model.index(best, 1))
            self.table.selectRow(idx.row())

    def _toggle_current_check(self) -> None:
        m = self._current_item()
        if m is None:
            return
        model = self._model_for(m["id"])
        row = model.row_of(m["id"])
        model.setData(model.index(row, 0), Qt.Unchecked if m.get("checked") else Qt.Checked, Qt.CheckStateRole)

    def _edit(self, m: dict) -> dict:
        e = self._edits_for(m["id"]).setdefault(m["id"], {})
        e["orig"] = m.get("orig") or [m["start"], m["end"]]
        return e

    def _sync_checks(self, items: list, edits: dict) -> None:
        for m in items:
            e = edits.get(m["id"], {})
            was = e["checked"] if "checked" in e else bool(m.get("auto_check"))
            if bool(m.get("checked")) != bool(was):
                self._edit(m)["checked"] = bool(m.get("checked"))
        self._save_timer.start()
        self._refresh_export_bar()

    def _on_checked(self) -> None:
        self._sync_checks(self.model.items, self.edits)

    def _on_kills_checked(self) -> None:
        self._sync_checks(self.alb.model.items, self.kedits)

    def _on_title_edited(self, mid: str, title: str) -> None:
        for m in self.model.items:
            if m["id"] == mid:
                self._edit(m)["title"] = title
                if self._current_item() is m:
                    self.player.title_edit.setText(title)
        self._save_timer.start()

    def _on_player_title(self, title: str) -> None:
        m = self._current_item()
        if not m:
            return
        m["title"] = title
        self._edit(m)["title"] = title
        model = self._model_for(m["id"])
        model.refresh_row(model.row_of(m["id"]))
        self._save_timer.start()

    def _on_range_changed(self, a: float, b: float) -> None:
        m = self._current_item()
        if not m:
            return
        m["start"], m["end"] = round(a, 2), round(b, 2)
        e = self._edit(m)
        e["start"], e["end"] = m["start"], m["end"]
        model = self._model_for(m["id"])
        model.refresh_row(model.row_of(m["id"]))
        if self.results.currentIndex() == TAB_MOMENTS:
            self.timeline.set_current((a, b))
        self._save_timer.start()

    def _save_edits(self) -> None:
        if self.current is not None and self.doc is not None:
            try:
                self.current.save_edits(self.edits)
                if self.kedits or self.current.p("albion_edits.json").exists():
                    self.current.save_albion_edits(self.kedits)
            except OSError as e:
                log.warning("could not save edits: %s", e)

    def _edit_subtitles(self) -> None:
        m = self._current_item()
        ref = self.current
        if not m or ref is None:
            return
        a, b = float(m["start"]), float(m["end"])
        words = export.clip_words(ref, {}, a, b)
        original = "".join(w[2] for w in words).strip()
        current = None
        if m.get("subs_text") is not None:
            current = "".join(w[2] for w in export.clip_words(ref, m, a, b)).strip() if m["subs_text"] else ""
        dlg = SubtitleDialog(original, current, self)
        if dlg.exec() != QDialog.Accepted:
            return
        e = self._edit(m)
        if dlg.result_value is SubtitleDialog.ORIGINAL:
            for k in ("subs_text", "subs_range"):
                e.pop(k, None)
                m.pop(k, None)
        else:
            e["subs_text"] = m["subs_text"] = dlg.result_value
            e["subs_range"] = m["subs_range"] = [a, b]
        model = self._model_for(m["id"])
        model.refresh_row(model.row_of(m["id"]))
        self.player.refresh_details(m)
        self._save_timer.start()

    # ---- preview
    def _fetch_preview(self, a: float, b: float) -> None:
        ref = self.current
        if ref is None:
            return
        vf = ref.video_file()
        if vf is not None:
            dur = float(ref.meta.get("duration") or 0)
            self.player.set_source({"path": str(vf), "vod_start": 0.0, "duration": dur, "full": True})
            return
        if ref.kind == "local":
            self.player.preview_failed(tr("err_local_missing"))
            return
        for s in self.segments.get(ref.key, []):
            if s["vod_start"] <= a + 0.05 and s["vod_start"] + s["duration"] >= b - 0.05 and Path(s["path"]).exists():
                self.player.set_source(s)
                return
        if self.preview_job is not None:
            if getattr(self.preview_job, "want", None) == (a, b) and self.preview_job.key == ref.key \
                    and not self.preview_job.cancelled:
                return      # the same piece is already on its way
            self.preview_job.cancel()
        job = Job("segment", ["--key", ref.key, "--work", str(self.cfg.work_dir), "--start", f"{a:.2f}",
                              "--end", f"{b:.2f}", "--purpose", "preview"], key=ref.key)
        job.want = (a, b)
        self.preview_job = job
        self.jobs.submit(job, "preview")

    def _preview_finished(self, job: Job) -> None:
        if job is self.preview_job:
            self.preview_job = None
        if job.cancelled:
            return
        if job.exit_code == 0 and job.result and job.result.get("path"):
            src = {k: job.result[k] for k in ("path", "vod_start", "duration", "full")}
            self.segments.setdefault(job.key, []).append(src)
            if self.current and self.current.key == job.key:
                m = self._current_item()
                if m and src["vod_start"] <= m["start"] + 0.05 and src["vod_start"] + src["duration"] >= m["end"] - 0.05:
                    self.player.set_source(src, autoplay=self.player._autoplay)
        else:
            e = job.last_error or {}
            if self.current and self.current.key == job.key:
                self.player.preview_failed(tr("preview_failed") + "\n" + tr(e.get("code", "err_download_failed"),
                                                                             **(e.get("fmt") or {})))

    # ================================================================== Albion
    def _albion_refresh(self, ref: Optional[VodRef] = None) -> None:
        ref = ref or self.current
        if ref is None:
            return
        if any(j is not None and j.key == ref.key for j in [self.jobs.active.get("albion")] + self.jobs.queues["albion"]):
            return
        job = Job("albion", ["--key", ref.key, "--work", str(self.cfg.work_dir)], key=ref.key)
        if self.current and self.current.key == ref.key:
            self.alb.btn_refresh.setEnabled(False)
            self.alb.btn_refresh.setText(tr("alb_refreshing", pct=0))
        self._save_edits()
        self.jobs.submit(job, "albion")

    def _albion_finished(self, job: Job) -> None:
        self.alb.btn_refresh.setText(tr("alb_refresh"))
        self.alb.btn_refresh.setEnabled(True)
        ref = self.lib.ref(job.key)
        if job.exit_code == 0:
            res = job.result or {}
            self.status.showMessage(tr("alb_refreshed", n=res.get("n", 0)), 6000)
            self._note_kill_count(ref)
            if self.current and self.current.key == job.key:
                self.results.setCurrentIndex(TAB_ALBION)
                self._load_current()
                if job.warnings:
                    self._show_warnings(job.warnings)
        elif not job.cancelled:
            e = job.last_error or {}
            QMessageBox.warning(self, "FireClips", tr(e.get("code", "warn_albion_failed"), **(e.get("fmt") or {}))
                                + ("\n\n" + str(e.get("detail"))[-500:] if e.get("detail") else ""))

    def _albion_filters_changed(self) -> None:
        self.cfg.update(self.alb.filter_values())
        self.cfg.save()
        if self.current and self.current.moments() is not None:
            self._rescore(self.current)

    def _albion_offset_changed(self, v: float) -> None:
        ref = self.current
        if ref is None:
            return
        s = ref.albion_settings()
        s["offset"] = float(v)
        ref.save_albion_settings(s)
        if ref.moments() is not None:
            self._rescore(ref)

    # ================================================================== export
    def _export_opts_changed(self, *_a, save: bool = True) -> None:
        if save:
            self.cfg.update({"export_landscape": self.chk_land.isChecked(), "export_vertical": self.chk_vert.isChecked(),
                             "vertical_style": self.vstyle.currentData(), "subtitles": self.chk_subs.isChecked(),
                             "title_overlay": self.chk_title.isChecked()})
            self.cfg.save()
        self.vstyle.setEnabled(self.chk_vert.isChecked())
        self.btn_webcam.setVisible(self.vstyle.currentData() == "webcam")
        self.btn_webcam.setEnabled(self.chk_vert.isChecked())
        self._refresh_export_bar()

    def _open_webcam_layout(self) -> None:
        img = self.player.grab_frame()
        dlg = WebcamLayoutDialog(self.cfg, img, self)
        if dlg.exec() == QDialog.Accepted:
            self.vstyle.blockSignals(True)
            self.vstyle.setCurrentIndex(max(0, self.vstyle.findData(self.cfg["vertical_style"])))
            self.vstyle.blockSignals(False)
            self._export_opts_changed(save=False)

    def _refresh_export_bar(self) -> None:
        if not hasattr(self, "alb"):
            return
        nm = len(self.model.checked())
        nk = len(self.alb.model.checked())
        n = nm + nk
        busy = self.jobs.active.get("export") is not None
        self.btn_export.setText(tr("btn_cancel_export") if busy else tr("btn_export", n=n))
        self.btn_export.setToolTip(tr("btn_export_tip", m=nm, k=nk))
        self.btn_export.setEnabled(busy or (n > 0 and (self.chk_land.isChecked() or self.chk_vert.isChecked())))
        self.exp_bar.setVisible(busy)
        self._update_tab_titles()

    def _out_dir(self, ref: VodRef) -> Path:
        return self.cfg.output_dir / export.vod_folder_name(ref.meta)

    def _open_output(self) -> None:
        d = self._out_dir(self.current) if self.current else self.cfg.output_dir
        if not d.exists():
            d = self.cfg.output_dir
        d.mkdir(parents=True, exist_ok=True)
        open_in_explorer(d)

    def _export_overrides(self) -> dict:
        return {"subtitles": self.chk_subs.isChecked(), "vertical_style": self.vstyle.currentData(),
                "title_overlay": self.chk_title.isChecked()}

    def _formats(self) -> list:
        return [f for f, on in (("vertical", self.chk_vert.isChecked()), ("landscape", self.chk_land.isChecked())) if on]

    def export_checked(self) -> None:
        if self.jobs.active.get("export") is not None:
            self.jobs.cancel_export()
            return
        if not self.current:
            return
        items = [export_item(m) for m in self.model.checked() + self.alb.model.checked()]
        if not items:
            return
        self._save_edits()
        job = Job("export", ["--key", self.current.key, "--work", str(self.cfg.work_dir), "--items", json.dumps(items),
                             "--formats", ",".join(self._formats()), "--overrides", json.dumps(self._export_overrides())],
                  key=self.current.key)
        self.export_job = job
        self.exp_bar.setValue(0)
        self.exp_lbl.setText(tr("exp_starting"))
        self.jobs.submit(job, "export")
        self._refresh_export_bar()

    def _auto_export(self, ref: VodRef) -> None:
        """Right after an analysis: export the clips asked for with a trigger phrase and the kills
        above the fame threshold (each clip only once)."""
        doc = ref.moments()
        if not doc:
            return
        done = set((ref.state or {}).get("auto_exported") or [])
        done_trig = [int(x[1:]) / 10 for x in done if x.startswith("t") and x[1:].isdigit()]

        def trigger_done(m: dict) -> bool:
            # the same phrase found again after a new transcription can move by a few tenths
            return m["id"] in done or any(abs(float(m.get("peak") or 0) - t) < 5 for t in done_trig)
        items = []
        if self.cfg["trigger_auto_export"]:
            items += [m for m in scoring.apply_edits(doc, ref.edits())
                      if m.get("trigger") and m.get("checked") and not m.get("exported") and not trigger_done(m)]
        if self.cfg["albion_auto_export"]:
            items += [k for k in scoring.apply_edits(doc, ref.albion_edits(), "kills")
                      if not k.get("ignored") and k.get("checked") and not k.get("exported") and k["id"] not in done]
        if not items:
            return
        formats = [f for f, on in (("vertical", self.cfg["export_vertical"]), ("landscape", self.cfg["export_landscape"]))
                   if on] or ["vertical"]
        overrides = {"subtitles": self.cfg["subtitles"], "vertical_style": self.cfg["vertical_style"],
                     "title_overlay": self.cfg["title_overlay"]}
        job = Job("export", ["--key", ref.key, "--work", str(self.cfg.work_dir),
                             "--items", json.dumps([export_item(m) for m in items]), "--formats", ",".join(formats),
                             "--overrides", json.dumps(overrides)], key=ref.key)
        job.setProperty("auto", True)
        ref.set_state(auto_exported=sorted(done | {m["id"] for m in items}))
        n_t = sum(1 for m in items if m.get("trigger"))
        self.exp_bar.setValue(0)
        self.exp_lbl.setText(tr("exp_auto_start", n=len(items)))
        self.jobs.submit(job, "export")
        self._refresh_export_bar()
        log.info("auto export of %d clips (%d trigger, %d kills) for %s", len(items), n_t, len(items) - n_t, ref.key)

    def _mark_exported(self, key: str, mid: str, path: str) -> None:
        if not mid:
            return
        ref = self.lib.ref(key)
        here = self.current is not None and self.current.key == key
        is_kill = str(mid).startswith("k")
        if here:
            edits = self._edits_for(mid)
        else:
            edits = ref.albion_edits() if is_kill else ref.edits()
        e = edits.setdefault(mid, {})
        lst = e.get("exported") or []
        if not isinstance(lst, list):
            lst = []
        lst.append(path)
        e["exported"] = lst
        if here:
            model = self._model_for(mid)
            for m in model.items:
                if m["id"] == mid:
                    m["exported"] = lst
                    e.setdefault("orig", m.get("orig") or [m["start"], m["end"]])
                    model.refresh_row(model.row_of(mid))
            self._save_timer.start()
        else:
            if "orig" not in e:
                doc = ref.moments() or {}
                for m in doc.get("kills" if is_kill else "moments", []):
                    if m["id"] == mid:
                        e["orig"] = [m["start"], m["end"]]
            (ref.save_albion_edits if is_kill else ref.save_edits)(edits)

    def _export_finished(self, job: Job) -> None:
        self.exp_bar.hide()
        res = job.result or {}
        files = res.get("files") or []
        auto = bool(job.property("auto"))
        if job.cancelled:
            self.exp_lbl.setText(tr("exp_cancelled"))
        elif files:
            fails = int(res.get("failures") or 0)
            self.exp_lbl.setText((tr("exp_auto_done", n=len(files)) if auto else tr("exp_done", n=len(files)))
                                 + (f" — {tr('exp_failed', n=fails)}" if fails else ""))
            if self.cfg["open_folder_after_export"] and res.get("folder") and not auto:
                open_in_explorer(Path(res["folder"]))
            if self.tray and (auto or not self.isVisible()):
                self.tray.showMessage("FireClips", tr("exp_auto_done", n=len(files)) if auto else
                                      tr("exp_done", n=len(files)), theme.app_icon(), 6000)
        else:
            e = job.last_error or {}
            self.exp_lbl.setText(tr("exp_error"))
            if not auto:
                detail = e.get("detail") or job.stderr_tail()
                w = (job.warnings or [{}])[0]
                code = e.get("code") or w.get("code") or "err_export_failed"
                QMessageBox.warning(self, "FireClips", tr(code, **(e.get("fmt") or w.get("fmt") or {}))
                                    + ("\n\n" + str(detail or w.get("detail") or "")[-800:] if (detail or w.get("detail")) else ""))
        self._refresh_export_bar()

    # ================================================================== settings / help
    def open_settings(self, tab="general") -> None:
        dlg = SettingsDialog(self.cfg, lambda j: self.jobs.submit(j, "preview"), self, tab,
                             frame_getter=self.player.grab_frame)
        if dlg.exec() != QDialog.Accepted:
            return
        groups = dlg.changed_groups()
        self.chk_land.setChecked(self.cfg["export_landscape"])
        self.chk_vert.setChecked(self.cfg["export_vertical"])
        self.chk_subs.setChecked(self.cfg["subtitles"])
        self.chk_title.setChecked(self.cfg["title_overlay"])
        self.vstyle.setCurrentIndex(max(0, self.vstyle.findData(self.cfg["vertical_style"])))
        self.alb.set_filter_values()
        i = self.top_combo.findData(int(self.cfg["top_n"]))
        if i < 0:
            self.top_combo.addItem(tr("main_top", n=self.cfg["top_n"]), int(self.cfg["top_n"]))
            i = self.top_combo.count() - 1
        self.top_combo.blockSignals(True)
        self.top_combo.setCurrentIndex(i)
        self.top_combo.blockSignals(False)
        if "work_dir" in groups:
            self.lib = Library(self.cfg.work_dir)
            self.current = None
            self.refresh_vods()
            self._load_current()
        if "auto" in groups:
            if self.cfg["mode"] != "auto":
                self.watcher.switch_off_reset()
            self.watcher.apply()
        if "autostart" in groups:
            set_autostart(bool(self.cfg["start_with_windows"]))
        if "albion" in groups:
            self.collector.apply()
            if self.current is not None and self.current.moments() is not None and "detection" not in groups:
                self._load_current()
        if "detection" in groups and self.current is not None and self.current.moments() is not None:
            self._rescore(self.current)
        if "ai" in groups and self.current is not None and self.current.status() == "done":
            self.status.showMessage(tr("hint_rerun_ai"), 10000)
        if "albion_links" in groups and self.current is not None and self.current.status() == "done" \
                and albion.links_for_vod(self.cfg, self.current.meta) and self.current.albion() is None:
            self.status.showMessage(tr("hint_albion_fetch"), 10000)
        if "language" in groups:
            QMessageBox.information(self, "FireClips", tr("msg_restart_lang"))
        self._status_line()

    def open_help(self) -> None:
        for p in (paths.PACKAGE_DIR.parent / "GUIDE.html", paths.ROOT / "app" / "GUIDE.html"):
            if p.exists():
                QDesktopServices.openUrl(QUrl.fromLocalFile(str(p)))
                return
        QMessageBox.information(self, "FireClips", tr("msg_no_guide"))

    def _status_line(self) -> None:
        g = tools.best_gpu()
        ai = {"none": tr("ai_none"), "anthropic": "Claude", "openai": "OpenAI", "ollama": "Ollama"}.get(
            self.cfg["ai_provider"], "?")
        parts = [f"GPU : {g.name}" if g else tr("status_no_gpu"), tr("status_ai", ai=ai),
                 tr("status_out", path=str(self.cfg.output_dir))]
        self.status.showMessage("   ·   ".join(parts))

    # ================================================================== window / quit
    def bring_to_front(self) -> None:
        self.show()
        self.setWindowState((self.windowState() & ~Qt.WindowMinimized) | Qt.WindowActive)
        self.raise_()
        self.activateWindow()

    def closeEvent(self, e) -> None:  # noqa: N802
        if self._quitting:
            e.accept()
            return
        keep = self.cfg["mode"] == "auto" or self.jobs.busy() or (self.cfg["albion_collect"] and self.collector.links())
        if self.tray is not None and self.cfg["minimize_to_tray"] and keep:
            e.ignore()
            self.hide()
            if not self._tray_hint_shown:
                self._tray_hint_shown = True
                self.tray.showMessage("FireClips", tr("tray_still_running"), theme.app_icon(), 5000)
            return
        if self.jobs.busy():
            r = QMessageBox.question(self, "FireClips", tr("confirm_quit_busy"))
            if r != QMessageBox.Yes:
                e.ignore()
                return
        self.quit_app()
        e.accept()

    def quit_app(self) -> None:
        self._quitting = True
        self._save_edits()
        self.player.release()
        self.jobs.stop_all()
        if self.tray is not None:
            self.tray.hide()
        QApplication.quit()
