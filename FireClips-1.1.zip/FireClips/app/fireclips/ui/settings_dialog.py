"""Settings window and first-run welcome window."""
from __future__ import annotations

import copy
from typing import Callable, Optional

from PySide6.QtCore import Qt, QUrl, Signal
from PySide6.QtGui import QColor, QDesktopServices
from PySide6.QtWidgets import (QAbstractItemView, QCheckBox, QColorDialog, QComboBox, QDialog, QDialogButtonBox,
                               QFileDialog, QFormLayout, QFrame, QGridLayout, QHBoxLayout, QHeaderView, QLabel,
                               QLineEdit, QMessageBox, QPlainTextEdit, QPushButton, QRadioButton, QScrollArea,
                               QSlider, QSpinBox, QStackedWidget, QTableWidget, QTableWidgetItem, QTabWidget,
                               QVBoxLayout, QWidget)

from .. import __version__, albion, paths, tools, transcribe
from ..config import DEFAULTS, SIGNALS, Config
from ..i18n import tr
from ..scoring import DETECTION_KEYS
from ..util import free_space, human_size, open_in_explorer
from . import theme
from .jobs import Job

TAB_NAMES = ["general", "auto", "detection", "triggers", "transcription", "ai", "albion", "export", "advanced"]
ALBION_KEYS = ("albion_links", "albion_collect")
REGION_LIST = ("europe", "americas", "asia")
AI_KEYS = ("ai_provider", "anthropic_key", "anthropic_model", "openai_key", "openai_model", "openai_base_url",
           "ollama_url", "ollama_model", "streamer_name", "ai_context", "ai_title_language", "ai_show_chat")

CLAUDE_MODELS = ["claude-sonnet-5-5", "claude-haiku-5-5", "claude-opus-5-5"]
OPENAI_MODELS = ["gpt-6-luna", "gpt-6-sol", "gpt-6.1-sol", "gpt-6-astra"]
OLLAMA_MODELS = ["qwen3.5:9b", "qwen3.5:4b", "gemma4:12b"]


def _words_to_text(words: list) -> str:
    return ", ".join(words)


def _text_to_words(text: str) -> list[str]:
    out = []
    for part in text.replace("\n", ",").split(","):
        p = part.strip()
        if p and p not in out:
            out.append(p)
    return out


def _combo(items: list[tuple[str, str]], current: str, editable: bool = False) -> QComboBox:
    c = QComboBox()
    c.setEditable(editable)
    for value, label in items:
        c.addItem(label, value)
    i = c.findData(current)
    if i >= 0:
        c.setCurrentIndex(i)
    elif editable:
        c.setEditText(current)
    return c


def _val(c: QComboBox) -> str:
    if c.isEditable():
        t = c.currentText().strip()
        i = c.findText(t)
        return c.itemData(i) if i >= 0 and c.itemData(i) else t
    return c.currentData()


def _spin(lo: int, hi: int, val: int, suffix: str = "") -> QSpinBox:
    s = QSpinBox()
    s.setRange(lo, hi)
    s.setValue(int(val))
    if suffix:
        s.setSuffix(suffix)
    return s


def _hint(text: str) -> QLabel:
    l = QLabel(text)
    l.setWordWrap(True)
    l.setObjectName("Muted")
    l.setStyleSheet("font-size: 8.5pt;")
    l.setOpenExternalLinks(True)
    return l


class SettingsDialog(QDialog):
    def __init__(self, cfg: Config, run_job: Callable[[Job], Job], parent=None, start_tab="general",
                 frame_getter: Optional[Callable] = None):
        super().__init__(parent)
        self.cfg = cfg
        self.run_job = run_job
        self.frame_getter = frame_getter
        self.before = cfg.snapshot()
        self.setWindowTitle(tr("set_title"))
        self.resize(860, 700)
        lay = QVBoxLayout(self)
        self.tabs = QTabWidget()
        self.tabs.setUsesScrollButtons(True)
        lay.addWidget(self.tabs, 1)
        self._build_general()
        self._build_auto()
        self._build_detection()
        self._build_triggers()
        self._build_transcription()
        self._build_ai()
        self._build_albion()
        self._build_export()
        self._build_advanced()
        self.tabs.setCurrentIndex(self.tab_index(start_tab))
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.button(QDialogButtonBox.Ok).setText(tr("btn_save"))
        bb.button(QDialogButtonBox.Ok).setObjectName("Primary")
        bb.button(QDialogButtonBox.Cancel).setText(tr("btn_cancel"))
        bb.accepted.connect(self._save)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)

    @staticmethod
    def tab_index(tab) -> int:
        if isinstance(tab, int):
            return tab
        return TAB_NAMES.index(tab) if tab in TAB_NAMES else 0

    # ------------------------------------------------------------------ helpers
    def _page(self, title: str) -> QFormLayout:
        inner = QWidget()
        form = QFormLayout(inner)
        form.setLabelAlignment(Qt.AlignRight | Qt.AlignVCenter)
        form.setHorizontalSpacing(14)
        form.setVerticalSpacing(10)
        sa = QScrollArea()
        sa.setWidgetResizable(True)
        sa.setFrameShape(QFrame.NoFrame)
        sa.setWidget(inner)
        self.tabs.addTab(sa, title)
        return form

    def _folder_row(self, current: str, default) -> tuple[QWidget, QLineEdit]:
        w = QWidget()
        h = QHBoxLayout(w)
        h.setContentsMargins(0, 0, 0, 0)
        e = QLineEdit(current)
        e.setPlaceholderText(str(default))
        b = QPushButton(tr("btn_browse"))

        def pick():
            d = QFileDialog.getExistingDirectory(self, tr("btn_browse"), e.text() or str(default))
            if d:
                e.setText(d)
        b.clicked.connect(pick)
        h.addWidget(e, 1)
        h.addWidget(b)
        return w, e

    # ------------------------------------------------------------------ tabs
    def _build_general(self) -> None:
        c = self.cfg
        f = self._page(tr("tab_general"))
        self.lang = _combo([("fr", "Français"), ("en", "English")], c["language"])
        f.addRow(tr("set_language"), self.lang)
        w, self.out_dir = self._folder_row(c["output_dir"], paths.default_output_dir())
        f.addRow(tr("set_output_dir"), w)
        w, self.work_dir = self._folder_row(c["work_dir"], paths.default_work_dir())
        f.addRow(tr("set_work_dir"), w)
        self.space_lbl = _hint("")
        f.addRow("", self.space_lbl)
        self.work_dir.textChanged.connect(self._update_space)
        self._update_space()
        self.dl_mode = _combo([("audio", tr("set_dl_audio")), ("full", tr("set_dl_full"))], c["download_mode"])
        f.addRow(tr("set_download"), self.dl_mode)
        f.addRow("", _hint(tr("set_download_hint")))
        q = [("best", tr("q_best")), ("1080p60", "1080p60"), ("720p60", "720p60"), ("720p", "720p"),
             ("480p", "480p")]
        self.exp_q = _combo(q, c["export_quality"])
        f.addRow(tr("set_export_quality"), self.exp_q)
        self.prev_q = _combo([("720p", "720p"), ("480p", tr("q_fast")), ("best", tr("q_best"))], c["preview_quality"])
        f.addRow(tr("set_preview_quality"), self.prev_q)
        self.delete_after = QCheckBox(tr("set_delete_after"))
        self.delete_after.setChecked(c["delete_after"])
        f.addRow("", self.delete_after)
        f.addRow("", _hint(tr("set_delete_after_hint")))

    def _update_space(self) -> None:
        d = self.work_dir.text().strip() or str(paths.default_work_dir())
        self.space_lbl.setText(tr("set_free_space", size=human_size(free_space(d))))

    def _build_auto(self) -> None:
        c = self.cfg
        f = self._page(tr("tab_auto"))
        self.mode = _combo([("manual", tr("mode_manual")), ("auto", tr("mode_auto"))], c["mode"])
        f.addRow(tr("set_mode"), self.mode)
        f.addRow("", _hint(tr("set_mode_hint")))
        self.channel = QLineEdit(c["channel"])
        self.channel.setPlaceholderText(tr("set_channel_ph"))
        f.addRow(tr("set_channel"), self.channel)
        self.check_min = _spin(2, 120, c["auto_check_minutes"], " min")
        f.addRow(tr("set_check_every"), self.check_min)
        self.wait_min = _spin(0, 240, c["auto_wait_minutes"], " min")
        f.addRow(tr("set_wait_after"), self.wait_min)
        self.backfill = _spin(0, 20, c["auto_backfill"])
        f.addRow(tr("set_backfill"), self.backfill)
        self.keep = _spin(0, 500, c["keep_vods"])
        self.keep.setSpecialValueText(tr("set_keep_all"))
        f.addRow(tr("set_keep"), self.keep)
        f.addRow("", _hint(tr("set_keep_hint")))
        self.autostart = QCheckBox(tr("set_autostart"))
        self.autostart.setChecked(c["start_with_windows"])
        f.addRow("", self.autostart)
        self.tray = QCheckBox(tr("set_tray"))
        self.tray.setChecked(c["minimize_to_tray"])
        f.addRow("", self.tray)
        f.addRow("", _hint(tr("set_tray_hint")))

    def _build_detection(self) -> None:
        c = self.cfg
        f = self._page(tr("tab_detection"))
        self.top_n = QComboBox()
        self.top_n.setEditable(True)
        for n in ("10", "20", "50"):
            self.top_n.addItem(n)
        self.top_n.setCurrentText(str(c["top_n"]))
        f.addRow(tr("set_top_n"), self.top_n)
        self.min_score = _spin(0, 100, c["min_score"])
        f.addRow(tr("set_min_score"), self.min_score)
        row = QHBoxLayout()
        self.min_len = _spin(5, 600, c["min_clip_len"], " s")
        self.max_len = _spin(10, 900, c["max_clip_len"], " s")
        row.addWidget(QLabel(tr("set_min")))
        row.addWidget(self.min_len)
        row.addSpacing(12)
        row.addWidget(QLabel(tr("set_max")))
        row.addWidget(self.max_len)
        row.addStretch(1)
        f.addRow(tr("set_clip_len"), row)
        row = QHBoxLayout()
        self.ctx_before = _spin(0, 120, c["context_before"], " s")
        self.ctx_after = _spin(0, 120, c["context_after"], " s")
        row.addWidget(QLabel(tr("set_before")))
        row.addWidget(self.ctx_before)
        row.addSpacing(12)
        row.addWidget(QLabel(tr("set_after")))
        row.addWidget(self.ctx_after)
        row.addStretch(1)
        f.addRow(tr("set_context"), row)
        f.addRow("", _hint(tr("set_context_hint")))
        self.chat_delay = _spin(0, 30, c["chat_delay"], " s")
        f.addRow(tr("set_chat_delay"), self.chat_delay)
        f.addRow("", _hint(tr("set_chat_delay_hint")))

        box = QFrame()
        box.setObjectName("Panel")
        g = QGridLayout(box)
        g.setContentsMargins(10, 10, 10, 10)
        self.weight_sliders = {}
        for i, k in enumerate(SIGNALS):
            lbl = QLabel(tr("sig_" + k))
            lbl.setToolTip(tr("sig_" + k + "_tip"))
            s = QSlider(Qt.Horizontal)
            s.setRange(0, 100)
            s.setValue(int(c["weights"].get(k, 0)))
            v = QLabel(str(s.value()))
            v.setMinimumWidth(28)
            s.valueChanged.connect(lambda val, v=v: v.setText(str(val)))
            g.addWidget(lbl, i, 0)
            g.addWidget(s, i, 1)
            g.addWidget(v, i, 2)
            self.weight_sliders[k] = s
        reset = QPushButton(tr("btn_defaults"))
        reset.setObjectName("Flat")
        reset.clicked.connect(lambda: [self.weight_sliders[k].setValue(DEFAULTS["weights"][k]) for k in SIGNALS])
        g.addWidget(reset, len(SIGNALS), 1, alignment=Qt.AlignRight)
        f.addRow(tr("set_weights"), box)
        f.addRow("", _hint(tr("set_weights_hint")))
        self.kw_laugh = QPlainTextEdit(_words_to_text(c["laugh_keywords"]))
        self.kw_laugh.setFixedHeight(70)
        f.addRow(tr("set_kw_laugh"), self.kw_laugh)
        self.kw_clip = QPlainTextEdit(_words_to_text(c["clip_keywords"]))
        self.kw_clip.setFixedHeight(50)
        f.addRow(tr("set_kw_clip"), self.kw_clip)
        self.kw_voice = QPlainTextEdit(_words_to_text(c["voice_keywords"]))
        self.kw_voice.setFixedHeight(60)
        f.addRow(tr("set_kw_voice"), self.kw_voice)
        f.addRow("", _hint(tr("set_kw_hint")))

    def _build_triggers(self) -> None:
        c = self.cfg
        f = self._page(tr("tab_triggers"))
        f.addRow(_hint(tr("trg_intro")))
        self.trg_table = QTableWidget(0, 2)
        self.trg_table.setHorizontalHeaderLabels([tr("trg_col_phrase"), tr("trg_col_secs")])
        self.trg_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.trg_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Fixed)
        self.trg_table.horizontalHeader().resizeSection(1, 150)
        self.trg_table.verticalHeader().hide()
        self.trg_table.verticalHeader().setDefaultSectionSize(36)
        self.trg_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.trg_table.setMinimumHeight(150)
        for ph in c["trigger_phrases"]:
            self._trg_add(ph.get("text", ""), int(ph.get("seconds") or 300))
        f.addRow(tr("trg_phrases"), self.trg_table)
        row = QHBoxLayout()
        b = QPushButton(tr("btn_add"))
        b.clicked.connect(lambda: self._trg_add("", 120, edit=True))
        row.addWidget(b)
        b = QPushButton(tr("btn_remove"))
        b.clicked.connect(lambda: self._remove_rows(self.trg_table))
        row.addWidget(b)
        row.addStretch(1)
        f.addRow("", row)
        self.trg_include = QCheckBox(tr("trg_include"))
        self.trg_include.setChecked(c["trigger_include_phrase"])
        f.addRow("", self.trg_include)
        self.trg_max = _spin(1, 60, max(1, int(c["trigger_max_seconds"]) // 60), " min")
        f.addRow(tr("trg_max"), self.trg_max)
        self.trg_auto = QCheckBox(tr("trg_auto"))
        self.trg_auto.setChecked(c["trigger_auto_export"])
        f.addRow("", self.trg_auto)
        row = QHBoxLayout()
        self.trg_try = QLineEdit()
        self.trg_try.setPlaceholderText(tr("trg_try_ph"))
        self.trg_try.textChanged.connect(self._trg_test)
        row.addWidget(self.trg_try, 1)
        f.addRow(tr("trg_try"), row)
        self.trg_try_res = _hint("")
        f.addRow("", self.trg_try_res)
        f.addRow("", _hint(tr("trg_hint")))

    def _trg_add(self, text: str, secs: int, edit: bool = False) -> None:
        r = self.trg_table.rowCount()
        self.trg_table.insertRow(r)
        self.trg_table.setItem(r, 0, QTableWidgetItem(text))
        sp = _spin(5, 3600, secs, " s")
        sp.setSingleStep(15)
        sp.setToolTip(tr("trg_secs_tip"))
        self.trg_table.setCellWidget(r, 1, sp)
        if edit:
            self.trg_table.setCurrentCell(r, 0)
            self.trg_table.editItem(self.trg_table.item(r, 0))

    @staticmethod
    def _remove_rows(table: QTableWidget) -> None:
        rows = sorted({i.row() for i in table.selectedIndexes()} or ({table.currentRow()} if table.currentRow() >= 0 else set()),
                      reverse=True)
        for r in rows:
            table.removeRow(r)

    def _trg_phrases(self) -> list:
        out = []
        for r in range(self.trg_table.rowCount()):
            it = self.trg_table.item(r, 0)
            text = (it.text() if it else "").strip()
            sp = self.trg_table.cellWidget(r, 1)
            if text:
                out.append({"text": text, "seconds": int(sp.value()) if sp else 300})
        return out

    def _trg_test(self) -> None:
        from .. import triggers
        text = self.trg_try.text().strip()
        if not text:
            self.trg_try_res.setText("")
            return
        words, t = [], 10.0
        for w in text.split():
            words.append([" " + w, t, t + 0.28])
            t += 0.3
        found = triggers.find({"segments": [{"s": 10.0, "e": t, "t": text, "w": words}]}, self._trg_phrases(),
                              self.trg_max.value() * 60)
        if found:
            f0 = found[0]
            from ..util import fmt_time
            self.trg_try_res.setStyleSheet(f"color: {theme.GOOD}; font-size: 8.5pt;")
            self.trg_try_res.setText(tr("trg_try_yes", dur=fmt_time(f0["seconds"]),
                                        how=tr("trg_try_said") if f0["spoken"] else tr("trg_try_default")))
        else:
            self.trg_try_res.setStyleSheet(f"color: {theme.BAD}; font-size: 8.5pt;")
            self.trg_try_res.setText(tr("trg_try_no"))

    def _build_albion(self) -> None:
        c = self.cfg
        f = self._page(tr("tab_set_albion"))
        f.addRow(_hint(tr("alb_set_intro")))
        self.alb_table = QTableWidget(0, 4)
        self.alb_table.setHorizontalHeaderLabels([tr("alb_col_player"), tr("alb_col_region"), tr("alb_col_channel"),
                                                  tr("alb_col_state")])
        hh = self.alb_table.horizontalHeader()
        for col, w in ((0, 130), (1, 118), (2, 130)):
            hh.setSectionResizeMode(col, QHeaderView.Interactive)
            hh.resizeSection(col, w)
        hh.setSectionResizeMode(3, QHeaderView.Stretch)
        self.alb_table.verticalHeader().hide()
        self.alb_table.verticalHeader().setDefaultSectionSize(38)
        self.alb_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.alb_table.setMinimumHeight(120)
        root = albion.data_root(c)
        for l in c["albion_links"]:
            self._alb_add(l.get("player", ""), l.get("region", "europe"), l.get("channel", ""),
                          albion.cached_player(root, l.get("region", "europe"), l.get("player", "")))
        f.addRow(tr("alb_links"), self.alb_table)
        row = QHBoxLayout()
        b = QPushButton(tr("btn_add"))
        b.clicked.connect(lambda: self._alb_add("", "europe", self.cfg["channel"] or "", None, edit=True))
        row.addWidget(b)
        b = QPushButton(tr("btn_remove"))
        b.clicked.connect(lambda: self._remove_rows(self.alb_table))
        row.addWidget(b)
        self.btn_alb_check = QPushButton(tr("alb_check"))
        self.btn_alb_check.clicked.connect(self._alb_check)
        row.addWidget(self.btn_alb_check)
        row.addStretch(1)
        f.addRow("", row)
        f.addRow("", _hint(tr("alb_links_hint")))
        self.alb_fame = QSpinBox()
        self.alb_fame.setRange(0, 1_000_000_000)
        self.alb_fame.setSingleStep(25_000)
        self.alb_fame.setGroupSeparatorShown(True)
        self.alb_fame.setValue(int(c["albion_min_fame"]))
        self.alb_fame.setSuffix(" fame")
        f.addRow(tr("alb_min_fame"), self.alb_fame)
        f.addRow("", _hint(tr("alb_min_fame_hint")))
        row = QHBoxLayout()
        row.setSpacing(18)
        types = set(c["albion_types"])
        self.alb_types = {}
        for t in ("kill", "assist", "death"):
            cb = QCheckBox(tr("ktypes_" + t))
            cb.setToolTip(tr("ktypes_" + t + "_tip"))
            cb.setChecked(t in types)
            self.alb_types[t] = cb
            row.addWidget(cb)
        row.addStretch(1)
        f.addRow(tr("alb_types"), row)
        row = QHBoxLayout()
        self.alb_before = _spin(0, 180, c["albion_before"], " s")
        self.alb_after = _spin(0, 120, c["albion_after"], " s")
        row.addWidget(QLabel(tr("set_before")))
        row.addWidget(self.alb_before)
        row.addSpacing(12)
        row.addWidget(QLabel(tr("set_after")))
        row.addWidget(self.alb_after)
        row.addStretch(1)
        f.addRow(tr("alb_clip"), row)
        self.alb_gap = _spin(0, 120, c["albion_group_gap"], " s")
        self.alb_gap.setSpecialValueText(tr("alb_gap_never"))
        f.addRow(tr("alb_gap"), self.alb_gap)
        f.addRow("", _hint(tr("alb_gap_hint")))
        self.alb_offset = _spin(-600, 600, c["albion_offset"], " s")
        f.addRow(tr("alb_offset"), self.alb_offset)
        f.addRow("", _hint(tr("alb_offset_hint")))
        self.alb_auto = QCheckBox(tr("alb_auto"))
        self.alb_auto.setChecked(c["albion_auto_export"])
        f.addRow("", self.alb_auto)
        self.alb_collect = QCheckBox(tr("alb_collect"))
        self.alb_collect.setChecked(c["albion_collect"])
        f.addRow("", self.alb_collect)
        f.addRow("", _hint(tr("alb_collect_hint")))

    def _alb_add(self, player: str, region: str, channel: str, info: Optional[dict], edit: bool = False) -> None:
        r = self.alb_table.rowCount()
        self.alb_table.insertRow(r)
        self.alb_table.setItem(r, 0, QTableWidgetItem(player))
        cb = QComboBox()
        for reg in REGION_LIST:
            cb.addItem(tr("region_" + reg), reg)
        cb.setCurrentIndex(max(0, cb.findData(region)))
        self.alb_table.setCellWidget(r, 1, cb)
        self.alb_table.setItem(r, 2, QTableWidgetItem(channel))
        st = QTableWidgetItem(self._alb_state(info))
        st.setFlags(Qt.ItemIsEnabled)
        self.alb_table.setItem(r, 3, st)
        if edit:
            self.alb_table.setCurrentCell(r, 0)
            self.alb_table.editItem(self.alb_table.item(r, 0))

    @staticmethod
    def _alb_state(info: Optional[dict]) -> str:
        if not info:
            return tr("alb_state_unknown")
        if info.get("ok") is False:
            return "✖ " + tr(info.get("code") or "err_albion_player", name=info.get("player", ""))
        g = info.get("guild") or tr("alb_no_guild")
        from ..i18n import language
        return f"✔ {g} · {albion.fmt_fame(info.get('kill_fame', 0), language())} kill fame"

    def _alb_links(self) -> list:
        out = []
        for r in range(self.alb_table.rowCount()):
            p = self.alb_table.item(r, 0)
            ch = self.alb_table.item(r, 2)
            cb = self.alb_table.cellWidget(r, 1)
            player = (p.text() if p else "").strip()
            if player:
                out.append({"player": player, "region": cb.currentData() if cb else "europe",
                            "channel": (ch.text() if ch else "").strip()})
        return out

    def _alb_check(self) -> None:
        import json
        links = self._alb_links()
        if not links:
            return
        self.btn_alb_check.setEnabled(False)
        for r in range(self.alb_table.rowCount()):
            it = self.alb_table.item(r, 3)
            if it:
                it.setText(tr("alb_state_checking"))
        job = Job("albion-check", ["--overrides", json.dumps({"albion_links": links, "language": self.cfg["language"],
                                                              "work_dir": self.work_dir.text().strip()})])

        def done(j: Job):
            self.btn_alb_check.setEnabled(True)
            res = ((j.result or {}).get("players")) or []
            by_name = {(x.get("player", "").lower(), x.get("region")): x for x in res}
            for r in range(self.alb_table.rowCount()):
                p = self.alb_table.item(r, 0)
                cb = self.alb_table.cellWidget(r, 1)
                key = ((p.text() if p else "").strip().lower(), cb.currentData() if cb else "europe")
                it = self.alb_table.item(r, 3)
                if it is not None:
                    info = by_name.get(key)
                    it.setText(self._alb_state(info) if info else ("✖ " + tr("err_albion_network")
                                                                   if j.exit_code != 0 else tr("alb_state_unknown")))
        job.finished.connect(done)
        self.run_job(job)

    def _build_transcription(self) -> None:
        c = self.cfg
        f = self._page(tr("tab_transcription"))
        self.w_model = _combo([("auto", tr("wm_auto")), ("small", tr("wm_small")),
                               ("large-v3-turbo", tr("wm_turbo")), ("large-v3", tr("wm_large"))], c["whisper_model"])
        f.addRow(tr("set_w_model"), self.w_model)
        self.w_lang = _combo([("auto", tr("wl_auto")), ("fr", "Français"), ("en", "English")], c["whisper_language"])
        f.addRow(tr("set_w_lang"), self.w_lang)
        self.w_dev = _combo([("auto", tr("wd_auto")), ("cuda", tr("wd_gpu")), ("cpu", tr("wd_cpu"))],
                            c["whisper_device"])
        f.addRow(tr("set_w_device"), self.w_dev)
        self.w_vocab = QLineEdit(c["whisper_vocab"])
        f.addRow(tr("set_w_vocab"), self.w_vocab)
        f.addRow("", _hint(tr("set_w_vocab_hint")))
        g = tools.best_gpu()
        opts = transcribe.auto_settings(c)
        info = (tr("set_gpu_found", name=g.name, vram=g.vram_mb) if g else tr("set_gpu_none"))
        info += "<br>" + tr("set_w_auto_choice", model=opts["model"], device=opts["device"].upper())
        f.addRow("", _hint(info))

    def _build_ai(self) -> None:
        c = self.cfg
        f = self._page(tr("tab_ai"))
        self.provider = _combo([("none", tr("ai_none")), ("anthropic", tr("ai_claude")), ("openai", tr("ai_openai")),
                                ("ollama", tr("ai_ollama"))], c["ai_provider"])
        f.addRow(tr("set_ai_provider"), self.provider)
        f.addRow("", _hint(tr("set_ai_hint")))
        self.ai_stack = QStackedWidget()
        # none
        self.ai_stack.addWidget(_hint(tr("ai_none_hint")))
        # claude
        w = QWidget()
        fl = QFormLayout(w)
        fl.setContentsMargins(0, 0, 0, 0)
        self.claude_key = QLineEdit(c["anthropic_key"])
        self.claude_key.setEchoMode(QLineEdit.Password)
        self.claude_key.setPlaceholderText("sk-ant-...")
        fl.addRow(tr("set_api_key"), self.claude_key)
        self.claude_model = _combo([(m, m) for m in CLAUDE_MODELS], c["anthropic_model"], editable=True)
        fl.addRow(tr("set_model"), self.claude_model)
        fl.addRow("", _hint(tr("ai_claude_hint")))
        self.ai_stack.addWidget(w)
        # openai
        w = QWidget()
        fl = QFormLayout(w)
        fl.setContentsMargins(0, 0, 0, 0)
        self.openai_key = QLineEdit(c["openai_key"])
        self.openai_key.setEchoMode(QLineEdit.Password)
        self.openai_key.setPlaceholderText("sk-...")
        fl.addRow(tr("set_api_key"), self.openai_key)
        self.openai_model = _combo([(m, m) for m in OPENAI_MODELS], c["openai_model"], editable=True)
        fl.addRow(tr("set_model"), self.openai_model)
        self.openai_url = QLineEdit(c["openai_base_url"])
        fl.addRow(tr("set_base_url"), self.openai_url)
        fl.addRow("", _hint(tr("ai_openai_hint")))
        self.ai_stack.addWidget(w)
        # ollama
        w = QWidget()
        fl = QFormLayout(w)
        fl.setContentsMargins(0, 0, 0, 0)
        self.ollama_url = QLineEdit(c["ollama_url"])
        fl.addRow(tr("set_ollama_url"), self.ollama_url)
        row = QHBoxLayout()
        self.ollama_model = _combo([(m, m) for m in OLLAMA_MODELS], c["ollama_model"], editable=True)
        self.btn_pull = QPushButton(tr("btn_pull"))
        self.btn_pull.clicked.connect(self._pull)
        row.addWidget(self.ollama_model, 1)
        row.addWidget(self.btn_pull)
        fl.addRow(tr("set_model"), row)
        fl.addRow("", _hint(tr("ai_ollama_hint")))
        self.ai_stack.addWidget(w)
        f.addRow("", self.ai_stack)
        self.provider.currentIndexChanged.connect(lambda i: self.ai_stack.setCurrentIndex(i))
        self.ai_stack.setCurrentIndex(self.provider.currentIndex())

        self.streamer = QLineEdit(c["streamer_name"])
        f.addRow(tr("set_streamer"), self.streamer)
        self.title_lang = _combo([("fr", "Français"), ("en", "English")], c["ai_title_language"])
        f.addRow(tr("set_title_lang"), self.title_lang)
        self.show_chat = QCheckBox(tr("set_show_chat"))
        self.show_chat.setChecked(c["ai_show_chat"])
        f.addRow("", self.show_chat)
        self.ai_context = QPlainTextEdit(c["ai_context"])
        self.ai_context.setPlaceholderText(tr("set_ai_context_ph"))
        self.ai_context.setFixedHeight(80)
        f.addRow(tr("set_ai_context"), self.ai_context)
        row = QHBoxLayout()
        self.btn_test = QPushButton(tr("btn_test_ai"))
        self.btn_test.clicked.connect(self._test_ai)
        self.test_lbl = QLabel("")
        self.test_lbl.setWordWrap(True)
        row.addWidget(self.btn_test)
        row.addWidget(self.test_lbl, 1)
        f.addRow("", row)

    def _build_export(self) -> None:
        c = self.cfg
        f = self._page(tr("tab_export"))
        row = QHBoxLayout()
        self.exp_land = QCheckBox("16:9")
        self.exp_land.setChecked(c["export_landscape"])
        self.exp_vert = QCheckBox("9:16 (TikTok / Shorts / Reels)")
        self.exp_vert.setChecked(c["export_vertical"])
        row.addWidget(self.exp_land)
        row.addWidget(self.exp_vert)
        row.addStretch(1)
        f.addRow(tr("set_formats"), row)
        row = QHBoxLayout()
        self.v_style = _combo([("blur", tr("vs_blur")), ("crop", tr("vs_crop")), ("webcam", tr("vs_webcam"))],
                              c["vertical_style"])
        row.addWidget(self.v_style, 1)
        b = QPushButton("🎥 " + tr("btn_webcam"))
        b.setToolTip(tr("btn_webcam_tip"))
        b.clicked.connect(self._webcam)
        row.addWidget(b)
        f.addRow(tr("set_v_style"), row)
        f.addRow("", _hint(tr("set_v_style_hint")))
        self.crop_pos = QSlider(Qt.Horizontal)
        self.crop_pos.setRange(0, 100)
        self.crop_pos.setValue(int(c["crop_position"]))
        f.addRow(tr("set_crop_pos"), self.crop_pos)
        f.addRow("", _hint(tr("set_crop_hint")))
        self.title_ov = QCheckBox(tr("set_title_overlay"))
        self.title_ov.setChecked(c["title_overlay"])
        f.addRow("", self.title_ov)
        self.title_ov_land = QCheckBox(tr("set_title_overlay_land"))
        self.title_ov_land.setChecked(c["title_overlay_landscape"])
        f.addRow("", self.title_ov_land)
        self.subs = QCheckBox(tr("set_subs"))
        self.subs.setChecked(c["subtitles"])
        f.addRow("", self.subs)
        self.subs_upper = QCheckBox(tr("set_subs_upper"))
        self.subs_upper.setChecked(c["subtitle_uppercase"])
        f.addRow("", self.subs_upper)
        self.subs_size = _spin(50, 200, c["subtitle_size"], " %")
        f.addRow(tr("set_subs_size"), self.subs_size)
        self.subs_pos = _spin(10, 95, c["subtitle_position"], " %")
        f.addRow(tr("set_subs_pos"), self.subs_pos)
        self.subs_words = _spin(1, 6, c["subtitle_words"])
        f.addRow(tr("set_subs_words"), self.subs_words)
        self.subs_color = QPushButton()
        self._set_color(c["subtitle_highlight"])
        self.subs_color.clicked.connect(self._pick_color)
        f.addRow(tr("set_subs_color"), self.subs_color)
        self.encoder = _combo([("auto", tr("enc_auto")), ("nvenc", "NVIDIA NVENC"), ("cpu", tr("enc_cpu"))],
                              c["encoder"])
        f.addRow(tr("set_encoder"), self.encoder)
        self.open_after = QCheckBox(tr("set_open_after"))
        self.open_after.setChecked(c["open_folder_after_export"])
        f.addRow("", self.open_after)

    def _webcam(self) -> None:
        from .edit_dialogs import WebcamLayoutDialog
        img = self.frame_getter() if self.frame_getter else None
        if WebcamLayoutDialog(self.cfg, img, self).exec() == QDialog.Accepted:
            self.v_style.setCurrentIndex(max(0, self.v_style.findData("webcam")))
            self.before["webcam_rect"] = self.cfg["webcam_rect"]

    def _set_color(self, hex_color: str) -> None:
        self._color = hex_color
        self.subs_color.setText(hex_color.upper())
        self.subs_color.setStyleSheet(f"background: {hex_color}; color: black; font-weight: 700;")

    def _pick_color(self) -> None:
        col = QColorDialog.getColor(QColor(self._color), self)
        if col.isValid():
            self._set_color(col.name())

    def _build_advanced(self) -> None:
        c = self.cfg
        f = self._page(tr("tab_advanced"))
        self.oauth = QLineEdit(c["twitch_oauth"])
        self.oauth.setEchoMode(QLineEdit.Password)
        f.addRow(tr("set_oauth"), self.oauth)
        f.addRow("", _hint(tr("set_oauth_hint")))
        row = QHBoxLayout()
        b1 = QPushButton(tr("btn_selfcheck"))
        b1.clicked.connect(self._selfcheck)
        b2 = QPushButton(tr("btn_update_tools"))
        b2.clicked.connect(self._update_tools)
        b3 = QPushButton(tr("btn_logs"))
        b3.clicked.connect(lambda: open_in_explorer(paths.LOGS))
        row.addWidget(b1)
        row.addWidget(b2)
        row.addWidget(b3)
        row.addStretch(1)
        f.addRow("", row)
        self.adv_out = QPlainTextEdit()
        self.adv_out.setReadOnly(True)
        self.adv_out.setFixedHeight(170)
        self.adv_out.setPlaceholderText(tr("set_adv_out_ph"))
        f.addRow("", self.adv_out)
        reset = QPushButton(tr("btn_reset_all"))
        reset.setObjectName("Flat")
        reset.clicked.connect(self._reset_all)
        f.addRow("", reset)
        f.addRow("", _hint(f"FireClips {__version__} — {paths.ROOT}"))

    # ------------------------------------------------------------------ actions
    def _collect(self) -> dict:
        try:
            top_n = max(1, min(200, int(self.top_n.currentText())))
        except ValueError:
            top_n = 20
        v = {
            "language": _val(self.lang), "output_dir": self.out_dir.text().strip(),
            "work_dir": self.work_dir.text().strip(), "download_mode": _val(self.dl_mode),
            "export_quality": _val(self.exp_q), "preview_quality": _val(self.prev_q),
            "delete_after": self.delete_after.isChecked(),
            "mode": _val(self.mode), "channel": self.channel.text().strip(),
            "auto_check_minutes": self.check_min.value(), "auto_wait_minutes": self.wait_min.value(),
            "auto_backfill": self.backfill.value(), "keep_vods": self.keep.value(),
            "start_with_windows": self.autostart.isChecked(), "minimize_to_tray": self.tray.isChecked(),
            "top_n": top_n, "min_score": self.min_score.value(), "min_clip_len": self.min_len.value(),
            "max_clip_len": max(self.max_len.value(), self.min_len.value() + 5),
            "context_before": self.ctx_before.value(), "context_after": self.ctx_after.value(),
            "chat_delay": self.chat_delay.value(),
            "weights": {k: s.value() for k, s in self.weight_sliders.items()},
            "laugh_keywords": _text_to_words(self.kw_laugh.toPlainText()),
            "clip_keywords": _text_to_words(self.kw_clip.toPlainText()),
            "voice_keywords": _text_to_words(self.kw_voice.toPlainText()),
            "whisper_model": _val(self.w_model), "whisper_language": _val(self.w_lang),
            "whisper_device": _val(self.w_dev), "whisper_vocab": self.w_vocab.text().strip(),
            "ai_provider": _val(self.provider), "anthropic_key": self.claude_key.text().strip(),
            "anthropic_model": _val(self.claude_model) or "claude-sonnet-5-5",
            "openai_key": self.openai_key.text().strip(), "openai_model": _val(self.openai_model) or "gpt-6-luna",
            "openai_base_url": self.openai_url.text().strip() or "https://api.openai.com/v1",
            "ollama_url": self.ollama_url.text().strip() or "http://localhost:11434",
            "ollama_model": _val(self.ollama_model) or "qwen3.5:9b",
            "streamer_name": self.streamer.text().strip(), "ai_title_language": _val(self.title_lang),
            "ai_show_chat": self.show_chat.isChecked(), "ai_context": self.ai_context.toPlainText().strip(),
            "export_landscape": self.exp_land.isChecked(), "export_vertical": self.exp_vert.isChecked(),
            "vertical_style": _val(self.v_style), "crop_position": self.crop_pos.value(),
            "subtitles": self.subs.isChecked(), "subtitle_uppercase": self.subs_upper.isChecked(),
            "subtitle_size": self.subs_size.value(), "subtitle_position": self.subs_pos.value(),
            "subtitle_words": self.subs_words.value(), "subtitle_highlight": self._color,
            "encoder": _val(self.encoder), "open_folder_after_export": self.open_after.isChecked(),
            "twitch_oauth": self.oauth.text().strip(),
            "title_overlay": self.title_ov.isChecked(), "title_overlay_landscape": self.title_ov_land.isChecked(),
            "trigger_phrases": self._trg_phrases(), "trigger_include_phrase": self.trg_include.isChecked(),
            "trigger_max_seconds": self.trg_max.value() * 60, "trigger_auto_export": self.trg_auto.isChecked(),
            "albion_links": self._alb_links(), "albion_min_fame": self.alb_fame.value(),
            "albion_types": [t for t, cb in self.alb_types.items() if cb.isChecked()],
            "albion_before": self.alb_before.value(), "albion_after": self.alb_after.value(),
            "albion_group_gap": self.alb_gap.value(), "albion_offset": self.alb_offset.value(),
            "albion_auto_export": self.alb_auto.isChecked(), "albion_collect": self.alb_collect.isChecked(),
        }
        return v

    def _save(self) -> None:
        v = self._collect()
        if v["mode"] == "auto" and not v["channel"]:
            QMessageBox.warning(self, tr("set_title"), tr("set_need_channel"))
            self.tabs.setCurrentIndex(self.tab_index("auto"))
            return
        self.cfg.update(v)
        self.cfg.save()
        self.accept()

    def changed_groups(self) -> set:
        after = self.cfg.snapshot()
        ch = {k for k in after if after.get(k) != self.before.get(k)}
        groups = set()
        if ch & set(DETECTION_KEYS):
            groups.add("detection")
        if ch & set(AI_KEYS):
            groups.add("ai")
        if "language" in ch:
            groups.add("language")
        if ch & {"mode", "channel", "auto_check_minutes", "auto_wait_minutes", "auto_backfill"}:
            groups.add("auto")
        if "start_with_windows" in ch:
            groups.add("autostart")
        if "work_dir" in ch:
            groups.add("work_dir")
        if ch & set(ALBION_KEYS):
            groups.add("albion")
        if "albion_links" in ch:
            groups.add("albion_links")
        return groups

    def _overrides(self) -> str:
        import json
        v = self._collect()
        return json.dumps({k: v[k] for k in AI_KEYS + ("language",)})

    def _test_ai(self) -> None:
        if _val(self.provider) == "none":
            self.test_lbl.setText(tr("err_ai_none"))
            return
        self.btn_test.setEnabled(False)
        self.test_lbl.setStyleSheet(f"color: {theme.MUTED};")
        self.test_lbl.setText(tr("ai_testing"))
        job = Job("test-ai", ["--overrides", self._overrides()])

        def done(j: Job):
            self.btn_test.setEnabled(True)
            if j.exit_code == 0 and j.result:
                self.test_lbl.setStyleSheet(f"color: {theme.GOOD};")
                self.test_lbl.setText(tr("ai_test_ok") + "  « " + str(j.result.get("text", ""))[:120] + " »")
            else:
                e = j.last_error or {}
                self.test_lbl.setStyleSheet(f"color: {theme.BAD};")
                self.test_lbl.setText(tr(e.get("code", "err_ai_request"), **(e.get("fmt") or {})))
                self.test_lbl.setToolTip(str(e.get("detail", ""))[:1500])
        job.finished.connect(done)
        self.run_job(job)

    def _pull(self) -> None:
        import json
        self.btn_pull.setEnabled(False)
        model = _val(self.ollama_model)
        self.test_lbl.setText(tr("ollama_pulling", model=model, pct=0))
        job = Job("ollama-pull", ["--model", model, "--overrides",
                                  json.dumps({"ollama_url": self.ollama_url.text().strip()})])
        job.event.connect(lambda ev: ev.get("ev") == "progress" and self.test_lbl.setText(
            tr("ollama_pulling", model=model, pct=int(100 * float(ev.get("frac", 0))))))

        def done(j: Job):
            self.btn_pull.setEnabled(True)
            if j.exit_code == 0:
                self.test_lbl.setStyleSheet(f"color: {theme.GOOD};")
                self.test_lbl.setText(tr("ollama_pulled", model=model))
            else:
                e = j.last_error or {}
                self.test_lbl.setStyleSheet(f"color: {theme.BAD};")
                self.test_lbl.setText(tr(e.get("code", "err_ollama_down"), **(e.get("fmt") or {})))
        job.finished.connect(done)
        self.run_job(job)

    def _selfcheck(self) -> None:
        self.adv_out.setPlainText(tr("selfcheck_running"))
        job = Job("selfcheck", [])
        lines: list[str] = []

        def on_ev(ev):
            if ev.get("ev") == "check":
                lines.append(ev.get("msg", ""))
                self.adv_out.setPlainText("\n".join(lines))
        job.event.connect(on_ev)
        job.finished.connect(lambda j: lines.append("" if j.exit_code == 0 else tr("selfcheck_problem"))
                             or self.adv_out.setPlainText("\n".join(lines)))
        self.run_job(job)

    def _update_tools(self) -> None:
        self.adv_out.setPlainText(tr("update_running"))
        job = Job("update-tools", [])
        lines: list[str] = []

        def on_ev(ev):
            if ev.get("ev") in ("log", "check"):
                lines.append(ev.get("msg", ""))
                self.adv_out.setPlainText("\n".join(lines))
        job.event.connect(on_ev)
        job.finished.connect(lambda j: self.adv_out.appendPlainText(
            tr("update_done") if j.exit_code == 0 else tr("update_failed")))
        self.run_job(job)

    def _reset_all(self) -> None:
        if QMessageBox.question(self, tr("set_title"), tr("set_reset_confirm")) != QMessageBox.Yes:
            return
        keep = {k: self.cfg[k] for k in ("anthropic_key", "openai_key", "twitch_oauth", "channel", "language",
                                          "first_run_done", "albion_links")}
        self.cfg.data = copy.deepcopy(DEFAULTS)
        self.cfg.update(keep)
        self.cfg.save()
        self.accept()


class WelcomeDialog(QDialog):
    """First start: language, channel, which AI."""
    language_changed = Signal(str)

    def __init__(self, cfg: Config, parent=None):
        super().__init__(parent)
        self.cfg = cfg
        self.setWindowTitle(tr("welcome_title"))
        self.setFixedWidth(700)
        lay = QVBoxLayout(self)
        lay.setSpacing(12)
        brand = QLabel("🔥 FireClips")
        brand.setObjectName("Brand")
        lay.addWidget(brand)
        intro = QLabel(tr("welcome_intro"))
        intro.setWordWrap(True)
        lay.addWidget(intro)
        form = QFormLayout()
        self.lang = _combo([("fr", "Français"), ("en", "English")], cfg["language"])
        self.lang.currentIndexChanged.connect(self._lang_changed)
        form.addRow(tr("set_language"), self.lang)
        self.channel = QLineEdit(cfg["channel"])
        self.channel.setPlaceholderText(tr("set_channel_ph"))
        form.addRow(tr("set_channel"), self.channel)
        lay.addLayout(form)
        lay.addWidget(_hint(tr("welcome_channel_hint")))
        box = QFrame()
        box.setObjectName("Panel")
        v = QVBoxLayout(box)
        v.addWidget(QLabel("<b>" + tr("welcome_ai_q") + "</b>"))
        self.radios = {}
        for key in ("anthropic", "openai", "ollama", "none"):
            r = QRadioButton(tr("welcome_ai_" + key))
            self.radios[key] = r
            v.addWidget(r)
            h = _hint(tr("welcome_ai_" + key + "_hint"))
            h.setContentsMargins(26, 0, 0, 4)
            h.setMinimumHeight(h.heightForWidth(560))
            v.addWidget(h)
        self.radios.get(cfg["ai_provider"], self.radios["none"]).setChecked(True)
        self.key = QLineEdit()
        self.key.setEchoMode(QLineEdit.Password)
        self.key.setPlaceholderText(tr("welcome_key_ph"))
        v.addWidget(self.key)
        for r in self.radios.values():
            r.toggled.connect(self._update_key)
        self._update_key()
        lay.addWidget(box)
        lay.addWidget(_hint(tr("welcome_later")))
        bb = QDialogButtonBox(QDialogButtonBox.Ok)
        bb.button(QDialogButtonBox.Ok).setText(tr("welcome_go"))
        bb.button(QDialogButtonBox.Ok).setObjectName("Primary")
        bb.accepted.connect(self._save)
        lay.addWidget(bb)
        self.adjustSize()

    def _choice(self) -> str:
        return next((k for k, r in self.radios.items() if r.isChecked()), "none")

    def _update_key(self) -> None:
        ch = self._choice()
        self.key.setVisible(ch in ("anthropic", "openai"))
        self.key.setText(self.cfg["anthropic_key"] if ch == "anthropic" else self.cfg["openai_key"] if ch == "openai" else "")

    def _lang_changed(self) -> None:
        lang = _val(self.lang)
        if lang != self.cfg["language"]:
            self.cfg["language"] = lang
            self.cfg.save()
            self.language_changed.emit(lang)
            self.done(2)  # re-open in the new language

    def _save(self) -> None:
        ch = self._choice()
        self.cfg["ai_provider"] = ch
        if ch == "anthropic":
            self.cfg["anthropic_key"] = self.key.text().strip()
        elif ch == "openai":
            self.cfg["openai_key"] = self.key.text().strip()
        self.cfg["channel"] = self.channel.text().strip()
        self.cfg["first_run_done"] = True
        self.cfg.save()
        self.accept()


def open_url(url: str) -> None:
    QDesktopServices.openUrl(QUrl(url))
