"""Table model for the list of moments."""
from __future__ import annotations

from PySide6.QtCore import QAbstractTableModel, QModelIndex, QSortFilterProxyModel, Qt, Signal

from ..i18n import tr
from ..scoring import reason_label
from ..util import fmt_time

SORT_ROLE = Qt.UserRole + 1
COLS = ["col_check", "col_rank", "col_start", "col_len", "col_score", "col_title", "col_why"]

CATEGORY_EMOJI = {"joke": "😂", "banter": "🗣️", "fail": "💀", "rage": "😡", "absurd": "🤪", "story": "📖",
                  "reaction": "😱", "other": "✨", "trigger": "🎯"}


def short_reasons(m: dict) -> str:
    parts = []
    for r in m.get("reasons", [])[:3]:
        if r["kind"] == "ai":
            parts.append(tr("why_ai", score=f"{r.get('score', 0):.0f}"))
        elif r["kind"] == "trigger":
            parts.append(tr("why_trigger_short", span=r.get("span", "")))
        else:
            parts.append(reason_label(r, tr))
    return " · ".join(parts)


class MomentsModel(QAbstractTableModel):
    checked_changed = Signal()
    title_edited = Signal(str, str)        # moment id, new title

    def __init__(self, parent=None):
        super().__init__(parent)
        self.items: list[dict] = []

    def set_items(self, items: list[dict]) -> None:
        self.beginResetModel()
        self.items = items
        self.endResetModel()
        self.checked_changed.emit()

    def rowCount(self, parent=QModelIndex()) -> int:  # noqa: N802
        return 0 if parent.isValid() else len(self.items)

    def columnCount(self, parent=QModelIndex()) -> int:  # noqa: N802
        return len(COLS)

    def headerData(self, section, orientation, role=Qt.DisplayRole):  # noqa: N802
        if orientation == Qt.Horizontal and role == Qt.DisplayRole:
            return tr(COLS[section])
        if orientation == Qt.Horizontal and role == Qt.ToolTipRole:
            return tr(COLS[section] + "_tip")
        return None

    def flags(self, idx):
        f = Qt.ItemIsEnabled | Qt.ItemIsSelectable
        if idx.column() == 0:
            f |= Qt.ItemIsUserCheckable
        if idx.column() == 5:
            f |= Qt.ItemIsEditable
        return f

    def data(self, idx, role=Qt.DisplayRole):
        if not idx.isValid():
            return None
        m = self.items[idx.row()]
        c = idx.column()
        if role == Qt.CheckStateRole and c == 0:
            return Qt.Checked if m.get("checked") else Qt.Unchecked
        if role == SORT_ROLE:
            pin = 1 if m.get("trigger") else 0          # clips asked for on stream stay on top
            return [int(bool(m.get("checked"))), m.get("rank", 0), m["start"], m["end"] - m["start"],
                    (pin, m["score"]), (m.get("title") or "").lower(), ""][c]
        if role == Qt.UserRole and c == 4:
            return m["score"]
        if role == Qt.DisplayRole:
            if c == 1:
                return "🎯" if m.get("trigger") else str(m.get("rank", ""))
            if c == 2:
                return fmt_time(m["start"])
            if c == 3:
                return fmt_time(m["end"] - m["start"])
            if c == 4:
                return f"{m['score']:.0f}"
            if c == 5:
                prefix = CATEGORY_EMOJI.get(m.get("category") or "", "")
                done = " ✅" if m.get("exported") else ""
                subs = " ✏" if m.get("subs_text") is not None else ""
                return (prefix + " " if prefix else "") + (m.get("title") or "") + subs + done
            if c == 6:
                return short_reasons(m)
        if role == Qt.EditRole and c == 5:
            return m.get("title") or ""
        if role == Qt.ToolTipRole:
            if c in (5, 6):
                lines = [f"<b>{m.get('title') or ''}</b>"] + ["• " + reason_label(r, tr) for r in m.get("reasons", [])]
                return "<br>".join(lines)
        if role == Qt.TextAlignmentRole and c in (1, 2, 3):
            return int(Qt.AlignCenter)
        if role == Qt.ForegroundRole and m.get("trigger") and c in (1, 5):
            from PySide6.QtGui import QColor
            from . import theme
            return QColor(theme.ACCENT_2)
        return None

    def setData(self, idx, value, role=Qt.EditRole) -> bool:  # noqa: N802
        if not idx.isValid():
            return False
        m = self.items[idx.row()]
        if role == Qt.CheckStateRole and idx.column() == 0:
            m["checked"] = (value == Qt.Checked or value == Qt.Checked.value or value == 2)
            self.dataChanged.emit(idx, idx)
            self.checked_changed.emit()
            return True
        if role == Qt.EditRole and idx.column() == 5:
            t = str(value).strip()
            if t and t != m.get("title"):
                m["title"] = t
                self.dataChanged.emit(idx, idx)
                self.title_edited.emit(m["id"], t)
            return True
        return False

    def checked(self) -> list[dict]:
        return [m for m in self.items if m.get("checked")]

    def set_all_checked(self, value: bool) -> None:
        for m in self.items:
            m["checked"] = value
        if self.items:
            self.dataChanged.emit(self.index(0, 0), self.index(len(self.items) - 1, 0))
        self.checked_changed.emit()

    def row_of(self, mid: str) -> int:
        for i, m in enumerate(self.items):
            if m["id"] == mid:
                return i
        return -1

    def refresh_row(self, row: int) -> None:
        if 0 <= row < len(self.items):
            self.dataChanged.emit(self.index(row, 0), self.index(row, len(COLS) - 1))


class MomentsProxy(QSortFilterProxyModel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setSortRole(SORT_ROLE)

    def lessThan(self, a, b) -> bool:  # noqa: N802
        va, vb = a.data(SORT_ROLE), b.data(SORT_ROLE)
        try:
            return va < vb
        except TypeError:
            return str(va) < str(vb)
