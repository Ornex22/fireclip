"""Automatic mode: watch the channel and analyse every new VOD once the stream is over.
Also: notification-area (tray) icon and "start with Windows"."""
from __future__ import annotations

import logging
import os
import subprocess
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

from PySide6.QtCore import QObject, QRunnable, QThreadPool, QTimer, Signal

from .. import paths, twitch
from ..config import Config
from ..i18n import tr
from ..util import IS_WINDOWS, no_window_flags

log = logging.getLogger("fireclips.auto")


class _Bridge(QObject):
    done = Signal(object)


class _CheckTask(QRunnable):
    def __init__(self, fn, bridge: _Bridge):
        super().__init__()
        self.fn = fn
        self.bridge = bridge

    def run(self) -> None:
        try:
            res = self.fn()
        except Exception as e:  # noqa: BLE001
            res = {"error": getattr(e, "code", "err_twitch_network"), "detail": str(e)}
        self.bridge.done.emit(res)


def _dt(s: str):
    try:
        return datetime.fromisoformat((s or "").replace("Z", "+00:00"))
    except ValueError:
        return None


class AutoWatcher(QObject):
    new_vods = Signal(list)          # [{"vod_id", "title", ...}] to analyse
    status = Signal(str, str)        # text, colour key ("good" | "live" | "bad" | "off")
    live_changed = Signal(object)    # True / False / None (unknown)

    def __init__(self, cfg: Config, lib_getter, parent=None):
        super().__init__(parent)
        self.cfg = cfg
        self.lib_getter = lib_getter
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.check_now)
        self.bridge = _Bridge()
        self.bridge.done.connect(self._on_result)
        self.busy = False
        self.last_live = None

    def apply(self) -> None:
        if self.cfg["mode"] == "auto" and self.cfg["channel"]:
            if not self.cfg["auto_since"]:
                self.cfg["auto_since"] = datetime.now(timezone.utc).isoformat()
                self.cfg["auto_done"] = []
                self.cfg.save()
                self._backfill_pending = True
            else:
                self._backfill_pending = False
            self.timer.start(max(2, int(self.cfg["auto_check_minutes"])) * 60_000)
            QTimer.singleShot(3000, self.check_now)
            self.status.emit(tr("auto_watching", channel=self.cfg["channel"]), "good")
        else:
            self.timer.stop()
            if self.cfg["mode"] == "auto":
                self.status.emit(tr("auto_no_channel"), "bad")
            else:
                self.status.emit(tr("auto_off"), "off")

    def switch_off_reset(self) -> None:
        self.cfg["auto_since"] = ""
        self.cfg.save()

    def check_now(self) -> None:
        if self.busy or self.cfg["mode"] != "auto" or not self.cfg["channel"]:
            return
        self.busy = True
        login = self.cfg["channel"]
        backfill = int(self.cfg["auto_backfill"]) if getattr(self, "_backfill_pending", False) else 0
        wait = int(self.cfg["auto_wait_minutes"])
        since = _dt(self.cfg["auto_since"]) or datetime.now(timezone.utc)
        done = set(self.cfg["auto_done"] or [])
        lib = self.lib_getter()

        def work():
            vids = twitch.get_channel_videos(login, 10)
            live = twitch.is_live(login)
            if live is None and vids:
                try:
                    live = twitch.get_video_info(vids[0]["vod_id"]).get("status", "").upper() == "RECORDING"
                except Exception:  # noqa: BLE001
                    live = None
            now = datetime.now(timezone.utc)
            todo = []
            for i, v in enumerate(vids):
                vid = v["vod_id"]
                if vid in done or lib.ref(f"tw_{vid}").dir.exists():
                    continue
                if i == 0 and live:
                    continue  # still being recorded
                created = _dt(v["created_at"])
                if created is None:
                    continue
                ended = created + timedelta(seconds=float(v.get("duration") or 0))
                if now - ended < timedelta(minutes=wait):
                    continue
                is_new = created >= since - timedelta(hours=12) and ended >= since
                if is_new or i < backfill:
                    todo.append(v)
            return {"live": live, "todo": todo, "backfilled": backfill > 0}

        QThreadPool.globalInstance().start(_CheckTask(work, self.bridge))

    def _on_result(self, res: dict) -> None:
        self.busy = False
        if res.get("error"):
            log.warning("auto check failed: %s", res.get("detail"))
            self.status.emit(tr("auto_check_failed"), "bad")
            return
        if res.get("backfilled"):
            self._backfill_pending = False
        live = res.get("live")
        if live != self.last_live:
            self.live_changed.emit(live)
        self.last_live = live
        if live:
            self.status.emit(tr("auto_live", channel=self.cfg["channel"]), "live")
        else:
            now = datetime.now().strftime("%H:%M")
            self.status.emit(tr("auto_offline", channel=self.cfg["channel"], time=now), "good")
        todo = res.get("todo") or []
        if todo:
            done = list(self.cfg["auto_done"] or [])
            done += [v["vod_id"] for v in todo]
            self.cfg["auto_done"] = done[-500:]
            self.cfg.save()
            self.new_vods.emit(todo)


# --------------------------------------------------------------------------- start with Windows

def startup_shortcut() -> Path:
    return Path(os.environ.get("APPDATA", "")) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup" / "FireClips.lnk"


def set_autostart(enabled: bool) -> bool:
    if not IS_WINDOWS:
        return False
    lnk = startup_shortcut()
    if not enabled:
        try:
            lnk.unlink(missing_ok=True)
        except OSError:
            return False
        return True
    exe = Path(sys.executable)
    pyw = exe.with_name("pythonw.exe") if exe.name.lower() == "python.exe" else exe
    icon = paths.ASSETS / "icon.ico"

    def q(s) -> str:
        return "'" + str(s).replace("'", "''") + "'"
    ps = (f"$s=(New-Object -COM WScript.Shell).CreateShortcut({q(lnk)});"
          f"$s.TargetPath={q(pyw)};$s.Arguments='-m fireclips --minimized';"
          f"$s.WorkingDirectory={q(paths.PACKAGE_DIR.parent)};$s.IconLocation={q(icon)};$s.Save()")
    try:
        subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", ps],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=30,
                       creationflags=no_window_flags())
    except Exception as e:  # noqa: BLE001
        log.warning("autostart shortcut failed: %s", e)
        return False
    return lnk.exists()
