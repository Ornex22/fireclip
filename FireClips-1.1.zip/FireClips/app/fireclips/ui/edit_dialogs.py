"""Small editors: the webcam + game layout of the 9:16 clips, and the subtitle text of a clip."""
from __future__ import annotations

from typing import Optional

from PySide6.QtCore import QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QColor, QFont, QImage, QLinearGradient, QPainter, QPen
from PySide6.QtWidgets import (QDialog, QDialogButtonBox, QGridLayout, QHBoxLayout, QLabel, QPlainTextEdit,
                               QPushButton, QSlider, QVBoxLayout, QWidget)

from ..i18n import tr
from . import theme


def placeholder_frame() -> QImage:
    img = QImage(1280, 720, QImage.Format_RGB32)
    p = QPainter(img)
    g = QLinearGradient(0, 0, 1280, 720)
    g.setColorAt(0, QColor("#2a2f45"))
    g.setColorAt(1, QColor("#3d2a2a"))
    p.fillRect(img.rect(), g)
    p.setPen(QColor("#c8c8d0"))
    f = QFont()
    f.setPointSize(26)
    p.setFont(f)
    p.drawText(img.rect(), Qt.AlignCenter | Qt.TextWordWrap, tr("wc_no_frame"))
    p.end()
    return img


class RectEditor(QWidget):
    """The stream picture with the webcam frame: drag inside to move it, drag a corner or an edge
    to resize it, or draw a new frame anywhere."""
    changed = Signal()
    HANDLE = 9

    def __init__(self, image: QImage, rect: list, parent=None):
        super().__init__(parent)
        self.img = image
        x, y, w, h = rect
        self.r = QRectF(x, y, w, h)
        self.mode: Optional[str] = None
        self.start_pos = QPointF()
        self.start_r = QRectF()
        self.setMinimumSize(520, 293)
        self.setMouseTracking(True)

    def frame(self) -> QRectF:
        W, H = self.width(), self.height()
        ar = self.img.width() / max(1, self.img.height())
        if W / max(1, H) > ar:
            h = H
            w = h * ar
        else:
            w = W
            h = w / ar
        return QRectF((W - w) / 2, (H - h) / 2, w, h)

    def _to_px(self, r: QRectF) -> QRectF:
        f = self.frame()
        return QRectF(f.x() + r.x() * f.width(), f.y() + r.y() * f.height(), r.width() * f.width(), r.height() * f.height())

    def _to_norm(self, p: QPointF) -> QPointF:
        f = self.frame()
        return QPointF((p.x() - f.x()) / max(1.0, f.width()), (p.y() - f.y()) / max(1.0, f.height()))

    def paintEvent(self, _e) -> None:  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        p.fillRect(self.rect(), QColor(theme.PANEL))
        f = self.frame()
        p.drawImage(f, self.img)
        rp = self._to_px(self.r)
        shade = QColor(0, 0, 0, 120)
        p.fillRect(QRectF(f.x(), f.y(), f.width(), rp.y() - f.y()), shade)
        p.fillRect(QRectF(f.x(), rp.bottom(), f.width(), f.bottom() - rp.bottom()), shade)
        p.fillRect(QRectF(f.x(), rp.y(), rp.x() - f.x(), rp.height()), shade)
        p.fillRect(QRectF(rp.right(), rp.y(), f.right() - rp.right(), rp.height()), shade)
        p.setPen(QPen(QColor(theme.ACCENT), 2))
        p.drawRect(rp)
        p.setBrush(QColor(theme.ACCENT))
        for c in (rp.topLeft(), rp.topRight(), rp.bottomLeft(), rp.bottomRight()):
            p.drawRect(QRectF(c.x() - 5, c.y() - 5, 10, 10))
        p.setPen(QColor("white"))
        p.drawText(rp.adjusted(6, 4, -4, -4), Qt.AlignLeft | Qt.AlignTop, "🎥 " + tr("wc_cam"))
        p.end()

    def _hit(self, pos: QPointF) -> Optional[str]:
        rp = self._to_px(self.r)
        hs = self.HANDLE
        near_l, near_r = abs(pos.x() - rp.left()) <= hs, abs(pos.x() - rp.right()) <= hs
        near_t, near_b = abs(pos.y() - rp.top()) <= hs, abs(pos.y() - rp.bottom()) <= hs
        inside_x = rp.left() - hs <= pos.x() <= rp.right() + hs
        inside_y = rp.top() - hs <= pos.y() <= rp.bottom() + hs
        if near_t and near_l:
            return "tl"
        if near_t and near_r:
            return "tr"
        if near_b and near_l:
            return "bl"
        if near_b and near_r:
            return "br"
        if near_l and inside_y:
            return "l"
        if near_r and inside_y:
            return "r"
        if near_t and inside_x:
            return "t"
        if near_b and inside_x:
            return "b"
        if rp.contains(pos):
            return "move"
        return None

    def mousePressEvent(self, e) -> None:  # noqa: N802
        pos = e.position()
        self.mode = self._hit(pos) or "new"
        self.start_pos = self._to_norm(pos)
        self.start_r = QRectF(self.r)
        if self.mode == "new":
            self.r = QRectF(self.start_pos.x(), self.start_pos.y(), 0.0, 0.0)

    def mouseMoveEvent(self, e) -> None:  # noqa: N802
        pos = e.position()
        if self.mode is None:
            cur = {"tl": Qt.SizeFDiagCursor, "br": Qt.SizeFDiagCursor, "tr": Qt.SizeBDiagCursor,
                   "bl": Qt.SizeBDiagCursor, "l": Qt.SizeHorCursor, "r": Qt.SizeHorCursor, "t": Qt.SizeVerCursor,
                   "b": Qt.SizeVerCursor, "move": Qt.SizeAllCursor}.get(self._hit(pos), Qt.CrossCursor)
            self.setCursor(cur)
            return
        n = self._to_norm(pos)
        nx, ny = max(0.0, min(1.0, n.x())), max(0.0, min(1.0, n.y()))
        r = QRectF(self.start_r)
        if self.mode == "move":
            dx, dy = n.x() - self.start_pos.x(), n.y() - self.start_pos.y()
            r.moveTo(max(0.0, min(1.0 - r.width(), self.start_r.x() + dx)),
                     max(0.0, min(1.0 - r.height(), self.start_r.y() + dy)))
        elif self.mode == "new":
            r = QRectF(QPointF(min(self.start_pos.x(), nx), min(self.start_pos.y(), ny)),
                       QPointF(max(self.start_pos.x(), nx), max(self.start_pos.y(), ny)))
        else:
            left, top, right, bottom = r.left(), r.top(), r.right(), r.bottom()
            if "l" in self.mode:
                left = min(nx, right - 0.05)
            if "r" in self.mode:
                right = max(nx, left + 0.05)
            if "t" in self.mode:
                top = min(ny, bottom - 0.05)
            if "b" in self.mode:
                bottom = max(ny, top + 0.05)
            r = QRectF(QPointF(left, top), QPointF(right, bottom))
        self.r = r
        self.update()
        self.changed.emit()

    def mouseReleaseEvent(self, _e) -> None:  # noqa: N802
        if self.mode == "new" and (self.r.width() < 0.05 or self.r.height() < 0.05):
            self.r = QRectF(self.start_r)
        self.mode = None
        self.update()
        self.changed.emit()

    def value(self) -> list:
        r = self.r.normalized()
        return [round(r.x(), 4), round(r.y(), 4), round(max(0.05, r.width()), 4), round(max(0.05, r.height()), 4)]


class LayoutPreview(QWidget):
    """The 9:16 result, computed like the export (webcam band on top, game below)."""

    def __init__(self, image: QImage, parent=None):
        super().__init__(parent)
        self.img = image
        self.rect_n = [0.7, 0.03, 0.28, 0.3]
        self.split = 35
        self.pos = 50
        self.setMinimumSize(200, 356)

    def set_params(self, rect_n, split, pos) -> None:
        self.rect_n, self.split, self.pos = rect_n, split, pos
        self.update()

    @staticmethod
    def _cover(src: QRectF, w: float, h: float) -> QRectF:
        """Part of src shown when it is scaled to cover w x h (centred), like ffmpeg increase+crop."""
        scale = max(w / max(1.0, src.width()), h / max(1.0, src.height()))
        vw, vh = w / scale, h / scale
        return QRectF(src.center().x() - vw / 2, src.center().y() - vh / 2, vw, vh)

    def paintEvent(self, _e) -> None:  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        p.fillRect(self.rect(), QColor(theme.PANEL))
        H = self.height() - 8
        W = H * 9 / 16
        if W > self.width() - 8:
            W = self.width() - 8
            H = W * 16 / 9
        ox, oy = (self.width() - W) / 2, (self.height() - H) / 2
        top = H * self.split / 100
        bot = H - top
        iw, ih = self.img.width(), self.img.height()
        x, y, w, h = self.rect_n
        cam = QRectF(x * iw, y * ih, w * iw, h * ih)
        p.drawImage(QRectF(ox, oy, W, top), self.img, self._cover(cam, W, top))
        gw = min(iw, ih * W / max(1.0, bot))
        game = QRectF((iw - gw) * self.pos / 100, 0, gw, ih)
        p.drawImage(QRectF(ox, oy + top, W, bot), self.img, self._cover(game, W, bot))
        p.setPen(QPen(QColor(theme.BORDER), 1))
        p.drawRect(QRectF(ox, oy, W, H))
        p.setPen(QPen(QColor(255, 255, 255, 90), 1, Qt.DashLine))
        p.drawLine(QPointF(ox, oy + top), QPointF(ox + W, oy + top))
        p.end()


class WebcamLayoutDialog(QDialog):
    def __init__(self, cfg, image: Optional[QImage], parent=None):
        super().__init__(parent)
        self.cfg = cfg
        self.setWindowTitle(tr("wc_title"))
        self.resize(1000, 560)
        img = image if image is not None and not image.isNull() else placeholder_frame()
        lay = QVBoxLayout(self)
        intro = QLabel(tr("wc_intro"))
        intro.setWordWrap(True)
        lay.addWidget(intro)
        row = QHBoxLayout()
        from ..export import webcam_layout
        rect, split, pos = webcam_layout(cfg)
        self.editor = RectEditor(img, rect)
        row.addWidget(self.editor, 3)
        right = QVBoxLayout()
        self.preview = LayoutPreview(img)
        right.addWidget(self.preview, 1)
        g = QGridLayout()
        g.addWidget(QLabel(tr("wc_split")), 0, 0)
        self.split = QSlider(Qt.Horizontal)
        self.split.setRange(15, 60)
        self.split.setValue(split)
        g.addWidget(self.split, 0, 1)
        self.split_lbl = QLabel(f"{split} %")
        g.addWidget(self.split_lbl, 0, 2)
        g.addWidget(QLabel(tr("wc_game_pos")), 1, 0)
        self.pos = QSlider(Qt.Horizontal)
        self.pos.setRange(0, 100)
        self.pos.setValue(pos)
        g.addWidget(self.pos, 1, 1)
        right.addLayout(g)
        row.addLayout(right, 2)
        lay.addLayout(row, 1)
        hint = QLabel(tr("wc_hint"))
        hint.setObjectName("Muted")
        hint.setWordWrap(True)
        hint.setStyleSheet("font-size: 8.5pt;")
        lay.addWidget(hint)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.button(QDialogButtonBox.Ok).setText(tr("btn_save"))
        bb.button(QDialogButtonBox.Ok).setObjectName("Primary")
        bb.button(QDialogButtonBox.Cancel).setText(tr("btn_cancel"))
        reset = bb.addButton(tr("btn_defaults"), QDialogButtonBox.ResetRole)
        reset.clicked.connect(self._defaults)
        bb.accepted.connect(self._save)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)
        self.editor.changed.connect(self._update)
        self.split.valueChanged.connect(self._update)
        self.pos.valueChanged.connect(self._update)
        self._update()

    def _update(self, *_a) -> None:
        self.split_lbl.setText(f"{self.split.value()} %")
        self.preview.set_params(self.editor.value(), self.split.value(), self.pos.value())

    def _defaults(self) -> None:
        from ..config import DEFAULTS
        x, y, w, h = DEFAULTS["webcam_rect"]
        self.editor.r = QRectF(x, y, w, h)
        self.editor.update()
        self.split.setValue(DEFAULTS["webcam_split"])
        self.pos.setValue(DEFAULTS["webcam_game_pos"])
        self._update()

    def _save(self) -> None:
        self.cfg.update({"webcam_rect": self.editor.value(), "webcam_split": self.split.value(),
                         "webcam_game_pos": self.pos.value(), "vertical_style": "webcam"})
        self.cfg.save()
        self.accept()


class SubtitleDialog(QDialog):
    """Correct the words of the subtitles of one clip (the timing of the words is kept)."""
    ORIGINAL = object()

    def __init__(self, original: str, current: Optional[str], parent=None):
        super().__init__(parent)
        self.original = original
        self.result_value = self.ORIGINAL
        self.setWindowTitle(tr("sub_title"))
        self.resize(640, 420)
        lay = QVBoxLayout(self)
        info = QLabel(tr("sub_intro"))
        info.setWordWrap(True)
        lay.addWidget(info)
        self.edit = QPlainTextEdit(current if current is not None else original)
        self.edit.setPlaceholderText(tr("sub_empty_ph"))
        lay.addWidget(self.edit, 1)
        row = QHBoxLayout()
        b1 = QPushButton(tr("sub_restore"))
        b1.clicked.connect(lambda: self.edit.setPlainText(self.original))
        b2 = QPushButton(tr("sub_none"))
        b2.setToolTip(tr("sub_none_tip"))
        b2.clicked.connect(self.edit.clear)
        row.addWidget(b1)
        row.addWidget(b2)
        row.addStretch(1)
        lay.addLayout(row)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.button(QDialogButtonBox.Ok).setText(tr("btn_save"))
        bb.button(QDialogButtonBox.Ok).setObjectName("Primary")
        bb.button(QDialogButtonBox.Cancel).setText(tr("btn_cancel"))
        bb.accepted.connect(self._save)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)

    def _save(self) -> None:
        text = " ".join(self.edit.toPlainText().split())
        self.result_value = self.ORIGINAL if text == " ".join(self.original.split()) else text
        self.accept()
