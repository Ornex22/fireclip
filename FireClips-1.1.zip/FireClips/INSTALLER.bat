@echo off
setlocal EnableExtensions
title FireClips - installation
cd /d "%~dp0"
set "SRC=%~dp0"
set "ROOT=%LOCALAPPDATA%\FireClips"

if not exist "%SRC%app\fireclips\__main__.py" goto :not_extracted

echo.
echo  ==============================================================
echo    FireClips - installation / mise a jour  (install / update)
echo  ==============================================================
echo.
echo   Dossier d'installation : %ROOT%
echo   La premiere installation telecharge environ 3 Go et prend
echo   10 a 30 minutes selon ta connexion. Les mises a jour sont rapides.
echo.

rem --- close FireClips if it is running from a previous install (so files can be replaced)
powershell -NoProfile -NonInteractive -Command "Get-Process python,pythonw -ErrorAction SilentlyContinue | Where-Object { $_.Path -like ($env:LOCALAPPDATA + '\FireClips\venv\*') } | Stop-Process -Force" >nul 2>nul

if not exist "%ROOT%\tools\uv" mkdir "%ROOT%\tools\uv"
set "UV=%ROOT%\tools\uv\uv.exe"
set "UVZIP=%TEMP%\fireclips-uv.zip"
set "UVURL=https://github.com/astral-sh/uv/releases/latest/download/uv-x86_64-pc-windows-msvc.zip"

if exist "%UV%" goto :have_uv
echo  [1/3] Telechargement de uv - installateur de Python
curl.exe -L --fail --retry 3 --ssl-no-revoke -o "%UVZIP%" "%UVURL%"
if errorlevel 1 powershell -NoProfile -Command "[Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest -UseBasicParsing -Uri '%UVURL%' -OutFile '%UVZIP%'"
if not exist "%UVZIP%" goto :fail_net
tar.exe -xf "%UVZIP%" -C "%ROOT%\tools\uv"
if errorlevel 1 powershell -NoProfile -Command "Expand-Archive -Force -Path '%UVZIP%' -DestinationPath '%ROOT%\tools\uv'"
del "%UVZIP%" >nul 2>nul
if not exist "%UV%" for /r "%ROOT%\tools\uv" %%F in (uv.exe) do if exist "%%F" copy /y "%%F" "%ROOT%\tools\uv\uv.exe" >nul
if not exist "%UV%" goto :fail
:have_uv

set "UV_PYTHON_INSTALL_DIR=%ROOT%\python"
set "UV_CACHE_DIR=%ROOT%\cache\uv"
set "UV_NO_CONFIG=1"

if exist "%ROOT%\venv\Scripts\python.exe" goto :have_venv
echo.
echo  [2/3] Installation de Python 3.12
"%UV%" venv --python 3.12 --managed-python "%ROOT%\venv"
if errorlevel 1 goto :fail
:have_venv

echo.
echo  [3/3] Installation des composants Python - patience, c'est le plus long
"%UV%" pip install --python "%ROOT%\venv\Scripts\python.exe" -r "%SRC%install\requirements.txt"
if errorlevel 1 goto :fail

"%ROOT%\venv\Scripts\python.exe" "%SRC%install\install.py" --src "%SRC%." --root "%ROOT%" --uv "%UV%"
if errorlevel 1 goto :fail

echo.
pause
exit /b 0

:not_extracted
echo.
echo  [!] Il faut d'abord EXTRAIRE le fichier ZIP :
echo      clic droit sur le ZIP, puis "Extraire tout...",
echo      puis double-clic sur INSTALLER.bat dans le dossier extrait.
echo.
echo  [!] Unzip first: right-click the ZIP, "Extract All...", then run INSTALLER.bat from the extracted folder.
echo.
pause
exit /b 1

:fail_net
echo.
echo  [!] Telechargement impossible. Verifie ta connexion Internet puis relance INSTALLER.bat.
echo      Download failed. Check your Internet connection and run INSTALLER.bat again.
echo.
pause
exit /b 1

:fail
echo.
echo  [!] L'installation n'est pas allee au bout - le detail est au-dessus.
echo      Relance INSTALLER.bat : elle reprend ou elle s'est arretee.
echo      Si ca recommence, fais une capture de cette fenetre.
echo  [!] Installation did not finish - details above. Run INSTALLER.bat again.
echo.
pause
exit /b 1
