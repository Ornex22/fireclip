"""FireClips installer, step 2 (started by INSTALLER.bat once Python is ready).

Copies the program, installs the NVIDIA libraries when there is an NVIDIA card, downloads
ffmpeg, TwitchDownloaderCLI, yt-dlp and the transcription model, then creates the shortcuts.
Running it again updates everything (settings and analysed VODs are kept).
"""
from __future__ import annotations

import argparse
import ctypes
import json
import locale
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path

import requests

UA = {"User-Agent": "FireClips-Installer/1.3 (+https://github.com)"}
FFMPEG_URLS = [
    "https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip",
    "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip",
]
YTDLP_URL = "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe"
VCREDIST_URL = "https://aka.ms/vs/17/release/vc_redist.x64.exe"
TD_API = "https://api.github.com/repos/lay295/TwitchDownloader/releases/latest"
TD_ASSET = re.compile(r"^TwitchDownloaderCLI-.*-Windows-x64\.zip$", re.I)


def _is_french() -> bool:
    try:
        lang_id = ctypes.windll.kernel32.GetUserDefaultUILanguage()
        return (lang_id & 0x3FF) == 0x0C  # LANG_FRENCH
    except Exception:  # noqa: BLE001
        return (locale.getlocale()[0] or "").lower().startswith("fr")


FR = _is_french()
M = {
    "title": ("Installation de FireClips", "Installing FireClips"),
    "copy": ("Copie du programme", "Copying the program"),
    "gpu": ("Recherche d'une carte graphique NVIDIA", "Looking for an NVIDIA graphics card"),
    "gpu_yes": ("Carte trouvée : {name} ({vram} Mo de mémoire)", "Card found: {name} ({vram} MB of memory)"),
    "gpu_no": ("Pas de carte NVIDIA trouvée : la transcription utilisera le processeur (plus lent, mais ça marche).",
               "No NVIDIA card found: transcription will use the processor (slower, but it works)."),
    "cuda": ("Bibliothèques NVIDIA pour la transcription rapide (~1,1 Go à télécharger, une seule fois)",
             "NVIDIA libraries for fast transcription (~1.1 GB download, only once)"),
    "ffmpeg": ("ffmpeg (découpe et encodage des clips)", "ffmpeg (cutting and encoding clips)"),
    "td": ("TwitchDownloaderCLI (téléchargement des VODs et du chat)", "TwitchDownloaderCLI (downloads VODs and chat)"),
    "ytdlp": ("yt-dlp (solution de secours pour les téléchargements)", "yt-dlp (backup downloader)"),
    "model": ("Modèle de transcription", "Transcription model"),
    "check": ("Vérification", "Checking"),
    "shortcuts": ("Raccourcis (Bureau + menu Démarrer)", "Shortcuts (Desktop + Start menu)"),
    "already": ("déjà présent, mis à jour si besoin", "already there, updated if needed"),
    "ok": ("OK", "OK"),
    "space": ("Attention : il reste seulement {free} Go sur le disque C:. Il faut environ 6 Go.",
              "Warning: only {free} GB left on drive C:. About 6 GB are needed."),
    "dl_fail": ("Téléchargement impossible : {url}\n   Vérifie ta connexion (ou ton antivirus) puis relance INSTALLER.bat.",
                "Download failed: {url}\n   Check your connection (or antivirus) and run INSTALLER.bat again."),
    "td_fail": ("TwitchDownloaderCLI n'a pas pu être téléchargé. FireClips marchera avec yt-dlp, mais sans le chat. Relance INSTALLER.bat plus tard pour réessayer.",
                "TwitchDownloaderCLI could not be downloaded. FireClips will work with yt-dlp, but without the chat. Run INSTALLER.bat again later to retry."),
    "done": ("Installation terminée ! Lance FireClips avec l'icône sur ton Bureau.",
             "Installation finished! Start FireClips with the icon on your Desktop."),
    "launch": ("Lancer FireClips maintenant ? (O/N) ", "Start FireClips now? (Y/N) "),
    "model_fail": ("Le modèle n'a pas pu être téléchargé maintenant : il le sera à la première analyse.",
                   "The model could not be downloaded now: it will be at the first analysis."),
    "vcredist": ("Composant Microsoft Visual C++ manquant : installation (Windows va demander l'autorisation)…",
                 "Missing Microsoft Visual C++ component: installing (Windows will ask for permission)…"),
    "check_warn": ("Un point n'est pas parfait (voir ci-dessus), mais FireClips peut quand même fonctionner.",
                   "One item is not perfect (see above), but FireClips can still work."),
}


def t(key: str, **kw) -> str:
    s = M[key][0 if FR else 1]
    return s.format(**kw) if kw else s


def step(n: int, total: int, key: str) -> None:
    print(f"\n[{n}/{total}] {t(key)}", flush=True)


def download(url: str, dest: Path, label: str = "", tries: int = 3) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_name(dest.name + ".part")
    last = None
    for attempt in range(tries):
        try:
            with requests.get(url, headers=UA, stream=True, timeout=(20, 120), allow_redirects=True) as r:
                r.raise_for_status()
                total = int(r.headers.get("Content-Length") or 0)
                done = 0
                t0 = time.time()
                last_print = 0.0
                with open(tmp, "wb") as f:
                    for chunk in r.iter_content(1 << 20):
                        f.write(chunk)
                        done += len(chunk)
                        now = time.time()
                        if now - last_print > 0.5:
                            last_print = now
                            speed = done / max(0.1, now - t0) / 1e6
                            if total:
                                pct = 100 * done / total
                                bar = "#" * int(pct / 4)
                                print(f"\r   [{bar:<25}] {pct:5.1f} %  {done / 1e6:7.1f}/{total / 1e6:.0f} Mo  {speed:4.1f} Mo/s ",
                                      end="", flush=True)
                            else:
                                print(f"\r   {done / 1e6:7.1f} Mo  {speed:4.1f} Mo/s ", end="", flush=True)
                print("\r   " + " " * 70 + "\r", end="", flush=True)
            tmp.replace(dest)
            return
        except Exception as e:  # noqa: BLE001
            last = e
            print(f"\n   ! {e} — {attempt + 1}/{tries}", flush=True)
            status = getattr(getattr(e, "response", None), "status_code", 0) or 0
            if 400 <= status < 500 and status != 429:
                break  # wrong address: retrying will not help
            time.sleep(3 * (attempt + 1))
    raise RuntimeError(t("dl_fail", url=url)) from last


def copy_program(src: Path, root: Path) -> None:
    if src.resolve() == root.resolve():
        return  # started from the installed copy: nothing to copy
    app_src = src / "app" / "fireclips"
    app_dst = root / "app" / "fireclips"
    if app_dst.exists():
        shutil.rmtree(app_dst, ignore_errors=True)
    shutil.copytree(app_src, app_dst, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    if (src / "GUIDE.html").exists():
        shutil.copy2(src / "GUIDE.html", root / "app" / "GUIDE.html")
    if (src / "DESINSTALLER.bat").exists():
        shutil.copy2(src / "DESINSTALLER.bat", root / "DESINSTALLER.bat")


def nvidia_gpu() -> tuple[str, int] | None:
    for smi in ("nvidia-smi", str(Path(os.environ.get("SystemRoot", r"C:\Windows")) / "System32" / "nvidia-smi.exe")):
        try:
            r = subprocess.run([smi, "--query-gpu=name,memory.total", "--format=csv,noheader,nounits"],
                               capture_output=True, text=True, timeout=20)
            if r.returncode == 0 and r.stdout.strip():
                name, mem = [x.strip() for x in r.stdout.strip().splitlines()[0].split(",")[:2]]
                return name, int(float(mem))
        except (OSError, subprocess.SubprocessError, ValueError):
            continue
    return None


def install_ffmpeg(tools: Path) -> None:
    dst = tools / "ffmpeg"
    if (dst / "ffmpeg.exe").exists() and (dst / "ffprobe.exe").exists():
        print("   " + t("already"))
        return
    tmpdir = Path(tempfile.mkdtemp(prefix="fireclips-ffmpeg-"))
    try:
        last = None
        for url in FFMPEG_URLS:
            try:
                z = tmpdir / "ffmpeg.zip"
                download(url, z)
                with zipfile.ZipFile(z) as zf:
                    names = zf.namelist()
                    for exe in ("ffmpeg.exe", "ffprobe.exe"):
                        member = next(n for n in names if n.lower().endswith("/bin/" + exe))
                        dst.mkdir(parents=True, exist_ok=True)
                        with zf.open(member) as srcf, open(dst / exe, "wb") as out:
                            shutil.copyfileobj(srcf, out)
                print("   " + t("ok"))
                return
            except Exception as e:  # noqa: BLE001
                last = e
                print(f"   ! {e}")
        raise RuntimeError(str(last))
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


def install_tdcli(tools: Path) -> bool:
    tmpdir = Path(tempfile.mkdtemp(prefix="fireclips-td-"))
    try:
        r = requests.get(TD_API, headers=dict(UA, Accept="application/vnd.github+json"), timeout=30)
        r.raise_for_status()
        rel = r.json()
        asset = next(a for a in rel.get("assets", []) if TD_ASSET.match(a.get("name", "")))
        print(f"   {rel.get('tag_name', '')}")
        z = tmpdir / asset["name"]
        download(asset["browser_download_url"], z)
        with zipfile.ZipFile(z) as zf:
            member = next(n for n in zf.namelist() if n.lower().endswith("twitchdownloadercli.exe"))
            with zf.open(member) as srcf, open(tools / "TwitchDownloaderCLI.exe.new", "wb") as out:
                shutil.copyfileobj(srcf, out)
        (tools / "TwitchDownloaderCLI.exe.new").replace(tools / "TwitchDownloaderCLI.exe")
        print("   " + t("ok"))
        return True
    except Exception as e:  # noqa: BLE001
        print(f"   ! {e}")
        if (tools / "TwitchDownloaderCLI.exe").exists():
            print("   " + t("already"))
            return True
        print("   " + t("td_fail"))
        return False
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


def run_worker(root: Path, py: Path, args: list[str]) -> int:
    env = dict(os.environ)
    env["PYTHONPATH"] = str(root / "app")
    env["PYTHONIOENCODING"] = "utf-8"
    return subprocess.call([str(py), "-m", "fireclips.worker"] + args + ["--plain"], cwd=str(root / "app"), env=env)


def ps_quote(s) -> str:
    return "'" + str(s).replace("'", "''") + "'"


def ensure_vcredist() -> None:
    """The transcription engine needs the Microsoft Visual C++ runtime (present on most gaming PCs)."""
    sysdir = Path(os.environ.get("SystemRoot", r"C:\Windows")) / "System32"
    if (sysdir / "msvcp140.dll").exists() and (sysdir / "vcruntime140_1.dll").exists():
        return
    print("   " + t("vcredist"))
    exe = Path(tempfile.gettempdir()) / "fireclips_vc_redist.x64.exe"
    try:
        download(VCREDIST_URL, exe)
        subprocess.call([str(exe), "/install", "/quiet", "/norestart"])
    except Exception as e:  # noqa: BLE001
        print(f"   ! {e}")


def make_shortcuts(root: Path) -> None:
    pyw = root / "venv" / "Scripts" / "pythonw.exe"
    icon = root / "app" / "fireclips" / "assets" / "icon.ico"
    wd = root / "app"
    script = ""
    for folder in ("Desktop", "Programs"):
        script += (f"$p=Join-Path ([Environment]::GetFolderPath('{folder}')) 'FireClips.lnk';"
                   f"$s=(New-Object -COM WScript.Shell).CreateShortcut($p);"
                   f"$s.TargetPath={ps_quote(pyw)};$s.Arguments='-m fireclips';"
                   f"$s.WorkingDirectory={ps_quote(wd)};$s.IconLocation={ps_quote(icon)};"
                   f"$s.Description='FireClips';$s.Save();")
    subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", script],
                   timeout=60)
    # plain launchers too (in case a shortcut is blocked)
    (root / "FireClips.bat").write_text(
        '@echo off\r\ncd /d "%~dp0app"\r\nstart "" "%~dp0venv\\Scripts\\pythonw.exe" -m fireclips\r\n', encoding="ascii")
    (root / "FireClips-debug.bat").write_text(
        '@echo off\r\ncd /d "%~dp0app"\r\n"%~dp0venv\\Scripts\\python.exe" -m fireclips\r\npause\r\n', encoding="ascii")
    print("   " + t("ok"))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", required=True)
    ap.add_argument("--root", required=True)
    ap.add_argument("--uv", required=True)
    a = ap.parse_args()
    src, root, uv = Path(a.src).resolve(), Path(a.root), Path(a.uv)
    py = root / "venv" / "Scripts" / "python.exe"
    tools = root / "tools"
    tools.mkdir(parents=True, exist_ok=True)
    total = 8

    free = shutil.disk_usage(root).free / 1e9
    if free < 6:
        print("\n   ⚠ " + t("space", free=f"{free:.1f}"))

    step(1, total, "copy")
    copy_program(src, root)
    print("   " + t("ok"))

    ensure_vcredist()

    step(2, total, "gpu")
    gpu = nvidia_gpu()
    if gpu:
        print("   " + t("gpu_yes", name=gpu[0], vram=gpu[1]))
        step(3, total, "cuda")
        code = subprocess.call([str(uv), "pip", "install", "--python", str(py), "-r",
                                str(src / "install" / "requirements-gpu.txt")])
        if code != 0:
            raise RuntimeError("uv pip install (NVIDIA)")
    else:
        print("   " + t("gpu_no"))
        step(3, total, "cuda")
        print("   -")

    step(4, total, "ffmpeg")
    install_ffmpeg(tools)

    step(5, total, "td")
    install_tdcli(tools)
    print("   " + t("ytdlp"))
    download(YTDLP_URL, tools / "yt-dlp.exe")
    print("   " + t("ok"))

    step(6, total, "model")
    if run_worker(root, py, ["download-model", "--model", "auto"]) != 0:
        print("   " + t("model_fail"))

    step(7, total, "check")
    if run_worker(root, py, ["selfcheck"]) != 0:
        print("   " + t("check_warn"))

    step(8, total, "shortcuts")
    make_shortcuts(root)
    (root / "installed.json").write_text(json.dumps({"installed_at": time.strftime("%Y-%m-%d %H:%M"),
                                                     "src": str(src)}), encoding="utf-8")

    print("\n" + "=" * 64 + "\n  " + t("done") + "\n" + "=" * 64 + "\n")
    try:
        ans = input(t("launch")).strip().lower()
    except EOFError:
        ans = ""
    if ans in ("o", "oui", "y", "yes", ""):
        pyw = root / "venv" / "Scripts" / "pythonw.exe"
        flags = 0x00000008 | 0x00000200  # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
        subprocess.Popen([str(pyw), "-m", "fireclips"], cwd=str(root / "app"), creationflags=flags,
                         close_fds=True)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as e:  # noqa: BLE001
        print(f"\n   X {e}\n", flush=True)
        sys.exit(1)
