"""What the Studio live preview shows and plays at any time of a clip, without rendering it first.

Everything comes from the same code as the export (montage.make_plan and the schedules, the Pillow
pictures of fxlib / montage, subtitles.layout), so the preview shows what the exported clip will show:
- Composition: the timeline of the clip and what is on screen at a time (no Qt here);
- VideoReader: frames of the stream video (or of a meme video) at a time (PyAV);
- mix_audio: the sound of the whole clip (stream sound with cuts / slow motion / bleeps, sounds,
  meme videos, music that gets quieter when the streamer talks), like the ffmpeg graph of the export."""
from __future__ import annotations

import logging
import math
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

from . import bank, export, fxlib, montage, profiles, subpaint, subtitles

log = logging.getLogger("fireclips.preview")

RATE = 48000
FPS = 30


class ByteLRU:
    """A cache that forgets the oldest things past a size in bytes (thread safe)."""

    def __init__(self, budget: int):
        from collections import OrderedDict
        self.budget = budget
        self.d: "OrderedDict" = OrderedDict()
        self.size = 0
        self.lock = threading.Lock()

    def get(self, key):
        with self.lock:
            v = self.d.get(key)
            if v is None:
                return None
            self.d.move_to_end(key)
            return v[0]

    def put(self, key, value, nbytes: int) -> None:
        with self.lock:
            old = self.d.pop(key, None)
            if old is not None:
                self.size -= old[1]
            self.d[key] = (value, nbytes)
            self.size += nbytes
            while self.size > self.budget and len(self.d) > 1:
                _k, (_v, nb) = self.d.popitem(last=False)
                self.size -= nb

    def clear(self) -> None:
        with self.lock:
            self.d.clear()
            self.size = 0


PICTURES = ByteLRU(160 << 20)      # element pictures (memes, texts, kill cards...)
EFFECT_FRAMES = ByteLRU(200 << 20)  # pictures of the animated effects
SOUNDS = ByteLRU(96 << 20)         # decoded sound effects / music


def _pic_bytes(frames) -> int:
    return sum(f[0].width * f[0].height * 4 for f in frames) + 1024


_PIC_KEYS = ("kind", "file", "text", "style", "color", "size", "card", "anim")


def _content_key(e: dict, keys) -> tuple:
    out = []
    for k in keys:
        v = e.get(k)
        if isinstance(v, dict):
            v = tuple(sorted((a, str(b)) for a, b in v.items()))
        elif isinstance(v, list):
            v = tuple(str(x) for x in v)
        out.append((k, v))
    return tuple(out)


# =========================================================================== the composition


@dataclass
class Overlay:
    """A picture on screen at a time: drawn centred on (cx, cy), scaled, turned (degrees, counter-
    clockwise), with an opacity, inside the clip box (x, y, w, h) when clip is set (slide-in)."""
    eid: str
    kind: str
    image: object              # PIL RGBA picture (cached by the caller through key)
    key: tuple
    cx: float
    cy: float
    scale: float
    angle: float
    alpha: float
    clip: Optional[tuple] = None
    box: Optional[tuple] = None        # where the element rests (x, y, w, h): for picking it on screen
    vt: float = 0.0                    # meme video: time inside the video file (image is None)
    element: Optional[dict] = None


class Composition:
    """A clip with its montage, ready to be shown at any time (sizes: the half-size preview picture)."""

    def __init__(self, moment: dict, m: dict, words: list, cfg, fmt: str, src_info: dict, prof: Optional[dict] = None,
                 lang: str = "fr"):
        self.moment = moment
        self.cfg = cfg
        self.fmt = fmt
        self.lang = lang
        self.info = dict(src_info)
        self.prof = prof or {}
        self.m = montage.normalize(m)
        self.W, self.H = export.out_size(fmt, self.info, preview=True)
        self.vertical = self.H > self.W
        self.game = export.game_rect(fmt, self.info, cfg, self.W, self.H)
        self.ctx = montage.Ctx(self.W, self.H, 30, fmt, self.vertical, self.game, Path("."), cfg, lang)
        self.words = list(words)
        self.pl = montage.make_plan(moment, self.m, self.words)
        self.total = self.pl.total
        self.visuals = montage.visual_schedule(self.pl, cfg)
        self.sounds = montage.sound_schedule(self.pl, cfg)
        self.zwin = montage.zoom_windows(self.pl)
        self.fwin = montage.filter_windows(self.pl)
        self.bleeps = montage.bleep_windows(self.pl)
        self.style = (cfg.get("vertical_style") or "blur") if fmt == "vertical" else "landscape"
        self._sources: dict[str, tuple] = {}
        self._boxes: dict[str, tuple] = {}
        self._subs = None
        self._wm = None

    # ---------------------------------------------------------------- timeline
    def vod_time(self, o: float) -> Optional[float]:
        """VOD time shown at clip time o."""
        return montage.unmap_time(self.pl.pieces, min(max(0.0, o), max(0.0, self.total - 1e-3)))

    def piece_at(self, o: float):
        for p in self.pl.pieces:
            if p.out_a - 1e-6 <= o < p.out_b:
                return p
        return self.pl.pieces[-1] if self.pl.pieces else None

    def clip_time(self, t: float) -> Optional[float]:
        """Clip time of VOD time t (its main occurrence)."""
        return montage.map_first(self.pl.pieces, t)

    # ---------------------------------------------------------------- what changes the video picture
    def zoom(self, o: float) -> tuple:
        return montage.zoom_at(self.zwin, o)

    def filters(self, o: float) -> list[str]:
        return [eid for eid in fxlib.EFFECT_ORDER for a, b in self.fwin.get(eid, []) if a <= o < b]

    def bleeping(self, o: float) -> bool:
        return any(a <= o < b for a, b in self.bleeps)

    # ---------------------------------------------------------------- pictures on top
    def _source(self, e: dict, slow_ok: bool = True):
        """The pictures of an element. slow_ok=False (the screen): a kill card (it may download the item
        pictures) is only made by the frame reader thread; until then it is not drawn."""
        k = e["id"]
        if k not in self._sources:
            key = (_content_key(e, _PIC_KEYS), self.W, self.H, self.lang)
            got = PICTURES.get(key)
            if got is None and not slow_ok and e["kind"] == "killcard":
                return [], None
            if got is None:
                try:
                    got = montage.picture_source(e, self.W, self.H, self.cfg, self.lang)
                except Exception as ex:  # noqa: BLE001 - a broken picture must not break the preview
                    log.warning("picture %s: %s", e.get("file") or e.get("kind"), ex)
                    got = ([], None)
                if got[0]:                     # (a meme not downloaded yet is looked for again next time)
                    PICTURES.put(key, got, _pic_bytes(got[0]))
            self._sources[k] = got
        return self._sources[k]

    def element_box(self, e: dict) -> Optional[tuple]:
        """(canvas w, canvas h, x, y) of an element picture at rest (the export's PNG sequence box)."""
        if e["id"] in self._boxes:
            return self._boxes[e["id"]]
        frames, _at = self._source(e)
        if not frames:
            return None
        kind = e["kind"]
        anim = e.get("anim") or montage.DEFAULT_ANIM.get(kind, "pop")
        w0 = max(f[0].width for f in frames)
        h0 = max(f[0].height for f in frames)
        cw, ch = montage.sprite_canvas(w0, h0, anim, float(e.get("rot") or 0.0), kind == "emoji" and anim == "pop")
        X, Y = montage._killcard_pos(e, cw, ch, self.ctx) if kind == "killcard" else montage.place(e, cw, ch, self.ctx)
        self._boxes[e["id"]] = (cw, ch, X, Y)
        return self._boxes[e["id"]]

    def overlays(self, o: float, slow_ok: bool = True) -> list[Overlay]:
        """The memes / texts / stickers / kill cards / effect pictures / meme videos on screen at clip time
        o, in drawing order. A meme video comes with image None and vt (time inside the video): its picture
        is read by the caller (see video_box())."""
        out: list[Overlay] = []
        for e, o0, d in self.visuals:
            if not (o0 - 1e-6 <= o < o0 + d):
                continue
            kind = e["kind"]
            tt = o - o0
            if kind == "video":
                out.append(Overlay(e["id"], kind, None, ("video", e["id"]), 0.0, 0.0, 1.0, 0.0, 1.0, vt=tt,
                                   element=e))
                continue
            if kind == "fx":
                sc = montage.effect_scale(e["effect"], preview=False)
                n = int(tt * montage.OV_FPS)
                im = self.effect_picture(e, n, d, sc)
                if im is not None:
                    out.append(Overlay(e["id"], kind, im, ("fx", e["id"], n, round(d, 3), sc), self.W / 2, self.H / 2,
                                       1.0 / sc, 0.0, 1.0, element=e))
                continue
            frames, picture_at = self._source(e, slow_ok)
            if not frames:
                continue
            box = self.element_box(e)
            if box is None:
                continue
            cw, ch, X, Y = box
            anim = e.get("anim") or montage.DEFAULT_ANIM.get(kind, "pop")
            wobble = kind == "emoji" and anim == "pop"
            if picture_at is not None:
                src, sk = picture_at(tt)
            elif len(frames) > 1:
                total_anim = sum(fd for _f, fd in frames)
                pos = tt % total_anim if total_anim > 0 else 0
                k, acc = 0, 0.0
                for k, (_fr, fd) in enumerate(frames):
                    acc += fd
                    if pos < acc:
                        break
                src, sk = frames[k][0], k
            else:
                src, sk = frames[0][0], 0
            s, ang, alpha, dx, dy = fxlib.anim_state(anim, tt, d, wobble, 0.25 if kind == "killcard" else 0.18)
            ang += float(e.get("rot") or 0.0)
            px_dx = dx * (cw if anim == "slide" else src.width)
            px_dy = dy * src.height
            clip = (X, Y, cw, ch) if anim == "slide" else None
            out.append(Overlay(e["id"], kind, src, ("el", e["id"], sk, id(src)), X + cw / 2 + px_dx, Y + ch / 2 + px_dy,
                               s, ang, alpha, clip, (X, Y, cw, ch), element=e))
        return out

    def effect_picture(self, e: dict, n: int, d: float, sc: float):
        """Picture n (30 per second) of an animated effect lasting d seconds (cached)."""
        key = (_content_key(e, ("effect", "id", "x", "y", "size", "file", "text", "color")), n, round(d, 3), sc,
               self.W, self.H, tuple(self.game), self.lang)
        got = EFFECT_FRAMES.get(key)
        if got is None:
            im = fxlib.effect_frame(e, n / montage.OV_FPS, d, self.W, self.H, self.game, self.lang, sc)
            got = (im,)
            EFFECT_FRAMES.put(key, got, (im.width * im.height * 4 if im is not None else 0) + 256)
        return got[0]

    def videos(self, o: float) -> list[tuple[dict, float, float]]:
        """Meme videos on screen at clip time o: (element, time inside the video file, length)."""
        return [(e, o - o0, d) for e, o0, d in self.visuals if e["kind"] == "video" and o0 - 1e-6 <= o < o0 + d]

    def video_box(self, e: dict, vw: int, vh: int) -> tuple[int, int, int, int]:
        """(x, y, w, h) of a meme video of vw x vh in the picture (like the export)."""
        if e.get("full"):
            s = min(self.W / max(1, vw), self.H / max(1, vh))
            w, h = export._even(vw * s), export._even(vh * s)
            return (self.W - w) // 2, (self.H - h) // 2, w, h
        box = int(min(self.W, self.H) * e.get("size", montage.DEFAULT_SIZE["video"]))
        s = box / max(1, max(vw, vh))
        w, h = export._even(vw * s), export._even(vh * s)
        X, Y = montage.place(e, w, h, self.ctx)
        return X, Y, w, h

    # ---------------------------------------------------------------- subtitles, title, watermark
    def subtitles(self) -> subpaint.SubtitlePainter:
        if self._subs is None:
            m, cfg = self.m, self.cfg
            with_subs = cfg.get("subtitles") if m.get("subs") is None else m.get("subs")
            title = self.moment.get("title") or ""
            with_title = bool(cfg.get("title_overlay")) and bool(subtitles.clean_title(title)) \
                and (self.fmt == "vertical" or bool(cfg.get("title_overlay_landscape")))
            look, events = None, []
            if with_subs or with_title:
                mw = montage.map_words(self.pl.pieces, self.words) if with_subs else []
                masked = {j for j, (_s, _e, _t, i) in enumerate(mw) if i in self.pl.swear}
                st = subtitles.resolve_style(m.get("sub_style") or self.prof.get("sub_style") or
                                             cfg.get("subtitle_style"), cfg)
                look, events = subtitles.layout([(s0, e2, t) for s0, e2, t, _i in mw], 0.0, self.total, self.W, self.H,
                                                title=title if with_title else "",
                                                title_y=export.title_position(self.fmt, self.info, cfg, self.W, self.H),
                                                style=st, masked=masked)
            self._subs = subpaint.SubtitlePainter(look, events)
        return self._subs

    def watermark(self):
        """(picture, x, y) or None."""
        if self._wm is None:
            self._wm = (None,)
            prof = self.prof
            text = profiles.watermark_text(prof) if prof else ""
            logo = None
            if prof.get("wm_on", True) and prof.get("wm_logo"):
                logo = bank.resolve(prof.get("wm_logo") or "", self.cfg)
            if text or logo is not None:
                try:
                    pic = montage.watermark_picture(text, logo, self.H, self.vertical, int(prof.get("wm_size") or 100),
                                                    int(prof.get("wm_opacity") or 85))
                except Exception:  # noqa: BLE001
                    pic = None
                if pic is not None:
                    X, Y = montage.watermark_position(prof.get("wm_pos") or "auto", pic.width, pic.height, self.W,
                                                      self.H, self.vertical)
                    self._wm = (pic, X, Y)
        return self._wm if self._wm[0] is not None else None

    # ---------------------------------------------------------------- where the stream picture goes
    def layout_rects(self, sw: int, sh: int) -> dict:
        """How the stream picture (sw x sh) is laid out, like export.layout_chain:
        {"game": (src rect, dst rect), "cam": (src rect, dst rect) | None, "bg": src rect | None}.
        Rects are (x, y, w, h); src in stream pixels, dst in picture pixels."""
        W, H = self.W, self.H
        out = {"cam": None, "bg": None}
        if self.fmt != "vertical":
            s = min(W / sw, H / sh)
            w, h = sw * s, sh * s
            out["game"] = ((0, 0, sw, sh), ((W - w) / 2, (H - h) / 2, w, h))
            return out
        style = self.style
        if style == "crop":
            pos = max(0, min(100, int(self.cfg.get("crop_position") or 50))) / 100.0
            cw = min(sw, sh * 9 / 16)
            out["game"] = (((sw - cw) * pos, 0, cw, sh), (0, 0, W, H))
            return out
        if style == "webcam":
            (x, y, w, h), split, pos = export.webcam_layout(self.cfg)
            top = export._even(H * split / 100)
            bot = H - top
            cx, cy, cw, ch = x * sw, y * sh, w * sw, h * sh
            out["cam"] = (_cover((cx, cy, cw, ch), W, top), (0, 0, W, top))
            gw = min(sw, sh * W / bot)
            gx = (sw - gw) * pos / 100
            out["game"] = (_cover((gx, 0, gw, sh), W, bot), (0, top, W, bot))
            return out
        _gx, gy, gw, gh = self.game
        out["game"] = ((0, 0, sw, sh), (0, gy, W, gh))
        out["bg"] = _cover((0, 0, sw, sh), W, H)
        return out


def _cover(src: tuple, dw: float, dh: float) -> tuple:
    """The centre part of src with the shape of dw x dh (scale to cover, then crop)."""
    x, y, w, h = src
    if w / max(1e-6, h) > dw / max(1e-6, dh):
        nw = h * dw / dh
        return x + (w - nw) / 2, y, nw, h
    nh = w * dh / dw
    return x, y + (h - nh) / 2, w, nh


def zoomed(src: tuple, z: float, cx: float, cy: float, dx: float, dy: float) -> tuple:
    """The part of the game picture shown with a punch-in zoom / shake (the zoompan of the export)."""
    x, y, w, h = src
    if z <= 1.0001 and abs(dx) < 1e-6 and abs(dy) < 1e-6:
        return src
    zw, zh = w / z, h / z
    zx = max(0.0, min(w - zw, cx * w - zw / 2 + dx * w))
    zy = max(0.0, min(h - zh, cy * h - zh / 2 + dy * h))
    return x + zx, y + zy, zw, zh


# =========================================================================== video frames (PyAV)


def _av():
    import av   # installed with FireClips (faster-whisper needs it)
    return av


class VideoReader:
    """Frames of a video file at given times: reads on when the time goes forward a little, jumps
    (seek) otherwise. frame_at() returns (time of the frame, BGRA numpy array) or None."""

    def __init__(self, path: str, max_w: int = 1280, max_h: int = 720):
        av = _av()
        self.path = path
        self.c = av.open(str(path))
        self.st = self.c.streams.video[0]
        self.st.thread_type = "AUTO"
        cc = self.st.codec_context
        self.src_w, self.src_h = int(cc.width or 16), int(cc.height or 9)
        s = min(1.0, max_w / self.src_w, max_h / self.src_h)
        self.w, self.h = max(2, int(self.src_w * s) // 2 * 2), max(2, int(self.src_h * s) // 2 * 2)
        rate = self.st.average_rate or self.st.guessed_rate or 30
        self.fps = float(rate) if rate else 30.0
        self.duration = float(self.c.duration or 0) / 1e6 if self.c.duration else float(
            (self.st.duration or 0) * (self.st.time_base or 0))
        self._gen = None
        self._cur = None
        self._cur_t = -1e9
        self._cur_img = None
        self._pend = None
        self._pend_t = 0.0
        self._eof = False
        self.lock = threading.Lock()

    def close(self) -> None:
        try:
            self.c.close()
        except Exception:  # noqa: BLE001
            pass

    def _seek(self, t: float) -> None:
        self.c.seek(max(0, int(max(0.0, t - 0.05) * 1_000_000)), backward=True)
        self._gen = self.c.decode(self.st)
        self._cur, self._cur_t, self._cur_img, self._pend, self._eof = None, -1e9, None, None, False

    def frame_at(self, t: float, convert: bool = True):
        eps = 0.5 / self.fps
        if self._cur is not None and self._cur_t - eps <= t and (self._pend is None or t < self._pend_t - eps):
            return self._out(convert)
        if self._gen is None or self._cur is None and self._pend is None or t < self._cur_t - eps or t > self._cur_t + 2.5:
            self._seek(t)
        while not self._eof:
            if self._pend is None:
                try:
                    self._pend = next(self._gen)
                except StopIteration:
                    self._eof = True
                    break
                except Exception as e:  # noqa: BLE001 - a damaged packet: go on
                    log.debug("decode: %s", e)
                    continue
                self._pend_t = float(self._pend.time if self._pend.time is not None else self._cur_t + 1 / self.fps)
            if self._pend_t <= t + eps or self._cur is None:
                self._cur, self._cur_t, self._cur_img, self._pend = self._pend, self._pend_t, None, None
                if self._cur_t > t + eps:
                    break
                continue
            break
        if self._cur is None:
            return None
        return self._out(convert)

    def _out(self, convert: bool):
        if not convert:
            return self._cur_t, None
        if self._cur_img is None:
            self._cur_img = self._cur.to_ndarray(format="bgra", width=self.w, height=self.h)
        return self._cur_t, self._cur_img


# =========================================================================== sound (numpy)


def _np():
    import numpy as np
    return np


def decode_audio(path: str, start: float = 0.0, dur: float = 0.0):
    """The sound of a file as a float32 (n, 2) array at 48 kHz, from start (seconds) for dur (0 = to the end)."""
    np = _np()
    av = _av()
    try:
        c = av.open(str(path))
    except Exception as e:  # noqa: BLE001
        log.info("sound %s: %s", path, e)
        return np.zeros((0, 2), np.float32)
    try:
        st = next((s for s in c.streams if s.type == "audio"), None)
        if st is None:
            return np.zeros((0, 2), np.float32)
        if start > 0.5:
            c.seek(int(max(0.0, start - 0.3) * 1_000_000), backward=True)
        res = av.AudioResampler(format="fltp", layout="stereo", rate=RATE)
        chunks = []
        first_t = None
        need = int(dur * RATE) if dur > 0 else 0
        got = 0
        for frame in c.decode(st):
            if first_t is None:
                first_t = float(frame.time) if frame.time is not None else 0.0
            for rf in res.resample(frame):
                a = rf.to_ndarray()
                chunks.append(a)
                got += a.shape[1]
            if need and got > need + int((start - (first_t or 0)) * RATE) + RATE:
                break
        for rf in res.resample(None):
            chunks.append(rf.to_ndarray())
        if not chunks:
            return np.zeros((0, 2), np.float32)
        x = np.concatenate(chunks, axis=1).T.astype(np.float32)
        skip = int(round((start - (first_t or 0.0)) * RATE)) if start > 0 else 0
        if skip > 0:
            x = x[skip:]
        elif skip < 0:
            x = np.concatenate([np.zeros((-skip, 2), np.float32), x])
        if need:
            x = x[:need]
        return np.ascontiguousarray(x)
    except Exception as e:  # noqa: BLE001
        log.info("sound %s: %s", path, e)
        return np.zeros((0, 2), np.float32)
    finally:
        c.close()


def sound_of(path, start: float = 0.0, dur: float = 0.0):
    """decode_audio, remembered (sounds, music, meme videos)."""
    p = Path(path)
    try:
        mt = p.stat().st_mtime
    except OSError:
        mt = 0.0
    key = (str(p), mt, round(start, 3), round(dur, 3))
    x = SOUNDS.get(key)
    if x is None:
        x = decode_audio(str(p), start, dur)
        SOUNDS.put(key, x, int(x.nbytes) + 256)
    return x


def _fade(x, fin: float, fout: float):
    np = _np()
    n = len(x)
    if n == 0:
        return x
    x = x.copy()
    a = min(n, int(fin * RATE))
    if a > 0:
        x[:a] *= np.linspace(0.0, 1.0, a, dtype=np.float32)[:, None]
    b = min(n, int(fout * RATE))
    if b > 0:
        x[n - b:] *= np.linspace(1.0, 0.0, b, dtype=np.float32)[:, None]
    return x


def _speed(x, speed: float):
    """asetrate + aresample: slower and lower (slow motion)."""
    np = _np()
    if abs(speed - 1.0) < 1e-3 or len(x) < 2:
        return x
    m = int(len(x) / speed)
    idx = np.arange(m, dtype=np.float64) * speed
    i0 = np.minimum(idx.astype(np.int64), len(x) - 1)
    i1 = np.minimum(i0 + 1, len(x) - 1)
    f = (idx - i0)[:, None].astype(np.float32)
    return x[i0] * (1 - f) + x[i1] * f


def _add(out, x, at: float, gain: float = 1.0) -> None:
    i = int(round(at * RATE))
    if i >= len(out) or len(x) == 0:
        return
    if i < 0:
        x = x[-i:]
        i = 0
    n = min(len(x), len(out) - i)
    if n > 0:
        out[i:i + n] += x[:n] * gain


def _windows_mask(n: int, windows: list, value: float):
    np = _np()
    g = np.ones(n, np.float32)
    for a, b in windows:
        i0, i1 = max(0, int(a * RATE)), min(n, int(b * RATE))
        if i1 > i0:
            g[i0:i1] = np.minimum(g[i0:i1], value)
    return g


def loudness(x) -> Optional[float]:
    """Loudness of a sound (LUFS, BS.1770 gating without the K filter): enough to level the preview."""
    np = _np()
    if len(x) < RATE // 2:
        return None
    blk, hop = int(0.4 * RATE), int(0.1 * RATE)
    sq = (x.astype(np.float64) ** 2).sum(axis=1)
    cs = np.concatenate([[0.0], np.cumsum(sq)])
    starts = np.arange(0, len(x) - blk + 1, hop)
    ms = (cs[starts + blk] - cs[starts]) / blk
    lk = -0.691 + 10 * np.log10(np.maximum(ms, 1e-12))
    ms = ms[lk > -70]
    if not len(ms):
        return None
    rel = -0.691 + 10 * np.log10(ms.mean()) - 10
    ms2 = ms[-0.691 + 10 * np.log10(ms) > rel]
    if not len(ms2):
        return None
    return float(-0.691 + 10 * np.log10(ms2.mean()))


def _envelope(x, attack: float, release: float, block: int = 240):
    """RMS level of a sound followed with an attack / release (per block of 5 ms)."""
    np = _np()
    n = len(x) // block
    if n == 0:
        return np.zeros(0, np.float32)
    m = x[: n * block].mean(axis=1) if x.ndim == 2 else x[: n * block]
    r = np.sqrt((m.reshape(n, block) ** 2).mean(axis=1))
    dt = block / RATE
    aa, ar = 1 - math.exp(-dt / attack), 1 - math.exp(-dt / release)
    env = np.empty(n, np.float32)
    e = 0.0
    for k in range(n):
        v = float(r[k])
        e += (v - e) * (aa if v > e else ar)
        env[k] = e
    return env


def _expand(g, n: int, block: int = 240):
    np = _np()
    if len(g) == 0:
        return np.ones(n, np.float32)
    x = np.repeat(g, block)
    if len(x) < n:
        x = np.concatenate([x, np.full(n - len(x), g[-1], np.float32)])
    return x[:n]


def _limit(x, limit: float = 0.89):
    """alimiter: no peak over the limit (looks ahead a little, lets go in 60 ms)."""
    np = _np()
    block = 240
    n = len(x) // block
    if n == 0:
        return np.clip(x, -limit, limit)
    pk = np.abs(x[: n * block]).max(axis=1).reshape(n, block).max(axis=1)
    want = np.minimum(1.0, limit / np.maximum(pk, 1e-9)).astype(np.float32)
    want = np.minimum(want, np.concatenate([want[1:], want[-1:]]))
    rel = 1 - math.exp(-(block / RATE) / 0.06)
    g = np.empty(n, np.float32)
    cur = 1.0
    for k in range(n):
        w = float(want[k])
        cur = w if w < cur else cur + (w - cur) * rel
        g[k] = cur
    y = x * _expand(g, len(x), block)[:, None]
    return np.clip(y, -limit, limit)


def stream_sound_range(moment: dict, seg: dict, margin: float = 14.0) -> tuple[float, float]:
    """(file time, length) of the stream sound to decode for a clip: the clip with some room around it
    (the start / end can be moved a little without decoding it again)."""
    a, b = float(moment["start"]), float(moment["end"])
    s0 = float(seg.get("vod_start") or 0.0)
    lo = max(0.0, a - margin - s0)
    hi = b + margin - s0
    if not seg.get("full") and seg.get("duration"):
        hi = min(hi, float(seg["duration"]))
    return lo, max(0.5, hi - lo)


def mix_audio(comp: Composition, src, src0: float, seg_start: float,
              cancel: Optional[Callable[[], bool]] = None):
    """The sound of the clip (float32 (n, 2), 48 kHz), made the way the export makes it.
    src: the stream sound (decode_audio) starting at file time src0; seg_start: VOD time of file time 0."""
    np = _np()
    pl, cfg, total = comp.pl, comp.cfg, comp.total
    n = int(total * RATE) + 1
    am = np.zeros((n, 2), np.float32)
    pieces = pl.pieces
    main = [p for p in pieces if not p.hook]
    if src is not None and len(src) and main:
        cut_fades = len(main) > 1
        for p in pieces:
            if cancel and cancel():
                return None
            if p.kind != "play":
                continue
            i0 = int(round((p.a - seg_start - src0) * RATE))
            i1 = int(round((p.b - seg_start - src0) * RATE))
            x = src[max(0, i0):max(0, i1)]
            if i0 < 0:
                x = np.concatenate([np.zeros((min(-i0, i1 - i0), 2), np.float32), x])
            if p.hook:
                x = _fade(x, 0.04, 0.12)
            elif cut_fades:
                x = _fade(x, 0.012, 0.012)
            x = _speed(x, p.speed)
            _add(am, x, p.out_a)
        if cfg.get("loudnorm", True):
            lu = loudness(am)
            if lu is not None:
                am *= 10 ** (max(-12.0, min(18.0, -14.0 - lu)) / 20)
    if cancel and cancel():
        return None
    duck = list(montage.duck_windows_for(pl, comp.sounds))
    extra = np.zeros((n, 2), np.float32)
    for e, o0, d in comp.visuals:
        if e["kind"] != "video" or e.get("vol", 100) <= 0:
            continue
        p = bank.resolve(e.get("file") or "", cfg)
        if p is None:
            continue
        x = sound_of(p, 0.0, d)
        if len(x):
            _add(extra, x, o0, e.get("vol", 100) / 100)
            if e.get("duck", True):
                duck.append((o0, o0 + d))
    am *= _windows_mask(n, comp.bleeps, 0.0)[:, None]
    if duck:
        am *= _windows_mask(n, duck, 0.35)[:, None]
    for e, path, o, d in comp.sounds:
        if cancel and cancel():
            return None
        x = sound_of(path, 0.0, d)
        _add(extra, x, o, e.get("vol", 100) / 100)
    if cfg.get("bleep_mode", "bip") == "bip":
        for o0, o1 in comp.bleeps:
            ln = max(0.05, o1 - o0)
            t = np.arange(int(ln * RATE), dtype=np.float32) / RATE
            tone = (0.125 * 1.2 * np.sin(2 * np.pi * 1000 * t)).astype(np.float32)
            _add(extra, np.stack([tone, tone], axis=1), o0)
    mus = bank.resolve(comp.m.get("music") or "", cfg) if comp.m.get("music") else None
    if mus is not None and comp.m.get("music_vol", 18) > 0:
        x = sound_of(mus)
        if len(x):
            reps = int(math.ceil(n / len(x)))
            x = np.tile(x, (reps, 1))[:n] * (comp.m.get("music_vol", 18) / 100.0)
            x = _fade(x, 0.8, 1.5)
            # sidechaincompress=threshold=0.02:ratio=8:attack=20:release=450 (keyed by the stream sound)
            env = _envelope(am, 0.020, 0.450)
            thr, ratio = 0.02, 8.0
            g = np.where(env > thr, (thr * (np.maximum(env, 1e-9) / thr) ** (1 / ratio)) / np.maximum(env, 1e-9),
                         1.0).astype(np.float32)
            x = x * _expand(g, len(x))[:, None]
            extra[: len(x)] += x
    out = am + extra
    out = _limit(out, 0.89)
    out = _fade(out, 0.05, 0.25)
    return out.astype(np.float32)


# =========================================================================== small helpers for the UI


def chroma_key(bgra):
    """colorkey=0x00D000:0.32:0.12 of the export, on a BGRA numpy picture (in place)."""
    np = _np()
    b = bgra[..., 0].astype(np.float32)
    g = bgra[..., 1].astype(np.float32)
    r = bgra[..., 2].astype(np.float32)
    diff = np.sqrt(r ** 2 + (g - 0xD0) ** 2 + b ** 2) / (255.0 * math.sqrt(3))
    a = np.clip((diff - 0.32) / 0.12, 0.0, 1.0)
    bgra[..., 3] = (a * 255).astype(np.uint8)
    # premultiplied for Qt
    for c in range(3):
        bgra[..., c] = (bgra[..., c].astype(np.float32) * a).astype(np.uint8)
    return bgra


_LUTS: dict = {}
_NOISE: dict = {}


def _lut(name: str):
    """256-entry tables (uint8) for the colour effects."""
    np = _np()
    if name not in _LUTS:
        x = np.arange(256, dtype=np.float32)
        if name == "bw":
            v = (x - 128) * 1.25 + 128
        elif name in ("sepia_r", "sepia_g", "sepia_b"):
            k = {"sepia_r": 1.351, "sepia_g": 1.203, "sepia_b": 0.937}[name]
            v = (np.minimum(255.0, x * k) - 128) * 1.08 + 128
        else:
            v = x
        _LUTS[name] = np.clip(v, 0, 255).astype(np.uint8)
    return _LUTS[name]


def _luma(bgra):
    np = _np()
    b = bgra[..., 0].astype(np.uint16)
    g = bgra[..., 1].astype(np.uint16)
    r = bgra[..., 2].astype(np.uint16)
    return ((r * 77 + g * 150 + b * 29) >> 8).astype(np.uint8)


def _noise(h: int, w: int, amp: int, n: int):
    """A few pictures of grain, used in turn (making new grain for every picture is slow)."""
    np = _np()
    key = (h, w, amp)
    if key not in _NOISE:
        rnd = np.random.default_rng(1234 + amp)
        _NOISE[key] = [rnd.integers(-amp, amp + 1, size=(h, w), dtype=np.int16) for _ in range(6)]
        if len(_NOISE) > 6:
            _NOISE.pop(next(iter(_NOISE)))
    tiles = _NOISE[key]
    return tiles[n % len(tiles)]


def filter_picture(bgra, effects: list[str], o: float, W: int) -> None:
    """The colour effects of the export (glitch, VHS, sepia "to be continued", black and white) on a
    BGRA numpy picture, in place (close to the ffmpeg filters, made fast enough to play)."""
    np = _np()
    if not effects:
        return
    h, w = bgra.shape[:2]
    k = max(2, int(W / 135))
    for eid in effects:
        if eid == "dramatic":
            y = _lut("bw")[_luma(bgra)]
            bgra[..., 0] = y
            bgra[..., 1] = y
            bgra[..., 2] = y
        elif eid == "tbc":
            y = _luma(bgra)
            bgra[..., 2] = _lut("sepia_r")[y]
            bgra[..., 1] = _lut("sepia_g")[y]
            bgra[..., 0] = _lut("sepia_b")[y]
        elif eid in ("glitch", "vhs"):
            kk = k if eid == "glitch" else max(1, k // 3)
            bgra[..., 2] = np.roll(bgra[..., 2], -kk, axis=1)
            bgra[..., 0] = np.roll(bgra[..., 0], kk, axis=1)
            if eid == "glitch":
                bgra[..., 1] = np.roll(bgra[..., 1], kk // 2, axis=0)
            rgb = bgra[..., :3].astype(np.int16)
            if eid == "vhs":
                y = _luma(bgra).astype(np.int16)[..., None]
                rgb = y + ((rgb - y) * 3 >> 2)                 # saturation 0.75
                rgb = ((rgb - 128) * 17 >> 4) + 128            # contrast 1.06
            rgb += _noise(h, w, 22 if eid == "glitch" else 8, int(o * 30))[..., None]
            bgra[..., :3] = np.clip(rgb, 0, 255).astype(np.uint8)


def thumb_times(total: float, n: int) -> list[float]:
    return [total * (i + 0.5) / n for i in range(max(1, n))]
