"""What comes with each exported clip: a ready-to-post text (title, description, hashtags - written by
the AI when one is set up) and a cover picture (a frame of the clip with the title written big)."""
from __future__ import annotations

import logging
import re
import subprocess
from pathlib import Path
from typing import Optional

from . import paths, profiles, tools
from .util import no_window_flags, strip_accents

log = logging.getLogger("fireclips.publish")

POST_SCHEMA = {
    "type": "object",
    "properties": {
        "title": {"type": "string"},
        "description": {"type": "string"},
        "hashtags": {"type": "array", "items": {"type": "string"}},
    },
    "required": ["title", "description", "hashtags"],
    "additionalProperties": False,
}

GAME_TAGS = {"albion online": ["albiononline", "albion", "mmorpg", "pvp"], "just chatting": ["justchatting"],
             "league of legends": ["leagueoflegends", "lol"], "valorant": ["valorant"], "fortnite": ["fortnite"],
             "minecraft": ["minecraft"], "counter-strike": ["cs2"]}
CATEGORY_TAGS = {"joke": ["drole", "humour"], "fail": ["fail"], "rage": ["rage"], "absurd": ["wtf"],
                 "reaction": ["reaction"], "banter": ["drole"], "story": ["storytime"]}
CATEGORY_TAGS_EN = {"joke": ["funny"], "fail": ["fail"], "rage": ["rage"], "absurd": ["wtf"], "reaction": ["reaction"],
                    "banter": ["funny"], "story": ["storytime"]}


def _tag(s: str) -> str:
    s = strip_accents(str(s or "")).lower()
    return re.sub(r"[^a-z0-9]", "", s)


def template_post(meta: dict, moment: dict, prof: dict, lang: str = "fr") -> dict:
    """Title / description / hashtags without AI."""
    title = re.sub(r"\s+", " ", (moment.get("title") or "").strip().strip("«»\"' ")) or meta.get("title") or "Clip"
    excerpt = (moment.get("transcript") or "").strip()
    first = re.split(r"(?<=[.!?…])\s", excerpt)[0][:160] if excerpt else ""
    who = profiles.display_name(prof, meta)
    login = prof.get("login") or meta.get("login") or ""
    lines = []
    if first and first.lower() != title.lower():
        lines.append(f"« {first} »" if lang == "fr" else f"“{first}”")
    if login:
        lines.append(("🔴 En live sur twitch.tv/" if lang == "fr" else "🔴 Live on twitch.tv/") + login)
    tags = []
    game = (meta.get("game") or "").lower()
    for g, t in GAME_TAGS.items():
        if g in game:
            tags += t
    tags += (CATEGORY_TAGS if lang == "fr" else CATEGORY_TAGS_EN).get(moment.get("category") or "", [])
    if str(moment.get("id", "")).startswith("k"):
        tags += ["kill", "pvp"]
    if who:
        tags.append(_tag(who))
    tags += ["twitch", "clip", "gaming"] + (["fr", "twitchfr"] if lang == "fr" else [])
    seen = []
    for t in tags:
        t = _tag(t)
        if t and t not in seen:
            seen.append(t)
    return {"title": title[:100], "description": "\n".join(lines), "hashtags": seen[:12]}


def ai_post(cfg, meta: dict, moment: dict, prof: dict, lang: str = "fr") -> Optional[dict]:
    """The same, written by the AI (better hook, better hashtags). None when there is no AI / it fails."""
    from . import llm
    try:
        prov = llm.make_provider(cfg)
    except Exception as e:  # noqa: BLE001 - no key, bad settings...: the template text is used
        log.info("no AI for the post text: %s", e)
        return None
    if prov is None:
        return None
    who = profiles.display_name(prof, meta) or "the streamer"
    game = meta.get("game") or ""
    language = "French" if lang == "fr" else "English"
    system = ("You write social media posts (TikTok, YouTube Shorts, Instagram Reels) for clips of a Twitch "
              f"streamer. Answer in JSON only. Write in {language}, casual and fun, like a young streamer would, "
              "no clickbait lies.")
    user = (f"Streamer: {who} (twitch.tv/{prof.get('login') or meta.get('login') or ''})\n"
            f"Game: {game or 'unknown'}\n"
            f"Clip title chosen so far: {moment.get('title') or ''}\n"
            f"What is said in the clip (transcript): {(moment.get('transcript') or '')[:1500]}\n\n"
            "Give: title (max 70 characters, a hook that makes people stop scrolling, may contain 1 emoji), "
            "description (1-2 short lines, end with where to watch the streams live), hashtags (6 to 10, without #, "
            "mix popular and precise ones, include the game).")
    try:
        out = prov.complete_json(system, user, POST_SCHEMA, max_tokens=600)
    except Exception as e:  # noqa: BLE001
        log.info("AI post text failed: %s", e)
        return None
    if not isinstance(out, dict) or not out.get("title"):
        return None
    tags = [_tag(t) for t in out.get("hashtags") or [] if _tag(t)]
    return {"title": str(out["title"]).strip()[:100], "description": str(out.get("description") or "").strip()[:600],
            "hashtags": tags[:12]}


def post_text(cfg, meta: dict, moment: dict, lang: str = "fr") -> dict:
    prof = profiles.for_vod(cfg, meta)
    res = ai_post(cfg, meta, moment, prof, lang) if cfg.get("post_ai", True) else None
    res = res or template_post(meta, moment, prof, lang)
    # Kevin MacLeod's music (CC BY 4.0) must be credited where the clip is posted
    try:
        from . import memebank, montage
        credit = memebank.music_credit(montage.effective(moment, cfg).get("music") or "", lang)
    except Exception:  # noqa: BLE001
        credit = ""
    if credit:
        desc = (res.get("description") or "").rstrip()
        res = dict(res, description=f"{desc}\n{credit}" if desc else credit)
    return res


def write_post_file(clip: Path, post: dict, lang: str = "fr") -> Path:
    tags = " ".join("#" + t for t in post.get("hashtags") or [])
    if lang == "fr":
        text = (f"TITRE\n{post['title']}\n\nDESCRIPTION\n{post.get('description', '')}\n\nHASHTAGS\n{tags}\n\n"
                f"TOUT EN UN (à coller sous la vidéo)\n{post['title']}\n{post.get('description', '')}\n{tags}\n")
    else:
        text = (f"TITLE\n{post['title']}\n\nDESCRIPTION\n{post.get('description', '')}\n\nHASHTAGS\n{tags}\n\n"
                f"ALL IN ONE (paste under the video)\n{post['title']}\n{post.get('description', '')}\n{tags}\n")
    out = clip.with_suffix(".txt")
    out.write_text(text, encoding="utf-8-sig")       # Notepad-friendly
    return out


# --------------------------------------------------------------------------- cover picture


def make_cover(clip: Path, t: float, title: str, vertical: bool) -> Optional[Path]:
    """A frame of the clip at time t with the title written big (cover for TikTok / Shorts / YouTube)."""
    ff = tools.find("ffmpeg")
    if not ff:
        return None
    frame = clip.with_name(clip.stem + "_frame.png")
    try:
        r = subprocess.run([str(ff), "-v", "error", "-y", "-ss", f"{max(0.0, t):.2f}", "-i", str(clip), "-frames:v", "1",
                            str(frame)], capture_output=True, timeout=60, stdin=subprocess.DEVNULL,
                           creationflags=no_window_flags())
        if r.returncode != 0 or not frame.exists():
            return None
        from PIL import Image, ImageDraw, ImageEnhance, ImageFont
        img = Image.open(frame).convert("RGB")
        if not vertical:
            img = img.resize((1280, int(1280 * img.height / max(1, img.width))))
        img = ImageEnhance.Contrast(ImageEnhance.Color(img).enhance(1.25)).enhance(1.08)
        W, H = img.size
        text = re.sub("[\U0001F000-\U0001FAFF☀-➿️‍]", "", title or "").strip().upper()
        if text:
            fs = int(min(W, H) * (0.11 if vertical else 0.10))
            font_path = str(paths.ASSETS / "fonts" / "Anton-Regular.ttf")
            draw = ImageDraw.Draw(img, "RGBA")
            max_w = int(W * 0.9)
            while True:
                font = ImageFont.truetype(font_path, fs)
                lines, cur = [], ""
                for w in text.split():
                    test = (cur + " " + w).strip()
                    if cur and font.getlength(test) > max_w:
                        lines.append(cur)
                        cur = w
                    else:
                        cur = test
                if cur:
                    lines.append(cur)
                if len(lines) <= 3 or fs < 30:
                    break
                fs = int(fs * 0.88)
            lh = int(fs * 1.08)
            block = lh * len(lines)
            y0 = int(H * (0.14 if vertical else 0.08))
            # dark band behind the text so it reads on any picture
            draw.rectangle((0, y0 - int(fs * 0.3), W, y0 + block + int(fs * 0.25)), fill=(0, 0, 0, 110))
            stroke = max(3, fs // 12)
            for i, line in enumerate(lines):
                lw = font.getlength(line)
                color = (255, 225, 77) if i == len(lines) - 1 and len(lines) > 1 else (255, 255, 255)
                draw.text(((W - lw) / 2, y0 + i * lh), line, font=font, fill=color, stroke_width=stroke,
                          stroke_fill=(0, 0, 0))
        out = clip.with_name(clip.stem + "_cover.jpg")
        img.save(out, "JPEG", quality=90)
        return out
    except Exception as e:  # noqa: BLE001
        log.info("cover: %s", e)
        return None
    finally:
        try:
            frame.unlink()
        except OSError:
            pass
