"""Clip files: names, picture layouts (16:9, or 9:16 with a blurred background / a crop / the
webcam on top), subtitle words. The rendering itself (with the montage) is in montage.py."""
from __future__ import annotations

import logging
import threading
from datetime import datetime
from pathlib import Path
from typing import Callable, Optional

from . import subtitles
from .store import VodRef
from .transcribe import find_transcript
from .util import fmt_tag, read_json, sanitize_filename

log = logging.getLogger("fireclips.export")


def vod_date(meta: dict) -> str:
    s = meta.get("created_at") or ""
    try:
        dt = datetime.fromisoformat(s.replace("Z", "+00:00")).astimezone()
        return dt.strftime("%Y-%m-%d")
    except ValueError:
        return s[:10] or datetime.now().strftime("%Y-%m-%d")


def vod_folder_name(meta: dict) -> str:
    title = sanitize_filename(meta.get("title") or meta.get("key") or "VOD", 50)
    return f"{vod_date(meta)} {title}".strip()


def clip_filename(meta: dict, moment: dict, fmt: str) -> str:
    title = sanitize_filename(moment.get("title") or "moment", 70).strip("« »\"'")
    title = sanitize_filename(title, 70)
    tag = "9x16" if fmt == "vertical" else "16x9"
    return f"{vod_date(meta)}_{fmt_tag(moment['start'])}_{title}_{tag}.mp4"


def webcam_layout(cfg) -> tuple[list[float], int, int]:
    """Webcam rectangle in the source picture (x, y, w, h as fractions), height of the webcam
    band in the 9:16 clip, horizontal position (0..100) of the game part."""
    try:
        x, y, w, h = (float(v) for v in (cfg.get("webcam_rect") or [0.70, 0.03, 0.28, 0.30])[:4])
    except (TypeError, ValueError):
        x, y, w, h = 0.70, 0.03, 0.28, 0.30
    w = max(0.05, min(1.0, w))
    h = max(0.05, min(1.0, h))
    x = max(0.0, min(1.0 - w, x))
    y = max(0.0, min(1.0 - h, y))
    split = max(15, min(60, int(cfg.get("webcam_split") or 35)))
    pos = max(0, min(100, int(cfg.get("webcam_game_pos") if cfg.get("webcam_game_pos") is not None else 50)))
    return [x, y, w, h], split, pos


def _even(v: float) -> int:
    return max(2, int(round(v / 2)) * 2)


def out_size(fmt: str, info: dict, preview: bool = False) -> tuple[int, int]:
    """Size of the exported clip (half of it for the quick preview of the Studio)."""
    if fmt == "vertical":
        W, H = 1080, 1920
    else:
        src_h = int(info.get("height") or 1080)
        H = 1080 if src_h >= 1000 else (720 if src_h >= 700 else max(360, src_h - src_h % 2))
        W = _even(H * 16 / 9)
    if preview:
        W, H = _even(W / 2), _even(H / 2)
    return W, H


def game_rect(fmt: str, info: dict, cfg, W: int, H: int) -> tuple[int, int, int, int]:
    """Where the game picture is in the clip (x, y, w, h) - the webcam band / blurred bands excluded."""
    if fmt != "vertical":
        return 0, 0, W, H
    style = cfg.get("vertical_style") or "blur"
    if style == "crop":
        return 0, 0, W, H
    if style == "webcam":
        _r, split, _p = webcam_layout(cfg)
        top = _even(H * split / 100)
        return 0, top, W, H - top
    sw, sh = float(info.get("width") or 16), float(info.get("height") or 9)
    gh = min(H, _even(W * sh / max(1.0, sw)))
    return 0, (H - gh) // 2, W, gh


def layout_chain(fmt: str, info: dict, cfg, W: int, H: int, src: str = "[0:v]", dst: str = "[v0]",
                 fx: Optional[Callable[[int, int], str]] = None) -> str:
    """ffmpeg filters turning the stream picture into the clip picture (16:9, or 9:16 with a blurred
    background / a crop / the webcam on top). fx(w, h) returns filters applied to the game picture
    only (zoom, shake...) once it has its final size w x h."""
    def with_fx(w: int, h: int) -> str:
        f = fx(w, h) if fx else ""
        return ("," + f) if f else ""

    if fmt == "vertical":
        style = cfg.get("vertical_style") or "blur"
        if style == "crop":
            pos = max(0, min(100, int(cfg.get("crop_position") or 50))) / 100.0
            return (f"{src}crop=w='min(iw,ih*9/16)':h=ih:x='(iw-min(iw,ih*9/16))*{pos:.3f}':y=0,"
                    f"scale={W}:{H}:flags=lanczos,setsar=1{with_fx(W, H)}{dst}")
        if style == "webcam":
            (x, y, w, h), split, pos = webcam_layout(cfg)
            top = _even(H * split / 100)
            bot = H - top
            gw = f"min(iw,ih*{W}/{bot})"
            return (f"{src}split=2[cam][game];"
                    f"[cam]crop=w=iw*{w:.4f}:h=ih*{h:.4f}:x=iw*{x:.4f}:y=ih*{y:.4f},"
                    f"scale={W}:{top}:force_original_aspect_ratio=increase:flags=lanczos,crop={W}:{top}[c];"
                    f"[game]crop=w='{gw}':h=ih:x='(iw-{gw})*{pos / 100:.3f}':y=0,"
                    f"scale={W}:{bot}:force_original_aspect_ratio=increase:flags=lanczos,crop={W}:{bot},"
                    f"setsar=1{with_fx(W, bot)}[g];"
                    f"[c][g]vstack=inputs=2,setsar=1{dst}")
        _gx, _gy, gw_, gh = game_rect(fmt, info, cfg, W, H)
        bw, bh = _even(W / 4), _even(H / 4)
        return (f"{src}split=2[bg][fg];"
                f"[bg]scale={bw}:{bh}:force_original_aspect_ratio=increase,crop={bw}:{bh},gblur=sigma=12,"
                f"scale={W}:{H},eq=brightness=-0.07:saturation=1.1[bgb];"
                f"[fg]scale={W}:{gh}:flags=lanczos,setsar=1{with_fx(W, gh)}[fgs];"
                f"[bgb][fgs]overlay=(W-w)/2:(H-h)/2,setsar=1{dst}")
    return (f"{src}scale={W}:{H}:force_original_aspect_ratio=decrease:flags=lanczos,"
            f"pad={W}:{H}:(ow-iw)/2:(oh-ih)/2,setsar=1{with_fx(W, H)}{dst}")


def build_filter(fmt: str, info: dict, cfg, with_subs: bool) -> tuple[str, int, int]:
    W, H = out_size(fmt, info)
    chain = layout_chain(fmt, info, cfg, W, H)
    if with_subs:
        chain += ";[v0]subtitles=subs.ass:fontsdir=fonts[v]"
    else:
        chain += ";[v0]null[v]"
    return chain, W, H


def title_position(fmt: str, info: dict, cfg, W: int, H: int) -> int:
    """Where the burned-in title goes (centre height in the clip)."""
    if fmt != "vertical":
        return int(H * 0.09)
    style = cfg.get("vertical_style") or "blur"
    if style == "webcam":
        _r, split, _p = webcam_layout(cfg)
        return int(H * split / 100) + int(H * 0.055)
    if style == "crop":
        return int(H * 0.12)
    sw, sh = float(info.get("width") or 16), float(info.get("height") or 9)
    band = (H - W * sh / max(1.0, sw)) / 2
    return int(band / 2) if band > 160 else int(H * 0.12)


def load_transcript(ref: VodRef) -> Optional[dict]:
    tp = find_transcript(ref.dir)
    return read_json(tp, None) if tp else None


def clip_words(ref: VodRef, moment: dict, a: float, b: float, transcript: Optional[dict] = None) -> list:
    """The words shown as subtitles: the transcript, or the text you corrected for this clip."""
    if transcript is None:
        transcript = load_transcript(ref)
    custom = (moment.get("subs_text") or "").strip() if moment.get("subs_text") is not None else None
    if custom is None:
        return subtitles.words_from_transcript(transcript, a, b)
    ra, rb = (float(x) for x in (moment.get("subs_range") or [a, b]))
    base = subtitles.words_from_transcript(transcript, ra, rb)
    base = [w for w in base if w[1] > ra and w[0] < rb]
    timed = subtitles.retime(base, custom, ra, rb) if custom else []
    # the clip may have been made longer after the text was corrected: keep the transcript there
    outside = [w for w in subtitles.words_from_transcript(transcript, a, b) if w[1] <= ra + 0.05 or w[0] >= rb - 0.05]
    words = sorted(outside + timed, key=lambda w: w[0])
    return [w for w in words if w[1] > a and w[0] < b]


def export_moment(ref: VodRef, cfg, moment: dict, fmt: str, out_dir: Path,
                  progress: Callable[[float, str], None], cancel: Optional[threading.Event] = None,
                  report: Optional[dict] = None) -> Path:
    """Cut one moment into a finished clip (with its montage: memes, effects, watermark...)."""
    from . import montage
    return montage.render(ref, cfg, moment, fmt, out_dir, progress, cancel, report=report)
