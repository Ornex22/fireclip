"""The diagnostic report: everything useful to help when something goes wrong (versions, graphics card,
tools, settings with the secret keys hidden, the last lines of the logs), to copy-paste in a chat."""
from __future__ import annotations

import platform
import re
import sys
import time
from importlib import metadata
from pathlib import Path

from . import __version__, paths, tools
from .util import human_size, free_space, run

SECRET_KEYS = re.compile(r"(_key|_token|oauth|password|secret)$", re.I)
SECRET_TEXT = [re.compile(r"sk-[A-Za-z0-9_\-]{8,}"), re.compile(r"(?i)(bearer|oauth|bot)\s+[A-Za-z0-9._\-]{12,}"),
               re.compile(r"(?i)((?:api[_-]?key|token|authorization)[\"'=:\s]+)[A-Za-z0-9._\-]{12,}"),
               re.compile(r"[A-Za-z0-9_\-]{24}\.[A-Za-z0-9_\-]{6}\.[A-Za-z0-9_\-]{27,}")]   # Discord bot tokens


def mask(text: str) -> str:
    for rx in SECRET_TEXT:
        text = rx.sub(lambda m: (m.group(1) if m.lastindex else "") + "***", text)
    return text


def _version(pkg: str) -> str:
    try:
        return metadata.version(pkg)
    except metadata.PackageNotFoundError:
        return "-"


def _tool_version(tool: str, args: list[str]) -> str:
    p = tools.find(tool)
    if not p:
        return "MISSING"
    try:
        r = run([str(p)] + args, timeout=20)
        out = (r.stdout or r.stderr or "").strip().splitlines()
        return f"{out[0][:120] if out else '?'}  ({p})"
    except Exception as e:  # noqa: BLE001
        return f"error {type(e).__name__}  ({p})"


def _tail(path: Path, n: int) -> list[str]:
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return []
    return lines[-n:]


def report(cfg, log_lines: int = 50) -> str:
    out = [f"=== FireClips {__version__} — diagnostic report — {time.strftime('%Y-%m-%d %H:%M:%S')} ==="]
    out.append(f"Windows/OS: {platform.platform()}  |  Python {sys.version.split()[0]}  |  {platform.machine()}")
    pkgs = ["PySide6-Essentials", "faster-whisper", "ctranslate2", "onnxruntime", "numpy", "av", "pillow", "requests"]
    out.append("Packages: " + ", ".join(f"{p} {_version(p)}" for p in pkgs))
    out.append("ffmpeg: " + _tool_version("ffmpeg", ["-hide_banner", "-version"]))
    out.append("TwitchDownloaderCLI: " + _tool_version("tdcli", ["--version"]))
    out.append("yt-dlp: " + _tool_version("ytdlp", ["--version"]))
    gpus = tools.gpus()
    if gpus:
        for g in gpus:
            out.append(f"GPU: {g.name}, {g.vram_mb} MB, driver {g.driver}, compute {g.compute_cap}")
        out.append(f"NVENC: {'yes' if tools.nvenc_available() else 'no'}")
    else:
        out.append("GPU: none found (nvidia-smi)")
    try:
        from .transcribe import auto_settings
        a = auto_settings(cfg)
        out.append(f"Transcription: model {a.get('model')} on {a.get('device')} ({a.get('compute_type')})")
    except Exception as e:  # noqa: BLE001
        out.append(f"Transcription settings: error {e}")
    try:
        work = cfg.work_dir
        outd = cfg.output_dir
        out.append(f"Work folder: {work} — free {human_size(free_space(work))}")
        out.append(f"Clips folder: {outd} — free {human_size(free_space(outd))}")
    except Exception:  # noqa: BLE001
        pass
    out.append(f"Install folder: {paths.ROOT}")
    # settings, secrets hidden
    out.append("--- settings ---")
    snap = cfg.snapshot() if hasattr(cfg, "snapshot") else dict(cfg)
    for k in sorted(snap):
        v = snap[k]
        if SECRET_KEYS.search(k):
            v = f"(set, {len(str(v))} chars)" if v else "(empty)"
        elif k in ("auto_done",):
            v = f"[{len(v or [])} VODs]"
        elif k == "streamers":
            v = [{kk: vv for kk, vv in (s or {}).items() if kk in ("login", "auto", "wm_on", "sub_style")} for s in v or []]
        out.append(f"{k} = {v}")
    # the VODs
    out.append("--- VODs ---")
    try:
        from .store import Library
        refs = Library(cfg.work_dir).all()
        out.append(f"{len(refs)} VOD(s)")
        for r in refs[:8]:
            st = r.state or {}
            err = (st.get("error") or {}).get("code", "")
            out.append(f"{r.key}: {st.get('status', '?')} {err} moments={st.get('n_moments', '-')} "
                       f"kills={st.get('n_kills', '-')} warnings={[w.get('code') for w in st.get('warnings') or []][:4]}")
    except Exception as e:  # noqa: BLE001
        out.append(f"(library: {e})")
    for name in ("fireclips.log", "worker.log"):
        lines = _tail(paths.LOGS / name, log_lines)
        if lines:
            out.append(f"--- last {len(lines)} lines of {name} ---")
            out += lines
    return mask("\n".join(str(x) for x in out))
