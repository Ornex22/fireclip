"""FireClips - finds the funniest moments in Twitch VODs and turns them into clips."""

__version__ = "1.3.1"
APP_NAME = "FireClips"
