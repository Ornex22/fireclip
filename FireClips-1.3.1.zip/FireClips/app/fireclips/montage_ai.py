"""The automatic montage made by the AI: it reads what is said in the clip (the transcript with the time of
every few words), how the streamer reacted (laughs, yelling), what happened in the game (kills, deaths) and what
the chat wrote, and picks memes from the bank at the right second: a sound right after the punchline, a text on the
reaction, a death sound on the death, "To be continued" on the cliffhanger...

The plan of a clip is cached in <vod>/montage_ai.json (one entry per moment id) and attached to the moment as
"montage_ai"; montage.auto_montage() turns it into real elements. Times in a plan are VOD seconds (like the
"fx" hints), so a clip made a little longer or shorter keeps its montage."""
from __future__ import annotations

import logging
import random
import threading
import time
from typing import Callable, Optional

from . import bank, fxlib, memebank
from .errors import UserError
from .util import Cancelled, fmt_hms, read_json, write_json

log = logging.getLogger("fireclips.montage_ai")

PLAN_VERSION = 1
CACHE_FILE = "montage_ai.json"
KINDS = ["sound", "text", "emoji", "emote", "green", "image", "zoom", "shake", "slowmo", "freeze", "bleep", "music"]
MAX_PARALLEL = 4

SCHEMA = {
    "type": "object",
    "properties": {
        "elements": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "t": {"type": "number", "description": "seconds from the start of the clip, one decimal"},
                    "kind": {"type": "string", "enum": KINDS},
                    "id": {"type": "string", "description": "the id from the lists (sound, emoji, emote, green, "
                                                            "image, music); empty for text and effects"},
                    "text": {"type": "string", "description": "for kind text: the text to show (a preset or your "
                                                              "own, 1 to 4 words); else empty"},
                    "dur": {"type": "number", "description": "seconds on screen for text, emoji, emote, image, "
                                                             "green; 0 = default"},
                    "why": {"type": "string", "description": "3 to 8 words: what it reacts to"},
                },
                "required": ["t", "kind", "id", "text", "dur", "why"],
                "additionalProperties": False,
            },
        }
    },
    "required": ["elements"],
    "additionalProperties": False,
}

# the emojis the AI may use (the most used in meme edits), out of the 537 of the bank
EMOJIS = ["1f602", "1f923", "1f480", "1f525", "1f440", "1f4af", "1f921", "1f62d", "1f631", "1f92f", "1f633",
          "1f976", "1fae1", "1f410", "1f60e", "1f644", "1f914", "1f621", "1f92c", "1f97a", "1f44f", "1f64f",
          "1f4a9", "1f9e2", "1f3af", "26a1", "1f4a5", "1f389", "1f3c6", "1f451", "1f6a8", "1f4a2", "1f9d0",
          "1f974", "1f928", "1f610", "2620-fe0f", "1f47b", "1f4b8", "1f4b0", "1f91d", "1f4aa", "1f64c", "1f937",
          "1f926", "1f62c", "1f975", "1f608", "1f4a4", "1f6ab", "1f3ae", "1f4a3", "1f9e0", "1f4e2", "1f37f",
          "1f52a", "1f308"]
MAX_EMOTES = 70          # emotes listed to the AI: the user's channels first, then the Twitch top
MAX_IMAGES = 60


# --------------------------------------------------------------------------- what the AI may use

_cat_cache: dict = {"key": None, "text": "", "maps": None}


def _emote_map() -> dict:
    """{CODE lower: ref} for the emotes of the bank (the user's first)."""
    out: dict = {}
    for e in memebank.entries("emote"):
        out.setdefault(e.name.lower(), e.ref)
    return out


def catalog(cfg) -> tuple[str, dict]:
    """The lists shown to the AI (one text, cached) and the maps to turn its ids into references."""
    idx = memebank.load_index()
    key = (id(idx), bool(cfg.get("montage_music")), (cfg.get("language") or "fr"))
    if _cat_cache["key"] == key and _cat_cache["maps"] is not None:
        return _cat_cache["text"], _cat_cache["maps"]
    cat = memebank.catalog()
    lang = cfg.get("language") or "fr"
    lines = []
    fams = {c["id"]: c for c in cat.get("sound_cats") or []}
    by_fam: dict = {}
    for s in cat.get("sounds") or []:
        by_fam.setdefault(s.get("cat") or "", []).append(s)
    lines.append("SOUNDS (kind sound, id = the slug). Families:")
    for fam, rows in by_fam.items():
        label = (fams.get(fam) or {}).get("en") or fam
        lines.append(f"- {label}: " + "; ".join(f"{s['id']} ({s['name']})" for s in rows))
    presets = [t for t, _s, _c in fxlib.TEXT_PRESETS]
    lines.append("")
    lines.append("TEXT PRESETS (kind text, put the preset in \"text\"; your own short text is fine too): "
                 + ", ".join(presets))
    em = {e["code"]: e for e in bank.emojis()}
    lines.append("")
    lines.append("EMOJIS (kind emoji, id = code): " + ", ".join(f"{c}={em[c]['char']}" for c in EMOJIS if c in em))
    emotes = memebank.entries("emote")
    mine = [e for e in emotes if e.group == "mine"]
    rest = [e for e in emotes if e.group != "mine"]
    chosen = (mine + rest)[:MAX_EMOTES]
    if chosen:
        lines.append("")
        lines.append("TWITCH EMOTES of the streamer's community (kind emote, id = the emote name): "
                     + ", ".join(e.name for e in chosen))
    greens = cat.get("greens") or []
    lines.append("")
    lines.append("GREEN SCREEN MEME VIDEOS, shown over the game (kind green, id = slug): "
                 + "; ".join(f"{g['id']} ({g['name']})" for g in greens))
    images = memebank.entries("image")[:MAX_IMAGES]
    if images:
        lines.append("")
        lines.append("MEME PICTURES (kind image, id = slug; use sparingly, only when the picture fits the "
                     "situation): " + "; ".join(f"{i.id} ({i.name})" for i in images))
    music = cat.get("music") or []
    if cfg.get("montage_music", True) and music:
        lines.append("")
        lines.append("BACKGROUND MUSIC (kind music, at most one, t = 0, id = slug): "
                     + "; ".join(f"{m['id']} ({m['title']}, {m.get('en') or ''})" for m in music))
    lines.append("")
    lines.append("EDITING EFFECTS (no id): zoom (punch-in on the game for a second, impact), shake (the picture "
                 "shakes: yelling, explosion), slowmo (2 s slow motion: a big play), freeze (freeze frame 1.2 s "
                 "with a record scratch: 'wait, what?'), bleep (hide a swear word, 0.5 s).")
    text = "\n".join(lines)
    maps = {"sounds": {s["id"] for s in cat.get("sounds") or []}, "presets": {p.upper(): p for p in presets},
            "emojis": {c for c in EMOJIS if c in em}, "emotes": _emote_map(),
            "greens": {g["id"] for g in greens}, "images": {i.id for i in memebank.entries("image")},
            "music": {m["id"] for m in music}, "lang": lang}
    _cat_cache.update(key=key, text=text, maps=maps)
    return text, maps


# --------------------------------------------------------------------------- the prompt

def system_prompt(cfg, meta: dict, cat_text: str) -> str:
    streamer = (cfg.get("streamer_name") or meta.get("display_name") or "the streamer").strip()
    game = (meta.get("game") or "").strip()
    extra = (cfg.get("ai_context") or "").strip()
    return f"""You are a meme video editor for TikTok / YouTube Shorts clips of a French Twitch streamer ({streamer}{', playing ' + game if game else ''}). You get the transcript of one clip with timestamps, the streamer's audible reactions, the in-game events and the chat. You place memes from the bank below at the exact second where they land, like a good CapCut edit.

HOW TO PLACE THINGS (timing is everything):
- A sound effect lands right AFTER the word it reacts to: the end of the punchline, the dumb statement, the roast. Use the timestamp of the next words, or the previous one + about 1.5 s if the line is long.
- A text ("BRUH", "SKILL ISSUE", "CHEH", "EMOTIONAL DAMAGE", "+1000 AURA"...) or an emoji / emote goes on the REACTION: just after the punchline, on the death, when the chat explodes. Not before the thing happens.
- A death / fail: a death sound (sad violin, roblox oof, fortnite death, price is right horn, mission failed...) or a green screen (coffin dance, wasted, mission failed, directed by), plus "SKILL ISSUE" / "CHEH" / "L" / a skull when it is deserved.
- A kill / clutch / big play: vine boom or mlg air horn or hitmarker, "GG EZ" / "OUTPLAYED" / "CLUTCH" / "+1000 AURA", a zoom or slow motion.
- Something dumb or absurd said: bruh, vine boom, emotional damage, "BRUH", "WAIT WHAT", "NPC", the clown emoji, huh cat, side eye (monkey-side-eye / quandale).
- A roast / trash talk: emotional damage, "RATIO", "EMOTIONAL DAMAGE", oh no no no (laugh), a fire or skull emoji.
- A cliffhanger or the clip ending on an unresolved situation: to-be-continued at the last 2-3 seconds; a fail at the end: directed-by.
- Laughs: 😂 / KEKW / OMEGALUL at the moment the streamer or the chat laughs; the chat reacts 3 to 10 seconds AFTER the moment, so look for what was said just before the chat burst.
- French jokes can take the French sounds (cheh, c'est honteux, ...). Twitch emotes of the community (KEKW, OMEGALUL, Sadge, catJAM...) fit better than emojis for a streamer's audience.

RULES:
- Be selective: 3 to 7 elements for a 30-60 s clip (1 or 2 for a 10 s clip), never more than one meme every 3 seconds except a sound together with a text / emoji at the same time. Boring parts get nothing. An empty list is fine for a clip that has no reaction worth a meme.
- Never two visual elements (text, emoji, emote, image, green) at the same second. Never two sounds within 2 seconds.
- t is in seconds from the start of the clip, between 0 and the clip length minus 1, with one decimal; take the timestamps from the transcript.
- Use only ids from the lists. kind music: at most one, t = 0, only if the clip is a story / banter without game sound that matters; never for a fight.
- A green screen video lasts 3 to 4 seconds (dur), a text 2 to 3 s, an emoji or emote 1.5 to 2 s.
- Subtitles are already shown: do not write the dialogue as text. Texts are short reactions (1 to 4 words, uppercase like the presets).
{('- Notes from the streamer: ' + extra) if extra else ''}
THE BANK:
{cat_text}"""


def _chunk_words(words: list, a: float, every: float = 1.5) -> str:
    """The transcript with a time stamp every few words: [12.4] Vous savez pourquoi [13.6] les mâches..."""
    out = []
    last_t = -1e9
    for ws, we, text in words:
        txt = (text or "").strip()
        if not txt:
            continue
        if ws - last_t >= every:
            out.append(f"[{max(0.0, ws - a):.1f}]")
            last_t = ws
        out.append(txt)
    return " ".join(out)


def _reactions(moment: dict, a: float, b: float) -> str:
    laughs = [h["t"] for h in moment.get("fx") or [] if h.get("kind") == "laugh" and a <= h["t"] <= b]
    chat_l = [h["t"] for h in moment.get("fx") or [] if h.get("kind") == "chat_laugh" and a <= h["t"] <= b]
    loud = [h["t"] for h in moment.get("fx") or [] if h.get("kind") == "loud" and a <= h["t"] <= b]
    hype = [h["t"] for h in moment.get("fx") or [] if h.get("kind") == "hype" and a <= h["t"] <= b]
    parts = []
    if laughs:
        parts.append("the streamer laughs at " + ", ".join(f"{t - a:.1f}" for t in laughs))
    if loud:
        parts.append("yells / gets loud at " + ", ".join(f"{t - a:.1f}" for t in loud))
    if chat_l:
        parts.append("the chat bursts out laughing around " + ", ".join(f"{t - a:.1f}" for t in chat_l)
                     + " (a few seconds after the funny thing)")
    if hype:
        parts.append("the chat goes wild around " + ", ".join(f"{t - a:.1f}" for t in hype))
    return "; ".join(parts)


def _events(moment: dict, a: float, b: float) -> list[str]:
    out = []
    for h in moment.get("fx") or []:
        k = h.get("kind")
        if k not in ("kill", "assist", "death") or not (a - 0.5 <= h["t"] <= b + 0.5):
            continue
        c = h.get("card") or {}
        other = c.get("other") or "?"
        fame = int(c.get("fame") or 0)
        if k == "kill":
            s = f"KILL: the streamer kills {other}"
        elif k == "assist":
            s = f"ASSIST: the streamer helps killing {other}"
        else:
            s = f"DEATH: the streamer is killed by {other}"
        if c.get("guild"):
            s += f" ({c['guild']})"
        if fame:
            s += f", {fame // 1000}k fame"
        if c.get("ip") and c.get("my_ip"):
            s += f", {c['ip']} IP vs {c['my_ip']} IP"
        out.append(f"[{max(0.0, h['t'] - a):.1f}] {s}")
    return out


def _chat_lines(chat: Optional[list], a: float, b: float, delay: float, limit: int = 40) -> list[str]:
    if not chat:
        return []
    rows = []
    for m in chat:
        off = float(m[0]) - delay
        if a <= off <= b + 2.0:
            text = str(m[2]).strip()
            if text:
                rows.append((off, str(m[1]), text[:60]))
    if len(rows) > limit:
        # keep the reactions: short messages, emotes, laughs; sample the rest
        rnd = random.Random(int(a * 10))
        rows = sorted(rnd.sample(rows, limit), key=lambda r: r[0])
    return [f"[{r[0] - a:.1f}] {r[1]}: {r[2]}" for r in rows]


def user_prompt(meta: dict, moment: dict, a: float, b: float, words: list, chat: Optional[list], delay: float) -> str:
    parts = [f"Clip: \"{moment.get('title') or ''}\" — {b - a:.1f} s long (VOD {fmt_hms(a)} to {fmt_hms(b)})."]
    why = ""
    for r in moment.get("reasons") or []:
        if r.get("kind") == "ai" and r.get("text"):
            why = r["text"]
            break
    if why:
        parts.append(f"Why it was picked: {why}")
    parts.append("")
    parts.append("Transcript (a [time] before every few words, seconds from the clip start; speech recognition "
                 "mistakes are possible):")
    parts.append(_chunk_words(words, a) or "(nothing understandable is said)")
    reac = _reactions(moment, a, b)
    if reac:
        parts.append("")
        parts.append("Reactions heard: " + reac + ".")
    ev = _events(moment, a, b)
    if ev:
        parts.append("")
        parts.append("Game events (Albion Online killboard):")
        parts.extend(ev)
    cl = _chat_lines(chat, a, b, delay)
    if cl:
        parts.append("")
        parts.append("Twitch chat (shifted: a message is shown near the moment it reacts to):")
        parts.extend(cl)
    parts.append("")
    parts.append("Place the memes. Answer with the JSON object only.")
    return "\n".join(parts)


# --------------------------------------------------------------------------- the plan

def _snap_after(t: float, words: list, within: float = 0.8) -> float:
    """A reaction lands right after the word that ends closest to t."""
    best = None
    for ws, we, _txt in words:
        d = abs(we - t)
        if d <= within and (best is None or d < best[0]):
            best = (d, we)
    return round(best[1] + 0.05, 2) if best else round(t, 2)


def _plan_key(moment: dict) -> str:
    return str(moment.get("id") or "")


def _fit_plan(raw: dict, a: float, b: float, words: list, maps: dict) -> list[dict]:
    """Check the AI's answer against the bank and the clip; returns plan elements (VOD times)."""
    out: list[dict] = []
    length = b - a
    for e in (raw.get("elements") or [])[:40]:
        if not isinstance(e, dict):
            continue
        kind = str(e.get("kind") or "")
        if kind not in KINDS:
            continue
        try:
            t = float(e.get("t"))
        except (TypeError, ValueError):
            continue
        if kind == "music":
            t = 0.0
        if not (0.0 <= t <= length + 0.5):
            continue
        t = min(t, max(0.0, length - 0.8))
        try:
            dur = float(e.get("dur") or 0)
        except (TypeError, ValueError):
            dur = 0.0
        ident = str(e.get("id") or "").strip()
        text = str(e.get("text") or "").strip()
        why = str(e.get("why") or "")[:80]
        item: dict = {"kind": kind, "why": why}
        if kind == "sound":
            if ident not in maps["sounds"]:
                continue
            item["ref"] = f"web:sound/{ident}"
        elif kind == "text":
            if not text:
                continue
            item["text"] = text[:40]
        elif kind == "emoji":
            code = ident.lower()
            if code not in maps["emojis"]:
                continue
            item["ref"] = f"emoji:{code}"
        elif kind == "emote":
            ref = maps["emotes"].get(ident.lower())
            if not ref:
                continue
            item["ref"] = ref
        elif kind == "green":
            if ident not in maps["greens"]:
                continue
            item["ref"] = f"web:green/{ident}"
        elif kind == "image":
            if ident not in maps["images"]:
                continue
            item["ref"] = f"web:image/{ident}"
        elif kind == "music":
            if ident not in maps["music"]:
                continue
            item["ref"] = f"web:music/{ident}"
        if kind in ("sound", "text", "emoji", "emote", "image"):
            t = _snap_after(a + t, words) - a
        if dur > 0 and kind in ("text", "emoji", "emote", "image", "green"):
            item["dur"] = round(max(0.8, min(dur, 8.0)), 2)
        item["t"] = round(a + t, 2)
        out.append(item)
    out.sort(key=lambda x: x["t"])
    # no two visuals in the same second, no two sounds within 2 s, at most one music
    kept: list[dict] = []
    last_vis = -1e9
    last_snd = -1e9
    music_done = False
    for item in out:
        k = item["kind"]
        if k in ("text", "emoji", "emote", "image", "green"):
            if item["t"] - last_vis < 1.2:
                continue
            last_vis = item["t"]
        elif k == "sound":
            if item["t"] - last_snd < 2.0:
                continue
            last_snd = item["t"]
        elif k == "music":
            if music_done:
                continue
            music_done = True
        kept.append(item)
    cap = 2 + int(length / 4.0)
    if len(kept) > cap:
        # keep the music and the earliest ones spread over the clip
        mus = [x for x in kept if x["kind"] == "music"]
        rest = [x for x in kept if x["kind"] != "music"]
        step = len(rest) / (cap - len(mus))
        rest = [rest[int(i * step)] for i in range(cap - len(mus))]
        kept = sorted(mus + rest, key=lambda x: x["t"])
    return kept


def plan_one(provider, cfg, meta: dict, moment: dict, words: list, chat: Optional[list],
             cancel: Optional[threading.Event] = None) -> dict:
    """Ask the AI for the montage of one moment; returns the plan (cached by the caller)."""
    a, b = float(moment["start"]), float(moment["end"])
    cat_text, maps = catalog(cfg)
    system = system_prompt(cfg, meta, cat_text)
    user = user_prompt(meta, moment, a, b, words, chat, float(cfg.get("chat_delay") or 6))
    raw = provider.complete_json(system, user, SCHEMA, max_tokens=1500, cancel=cancel)
    elements = _fit_plan(raw if isinstance(raw, dict) else {}, a, b, words, maps)
    return {"v": PLAN_VERSION, "model": f"{provider.name} {provider.model}", "t": time.time(),
            "range": [round(a, 2), round(b, 2)], "elements": elements}


GROWN = 8.0          # a clip made this much longer than when the AI saw it gets a new plan


def valid(plan: Optional[dict], moment: dict) -> bool:
    """A plan still fits a clip whose edges moved a little (its times are VOD seconds)."""
    if not isinstance(plan, dict) or plan.get("v") != PLAN_VERSION or not isinstance(plan.get("range"), list):
        return False
    try:
        pa, pb = float(plan["range"][0]), float(plan["range"][1])
        return float(moment["start"]) >= pa - GROWN and float(moment["end"]) <= pb + GROWN
    except (TypeError, ValueError, IndexError):
        return False


def load_cache(ref) -> dict:
    data = read_json(ref.p(CACHE_FILE), None)
    return data if isinstance(data, dict) else {}


def attach(ref, moments: list[dict]) -> int:
    """Put the cached plans on the moments (those whose clip did not change much). Returns how many got one."""
    cache = load_cache(ref)
    n = 0
    for m in moments:
        p = cache.get(_plan_key(m))
        if valid(p, m):
            m["montage_ai"] = p
            n += 1
        else:
            m.pop("montage_ai", None)
    return n


def plan_moments(ref, cfg, moments: list[dict], progress: Callable[[float, str], None] = lambda f, m="": None,
                 cancel: Optional[threading.Event] = None, force: bool = False, log_fn=None) -> dict:
    """Make (or refresh) the AI plan of these moments, in parallel; saves the cache and attaches the plans.
    Returns {"done": n, "failed": n, "skipped": n}. Raises nothing but Cancelled: a failing clip is skipped."""
    from concurrent.futures import ThreadPoolExecutor, as_completed
    from . import export, llm
    from .media import load_chat
    provider = llm.make_provider(cfg)
    stats = {"done": 0, "failed": 0, "skipped": 0}
    if provider is None or not moments:
        return stats
    transcript = export.load_transcript(ref)
    chat = load_chat(ref)
    meta = ref.meta
    cache = load_cache(ref)
    lock = threading.Lock()
    todo = []
    for m in moments:
        old = cache.get(_plan_key(m))
        if not force and valid(old, m):
            m["montage_ai"] = old
            stats["skipped"] += 1
            continue
        todo.append((m, export.clip_words(ref, m, float(m["start"]), float(m["end"]), transcript)))
    total = len(todo)
    if not total:
        return stats

    def one(m, words):
        if cancel is not None and cancel.is_set():
            raise Cancelled()
        return m, plan_one(provider, cfg, meta, m, words, chat, cancel)

    def save():
        with lock:
            try:
                write_json(ref.p(CACHE_FILE), cache, indent=None)
            except OSError as e:
                log.info("montage cache: %s", e)
    done = 0
    first_err: Optional[Exception] = None
    with ThreadPoolExecutor(max_workers=min(MAX_PARALLEL, total)) as pool:
        futs = [pool.submit(one, m, w) for m, w in todo]
        for fut in as_completed(futs):
            try:
                m, plan = fut.result()
                with lock:
                    cache[_plan_key(m)] = plan
                m["montage_ai"] = plan
                stats["done"] += 1
                if log_fn:
                    log_fn(f"AI montage {m.get('id')}: {len(plan['elements'])} memes")
            except Cancelled:
                for f in futs:
                    f.cancel()
                save()
                raise
            except Exception as e:  # noqa: BLE001 - one clip without a plan does not stop the others
                stats["failed"] += 1
                first_err = first_err or e
                log.info("AI montage: %s", e)
            done += 1
            progress(done / total, "")
            if done % 4 == 0:
                save()
    save()
    if first_err is not None and stats["done"] == 0:
        if isinstance(first_err, UserError):
            raise first_err
        raise UserError("err_ai_request", str(first_err)[:300])
    return stats


# --------------------------------------------------------------------------- plan -> elements

def elements(plan: dict, moment: dict, cfg, rnd: Optional[random.Random] = None) -> tuple[list[dict], str, int]:
    """The montage elements of a plan for this clip (times are kept inside the clip). Returns
    (elements, music ref, music volume)."""
    from . import montage
    a, b = float(moment["start"]), float(moment["end"])
    rnd = rnd or random.Random(str(moment.get("id")))
    positions = [(0.76, 0.30), (0.25, 0.32), (0.74, 0.68), (0.28, 0.66)]
    rnd.shuffle(positions)
    pi = 0
    out: list[dict] = []
    music = ""
    music_vol = int(cfg.get("montage_music_vol") or 18)
    with_sound = bool(cfg.get("montage_fx_sounds", True))
    presets = {t.upper(): (s, c) for t, s, c in fxlib.TEXT_PRESETS}
    for item in plan.get("elements") or []:
        k = item.get("kind")
        t = float(item.get("t") or 0.0)
        if k == "music":
            if cfg.get("montage_music", True) and item.get("ref"):
                music = item["ref"]
            continue
        if not (a - 0.3 <= t <= b - 0.4):
            continue
        t = min(max(t, a + 0.1), b - 0.5)
        room = b - t
        x, y = positions[pi % len(positions)]
        E = montage.element
        if k == "sound":
            if with_sound:
                out.append(E("sound", t, file=item["ref"], vol=85, auto=True))
        elif k == "text":
            text = item.get("text") or ""
            style, color = presets.get(text.upper(), ("impact", None))
            dur = min(float(item.get("dur") or 2.4), max(0.8, room))
            out.append(E("text", t, dur=dur, text=text, style=style, color=color,
                         anim=rnd.choice(["pop", "bounce", "typewriter"]), x=0.5, y=rnd.choice([0.22, 0.78]),
                         auto=True))
        elif k in ("emoji", "emote", "image"):
            pi += 1
            kind = "emoji" if k == "emoji" else "image"
            dur = min(float(item.get("dur") or (1.8 if k != "image" else 2.4)), max(0.8, room))
            size = 0.22 if k == "emoji" else (0.26 if k == "emote" else 0.42)
            out.append(E(kind, t, dur=dur, file=item["ref"], x=x, y=y, size=size,
                         anim=rnd.choice(["pop", "bounce", "pulse"]), auto=True))
        elif k == "green":
            dur = min(float(item.get("dur") or 3.5), max(1.0, room))
            out.append(E("video", t, dur=dur, file=item["ref"], chroma=True, duck=True, x=0.5, y=0.5,
                         size=0.62, auto=True))
        elif k == "zoom":
            out.append(E("zoom", t, dur=1.1, amount=1.3, auto=True))
        elif k == "shake":
            out.append(E("shake", t, dur=0.7, auto=True))
        elif k == "slowmo":
            out.append(E("slowmo", t, dur=min(2.0, max(0.8, room)), auto=True))
        elif k == "freeze":
            out.append(E("freeze", t, dur=1.2, auto=True))
            snd = memebank.auto_sound("freeze")
            if with_sound and snd:
                out.append(E("sound", t, file=snd, vol=80, auto=True))
        elif k == "bleep":
            out.append(E("bleep", t, dur=0.5, auto=True))
    # the Albion kill cards are not memes: they come with every kill / death, like in the classic montage
    for h in moment.get("fx") or []:
        card = h.get("card")
        if not card or h.get("kind") not in ("kill", "death", "assist"):
            continue
        if h["kind"] == "assist" and float(h.get("v") or 0) < 0.6:
            continue
        t = min(max(float(h["t"]), a + 0.2), b - 0.5)
        delay, dur = {"kill": (0.1, 3.4), "death": (0.4, 3.0)}.get(h["kind"], (0.1, 3.0))
        out.append(E("killcard", min(t + delay, b - 0.5), dur=dur, card=card, auto=True))
    out.sort(key=lambda e: e["t"])
    return [e for e in out if e], music, music_vol


def explain(plan: dict, lang: str = "fr") -> str:
    """One line per meme, for the Studio status / log."""
    rows = []
    for item in plan.get("elements") or []:
        name = item.get("text") or bank.display_name(item.get("ref") or "", lang) or item.get("kind")
        rows.append(f"{item['t']:.1f}s {item['kind']} {name} — {item.get('why', '')}".strip())
    return "\n".join(rows)
