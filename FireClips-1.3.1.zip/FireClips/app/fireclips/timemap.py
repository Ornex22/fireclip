"""Stream cuts. When a stream drops and comes back a few minutes later, Twitch goes on with the same
VOD without the offline gap: "real time of a kill - start of the VOD" is then too late by the length
of the gap for everything after the cut. The chat replay knows, for every message, both the real time
it was sent and where it is shown in the VOD: the difference jumps at each cut, which gives the gaps."""
from __future__ import annotations

from typing import Optional

import numpy as np

MIN_JUMP = 15.0          # seconds: smaller differences are just chat lag
MIN_LEN_MSGS = 25        # a new level must hold for this many messages...
MIN_LEN_SECONDS = 60.0   # ... and this long


def build(chat: Optional[list], vod_start: Optional[float]) -> Optional[list[tuple[float, float]]]:
    """[(real_time, extra_delay)] from the start of each part of the VOD, None when there is no cut.
    extra_delay = how much later than "real time - VOD start" things happen from then on."""
    if not chat or not vod_start:
        return None
    pts = [(float(r[4]), float(r[4]) - float(vod_start) - float(r[0])) for r in chat
           if len(r) >= 5 and r[4] is not None]
    if len(pts) < 2 * MIN_LEN_MSGS:
        return None
    pts.sort()
    t = np.array([p[0] for p in pts])
    d = np.array([p[1] for p in pts])
    k = 21
    pad = np.pad(d, (k // 2, k // 2), mode="edge")
    win = np.lib.stride_tricks.sliding_window_view(pad, k)
    med = np.median(win, axis=1)
    levels: list[tuple[float, float]] = []
    level = float(np.median(med[: max(MIN_LEN_MSGS, len(med) // 20)]))
    base = level
    levels.append((float(t[0]), 0.0))
    i = 0
    n = len(med)
    while i < n:
        if abs(med[i] - level) > MIN_JUMP:
            # does the new level hold?
            j = i
            while j < n and abs(med[j] - med[i]) <= MIN_JUMP / 2:
                j += 1
            enough_msgs = j - i >= MIN_LEN_MSGS
            long_enough = t[min(j, n - 1)] - t[i] >= MIN_LEN_SECONDS or j >= n - 1
            if enough_msgs and long_enough:
                level = float(np.median(med[i:j]))
                levels.append((float(t[i]), round(level - base, 2)))
                i = j
                continue
        i += 1
    if len(levels) < 2:
        return None
    return levels


def vod_offset(real_t: float, vod_start: float, knots: Optional[list]) -> float:
    """Where something that happened at real_t is in the VOD."""
    extra = 0.0
    for t0, dl in knots or []:
        if real_t >= t0:
            extra = dl
        else:
            break
    return float(real_t) - float(vod_start) - extra


def describe(knots: Optional[list]) -> list[dict]:
    """For the interface: the cuts found ({"at": real time, "gap": seconds})."""
    out = []
    prev = 0.0
    for t0, dl in (knots or [])[1:]:
        out.append({"at": t0, "gap": round(dl - prev, 1)})
        prev = dl
    return out
