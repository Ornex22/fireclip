"""Combine all the signals into one score per moment and build the ranked list.

score = weighted average of the signals (weights from the settings), 0..100.
Candidates come from: AI moments, peaks of the "reaction" signals (chat, laughter, yelling,
keywords, Albion kills) and clips made by viewers. Overlapping candidates are merged, context
is added around peaks (20 s before / 10 s after by default) and clip edges are moved so that
they do not cut a word in half.

Also built here: the clips asked for with a trigger phrase (always shown first) and the Albion
kill clips of the "Kills Albion" tab.
"""
from __future__ import annotations

import logging
import math
import time
from typing import Optional

import numpy as np

from . import albion as A
from . import markers as MK
from . import signals as S
from . import timemap as TM
from . import triggers as TR
from .store import VodRef
from .transcribe import find_transcript

log = logging.getLogger("fireclips.scoring")
from .util import fmt_time, read_json, write_json

REACTION = ("chat_activity", "chat_laughs", "laughter", "loudness", "voice_keywords", "clips", "albion")
DOC_VERSION = 4        # 3 = moments carry "fx" hints (where to put memes / effects); 4 = better timed


def load_inputs(ref: VodRef, cfg=None) -> dict:
    meta = ref.meta
    tp = find_transcript(ref.dir)
    transcript = read_json(tp, None) if tp else None
    from .media import load_chat
    chat = load_chat(ref)
    clips = read_json(ref.p("clips.json"), None)
    ai = read_json(ref.p("ai_moments.json"), None)
    feats = ref.p("audio_features.npz")
    duration = float(meta.get("duration") or 0)
    if not duration and transcript:
        duration = float(transcript.get("duration") or 0)
    inp = {"meta": meta, "transcript": transcript, "chat": chat, "clips": clips, "ai": ai,
           "features": feats if feats.exists() else None, "duration": duration,
           "albion": ref.albion(), "albion_vod": ref.albion_settings(),
           "votes": read_json(ref.p("discord_votes.json"), None)}
    if cfg is not None and transcript:
        inp["triggers"] = _cached_triggers(ref, tp, transcript, cfg)
    return inp


def _cached_triggers(ref: VodRef, tp, transcript: dict, cfg) -> list:
    """Looking for the trigger phrases in an 8 h transcript takes about a second: remember it."""
    import hashlib
    import json
    phrases = cfg.get("trigger_phrases") or []
    try:
        mtime = tp.stat().st_mtime
    except OSError:
        mtime = 0
    key = hashlib.sha1(json.dumps([tp.name, mtime, phrases, cfg.get("trigger_max_seconds"), 2],
                                  sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()[:16]
    cache = read_json(ref.p("triggers.json"), {}) or {}
    if cache.get("key") == key:
        return cache.get("found") or []
    found = TR.find(transcript, phrases, float(cfg.get("trigger_max_seconds") or 600)) if phrases else []
    try:
        write_json(ref.p("triggers.json"), {"key": key, "found": found})
    except OSError:
        pass
    return found


def stream_cuts(inp: dict) -> Optional[list]:
    """Stream cuts found in the chat (see timemap.py), computed once per ranking."""
    if "cuts" not in inp:
        start = A.vod_start(inp.get("meta") or {})
        if inp.get("albion") and inp["albion"].get("vod_start"):
            start = float(inp["albion"]["vod_start"])
        try:
            inp["cuts"] = TM.build(inp.get("chat"), start)
        except Exception:  # noqa: BLE001
            inp["cuts"] = None
    return inp["cuts"]


def albion_events(inp: dict, cfg) -> list:
    """Kills / assists / deaths of the linked Albion players, placed in the VOD."""
    doc = inp.get("albion")
    if not doc:
        return []
    return A.map_events(doc, A.vod_offset(cfg, inp.get("albion_vod")), max(1.0, inp["duration"]), stream_cuts(inp))


def build_signals(inp: dict, cfg) -> tuple[dict, dict]:
    dur = max(1.0, inp["duration"])
    n = int(math.ceil(dur)) + 1
    sig: dict = {}
    extra: dict = {}
    chat = inp.get("chat")
    if chat and len(chat) >= 20:
        cs = S.chat_signals(chat, dur, float(cfg.get("chat_delay") or 6), cfg.get("laugh_keywords") or [],
                            cfg.get("clip_keywords") or [])
        sig["chat_activity"] = cs["chat_activity"]
        sig["chat_laughs"] = cs["chat_laughs"]
        extra["chat_raw"] = cs["raw"]
    if inp.get("features") is not None:
        try:
            a = S.audio_signals(inp["features"], dur)
            sig["loudness"] = a["loudness"]
            if "laughter" in a:
                sig["laughter"] = a["laughter"]
        except Exception:  # noqa: BLE001 - a broken features file must not stop the ranking
            pass
    tr = inp.get("transcript")
    if tr and tr.get("segments"):
        vk, found = S.voice_keyword_signal(tr, dur, cfg.get("voice_keywords") or [])
        sig["voice_keywords"] = vk
        extra["voice_found"] = found
    clips = inp.get("clips")
    if clips:
        sig["clips"] = S.clips_signal(clips, dur)
    events = inp.get("albion_events")
    if events is None:
        events = albion_events(inp, cfg)
    if events:
        arr = np.zeros(n, dtype=np.float32)
        for e in events:
            a, b = int(max(0, e["off"] - 12)), int(min(n, e["off"] + 7))
            if b > a:
                arr[a:b] = np.maximum(arr[a:b], A.event_strength(e))
        sig["albion"] = arr
    ai = inp.get("ai")
    if ai and ai.get("provider") not in (None, "none"):
        arr = np.zeros(n, dtype=np.float32)
        for m in ai.get("moments", []):
            a, b = int(max(0, m["start"])), int(min(n, math.ceil(m["end"]) + 1))
            arr[a:b] = np.maximum(arr[a:b], m["score"] / 10.0)
        sig["ai"] = arr
    for k in list(sig):
        if len(sig[k]) < n:
            sig[k] = np.pad(sig[k], (0, n - len(sig[k])))
        sig[k] = sig[k][:n]
    return sig, extra


def _weights(cfg, available) -> dict:
    w = cfg.get("weights") or {}
    return {k: max(0.0, float(w.get(k, 0))) for k in available}


def game_spans(meta: dict, cfg, available, w: dict, n: int) -> list[tuple[int, int, dict, str]]:
    """Parts of the VOD played on a game that has its own weights: [(start, end, weights, game)]."""
    profs = {str(p.get("game") or "").strip().lower(): p for p in cfg.get("game_profiles") or [] if p.get("game")}
    if not profs:
        return []
    chapters = (meta or {}).get("chapters") or []
    if not chapters and (meta or {}).get("game"):
        chapters = [{"start": 0, "end": n, "game": meta["game"]}]
    spans = []
    for c in chapters:
        p = profs.get(str(c.get("game") or "").strip().lower())
        if not p:
            continue
        pw = p.get("weights") or {}
        ww = {k: max(0.0, float(pw.get(k, w.get(k, 0)))) for k in available}
        a, b = int(max(0, c.get("start") or 0)), int(min(n, math.ceil(float(c.get("end") or n))))
        if b > a:
            spans.append((a, b, ww, str(c.get("game"))))
    return spans


def _combined(sig: dict, w: dict, keys) -> np.ndarray:
    keys = [k for k in keys if k in sig and w.get(k, 0) > 0]
    if not keys:
        n = len(next(iter(sig.values()))) if sig else 1
        return np.zeros(n)
    tot = sum(w[k] for k in keys)
    return sum(sig[k] * (w[k] / tot) for k in keys)


def _pick_peaks(r: np.ndarray, min_value: float, min_gap: int, limit: int) -> list[int]:
    order = np.argsort(-r)
    taken: list[int] = []
    for i in order:
        if r[i] < min_value or len(taken) >= limit:
            break
        if all(abs(int(i) - t) >= min_gap for t in taken):
            taken.append(int(i))
    return taken


def _best_window(S_all: np.ndarray, a: float, b: float, length: float) -> tuple[float, float]:
    ia, ib, L = int(a), int(math.ceil(b)), int(round(length))
    seg = S_all[ia:ib]
    if len(seg) <= L or L <= 0:
        return a, b
    cs = np.concatenate([[0.0], np.cumsum(seg)])
    sums = cs[L:] - cs[:-L]
    j = int(np.argmax(sums))
    return float(ia + j), float(ia + j + L)


def _words(transcript: Optional[dict]) -> list:
    if not transcript:
        return []
    out = []
    for seg in transcript.get("segments", []):
        for w in seg.get("w", []):
            out.append((float(w[1]), float(w[2]), w[0]))
    out.sort()
    return out


FX_SIGNALS = (("laughter", "laugh", 0.5), ("chat_laughs", "chat_laugh", 0.55), ("loudness", "loud", 0.82),
              ("chat_activity", "hype", 0.75))


def _after_last_word(t: float, words: list, lo: float, back: float = 4.0) -> Optional[float]:
    """A reaction comes right after the last thing said: the end of the last word before t (at most `back`
    seconds earlier, inside the clip, after lo). None when nothing was said: the chat reacts to something else."""
    best = None
    for ws, we, _txt in words:
        if lo <= we <= t + 0.3 and we >= t - back and (best is None or we > best):
            best = we
    return round(best + 0.1, 2) if best is not None else None


def _burst_start(counts, ia: int, peak: int, lo: int) -> Optional[int]:
    """The second the chat burst really starts (the first second with a message in the 10 s before the
    smoothed peak that is followed by another one within 4 s)."""
    if counts is None:
        return None
    for q in range(max(lo, peak - 10), peak + 1):
        j = ia + q
        if j < len(counts) and counts[j] >= 1 and float(np.sum(counts[j:j + 5])) >= 2:
            return q
    return None


def fx_hints(sig: dict, events: list, a: float, b: float, words: Optional[list] = None,
             chat_raw: Optional[dict] = None) -> list[dict]:
    """Moments inside a clip where a meme / effect fits: kills, deaths, laughs, yelling, chat hype. The time of a
    laugh is when it starts; a chat reaction is put back on the last thing said before the chat burst."""
    hints = []
    words = words or []
    for e in events:
        if a - 0.5 <= e["off"] <= b + 0.5:
            hints.append({"t": round(float(e["off"]), 2), "kind": e["role"], "v": round(A.event_strength(e), 2),
                          "card": A.card_info(e)})
    raw_laughs = (chat_raw or {}).get("laughs")          # laughing messages per second (shifted by the chat delay)
    for key, kind, thr in FX_SIGNALS:
        arr = sig.get(key)
        if arr is None:
            continue
        ia, ib = int(max(0, a)), int(min(len(arr), math.ceil(b)))
        if ib - ia < 2:
            continue
        seg = np.asarray(arr[ia:ib], dtype=np.float32)
        # keep local maxima only (a long laugh is one moment)
        for p in _pick_peaks(seg, thr, 5, 3):
            if 0 < p < len(seg) - 1 and seg[p] < max(seg[p - 1], seg[p + 1]):
                continue
            if kind == "laugh":
                q = p
                while q > 0 and seg[q - 1] >= 0.45 * seg[p]:        # the laugh starts here
                    q -= 1
                t = float(ia + q) + 1.0            # (the laughter signal is a 3 s centred maximum)
            elif kind in ("chat_laugh", "hype"):
                q = _burst_start(raw_laughs if kind == "chat_laugh" else None, ia, p, 0)
                if q is None:
                    q = p
                    while q > 0 and seg[q - 1] >= 0.5 * seg[p]:
                        q -= 1
                # the chat types after the thing: the reaction goes on the last words said before the burst;
                # a burst at the very start of the clip reacts to something before it: no cue
                t0 = float(ia + q) - 1.0
                if words:
                    t = _after_last_word(t0, words, a + 0.2)
                    if t is None:
                        continue
                else:
                    if t0 < a + 1.5:
                        continue
                    t = t0
            else:
                t = float(ia + p) + 0.5
            t = min(max(t, a + 0.2), b - 0.5)
            if any(h["kind"] == kind and abs(h["t"] - t) < 3.0 for h in hints):
                continue
            hints.append({"t": round(t, 2), "kind": kind, "v": round(float(seg[p]), 2)})
    hints.sort(key=lambda h: h["t"])
    return hints


def _snap(start: float, end: float, words: list, segs: list, duration: float) -> tuple[float, float]:
    """Move clip edges so they fall between words, preferably at a sentence start / end."""
    if segs:
        cand = [s for s in segs if start - 3.0 <= s[0] <= start + 1.0]
        if cand:
            start = min(cand, key=lambda s: abs(s[0] - start))[0] - 0.25
        cand = [s for s in segs if end - 1.5 <= s[1] <= end + 3.0]
        if cand:
            end = min(cand, key=lambda s: abs(s[1] - end))[1] + 0.35
    for ws, we, _t in words:
        if ws < start < we:
            start = ws - 0.15
        if ws < end < we:
            end = we + 0.2
    return max(0.0, start), min(duration, end)


def _text_between(transcript: Optional[dict], a: float, b: float, limit: int = 900) -> str:
    if not transcript:
        return ""
    parts = []
    for seg in transcript.get("segments", []):
        if seg["e"] < a or seg["s"] > b:
            continue
        words = [w[0] for w in seg.get("w", []) if a - 0.2 <= w[1] <= b]
        parts.append("".join(words).strip() if words else seg.get("t", ""))
    text = " ".join(p for p in parts if p)
    return text[:limit] + ("…" if len(text) > limit else "")


def rank(inp: dict, cfg) -> dict:
    from .i18n import language, tr
    t0 = time.time()
    dur = max(1.0, inp["duration"])
    events = albion_events(inp, cfg)
    inp = dict(inp, albion_events=events)
    sig, extra = build_signals(inp, cfg)
    available = sorted(sig)
    w = _weights(cfg, available)
    S_all = _combined(sig, w, available) if sig else np.zeros(int(math.ceil(dur)) + 1)
    R = _combined(sig, w, [k for k in REACTION if k in sig])
    # games with their own weights (Twitch chapters: Albion, then Just Chatting...)
    spans = game_spans(inp.get("meta") or {}, cfg, available, w, len(S_all)) if sig else []
    if spans:
        n_s = len(S_all)
        W = {k: np.full(n_s, w[k], dtype=np.float64) for k in available}
        for a_, b_, ww, _g in spans:
            for k in available:
                W[k][a_:b_] = ww[k]

        def per_second(keys) -> np.ndarray:
            ks = [k for k in keys if k in sig]
            if not ks:
                return np.zeros(n_s)
            tot = sum(W[k] for k in ks)
            return sum(sig[k] * W[k] for k in ks) / np.maximum(tot, 1e-9)
        S_all = per_second(available)
        R = per_second([k for k in REACTION if k in sig])

    def weights_at(t: float) -> dict:
        for a_, b_, ww, _g in spans:
            if a_ <= t < b_:
                return ww
        return w
    R5 = np.convolve(R, np.ones(5) / 5, mode="same") if len(R) else R

    top_n = int(cfg.get("top_n") or 20)
    pre = float(cfg.get("context_before") or 20)
    post = float(cfg.get("context_after") or 10)
    min_len = float(cfg.get("min_clip_len") or 15)
    max_len = max(min_len + 5, float(cfg.get("max_clip_len") or 90))
    transcript = inp.get("transcript")
    words = _words(transcript)
    segs = [(float(s["s"]), float(s["e"])) for s in (transcript or {}).get("segments", [])]

    # ---- candidates
    cands: list[dict] = []
    ai = inp.get("ai") or {}
    for m in ai.get("moments", []) if "ai" in sig else []:
        cands.append({"start": m["start"] - 2.0, "end": m["end"] + 2.0, "peak": None, "src": {"ai"},
                      "ai": m})
    if len(R5):
        for p in _pick_peaks(R5, 0.12, 30, 4 * top_n):
            cands.append({"start": p - pre, "end": p + post, "peak": float(p), "src": {"reaction"}})
    for c in inp.get("clips") or []:
        p = c["offset"] + max(5.0, c.get("duration", 30)) - 5.0
        cands.append({"start": p - pre, "end": p + post, "peak": p, "src": {"clip"}})
    for c in cands:
        c["start"] = max(0.0, c["start"])
        c["end"] = min(dur, c["end"])

    def score_span(a: float, b: float) -> tuple[float, dict]:
        ia, ib = int(max(0, a - 2)), int(min(len(S_all), b + 4))
        ww = weights_at((a + b) / 2)
        wsum = sum(ww.values()) or 1.0
        vals = {}
        tot = 0.0
        for k in available:
            arr = sig[k][ia:ib]
            v = float(arr.max()) if len(arr) else 0.0
            vals[k] = round(v, 3)
            tot += ww[k] * v
        return 100.0 * tot / wsum, vals

    for c in cands:
        c["score"], c["vals"] = score_span(c["start"], c["end"])
    cands.sort(key=lambda c: -c["score"])

    # ---- greedy selection + merging
    chosen: list[dict] = []
    for c in cands:
        placed = False
        trimmed = False
        for m in chosen:
            inter = min(m["end"], c["end"]) - max(m["start"], c["start"])
            if inter <= -2.0:
                continue
            union = max(m["end"], c["end"]) - min(m["start"], c["start"])
            if union <= max_len + 5:
                m["start"], m["end"] = min(m["start"], c["start"]), max(m["end"], c["end"])
                m["src"] |= c["src"]
                if c.get("ai") and (not m.get("ai") or c["ai"]["score"] > m["ai"]["score"]):
                    m["ai"] = c["ai"]
                if m.get("peak") is None and c.get("peak") is not None:
                    m["peak"] = c["peak"]
                placed = True
                break
            if inter > 0.3 * (c["end"] - c["start"]):
                placed = True  # mostly covered by a better moment
                break
            if inter > 0:
                trimmed = True
                if c["start"] < m["start"]:
                    c["end"] = m["start"]
                else:
                    c["start"] = m["end"]
        if not placed and (not trimmed or c["end"] - c["start"] >= min_len * 0.6) and c["end"] > c["start"]:
            chosen.append(dict(c))
        if len(chosen) >= 3 * top_n:
            break

    # ---- finalize each moment
    out = []
    raw = extra.get("chat_raw")
    chat = inp.get("chat") or []
    delay = float(cfg.get("chat_delay") or 6)
    for m in chosen:
        a, b = m["start"], m["end"]
        if m.get("ai"):
            # the AI chose where the story starts: do not add unrelated talk before it
            a = max(a, m["ai"]["start"] - 3.0)
        if b - a > max_len:
            a, b = _best_window(S_all, a, b, max_len)
        if b - a < min_len:
            need = min_len - (b - a)
            b = min(dur, b + need * 0.6)
            a = max(0.0, a - (min_len - (b - a)))
            if b - a < min_len:
                b = min(dur, a + min_len)
        a, b = _snap(a, b, words, segs, dur)
        score, vals = score_span(a, b)
        reasons = []
        if m.get("ai"):
            am = m["ai"]
            reasons.append({"kind": "ai", "value": vals.get("ai", am["score"] / 10), "score": am["score"],
                            "text": am.get("reason", ""), "category": am.get("category", "")})
        if vals.get("chat_activity", 0) >= 0.3 and raw is not None:
            ia, ib = int(a), int(min(len(raw["rate"]), b + 4))
            rate = float(raw["rate"][ia:ib].max()) if ib > ia else 0
            base = float(max(0.02, raw["base"][ia:ib].mean())) if ib > ia else 1
            reasons.append({"kind": "chat_activity", "value": vals["chat_activity"], "ratio": round(rate / base, 1)})
        if vals.get("chat_laughs", 0) >= 0.3 and raw is not None:
            ia, ib = int(a), int(min(len(raw["laughs"]), b + 4))
            n_l = int(raw["laughs"][ia:ib].sum() + raw["clipreq"][ia:ib].sum())
            laugh_rx = S.keyword_regex((cfg.get("laugh_keywords") or []) + (cfg.get("clip_keywords") or []),
                                       builtin=True)
            top = S.chat_excerpt(chat, a + delay - 2, b + delay + 6, 3, only=laugh_rx)
            reasons.append({"kind": "chat_laughs", "value": vals["chat_laughs"], "count": n_l, "top": top})
        overlapping = [c for c in (inp.get("clips") or []) if c["offset"] < b and c["offset"] + c.get("duration", 30) > a]
        if overlapping:
            reasons.append({"kind": "clips", "value": vals.get("clips", 1.0), "count": len(overlapping),
                            "views": int(sum(c.get("views", 0) for c in overlapping))})
        if vals.get("laughter", 0) >= 0.35:
            reasons.append({"kind": "laughter", "value": vals["laughter"]})
        if vals.get("loudness", 0) >= 0.4:
            reasons.append({"kind": "loudness", "value": vals["loudness"]})
        if vals.get("voice_keywords", 0) >= 0.3:
            kws = sorted({k for t, k in extra.get("voice_found", []) if a - 1 <= t <= b + 1})
            reasons.append({"kind": "voice_keywords", "value": vals["voice_keywords"], "words": kws[:5]})
        near = [e for e in events if a - 2 <= e["off"] <= b + 2]
        if near:
            reasons.append(_albion_reason(near, vals.get("albion", 0)))
        reasons.sort(key=lambda r: -(w.get(r["kind"], 0) * float(r.get("value", 0))))
        score, reasons = _apply_votes(inp, cfg, a, b, score, reasons, f"m{int(a * 10)}")

        title = ""
        category = ""
        if m.get("ai"):
            title = m["ai"].get("title", "")
            category = m["ai"].get("category", "")
        if not title and overlapping:
            best = max(overlapping, key=lambda c: c.get("views", 0))
            title = (best.get("title") or "").strip()
        excerpt = _text_between(transcript, a, b)
        if not title:
            pk = m.get("peak") if m.get("peak") is not None else (a + b) / 2
            setup = _text_between(transcript, max(a, pk - 12), pk + 2, 200).split()
            title = ("« " + " ".join(setup[:9]) + ("… »" if len(setup) > 9 else " »")) if setup else ""
        out.append({
            "id": f"m{int(a * 10)}",
            "start": round(a, 2), "end": round(b, 2),
            "peak": round(m["peak"], 1) if m.get("peak") is not None else None,
            "score": round(score, 1),
            "title": title, "category": category,
            "sources": sorted(m["src"]), "signals": vals, "reasons": reasons,
            "transcript": excerpt, "fx": fx_hints(sig, events, a, b, words, extra.get("chat_raw")),
        })

    out.sort(key=lambda x: -x["score"])
    min_score = float(cfg.get("min_score") or 0)
    shown = [m for m in out if m["score"] >= min_score][:top_n]
    for i, m in enumerate(shown, 1):
        m["rank"] = i

    # ---- clips asked for on stream with a trigger phrase: always kept, shown first
    trig = _trigger_moments(inp.get("triggers") or [], inp, cfg, words, segs, dur, score_span, events, tr)
    # ---- moments marked live (keyboard shortcut / tray / "!clip" in the chat): pinned too
    try:
        marks = MK.for_vod(cfg, inp.get("meta") or {}, dur, inp.get("chat"), stream_cuts(inp))
    except Exception:  # noqa: BLE001 - a broken marks file must not stop the ranking
        marks = []
    pins = _marker_moments(marks, inp, cfg, words, segs, dur, score_span, events, tr, trig)
    for t in trig + pins:
        t["fx"] = fx_hints(sig, events, t["start"], t["end"], words, extra.get("chat_raw"))
    shown = trig + pins + shown

    # ---- Albion kill clips (second tab)
    kills = A.build_clips(events, cfg, dur, tr, language(),
                          snap=lambda x, y: _snap(x, y, words, segs, dur),
                          text_between=lambda x, y: _text_between(transcript, x, y)) if events else []
    from .discord import votes_for
    for k in kills:
        k["fx"] = fx_hints(sig, events, k["start"], k["end"], words, extra.get("chat_raw"))
        v = votes_for(inp.get("votes"), k["start"], k["end"], k["id"])
        if v and (v.get("up") or v.get("down")):
            k["reasons"] = [{"kind": "votes", "up": v.get("up", 0), "down": v.get("down", 0), "value": 1.0}] + k["reasons"]
    # small overview of the whole VOD for the timeline (one value per 10 s)
    step = 10
    nb = int(math.ceil(len(S_all) / step))
    timeline = (np.pad(S_all, (0, nb * step - len(S_all))).reshape(nb, step).max(axis=1) * 100).round(1).tolist()
    return {
        "version": DOC_VERSION,
        "computed_at": time.time(),
        "duration": dur,
        "available": available,
        "weights": w,
        "moments": shown,
        "kills": kills,
        "albion_info": _albion_info(inp.get("albion"), events),
        "games": [[a_, b_, g] for a_, b_, _w, g in spans],
        "cuts": TM.describe(stream_cuts(inp)),
        "timeline_events": [[round(e["off"], 1), e["role"]] for e in events],
        "candidates": len(out),
        "timeline_step": step,
        "timeline": timeline,
        "elapsed": round(time.time() - t0, 2),
    }


def _apply_votes(inp: dict, cfg, a: float, b: float, score: float, reasons: list,
                 mid: Optional[str] = None) -> tuple[float, list]:
    """👍 / 👎 of the mods on Discord (see discord.py) move the score."""
    from .discord import votes_for
    v = votes_for(inp.get("votes"), a, b, mid)
    if not v or not (v.get("up") or v.get("down")):
        return score, reasons
    net = int(v.get("up", 0)) - int(v.get("down", 0))
    bonus = max(-25.0, min(25.0, float(cfg.get("discord_votes_weight") or 5) * net))
    return max(0.0, min(100.0, score + bonus)), [{"kind": "votes", "up": v.get("up", 0), "down": v.get("down", 0),
                                                  "value": 1.0}] + reasons


def _albion_reason(near: list, value: float) -> dict:
    return {"kind": "albion", "value": value,
            "kills": sum(1 for e in near if e["role"] == "kill"),
            "assists": sum(1 for e in near if e["role"] == "assist"),
            "deaths": sum(1 for e in near if e["role"] == "death"),
            "fame": int(sum(int(e.get("fame") or 0) for e in near if e["role"] != "death")),
            "death_fame": int(sum(int(e.get("fame") or 0) for e in near if e["role"] == "death")),
            "names": [A.opponent(e)["name"] for e in near][:4]}


def _albion_info(doc, events) -> dict:
    if not doc:
        return {}
    return {"fetched_at": doc.get("fetched_at"), "players": doc.get("players") or [],
            "partial": bool(doc.get("partial")), "errors": len(doc.get("errors") or []),
            "n_events": len(events)}


def _trigger_moments(found: list, inp: dict, cfg, words, segs, dur: float, score_span, events, tr) -> list:
    include = bool(cfg.get("trigger_include_phrase"))
    ai_moments = (inp.get("ai") or {}).get("moments") or []
    out = []
    for f in found:
        end = (f["said_end"] + 0.6) if include else (f["said_at"] - 0.25)
        end = max(1.0, min(dur, end))
        start = max(0.0, end - float(f["seconds"]))
        # start on a sentence / between two words
        cand = [s for s in segs if start - 4.0 <= s[0] <= start + 1.5]
        if cand:
            start = max(0.0, min(cand, key=lambda s: abs(s[0] - start))[0] - 0.25)
        for ws, we, _t in words:
            if ws < start < we:
                start = max(0.0, ws - 0.15)
                break
        if end - start < 3:
            continue
        score, vals = score_span(start, end)
        inside = [m for m in ai_moments if m["start"] >= start - 1 and m["end"] <= end + 1]
        best = max(inside, key=lambda m: m["score"]) if inside else None
        minutes = float(f["seconds"]) / 60.0
        if abs(minutes - 1) < 0.05:
            span = tr("trigger_span_1min")
        elif minutes >= 1:
            span = tr("trigger_span_min", n=(f"{minutes:.0f}" if abs(minutes - round(minutes)) < 0.05
                                             else f"{minutes:.1f}".replace(".", ",")))
        else:
            span = tr("trigger_span_sec", n=f"{float(f['seconds']):.0f}")
        title = (best.get("title") or "") if best else ""
        title = title or tr("trigger_title", span=span)
        reasons = [{"kind": "trigger", "heard": f.get("heard", ""), "phrase": f.get("phrase", ""),
                    "at": f["said_at"], "seconds": f["seconds"], "spoken": f.get("spoken", False), "span": span}]
        if best:
            reasons.append({"kind": "ai", "value": vals.get("ai", best["score"] / 10), "score": best["score"],
                            "text": best.get("reason", ""), "category": best.get("category", "")})
        near = [e for e in events if start - 2 <= e["off"] <= end + 2]
        if near:
            reasons.append(_albion_reason(near, vals.get("albion", 0)))
        score, reasons = _apply_votes(inp, cfg, start, end, score, reasons, f"t{int(f['said_at'] * 10)}")
        out.append({
            "id": f"t{int(f['said_at'] * 10)}",
            "start": round(start, 2), "end": round(end, 2), "peak": round(f["said_at"], 1),
            "score": round(score, 1), "title": title, "category": "trigger", "trigger": True,
            "auto_check": True, "rank": 0, "sources": ["trigger"], "signals": vals, "reasons": reasons,
            "transcript": _text_between(inp.get("transcript"), start, end, limit=1500),
        })
    return out


def _marker_moments(marks: list, inp: dict, cfg, words, segs, dur: float, score_span, events, tr,
                    existing: list) -> list:
    before = float(cfg.get("marker_before") or 60)
    after = float(cfg.get("marker_after") or 10)
    ai_moments = (inp.get("ai") or {}).get("moments") or []
    out = []
    for mk in marks:
        off = float(mk["off"])
        if any(t["start"] - 2 <= off <= t["end"] + 5 for t in existing):
            continue        # the trigger phrase already made this clip
        a, b = max(0.0, off - before), min(dur, off + after)
        a, b = _snap(a, b, words, segs, dur)
        if b - a < 3:
            continue
        score, vals = score_span(a, b)
        inside = [m for m in ai_moments if m["start"] >= a - 1 and m["end"] <= b + 1]
        best = max(inside, key=lambda m: m["score"]) if inside else None
        title = (mk.get("title") or "").strip() or ((best.get("title") or "") if best else "")
        if not title:
            title = tr("marker_title_chat", by=mk.get("by", "")) if mk.get("source") == "chat" else tr("marker_title")
        reasons = [{"kind": "marker", "source": mk.get("source", "hotkey"), "by": mk.get("by", ""), "at": off,
                    "count": mk.get("count", 1), "title": mk.get("title", "")}]
        if best:
            reasons.append({"kind": "ai", "value": vals.get("ai", best["score"] / 10), "score": best["score"],
                            "text": best.get("reason", ""), "category": best.get("category", "")})
        near = [e for e in events if a - 2 <= e["off"] <= b + 2]
        if near:
            reasons.append(_albion_reason(near, vals.get("albion", 0)))
        score, reasons = _apply_votes(inp, cfg, a, b, score, reasons, f"p{int(off * 10)}")
        out.append({
            "id": f"p{int(off * 10)}",
            "start": round(a, 2), "end": round(b, 2), "peak": round(off, 1),
            "score": round(score, 1), "title": title, "category": "marker", "marker": True,
            "auto_check": True, "rank": 0, "sources": ["marker"], "signals": vals, "reasons": reasons,
            "transcript": _text_between(inp.get("transcript"), a, b, limit=1500),
        })
    return out


DETECTION_KEYS = ("top_n", "min_score", "min_clip_len", "max_clip_len", "context_before", "context_after",
                  "chat_delay", "weights", "laugh_keywords", "clip_keywords", "voice_keywords",
                  "trigger_phrases", "trigger_include_phrase", "trigger_max_seconds",
                  "albion_min_fame", "albion_types", "albion_before", "albion_after", "albion_group_gap",
                  "albion_offset", "language", "marker_before", "marker_after", "chat_clip_command",
                  "chat_clip_roles", "game_profiles", "discord_votes_weight")


def settings_fingerprint(cfg) -> str:
    import hashlib
    import json
    data = json.dumps({k: cfg.get(k) for k in DETECTION_KEYS}, sort_keys=True, ensure_ascii=False)
    return hashlib.sha1(data.encode("utf-8")).hexdigest()[:12]


def compute_and_save(ref: VodRef, cfg) -> dict:
    doc = rank(load_inputs(ref, cfg), cfg)
    doc["settings_fp"] = settings_fingerprint(cfg)
    try:
        from . import montage_ai
        montage_ai.attach(ref, doc["moments"])          # the memes the AI placed, when the clip did not move
    except Exception as e:  # noqa: BLE001
        log.info("AI montage plans: %s", e)
    write_json(ref.p("moments.json"), doc, indent=None)
    return doc


def reason_label(r: dict, tr) -> str:
    """Human text for one reason (tr = translation function)."""
    k = r.get("kind")
    if k == "ai":
        s = tr("why_ai", score=f"{r.get('score', 0):.0f}")
        return s + (f" — {r['text']}" if r.get("text") else "")
    if k == "chat_activity":
        return tr("why_chat", ratio=r.get("ratio", 0))
    if k == "chat_laughs":
        top = ", ".join(r.get("top") or [])
        return tr("why_laughs", count=r.get("count", 0)) + (f" ({top})" if top else "")
    if k == "clips":
        return tr("why_clips", count=r.get("count", 0), views=r.get("views", 0))
    if k == "laughter":
        return tr("why_laughter")
    if k == "loudness":
        return tr("why_loud")
    if k == "voice_keywords":
        return tr("why_words", words=", ".join(f"« {x} »" for x in r.get("words") or []))
    if k == "trigger":
        return tr("why_trigger", heard=r.get("heard", ""), at=fmt_time(r.get("at", 0)), span=r.get("span", ""))
    if k == "votes":
        return tr("why_votes", up=r.get("up", 0), down=r.get("down", 0))
    if k == "marker":
        if r.get("source") == "chat":
            n = int(r.get("count") or 1)
            return tr("why_marker_chat", by=r.get("by", ""), at=fmt_time(r.get("at", 0))) + \
                (f" (+{n - 1})" if n > 1 else "")
        return tr("why_marker_key", at=fmt_time(r.get("at", 0)))
    if k == "albion":
        from .i18n import language
        parts = []
        lang = language()
        if r.get("kills"):
            parts.append(tr("why_alb_kills", n=r["kills"], fame=A.fmt_fame(r.get("fame", 0), lang)))
        if r.get("assists"):
            parts.append(tr("why_alb_assists", n=r["assists"]))
        if r.get("deaths"):
            parts.append(tr("why_alb_deaths", n=r["deaths"]))
        names = ", ".join(r.get("names") or [])
        return " · ".join(parts) + (f" ({names})" if names else "")
    if k == "albion_event":
        from .i18n import language
        f = A.fmt_fame(r.get("fame", 0), language())
        who = r.get("name", "") + (f" [{r['guild']}]" if r.get("guild") else "")
        key = {"kill": "why_alb_kill", "assist": "why_alb_assist", "death": "why_alb_death"}.get(r.get("role"), "why_alb_kill")
        return tr(key, who=who, fame=f, at=fmt_time(r.get("at", 0)))
    return k or ""


def apply_edits(doc: dict, edits: dict, key: str = "moments") -> list[dict]:
    """Moments (or kill clips, key="kills") with the user's changes (start/end/title/ticks)
    applied. Edits made on an older ranking are matched to the new moments by overlap."""
    moments = [dict(m) for m in doc.get(key, [])]
    used = set()
    for m in moments:
        e = edits.get(m["id"])
        if e is None:
            best, best_iou = None, 0.0
            for k, ed in edits.items():
                if k in used or "orig" not in ed:
                    continue
                oa, ob = ed["orig"]
                inter = min(ob, m["end"]) - max(oa, m["start"])
                union = max(ob, m["end"]) - min(oa, m["start"])
                iou = inter / union if union > 0 else 0
                if iou > best_iou:
                    best, best_iou = k, iou
            if best is not None and best_iou >= 0.5:
                e = edits[best]
                used.add(best)
        else:
            used.add(m["id"])
        if e:
            for key in ("start", "end", "title", "checked", "exported", "subs_text", "subs_range", "montage",
                        "decision"):
                if key in e:
                    m[key] = e[key]
            m["edited"] = any(k in e for k in ("start", "end", "title"))
        if "checked" not in (e or {}):
            m["checked"] = bool(m.get("auto_check"))
    return moments


def label_time(sec: float) -> str:
    return fmt_time(sec)
