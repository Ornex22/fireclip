"""The looks shared by the export (ffmpeg) and the Studio live preview (Qt): text styles, stickers,
picture animations and animated effects. Every picture is drawn here with Pillow, so the live
preview shows exactly what the exported clip will show."""
from __future__ import annotations

import functools
import hashlib
import math
import random
import re
from pathlib import Path
from typing import Optional

from . import paths

FONT_FILES = {"Montserrat ExtraBold": "Montserrat-ExtraBold.ttf", "Anton": "Anton-Regular.ttf",
              "Bangers": "Bangers-Regular.ttf", "Luckiest Guy": "LuckiestGuy-Regular.ttf",
              "Poppins ExtraBold": "Poppins-ExtraBold.ttf", "Poppins SemiBold": "Poppins-SemiBold.ttf"}
STICKER_DIR = paths.ASSETS / "stickers"


def _pil():
    try:
        from PIL import Image, ImageDraw, ImageFilter, ImageFont
    except ImportError as e:  # pragma: no cover - installed with FireClips
        from .errors import UserError
        raise UserError("err_pillow_missing", str(e)) from e
    return Image, ImageDraw, ImageFilter, ImageFont


@functools.lru_cache(maxsize=128)
def font(size: int, name: str = "Montserrat ExtraBold"):
    _I, _D, _F, ImageFont = _pil()
    return ImageFont.truetype(str(paths.ASSETS / "fonts" / FONT_FILES.get(name, "Montserrat-ExtraBold.ttf")),
                              max(6, int(size)))


def hex_rgba(c: str, alpha: int = 255) -> tuple:
    c = (c or "#FFFFFF").lstrip("#")
    try:
        return int(c[0:2], 16), int(c[2:4], 16), int(c[4:6], 16), alpha
    except (ValueError, IndexError):
        return 255, 255, 255, alpha


def seed_of(*parts) -> int:
    return int(hashlib.md5("|".join(str(p) for p in parts).encode("utf-8")).hexdigest()[:8], 16)


def ease_out_back(u: float) -> float:
    c1 = 1.70158
    c3 = c1 + 1
    return 1 + c3 * (u - 1) ** 3 + c1 * (u - 1) ** 2


def ease_out_cubic(u: float) -> float:
    u = max(0.0, min(1.0, u))
    return 1 - (1 - u) ** 3


def ease_in_out(u: float) -> float:
    u = max(0.0, min(1.0, u))
    return u * u * (3 - 2 * u)


# =========================================================================== emoji inside texts

_EMOJI_RX = re.compile("([\U0001F000-\U0001FAFF☀-➿⬀-⯿←-⇿⌀-⏿⤴⤵〰"
                       "〽㊗㊙©®‼⁉™ℹ][️‍\U0001F3FB-\U0001F3FF"
                       "\U0001F000-\U0001FAFF☀-➿]*)")


@functools.lru_cache(maxsize=1)
def _emoji_by_char() -> dict:
    from . import bank
    out = {}
    for e in bank.emojis():
        out[e["char"].replace("️", "")] = e["code"]
    return out


def emoji_code_of(ch: str) -> Optional[str]:
    return _emoji_by_char().get(ch.replace("️", ""))


@functools.lru_cache(maxsize=256)
def emoji_image(code: str, px: int):
    """The emoji picture (RGBA) fitted in px x px, or None."""
    from . import bank
    p = bank.emoji_path(code)
    if p is None:
        return None
    Image, _D, _F, _Fo = _pil()
    try:
        im = Image.open(p).convert("RGBA")
    except OSError:
        return None
    return im.resize((max(1, px), max(1, px)), Image.LANCZOS)


def _segments(text: str) -> list[tuple[str, str]]:
    """[("t", "text") | ("e", code)] - emoji become pictures, the rest stays text."""
    out = []
    for part in _EMOJI_RX.split(text):
        if not part:
            continue
        if _EMOJI_RX.fullmatch(part):
            code = emoji_code_of(part)
            if code:
                out.append(("e", code))
            continue
        out.append(("t", part))
    return out


def _measure(word: str, fnt) -> float:
    w = 0.0
    for kind, v in _segments(word):
        w += fnt.size * 1.05 if kind == "e" else fnt.getlength(v)
    return w


def _wrap(text: str, fnt, max_w: float, max_lines: int = 4) -> list[str]:
    lines: list[str] = []
    for para in (text or "").split("\n"):
        cur = ""
        for w in para.split():
            test = (cur + " " + w).strip()
            if cur and _measure(test, fnt) > max_w:
                lines.append(cur)
                cur = w
            else:
                cur = test
        lines.append(cur)
    lines = [l for l in lines if l.strip()] or [""]
    return lines[:max_lines]


def _draw_line(img, xy, line: str, fnt, fill, stroke_w: int = 0, stroke_fill=None, budget: Optional[list] = None) -> None:
    """Draw one line of text with emoji pictures inline. budget: [characters left to show] (typewriter)."""
    _I, ImageDraw, _F, _Fo = _pil()
    d = ImageDraw.Draw(img)
    x, y = xy
    for kind, v in _segments(line):
        if budget is not None and budget[0] <= 0:
            return
        if kind == "e":
            px = int(fnt.size * 1.0)
            em = emoji_image(v, px)
            if em is not None:
                img.alpha_composite(em, (int(x + fnt.size * 0.025), int(y + fnt.size * 0.12)))
            x += fnt.size * 1.05
            if budget is not None:
                budget[0] -= 1
            continue
        if budget is not None:
            if len(v) > budget[0]:
                v = v[: budget[0]]
            budget[0] -= len(v)
        if stroke_w:
            d.text((x, y), v, font=fnt, fill=fill, stroke_width=stroke_w, stroke_fill=stroke_fill)
        else:
            d.text((x, y), v, font=fnt, fill=fill)
        x += fnt.getlength(v)
    if budget is not None:
        budget[0] -= 1          # the space at the end of the line


# =========================================================================== text styles

TEXT_STYLES: dict[str, dict] = {
    "classic": {"font": "Montserrat ExtraBold", "base": 0.08, "fill": "#FFFFFF", "stroke": "#000000", "sw": 0.11,
                "lh": 1.12},
    "impact": {"font": "Anton", "base": 0.095, "fill": "#FFFFFF", "stroke": "#000000", "sw": 0.10, "upper": True,
               "lh": 1.08},
    "comic": {"font": "Bangers", "base": 0.105, "fill": "#FFD23F", "stroke": "#000000", "sw": 0.12, "upper": True,
              "rot": -4, "shadow": True},
    "fire": {"font": "Luckiest Guy", "base": 0.09, "fill": "#FFE14D", "fill2": "#FF7A00", "stroke": "#8E1407",
             "sw": 0.10, "upper": True, "glow": "#FF6A00"},
    "badge": {"font": "Anton", "base": 0.072, "fill": "#FFFFFF", "bg": "#E53935", "upper": True, "color": "bg"},
    "bubble": {"font": "Poppins ExtraBold", "base": 0.062, "fill": "#111111", "bg": "#FFFFFF", "border": "#111111",
               "color": "bg"},
    "neon": {"font": "Poppins ExtraBold", "base": 0.075, "fill": "#FFFFFF", "glow": "#00E5FF", "color": "glow"},
    "caption": {"font": "Poppins SemiBold", "base": 0.052, "fill": "#111111", "bg": "#FFFFFF", "color": "bg"},
    "achievement": {"font": "Poppins ExtraBold", "base": 0.05, "fill": "#FFFFFF", "bg": "#1C1C24", "color": "bg"},
    "glitch": {"font": "Anton", "base": 0.095, "fill": "#FFFFFF", "upper": True},
    "burst": {"font": "Bangers", "base": 0.11, "fill": "#FFFFFF", "stroke": "#000000", "sw": 0.09, "upper": True,
              "bg": "#FFD23F", "border": "#E53935", "color": "bg", "rot": -6},
}
TEXT_STYLE_ORDER = ["classic", "impact", "comic", "fire", "burst", "badge", "bubble", "caption", "neon", "glitch",
                    "achievement"]


def _style_color(st: dict, key: str, color: Optional[str]) -> str:
    if color and st.get("color", "fill") == key:
        return color
    return st.get(key) or "#FFFFFF"


def text_picture(text: str, W: int, H: int, size: float = 1.0, color: Optional[str] = None, style: str = "classic",
                 lang: str = "fr", reveal: Optional[int] = None):
    """A text sticker as an RGBA picture (sized for a W x H clip). reveal: only the first characters are
    drawn (typewriter animation) - the picture keeps the size of the whole text."""
    Image, ImageDraw, ImageFilter, _Fo = _pil()
    st = TEXT_STYLES.get(style) or TEXT_STYLES["classic"]
    if style == "classic" and not color:
        color = "#FFFFFF"
    txt = (text or "").strip()
    if st.get("upper"):
        txt = txt.upper()
    fs = max(8, int(min(W, H) * st["base"] * max(0.25, size)))
    fnt = font(fs, st["font"])
    max_w = int(W * (0.80 if style in ("bubble", "caption", "achievement") else 0.86))
    if style == "achievement":
        return _achievement(txt, fnt, fs, max_w, color, st, lang, reveal)
    lines = _wrap(txt, fnt, max_w)
    lh = int(fs * st.get("lh", 1.16))
    widths = [int(_measure(l, fnt)) for l in lines]
    tw, th = max(widths + [1]), lh * len(lines)
    sw = max(2, int(fs * st.get("sw", 0.0))) if st.get("stroke") else 0
    fill = _style_color(st, "fill", color)
    pad = sw + 4
    glow_pad = int(fs * 0.45) if st.get("glow") else 0
    shadow = int(fs * 0.06) if st.get("shadow") else 0
    w = tw + 2 * pad + 2 * glow_pad + shadow
    h = th + 2 * pad + 2 * glow_pad + shadow + int(fs * 0.2)
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    ox, oy = pad + glow_pad, pad + glow_pad

    def draw_text(target, fill_c, stroke_c=None, sw_=0, dx=0, dy=0):
        budget = [reveal] if reveal is not None else None
        for i, l in enumerate(lines):
            x = ox + (tw - widths[i]) / 2 + dx
            _draw_line(target, (x, oy + i * lh + dy), l, fnt, fill_c, sw_, stroke_c, budget)

    if style in ("badge", "caption", "bubble", "burst"):
        return _boxed(lines, widths, fnt, fs, lh, color, st, style, reveal)
    if st.get("glow"):
        glow_c = _style_color(st, "glow", color)
        layer = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        draw_text(layer, hex_rgba(glow_c), hex_rgba(glow_c), max(2, int(fs * 0.16)))
        g1 = layer.filter(ImageFilter.GaussianBlur(fs * 0.18))
        img.alpha_composite(g1)
        img.alpha_composite(g1)
        if style == "neon":
            g2 = layer.filter(ImageFilter.GaussianBlur(fs * 0.05))
            img.alpha_composite(g2)
    if shadow:
        draw_text(img, (0, 0, 0, 200), (0, 0, 0, 200), sw, shadow, shadow)
    if style == "glitch":
        k = max(2, int(fs * 0.06))
        layer = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        draw_text(layer, (255, 0, 64, 230), dx=-k)
        img.alpha_composite(layer)
        layer = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        draw_text(layer, (0, 229, 255, 230), dx=k)
        img.alpha_composite(layer)
        draw_text(img, hex_rgba(fill))
        rnd = random.Random(seed_of(txt, fs))
        for _ in range(2):
            y0 = rnd.randint(oy, max(oy + 1, oy + th - fs // 4))
            hh = rnd.randint(max(2, fs // 14), max(3, fs // 8))
            band = img.crop((0, y0, w, y0 + hh))
            img.paste((0, 0, 0, 0), (0, y0, w, y0 + hh))
            img.alpha_composite(band, (rnd.choice([-1, 1]) * rnd.randint(k, 2 * k), y0))
    elif style == "fire":
        draw_text(img, hex_rgba(st["stroke"]), hex_rgba(st["stroke"]), sw)
        mask = Image.new("L", (w, h), 0)
        mtmp = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        draw_text(mtmp, (255, 255, 255, 255))
        mask = mtmp.split()[3]
        top = hex_rgba(_style_color(st, "fill", color))
        bot = hex_rgba(st["fill2"])
        grad = Image.new("RGBA", (1, h))
        for y in range(h):
            u = min(1.0, max(0.0, (y - oy) / max(1, th)))
            grad.putpixel((0, y), tuple(int(top[c] + (bot[c] - top[c]) * u) for c in range(3)) + (255,))
        grad = grad.resize((w, h))
        img.paste(grad, (0, 0), mask)
    else:
        stroke_c = hex_rgba(st["stroke"]) if st.get("stroke") else None
        draw_text(img, hex_rgba(fill), stroke_c, sw)
    if st.get("rot"):
        img = img.rotate(st["rot"], Image.BICUBIC, expand=True)
    if reveal is not None:
        return img              # same size for every step of the animation
    return img.crop(img.getbbox()) if img.getbbox() else img


def _boxed(lines, widths, fnt, fs, lh, color, st, style, reveal=None):
    Image, ImageDraw, ImageFilter, _Fo = _pil()
    tw, th = max(widths + [1]), lh * len(lines)
    padx = int(fs * (0.55 if style != "burst" else 0.8))
    pady = int(fs * (0.28 if style != "burst" else 0.7))
    tail = int(fs * 0.7) if style == "bubble" else 0
    bw, bh = tw + 2 * padx, th + 2 * pady
    margin = int(fs * 0.3)
    w, h = bw + 2 * margin, bh + 2 * margin + tail
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    bg = hex_rgba(_style_color(st, "bg", color))
    x0, y0, x1, y1 = margin, margin, margin + bw, margin + bh
    if style == "burst":
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        rx, ry = bw / 2 * 1.02, bh / 2 * 1.08
        pts = []
        n = 16
        rnd = random.Random(seed_of("".join(lines)))
        for i in range(2 * n):
            a = math.pi * i / n
            r = 1.0 if i % 2 == 0 else 0.72 + 0.08 * rnd.random()
            pts.append((cx + math.cos(a) * rx * r, cy + math.sin(a) * ry * r))
        d.polygon(pts, fill=hex_rgba(st["border"]))
        inner = [(cx + (px - cx) * 0.86, cy + (py - cy) * 0.84) for px, py in pts]
        d.polygon(inner, fill=bg)
    else:
        radius = int(min(bh / 2, fs * (0.5 if style == "badge" else 0.38)))
        shadow = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        ImageDraw.Draw(shadow).rounded_rectangle((x0 + 2, y0 + int(fs * 0.08), x1 + 2, y1 + int(fs * 0.08)), radius,
                                                 fill=(0, 0, 0, 110))
        img.alpha_composite(shadow.filter(ImageFilter.GaussianBlur(fs * 0.08)))
        border = st.get("border")
        bwid = max(2, int(fs * 0.08)) if border else 0
        d.rounded_rectangle((x0, y0, x1, y1), radius, fill=bg, outline=hex_rgba(border) if border else None,
                            width=bwid)
        if style == "bubble":
            tx = x0 + bw * 0.22
            pts = [(tx, y1 - bwid), (tx + fs * 0.75, y1 - bwid), (tx - fs * 0.25, y1 + tail)]
            d.polygon(pts, fill=bg)
            d.line([pts[1], pts[2], pts[0]], fill=hex_rgba(border), width=bwid)
    fill = hex_rgba(st["fill"])
    sw = int(fs * st.get("sw", 0.0)) if st.get("stroke") else 0
    budget = [reveal] if reveal is not None else None
    for i, l in enumerate(lines):
        x = x0 + padx + (tw - widths[i]) / 2
        _draw_line(img, (x, y0 + pady + i * lh - int(fs * 0.04)), l, fnt, fill, sw, hex_rgba(st["stroke"]) if sw else None,
                   budget)
    if st.get("rot"):
        img = img.rotate(st["rot"], Image.BICUBIC, expand=True)
    if reveal is not None:
        return img
    return img.crop(img.getbbox()) if img.getbbox() else img


def _achievement(txt, fnt, fs, max_w, color, st, lang, reveal=None):
    Image, ImageDraw, ImageFilter, _Fo = _pil()
    small = font(int(fs * 0.55), "Poppins SemiBold")
    label = "SUCCÈS DÉBLOQUÉ" if lang == "fr" else "ACHIEVEMENT UNLOCKED"
    lines = _wrap(txt, fnt, max_w - fs * 2.6, 2)
    lh = int(fs * 1.15)
    tw = max([int(_measure(l, fnt)) for l in lines] + [int(small.getlength(label))])
    icon = int(fs * 1.9)
    pad = int(fs * 0.45)
    bw = pad + icon + pad + tw + pad * 2
    bh = max(icon + 2 * pad, int(small.size * 1.4) + lh * len(lines) + 2 * pad)
    m = int(fs * 0.3)
    img = Image.new("RGBA", (bw + 2 * m, bh + 2 * m), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    shadow = Image.new("RGBA", img.size, (0, 0, 0, 0))
    ImageDraw.Draw(shadow).rounded_rectangle((m, m + 4, m + bw, m + bh + 4), int(bh / 2), fill=(0, 0, 0, 130))
    img.alpha_composite(shadow.filter(ImageFilter.GaussianBlur(fs * 0.1)))
    bg = hex_rgba(_style_color(st, "bg", color), 238)
    d.rounded_rectangle((m, m, m + bw, m + bh), int(bh / 2), fill=bg, outline=(255, 210, 63, 255),
                        width=max(2, int(fs * 0.06)))
    cx, cy = m + pad + icon // 2, m + bh // 2
    d.ellipse((cx - icon // 2, cy - icon // 2, cx + icon // 2, cy + icon // 2), fill=(255, 210, 63, 255))
    em = emoji_image(emoji_code_of("🏆") or "1f3c6", int(icon * 0.68))
    if em is not None:
        img.alpha_composite(em, (cx - em.width // 2, cy - em.height // 2))
    x = m + pad + icon + pad
    y = m + (bh - (int(small.size * 1.4) + lh * len(lines))) // 2
    d.text((x, y), label, font=small, fill=(255, 210, 63, 255))
    y += int(small.size * 1.4)
    budget = [reveal] if reveal is not None else None
    for i, l in enumerate(lines):
        _draw_line(img, (x, y + i * lh - int(fs * 0.12)), l, fnt, hex_rgba(st["fill"]), budget=budget)
    return img


# Text stickers offered in the library (text, style, colour): what streamers and TikTok actually write
TEXT_PRESETS = [
    ("BRUH", "impact", None), ("SKILL ISSUE", "badge", "#E53935"), ("EMOTIONAL DAMAGE", "impact", None),
    ("+1000 AURA", "fire", None), ("-1000 AURA", "badge", "#2B2B33"), ("W", "badge", "#2EAD4B"),
    ("L", "badge", "#E53935"), ("RATIO", "badge", "#1D9BF0"), ("GG EZ", "neon", "#00E5FF"), ("SHEESH", "fire", None),
    ("NO WAY", "impact", None), ("BRO WHAT", "impact", None), ("WAIT WHAT", "comic", None),
    ("IT'S OVER", "badge", "#2B2B33"), ("WE'RE SO BACK", "neon", "#7CFF6B"), ("SIGMA", "glitch", None),
    ("CAUGHT IN 4K", "badge", "#E53935"), ("NPC", "glitch", None), ("COPIUM", "bubble", None),
    ("MAIN CHARACTER", "achievement", None), ("SUS", "badge", "#C51111"), ("BASED", "neon", "#FFD400"),
    ("CRINGE", "comic", None), ("LET'S GOOO", "fire", None), ("OUTPLAYED", "impact", None), ("CLUTCH", "fire", None),
    ("1 HP", "badge", "#E53935"), ("OOF", "comic", None), ("RIP", "impact", None), ("GAME OVER", "glitch", None),
    ("NOT LIKE THIS", "caption", None), ("POV :", "caption", None), ("Me when…", "caption", None),
    ("GOAT 🐐", "achievement", None), ("CHEH", "badge", "#E53935"), ("LE SEUM", "comic", "#7CFF6B"),
    ("C'EST CHAUD", "fire", None), ("LA DINGUERIE", "burst", "#FF7A00"), ("ZINZIN", "burst", None),
    ("🔴 CLIP IT", "badge", "#9146FF"),
]
TEXT_PRESETS_EN = {"LE SEUM": "SALTY", "C'EST CHAUD": "IT'S HEATED", "LA DINGUERIE": "INSANE", "ZINZIN": "CRAZY",
                   "CHEH": "GET REKT"}


# =========================================================================== graphic stickers

@functools.lru_cache(maxsize=1)
def stickers() -> list[dict]:
    """Built-in graphic stickers: [{"id", "fr", "en"}] (assets/stickers/<id>.png)."""
    import json
    try:
        return json.loads((STICKER_DIR / "index.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []


def sticker_path(name: str) -> Optional[Path]:
    p = STICKER_DIR / f"{name}.png"
    return p if p.is_file() else None


# =========================================================================== picture animations

ANIMS = ["pop", "bounce", "shake", "spin", "pulse", "float", "grow", "slide", "fade", "typewriter", "none"]
ANIM_NAMES = {"pop": ("Pop", "Pop"), "bounce": ("Rebond", "Bounce"), "shake": ("Tremble", "Shake"),
              "spin": ("Tourne", "Spin"), "pulse": ("Pulse", "Pulse"), "float": ("Monte", "Float up"),
              "grow": ("Grossit", "Grow"), "slide": ("Glisse", "Slide in"), "fade": ("Fondu", "Fade"),
              "typewriter": ("Machine à écrire", "Typewriter"), "none": ("Aucune", "None")}


def anim_state(anim: str, tt: float, dur: float, wobble: bool = False, fade_out: float = 0.18) -> tuple:
    """(scale, angle in degrees, alpha 0..1, dx, dy) of an animated picture at time tt of its life.
    dx / dy are fractions of the picture size."""
    s, ang, alpha, dx, dy = 1.0, 0.0, 1.0, 0.0, 0.0
    a = anim or "pop"
    if a == "pop":
        if tt < 0.22:
            s = 0.35 + 0.65 * ease_out_back(min(1.0, tt / 0.22))
        if wobble and tt < 1.4:
            ang = 7.0 * math.sin(2 * math.pi * 1.6 * tt) * math.exp(-2.2 * tt)
    elif a == "bounce":
        if tt < 0.9:
            u = tt / 0.9
            dy = -1.3 * abs(math.cos(u * math.pi * 2.5)) * (1 - u) ** 2
            s = 1.0 + 0.08 * (1 - u) * math.sin(u * math.pi * 5)
        if tt < 0.06:
            alpha = tt / 0.06
    elif a == "shake":
        ang = 9.0 * math.sin(2 * math.pi * 7.0 * tt)
        dx = 0.04 * math.sin(2 * math.pi * 11.0 * tt)
        if tt < 0.15:
            s = 0.6 + 0.4 * ease_out_back(tt / 0.15)
    elif a == "spin":
        ang = -360.0 * tt / 0.9
        if tt < 0.2:
            s = 0.3 + 0.7 * ease_out_back(tt / 0.2)
    elif a == "pulse":
        s = 1.0 + 0.12 * math.sin(2 * math.pi * 2.6 * tt)
        if tt < 0.18:
            s *= 0.4 + 0.6 * ease_out_back(tt / 0.18)
    elif a == "float":
        dy = -0.6 * tt / max(0.3, dur)
        alpha = min(1.0, tt / 0.25)
        fade_out = max(fade_out, 0.4)
    elif a == "grow":
        s = 0.25 + 1.0 * ease_in_out(tt / max(0.3, dur))
        alpha = min(1.0, tt / 0.15)
    elif a == "slide":
        if tt < 0.28:
            dx = -1.6 * (1 - ease_out_cubic(tt / 0.28))
    elif a == "fade":
        alpha = min(1.0, tt / 0.3)
        fade_out = max(fade_out, 0.3)
    elif a == "typewriter":
        pass
    if fade_out > 0 and tt > dur - fade_out:
        alpha = min(alpha, max(0.0, (dur - tt) / fade_out))
    return s, ang, alpha, dx, dy


def typewriter_count(text: str, tt: float) -> int:
    """How many characters of the text are shown at time tt (typewriter animation)."""
    return max(1, min(len(text), int(tt / 0.055) + 1))


# =========================================================================== animated effects

# kind of effect: "overlay" = pictures drawn on top | "filter" = colours of the video changed | both
EFFECTS: dict[str, dict] = {
    "explosion": {"icon": "💥", "fr": "Explosion", "en": "Explosion", "dur": 1.6, "sound": "sfx:explosion",
                  "overlay": True, "pos": True, "shake": True},
    "confetti": {"icon": "🎉", "fr": "Confettis", "en": "Confetti", "dur": 2.8, "sound": "sfx:canon-confettis",
                 "overlay": True},
    "emoji_rain": {"icon": "🌧", "fr": "Pluie d'emojis", "en": "Emoji rain", "dur": 3.0, "sound": "",
                   "overlay": True, "emoji": True},
    "hearts": {"icon": "💕", "fr": "Cœurs", "en": "Hearts", "dur": 2.8, "sound": "sfx:carillon", "overlay": True},
    "flash": {"icon": "⚡", "fr": "Flash blanc", "en": "White flash", "dur": 1.0, "sound": "sfx:sub-drop",
              "overlay": True},
    "camera": {"icon": "📸", "fr": "Photo (flash + arrêt)", "en": "Photo (flash + freeze)", "dur": 1.2,
               "sound": "sfx:appareil-photo", "overlay": True, "freeze": True},
    "fire": {"icon": "🔥", "fr": "Bordure de feu", "en": "Fire border", "dur": 2.6, "sound": "", "overlay": True},
    "crack": {"icon": "🪟", "fr": "Écran fissuré", "en": "Cracked screen", "dur": 2.4, "sound": "sfx:verre-brise",
              "overlay": True, "pos": True},
    "glitch": {"icon": "📺", "fr": "Glitch", "en": "Glitch", "dur": 0.9, "sound": "sfx:glitch", "overlay": True,
               "filter": True},
    "vhs": {"icon": "📼", "fr": "Cassette VHS", "en": "VHS tape", "dur": 3.0, "sound": "", "overlay": True,
            "filter": True},
    "tbc": {"icon": "⏩", "fr": "À suivre…", "en": "To be continued…", "dur": 2.8, "sound": "sfx:jingle-mystere",
            "overlay": True, "filter": True, "freeze": True, "text": True},
    "credits": {"icon": "🎬", "fr": "Générique de fin", "en": "End credits", "dur": 3.2, "sound": "sfx:jingle-rigolo",
                "overlay": True, "freeze": True, "text": True},
    "speed_lines": {"icon": "💨", "fr": "Lignes de vitesse", "en": "Speed lines", "dur": 1.4, "sound": "sfx:whoosh",
                    "overlay": True, "pos": True},
    "spotlight": {"icon": "🔦", "fr": "Projecteur", "en": "Spotlight", "dur": 2.2, "sound": "sfx:coup-suspense",
                  "overlay": True, "pos": True},
    "dramatic": {"icon": "🎭", "fr": "Dramatique (noir et blanc)", "en": "Dramatic (black & white)", "dur": 2.4,
                 "sound": "sfx:dun-dun-duuun", "overlay": True, "filter": True},
    "stars": {"icon": "💫", "fr": "Étoiles K.O.", "en": "K.O. stars", "dur": 2.4, "sound": "sfx:ressort",
              "overlay": True, "pos": True},
    "sparkles": {"icon": "✨", "fr": "Paillettes", "en": "Sparkles", "dur": 1.8, "sound": "sfx:paillettes",
                 "overlay": True, "pos": True},
}
EFFECT_ORDER = ["explosion", "confetti", "emoji_rain", "hearts", "flash", "camera", "fire", "crack", "glitch", "vhs",
                "tbc", "credits", "speed_lines", "spotlight", "dramatic", "stars", "sparkles"]
FREEZE_EFFECTS = {k for k, v in EFFECTS.items() if v.get("freeze")}
OV_SCALE = 0.5          # effect pictures are drawn at half size, then scaled up (they are soft anyway)


def effect_name(eid: str, lang: str = "fr") -> str:
    e = EFFECTS.get(eid) or {}
    return e.get(lang) or e.get("fr") or eid


def default_effect_text(eid: str, lang: str, streamer: str = "") -> str:
    if eid == "tbc":
        return "À suivre…" if lang == "fr" else "To be continued…"
    if eid == "credits":
        who = streamer or ("toi" if lang == "fr" else "you")
        return (f"Réalisé par\n{who}" if lang == "fr" else f"Directed by\n{who}")
    return ""


def _center(e: dict, game: tuple, sc: float) -> tuple[float, float]:
    gx, gy, gw, gh = game
    x = e.get("x") if e.get("x") is not None else 0.5
    y = e.get("y") if e.get("y") is not None else 0.5
    return (gx + float(x) * gw) * sc, (gy + float(y) * gh) * sc


@functools.lru_cache(maxsize=512)
def _disc(radius: int, rgba: tuple, soft: float = 0.6):
    """A round soft-edged blob (RGBA), for particles."""
    Image, ImageDraw, ImageFilter, _Fo = _pil()
    r = max(1, int(radius))
    pad = int(r * soft) + 2
    im = Image.new("RGBA", (2 * (r + pad), 2 * (r + pad)), (0, 0, 0, 0))
    ImageDraw.Draw(im).ellipse((pad, pad, pad + 2 * r, pad + 2 * r), fill=rgba)
    if soft > 0:
        im = im.filter(ImageFilter.GaussianBlur(r * soft * 0.5))
    return im


def _with_alpha(im, a: float):
    if a >= 0.995:
        return im
    if a <= 0.0:
        return None
    r, g, b, al = im.split()
    al = al.point(lambda v: int(v * a))
    Image, _D, _F, _Fo = _pil()
    return Image.merge("RGBA", (r, g, b, al))


def _put(canvas, im, cx: float, cy: float, alpha: float = 1.0) -> None:
    if im is None:
        return
    im = _with_alpha(im, alpha) if alpha < 0.995 else im
    if im is None:
        return
    x, y = int(cx - im.width / 2), int(cy - im.height / 2)
    if x >= canvas.width or y >= canvas.height or x + im.width <= 0 or y + im.height <= 0:
        return
    if x >= 0 and y >= 0 and x + im.width <= canvas.width and y + im.height <= canvas.height:
        canvas.alpha_composite(im, (x, y))
    else:
        tmp = canvas.crop((x, y, x + im.width, y + im.height))
        tmp.alpha_composite(im)
        canvas.paste(tmp, (x, y))


@functools.lru_cache(maxsize=64)
def _rotated_emoji(code: str, px: int, ang: int):
    em = emoji_image(code, px)
    if em is None:
        return None
    if ang:
        Image, _D, _F, _Fo = _pil()
        em = em.rotate(ang, Image.BICUBIC, expand=True)
    return em


def _global_fade(tt: float, dur: float, fin: float = 0.12, fout: float = 0.35) -> float:
    a = 1.0
    if fin > 0 and tt < fin:
        a = tt / fin
    if fout > 0 and tt > dur - fout:
        a = min(a, max(0.0, (dur - tt) / fout))
    return a


def effect_frame(e: dict, tt: float, dur: float, W: int, H: int, game: tuple, lang: str = "fr",
                 scale: float = OV_SCALE):
    """The overlay picture of an animated effect at time tt (0..dur): a transparent RGBA picture of
    (W * scale) x (H * scale), to be stretched to W x H. None when there is nothing to draw."""
    Image, ImageDraw, ImageFilter, _Fo = _pil()
    eid = e.get("effect") or ""
    sw, sh = max(2, int(W * scale)), max(2, int(H * scale))
    m = min(sw, sh)
    size = float(e.get("size") or 1.0)
    rnd = random.Random(seed_of(e.get("id", ""), eid))
    cv = Image.new("RGBA", (sw, sh), (0, 0, 0, 0))
    cx, cy = _center(e, game, scale)
    if eid == "explosion":
        R = m * 0.28 * size
        if tt < 0.3:
            u = tt / 0.3
            _put(cv, _disc(int(R * (0.25 + 0.9 * u)), (255, 250, 220, 255), 0.5), cx, cy, 1 - u * 0.7)
        u = min(1.0, tt / 0.55)
        fade = max(0.0, 1 - tt / dur) ** 1.2
        for k, (col, rr) in enumerate((((255, 80, 10, 255), 1.0), ((255, 150, 30, 255), 0.78), ((255, 220, 90, 255), 0.52),
                                       ((255, 252, 225, 255), 0.26))):
            r = int(R * rr * (0.35 + 0.8 * ease_out_cubic(u)))
            _put(cv, _disc(max(2, r // 4 * 4), col, 0.4), cx, cy - R * 0.25 * tt, fade * (1.0 if k else 0.85))
        for _ in range(16):
            a = rnd.uniform(0, 2 * math.pi)
            sp = rnd.uniform(0.3, 1.0) * R * 1.6
            age = tt
            px = cx + math.cos(a) * sp * ease_out_cubic(min(1, age / 0.9))
            py = cy + math.sin(a) * sp * ease_out_cubic(min(1, age / 0.9)) - R * 0.5 * age
            rr = int(R * rnd.uniform(0.18, 0.32) * (0.6 + 0.6 * min(1.0, age / 0.8)))
            g = rnd.randint(60, 110)
            _put(cv, _disc(max(2, rr // 3 * 3), (g, g, g, 255), 0.8), px, py, 0.55 * max(0.0, 1 - age / dur) * min(1, age / 0.15))
        for _ in range(34):
            a = rnd.uniform(0, 2 * math.pi)
            sp = rnd.uniform(0.8, 2.2) * R
            vx, vy = math.cos(a) * sp, math.sin(a) * sp - R * 0.8
            px = cx + vx * tt
            py = cy + vy * tt + R * 2.4 * tt * tt
            rr = max(1, int(R * rnd.uniform(0.02, 0.05)))
            col = rnd.choice([(255, 200, 60, 255), (255, 120, 30, 255), (255, 240, 180, 255)])
            _put(cv, _disc(rr, col, 0.3), px, py, max(0.0, 1 - tt / (dur * 0.8)))
        return cv
    if eid == "confetti":
        pal = [(255, 64, 96), (255, 210, 63), (62, 207, 142), (0, 180, 255), (169, 112, 255), (255, 140, 40)]
        d = ImageDraw.Draw(cv)
        g = sh * 1.5
        n = int(130 * min(2.0, size))
        for i in range(n):
            left = i % 2 == 0
            x0 = sw * (0.02 if left else 0.98)
            y0 = sh * 1.02
            vx = (1 if left else -1) * sw * rnd.uniform(0.08, 1.05)
            vy = -sh * rnd.uniform(0.8, 1.9)
            delay = rnd.uniform(0, 0.3)
            t = tt - delay
            if t < 0:
                continue
            drag = math.exp(-1.2 * t)
            px = x0 + vx * (1 - drag) / 1.2
            py = y0 + vy * (1 - drag) / 1.2 + 0.5 * g * t * t * 0.55
            if py > sh + 20:
                continue
            ang = rnd.uniform(0, math.pi) + t * rnd.uniform(4, 12)
            flip = abs(math.cos(t * rnd.uniform(6, 14)))
            w2, h2 = m * 0.011 * (0.35 + flip), m * 0.02
            ca, sa = math.cos(ang), math.sin(ang)
            pts = [(px + ca * dx - sa * dy, py + sa * dx + ca * dy) for dx, dy in ((-w2, -h2), (w2, -h2), (w2, h2), (-w2, h2))]
            d.polygon(pts, fill=pal[i % len(pal)] + (255,))
        return _fade_all(cv, _global_fade(tt, dur, 0.0, 0.5))
    if eid in ("emoji_rain", "hearts"):
        code = (e.get("file") or "").split(":", 1)[-1] if eid == "emoji_rain" else ""
        codes = [code or "1f480"] if eid == "emoji_rain" else [emoji_code_of(c) or "2764-fe0f" for c in ("❤️", "💖", "💕", "❤️")]
        n = int((24 if eid == "emoji_rain" else 20) * min(2.0, size))
        for i in range(n):
            c = codes[i % len(codes)]
            px_size = int(m * rnd.uniform(0.08, 0.13) * (0.8 + 0.4 * min(1.5, size)))
            px_size = max(8, px_size // 4 * 4)
            delay = rnd.uniform(0, dur * 0.45)
            t = tt - delay
            if t < 0:
                continue
            x = rnd.uniform(0.04, 0.96) * sw
            if eid == "emoji_rain":
                speed = sh * rnd.uniform(0.55, 1.0)
                y = -px_size + speed * t
                x += math.sin(t * 2 + i) * px_size * 0.3
                ang = int(round(25 * math.sin(t * 3 + i) / 10)) * 10
            else:
                speed = sh * rnd.uniform(0.25, 0.5)
                y = sh + px_size - speed * t
                x += math.sin(t * 3 + i) * px_size * 0.6
                ang = int(round(15 * math.sin(t * 2.5 + i) / 5)) * 5
            if y < -px_size * 2 or y > sh + px_size * 2:
                continue
            _put(cv, _rotated_emoji(c, px_size, ang), x, y, _global_fade(tt, dur, 0.0, 0.4))
        return cv
    if eid == "flash":
        a = (1 - tt / dur) ** 1.6
        return Image.new("RGBA", (sw, sh), (255, 255, 255, int(255 * a)))
    if eid == "camera":
        if tt > 0.35:
            return None
        a = (1 - tt / 0.35) ** 1.4
        return Image.new("RGBA", (sw, sh), (255, 255, 255, int(255 * a)))
    if eid == "fire":
        d = ImageDraw.Draw(cv)
        base_h = sh * 0.17 * size
        a = _global_fade(tt, dur, 0.25, 0.5)
        for layer, (col, hs) in enumerate((((200, 30, 10), 1.0), ((255, 110, 20), 0.75), ((255, 210, 60), 0.45))):
            pts = [(0, sh)]
            nx = 40
            for k in range(nx + 1):
                x = sw * k / nx
                n_ = (math.sin(k * 1.7 + tt * 9 + layer) * 0.5 + math.sin(k * 0.6 - tt * 6.5) * 0.35
                      + math.sin(k * 3.1 + tt * 13) * 0.25)
                h = base_h * hs * (0.75 + 0.35 * n_) * (1.0 if k % 2 == 0 else 0.55)
                pts.append((x, sh - h))
            pts.append((sw, sh))
            d.polygon(pts, fill=col + (230,))
        glow = cv.filter(ImageFilter.GaussianBlur(m * 0.012))
        out = Image.new("RGBA", (sw, sh), (0, 0, 0, 0))
        out.alpha_composite(glow)
        out.alpha_composite(cv)
        return _fade_all(out, a)
    if eid == "crack":
        a = _global_fade(tt, dur, 0.0, 0.45)
        grow = min(1.0, tt / 0.12)
        d = ImageDraw.Draw(cv)
        L = m * 0.6 * size
        k = m / 540.0
        _put(cv, _disc(max(2, int(m * 0.03 * size) // 2 * 2), (255, 255, 255, 120), 0.9), cx, cy)
        for pts, wid, late in _crack_lines(rnd, cx, cy, L):
            if late and grow < 0.75:
                continue
            n_ = len(pts) if late else max(2, int(round(len(pts) * grow)))
            seg = pts[:n_]
            w_ = max(1, int(round(wid * k)))
            d.line([(x + max(1, w_ // 2), y + max(1, w_ // 2)) for x, y in seg], fill=(0, 0, 0, 120), width=w_,
                   joint="curve")
            d.line(seg, fill=(255, 255, 255, 235), width=w_, joint="curve")
        r = m * 0.013 * size
        shard = [(cx + math.cos(t_) * r * rnd.uniform(0.6, 1.3), cy + math.sin(t_) * r * rnd.uniform(0.6, 1.3))
                 for t_ in [2 * math.pi * j / 7 for j in range(7)]]
        d.polygon(shard, fill=(255, 255, 255, 230))
        return _fade_all(cv, a)
    if eid == "glitch":
        frame = int(tt * 30)
        r2 = random.Random(seed_of(e.get("id", ""), frame))
        d = ImageDraw.Draw(cv)
        for _ in range(r2.randint(2, 6)):
            y = r2.uniform(0, sh)
            h = r2.uniform(sh * 0.005, sh * 0.03)
            col = r2.choice([(255, 0, 80), (0, 230, 255), (255, 255, 255), (60, 255, 120)])
            xa = r2.uniform(-sw * 0.2, sw * 0.5)
            d.rectangle((xa, y, xa + r2.uniform(sw * 0.2, sw * 0.9), y + h), fill=col + (r2.randint(60, 150),))
        return cv
    if eid == "vhs":
        a = _global_fade(tt, dur, 0.1, 0.3)
        d = ImageDraw.Draw(cv)
        step = max(2, int(sh / 240))
        for y in range(0, sh, step * 2):
            d.line([(0, y), (sw, y)], fill=(0, 0, 0, 45))
        band_y = (tt * 0.35 % 1.0) * sh
        r2 = random.Random(seed_of(e.get("id", ""), int(tt * 30)))
        for _ in range(int(sw / 6)):
            x = r2.uniform(0, sw)
            yy = band_y + r2.uniform(-sh * 0.02, sh * 0.02)
            d.line([(x, yy), (x + r2.uniform(2, 12), yy)], fill=(255, 255, 255, r2.randint(60, 160)))
        f = font(int(m * 0.045), "Poppins SemiBold")
        play = "▶ PLAY" if int(tt * 2) % 2 == 0 or tt > 1.0 else ""
        d.text((sw * 0.06 + 2, sh * 0.06 + 2), "PLAY", font=f, fill=(0, 0, 0, 160))
        d.text((sw * 0.06, sh * 0.06), "PLAY", font=f, fill=(255, 255, 255, 230))
        if play:
            tri = int(m * 0.03)
            x0, y0 = sw * 0.06 + f.getlength("PLAY ") + 4, sh * 0.06 + f.size * 0.25
            d.polygon([(x0, y0), (x0, y0 + tri), (x0 + tri * 0.9, y0 + tri / 2)], fill=(255, 255, 255, 230))
        d.text((sw * 0.06, sh * 0.9), "AM 12:00", font=f, fill=(255, 255, 255, 220))
        return _fade_all(cv, a)
    if eid == "tbc":
        u = ease_out_cubic(min(1.0, max(0.0, (tt - 0.15) / 0.45)))
        text = e.get("text") or default_effect_text("tbc", lang)
        f = font(int(m * 0.085 * size), "Bangers")
        tw = f.getlength(text)
        bw, bh = tw + m * 0.2, m * 0.15 * size
        x1 = sw * 0.05 + bw
        x0 = x1 - bw - (1 - u) * (bw + sw * 0.1)
        y1 = sh * (0.775 if sh > sw else 0.9)        # 9:16: above the watermark
        y0 = y1 - bh
        d = ImageDraw.Draw(cv)
        tip = bh * 0.55
        pts = [(x0, y0), (x0 + bw - tip, y0), (x0 + bw, (y0 + y1) / 2), (x0 + bw - tip, y1), (x0, y1)]
        d.polygon([(x + 3, y + 3) for x, y in pts], fill=(0, 0, 0, 120))
        d.polygon(pts, fill=(70, 46, 24, 240), outline=(240, 200, 120, 255))
        d.text((x0 + m * 0.04, y0 + (bh - f.size * 1.15) / 2), text, font=f, fill=(250, 226, 160, 255))
        return cv
    if eid == "credits":
        a = min(1.0, tt / 0.35)
        cv = Image.new("RGBA", (sw, sh), (0, 0, 0, int(255 * a)))
        text = e.get("text") or default_effect_text("credits", lang)
        lines = [l for l in text.split("\n") if l.strip()] or [" "]
        d = ImageDraw.Draw(cv)
        sizes = [0.06] + [0.11] * (len(lines) - 1) if len(lines) > 1 else [0.11]
        ys = []
        total_h = 0
        fonts_ = []
        for k, l in enumerate(lines):
            f = font(int(m * sizes[min(k, len(sizes) - 1)] * size), "Poppins SemiBold" if k == 0 and len(lines) > 1
                     else "Poppins ExtraBold")
            fonts_.append(f)
            ys.append(total_h)
            total_h += int(f.size * 1.45)
        y0 = (sh - total_h) / 2
        ta = min(1.0, max(0.0, (tt - 0.35) / 0.4))
        for k, l in enumerate(lines):
            f = fonts_[k]
            d.text(((sw - f.getlength(l)) / 2, y0 + ys[k]), l, font=f, fill=(255, 255, 255, int(255 * ta)))
        return cv
    if eid == "speed_lines":
        a = _global_fade(tt, dur, 0.1, 0.3)
        frame = int(tt * 24)
        r2 = random.Random(seed_of(e.get("id", ""), frame))
        d = ImageDraw.Draw(cv)
        R0 = m * 0.22 * size
        Rmax = math.hypot(sw, sh)
        for _ in range(70):
            ang = r2.uniform(0, 2 * math.pi)
            wid = r2.uniform(0.004, 0.012)
            r_in = R0 * r2.uniform(1.0, 1.8)
            p1 = (cx + math.cos(ang) * r_in, cy + math.sin(ang) * r_in)
            p2 = (cx + math.cos(ang - wid) * Rmax, cy + math.sin(ang - wid) * Rmax)
            p3 = (cx + math.cos(ang + wid) * Rmax, cy + math.sin(ang + wid) * Rmax)
            d.polygon([p1, p2, p3], fill=(255, 255, 255, r2.randint(120, 220)))
        return _fade_all(cv, a)
    if eid == "spotlight":
        a = _global_fade(tt, dur, 0.25, 0.3)
        return _fade_all(_spot_mask(sw, sh, int(cx), int(cy), int(m * 0.2 * size)), a)
    if eid == "dramatic":
        a = _global_fade(tt, dur, 0.3, 0.3)
        return _fade_all(_vignette(sw, sh), a)
    if eid == "stars":
        a = _global_fade(tt, dur, 0.2, 0.35)
        rx = m * 0.13 * size
        ry = rx * 0.35
        code = emoji_code_of("⭐") or "2b50"
        items = []
        for k in range(5):
            ang = 2 * math.pi * (k / 5 + tt * 0.6)
            px, py = cx + math.cos(ang) * rx, cy - m * 0.08 * size + math.sin(ang) * ry
            depth = (math.sin(ang) + 1) / 2
            items.append((depth, px, py))
        for depth, px, py in sorted(items):
            s = int(m * 0.085 * size * (0.7 + 0.5 * depth)) // 2 * 2
            _put(cv, emoji_image(code, max(8, s)), px, py, a)
        return cv
    if eid == "sparkles":
        R = m * 0.2 * size
        d = ImageDraw.Draw(cv)
        for i in range(32):
            t0 = rnd.uniform(0, dur * 0.7)
            life = rnd.uniform(0.45, 0.9)
            u = (tt - t0) / life
            if not 0 <= u <= 1:
                continue
            ang = rnd.uniform(0, 2 * math.pi)
            dist = R * math.sqrt(rnd.random())
            px, py = cx + math.cos(ang) * dist, cy + math.sin(ang) * dist
            s = m * rnd.uniform(0.02, 0.05) * size * math.sin(math.pi * u)
            col = rnd.choice([(255, 255, 255), (255, 236, 140), (255, 210, 63)])
            _sparkle(d, px, py, s, col)
        glow = cv.filter(ImageFilter.GaussianBlur(m * 0.006))
        out = Image.new("RGBA", (sw, sh), (0, 0, 0, 0))
        out.alpha_composite(glow)
        out.alpha_composite(cv)
        return out
    return None


def _fade_all(im, a: float):
    if a >= 0.995:
        return im
    if a <= 0:
        Image, _D, _F, _Fo = _pil()
        return Image.new("RGBA", im.size, (0, 0, 0, 0))
    return _with_alpha(im, a)


def _sparkle(d, x: float, y: float, s: float, col) -> None:
    if s <= 0.5:
        return
    w = s * 0.22
    d.polygon([(x, y - s), (x + w, y - w), (x + s, y), (x + w, y + w), (x, y + s), (x - w, y + w), (x - s, y),
               (x - w, y - w)], fill=col + (255,))


def _point_at(pts: list, dist: float):
    """The point at distance dist along a polyline (None past its end)."""
    for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
        L = math.hypot(x1 - x0, y1 - y0)
        if dist <= L:
            u = dist / max(1e-6, L)
            return x0 + (x1 - x0) * u, y0 + (y1 - y0) * u
        dist -= L
    return None


def _crack_lines(rnd, cx: float, cy: float, L: float) -> list:
    """Shattered glass: straight cracks going out of the impact, a few branches, and broken rings joining
    them (the spider web of a broken screen). [(points, width, late)] - late ones (branches, rings) show up
    once the main cracks have grown."""
    out = []
    n = rnd.randint(9, 13)
    base = rnd.uniform(0, 2 * math.pi)
    rays = []
    for k in range(n):
        ang = base + 2 * math.pi * k / n + rnd.uniform(-0.2, 0.2)
        length = L * rnd.uniform(0.5, 1.0)
        segs = rnd.randint(4, 7)
        x, y = cx, cy
        pts = [(x, y)]
        for i in range(segs):
            ang += rnd.uniform(-0.13, 0.13)
            step = length / segs * rnd.uniform(0.7, 1.3)
            x += math.cos(ang) * step
            y += math.sin(ang) * step
            pts.append((x, y))
            if i >= 1 and rnd.random() < 0.3:
                bang = ang + rnd.choice([-1, 1]) * rnd.uniform(0.35, 0.8)
                bx, by = x, y
                bpts = [(bx, by)]
                for _ in range(rnd.randint(1, 3)):
                    bang += rnd.uniform(-0.15, 0.15)
                    bl = step * rnd.uniform(0.5, 0.9)
                    bx += math.cos(bang) * bl
                    by += math.sin(bang) * bl
                    bpts.append((bx, by))
                out.append((bpts, 1.4, True))
        rays.append(pts)
        out.append((pts, 2.6 if k % 3 == 0 else 2.0, False))
    for ring_r in (0.09, 0.22, 0.42):
        for k in range(n):
            if rnd.random() < 0.3:
                continue
            p = _point_at(rays[k], L * ring_r * rnd.uniform(0.85, 1.15))
            q = _point_at(rays[(k + 1) % n], L * ring_r * rnd.uniform(0.85, 1.15))
            if p is None or q is None:
                continue
            mid = ((p[0] + q[0]) / 2 + rnd.uniform(-1, 1) * L * 0.015,
                   (p[1] + q[1]) / 2 + rnd.uniform(-1, 1) * L * 0.015)
            out.append(([p, mid, q], 1.4, True))
    return out


@functools.lru_cache(maxsize=16)
def _spot_mask(w: int, h: int, cx: int, cy: int, r: int):
    Image, ImageDraw, ImageFilter, _Fo = _pil()
    mask = Image.new("L", (w, h), 200)
    ImageDraw.Draw(mask).ellipse((cx - r, cy - r, cx + r, cy + r), fill=0)
    mask = mask.filter(ImageFilter.GaussianBlur(max(2, r * 0.25)))
    im = Image.new("RGBA", (w, h), (0, 0, 0, 255))
    im.putalpha(mask)
    return im


@functools.lru_cache(maxsize=8)
def _vignette(w: int, h: int):
    Image, ImageDraw, ImageFilter, _Fo = _pil()
    mask = Image.new("L", (w, h), 230)
    ImageDraw.Draw(mask).ellipse((-w * 0.15, -h * 0.05, w * 1.15, h * 1.05), fill=0)
    mask = mask.filter(ImageFilter.GaussianBlur(min(w, h) * 0.12))
    im = Image.new("RGBA", (w, h), (0, 0, 0, 255))
    im.putalpha(mask)
    return im


def effect_filters(eid: str, W: int) -> str:
    """ffmpeg filters changing the colours of the video during an effect (without the enable part)."""
    k = max(2, int(W / 135))
    if eid == "glitch":
        return f"rgbashift=rh=-{k}:bh={k}:gv={k // 2},noise=alls=45:allf=t"
    if eid == "vhs":
        return f"rgbashift=rh=-{max(1, k // 3)}:bh={max(1, k // 3)},noise=alls=16:allf=t,eq=saturation=0.75:contrast=1.06"
    if eid == "tbc":
        return "colorchannelmixer=.393:.769:.189:0:.349:.686:.168:0:.272:.534:.131,eq=contrast=1.08"
    if eid == "dramatic":
        return "hue=s=0,eq=contrast=1.25"
    return ""
