"""Subtitles drawn with Pillow (for the Studio live preview), the way libass draws them in the export:
same fonts, sizes, outline, shadow, glow, box, highlight colour and line breaks (see subtitles.layout)."""
from __future__ import annotations

import functools
import struct
from typing import Optional

from . import fxlib, paths
from .subtitles import SubEvent, SubLook

SHADOW_ALPHA = 255 - 0x90          # BackColour &H90000000 of the subtitles
TITLE_SHADOW_ALPHA = 255 - 0xA0    # BackColour &HA0000000 of the title


@functools.lru_cache(maxsize=16)
def _metrics(font_name: str) -> tuple[int, int, int]:
    """(units per em, Windows ascent, Windows descent) of a font file: libass sizes a font so that
    ascent + descent = the font size (like Windows), Pillow sizes the em square."""
    path = paths.ASSETS / "fonts" / fxlib.FONT_FILES.get(font_name, "Montserrat-ExtraBold.ttf")
    try:
        data = path.read_bytes()
        n = struct.unpack(">H", data[4:6])[0]
        tables = {}
        for i in range(n):
            tag, _chk, off, ln = struct.unpack(">4sIII", data[12 + 16 * i: 28 + 16 * i])
            tables[tag] = (off, ln)
        off = tables[b"head"][0]
        upm = struct.unpack(">H", data[off + 18: off + 20])[0]
        off = tables[b"OS/2"][0]
        win_asc, win_desc = struct.unpack(">HH", data[off + 74: off + 78])
        if win_asc + win_desc > 0:
            return upm, win_asc, win_desc
    except (OSError, KeyError, struct.error):
        pass
    return 1000, 900, 250


class _Face:
    """A font at a libass size: the Pillow font, ascent / descent in pixels."""

    def __init__(self, font_name: str, ass_size: float):
        upm, wa, wd = _metrics(font_name)
        k = ass_size / float(wa + wd)
        self.asc = wa * k
        self.desc = wd * k
        self.height = ass_size
        self.font = fxlib.font(max(6, int(round(upm * k))), font_name)

    def width(self, text: str, spacing: float = 0.0) -> float:
        if not text:
            return 0.0
        return self.font.getlength(text) + spacing * len(text)


def _wrap(words: list[str], face: _Face, max_w: float, spacing: float) -> list[list[int]]:
    """Indexes of the words of each line: libass "smart" wrapping (WrapStyle 0: lines evenly broken,
    the top one wider)."""
    if not words:
        return [[]]
    space = face.width(" ", spacing)
    widths = [face.width(w, spacing) for w in words]
    lines: list[list[int]] = []
    cur: list[int] = []
    cw = 0.0
    for i, w in enumerate(widths):
        add = w if not cur else space + w
        if cur and cw + add > max_w:
            lines.append(cur)
            cur, cw = [i], w
        else:
            cur.append(i)
            cw += add
    lines.append(cur)
    if len(lines) == 2:
        idx = lines[0] + lines[1]
        best, best_k = None, len(lines[0])
        for k in range(1, len(idx)):
            w1 = sum(widths[j] for j in idx[:k]) + space * (k - 1)
            w2 = sum(widths[j] for j in idx[k:]) + space * (len(idx) - k - 1)
            if w1 > max_w or w2 > max_w:
                continue
            score = abs(w1 - w2) + (0.0 if w1 >= w2 else 0.5)
            if best is None or score < best:
                best, best_k = score, k
        lines = [idx[:best_k], idx[best_k:]]
    return lines


def _hex(c: Optional[str], alpha: int = 255) -> tuple:
    return fxlib.hex_rgba(c or "#FFFFFF", alpha)


def event_picture(lk: SubLook, ev: SubEvent):
    """The subtitle card (or the title) as an RGBA picture whose centre is the anchor point of the
    line (\\pos of the ASS file), before the pop / rotation / fade of the event."""
    Image, ImageDraw, ImageFilter, _Fo = fxlib._pil()
    title = ev.title
    face = _Face(lk.font, lk.tsize if title else lk.size)
    spacing = 0.0 if title else float(lk.spacing)
    outline = lk.toutline if title else lk.outline
    shadow = lk.tshadow if title else lk.shadow
    max_w = lk.width - (2 * lk.tmargin if title else 120)
    words = ev.words if not title else ev.words[0].split()
    lines = _wrap(words, face, max_w, spacing)
    space = face.width(" ", spacing)
    n = len(lines)
    block_h = face.height * n
    # each line: (y of the baseline relative to the anchor, x of its left end, [(word index, x)])
    placed = []
    for li, idx in enumerate(lines):
        lw = sum(face.width(words[j], spacing) for j in idx) + space * max(0, len(idx) - 1)
        x = -lw / 2
        base = -block_h / 2 + li * face.height + face.asc
        items = []
        for j in idx:
            items.append((j, x))
            x += face.width(words[j], spacing) + space
        placed.append((base, -lw / 2, lw, items))
    glow_r = (lk.glow_blur * 0.85 * 3 + lk.glow_bord) if (lk.glow and not title) else 0
    pad = int(outline + abs(shadow) + lk.box_pad + glow_r + lk.blur * 3 + 6)
    half_w = int(max([pl[2] / 2 for pl in placed] + [1]) + pad)
    half_h = int(block_h / 2 + pad)
    W2, H2 = 2 * half_w, 2 * half_h
    ox, oy = half_w, half_h

    def word_runs(target, color_of, stroke_w: int, stroke_c, dx: float = 0.0, dy: float = 0.0,
                  fill_override=None) -> None:
        d = ImageDraw.Draw(target)
        for base, _x0, _lw, items in placed:
            for j, x in items:
                col = color_of(j)
                if col is None:             # "reveal": not said yet (keeps its room, like \alpha&HFF&)
                    continue
                if fill_override is not None:
                    col = fill_override
                w = words[j]
                if spacing:
                    for ci, ch in enumerate(w):
                        cx = x + face.font.getlength(w[:ci]) + spacing * ci
                        d.text((ox + cx + dx, oy + base + dy), ch, font=face.font, fill=col, anchor="ls",
                               stroke_width=stroke_w, stroke_fill=stroke_c)
                else:
                    d.text((ox + x + dx, oy + base + dy), w, font=face.font, fill=col, anchor="ls",
                           stroke_width=stroke_w, stroke_fill=stroke_c)

    def color_of(j: int):
        if title:
            return (255, 255, 255, 255)
        if ev.hidden_from is not None and j >= ev.hidden_from:
            return None
        if ev.color:
            return _hex(ev.color)
        if ev.hi is not None and j == ev.hi:
            return _hex(lk.hi)
        return _hex(lk.color)

    out = Image.new("RGBA", (W2, H2), (0, 0, 0, 0))
    ocol = (0, 0, 0, 255) if title else _hex(lk.outline_color)
    # glow (fire style): a wide blurred border in the glow colour behind the words
    if lk.glow and not title:
        layer = Image.new("RGBA", (W2, H2), (0, 0, 0, 0))
        gc = _hex(lk.glow)
        word_runs(layer, color_of, max(1, lk.glow_bord), gc, fill_override=gc)
        layer = layer.filter(ImageFilter.GaussianBlur(lk.glow_blur * 0.85))
        out.alpha_composite(layer)
    # box behind each line (box style)
    if lk.box is not None and not title:
        d = ImageDraw.Draw(out)
        bc = _hex(lk.outline_color, 255 - int(lk.box))
        for base, x0, lw, _items in placed:
            top = base - face.asc
            d.rectangle((ox + x0 - lk.box_pad, oy + top - lk.box_pad, ox + x0 + lw + lk.box_pad,
                         oy + top + face.height + lk.box_pad), fill=bc)
    # shadow: the outlined words, shifted, half transparent
    if shadow:
        layer = Image.new("RGBA", (W2, H2), (0, 0, 0, 0))
        word_runs(layer, color_of, outline, (0, 0, 0, 255), shadow, shadow, fill_override=(0, 0, 0, 255))
        a = layer.split()[3].point(lambda v: v * (TITLE_SHADOW_ALPHA if title else SHADOW_ALPHA) // 255)
        layer.putalpha(a)
        out.alpha_composite(layer)
    # outline, then the words on top (two passes: the outline of a letter never covers its neighbour)
    if outline:
        layer = Image.new("RGBA", (W2, H2), (0, 0, 0, 0))
        word_runs(layer, color_of, outline, ocol, fill_override=ocol)
        if lk.blur and not title:
            layer = layer.filter(ImageFilter.GaussianBlur(lk.blur * 0.85))
        out.alpha_composite(layer)
    word_runs(out, color_of, 0, None)
    return out


class SubtitlePainter:
    """Pictures of the subtitle events (cached), and how they show at a given time."""

    def __init__(self, look: Optional[SubLook], events: list):
        self.look = look
        self.events = sorted(events, key=lambda e: (e.start, e.title))
        self._cache: dict[int, object] = {}

    def active(self, o: float) -> list[tuple[int, SubEvent]]:
        return [(i, ev) for i, ev in enumerate(self.events) if ev.start - 1e-6 <= o < ev.end]

    def picture(self, i: int):
        if i not in self._cache:
            if len(self._cache) > 160:
                self._cache.clear()
            self._cache[i] = event_picture(self.look, self.events[i])
        return self._cache[i]

    def state(self, ev: SubEvent, o: float) -> tuple[float, float, float, float, float]:
        """(x, y, scale, angle in degrees counter-clockwise, alpha) of an event at clip time o."""
        lk = self.look
        if ev.title:
            a = min(1.0, max(0.0, (o - ev.start) / 0.15))
            return lk.x, lk.ty, 1.0, 0.0, a
        s = 1.0
        if lk.pop and ev.first:
            u = (o - ev.start) / 0.09
            s = 1.12 - 0.12 * min(1.0, max(0.0, u))
        a = 1.0
        if ev.fade:
            a = min(1.0, max(0.0, (o - ev.start) / 0.06), max(0.0, (ev.end - o) / 0.06))
        return lk.x, lk.y, s, lk.rot, a
