"""Streamers handled by FireClips (it is not only for one channel): each one has its own
watermark, logo, subtitle style, intro / outro and automatic mode switch."""
from __future__ import annotations

import copy
import re
from typing import Optional

STREAMER_DEFAULTS: dict = {
    "login": "",          # Twitch channel (login)
    "name": "",           # how the streamer is called (AI titles, kill cards)
    "auto": True,         # automatic mode watches this channel
    "wm_on": True,        # watermark on the clips
    "wm_text": "",        # "" = twitch.tv/<login>
    "wm_logo": "",        # optional picture next to the text
    "wm_pos": "auto",     # auto | tl | tc | tr | bl | bc | br
    "wm_opacity": 85,     # %
    "wm_size": 100,       # %
    "sub_style": "",      # "" = the general setting
    "intro": "",          # video or picture played before each clip
    "outro": "",          # ... and after
}

_LOGIN_RE = re.compile(r"^[a-z0-9_]{2,25}$")


def clean_streamer(s) -> Optional[dict]:
    if not isinstance(s, dict):
        return None
    out = copy.deepcopy(STREAMER_DEFAULTS)
    for k, dv in STREAMER_DEFAULTS.items():
        if k not in s:
            continue
        v = s[k]
        if isinstance(dv, bool):
            out[k] = bool(v)
        elif isinstance(dv, int):
            try:
                out[k] = int(float(v))
            except (TypeError, ValueError):
                pass
        else:
            out[k] = "" if v is None else str(v).strip()
    out["login"] = out["login"].lstrip("@").lower()
    if out["login"] and not _LOGIN_RE.match(out["login"]):
        m = re.search(r"twitch\.tv/([A-Za-z0-9_]{2,25})", out["login"])
        out["login"] = m.group(1).lower() if m else re.sub(r"[^a-z0-9_]", "", out["login"])[:25]
    out["wm_opacity"] = max(10, min(100, out["wm_opacity"]))
    out["wm_size"] = max(40, min(250, out["wm_size"]))
    if out["wm_pos"] not in ("auto", "tl", "tc", "tr", "bl", "bc", "br"):
        out["wm_pos"] = "auto"
    if not out["login"] and not out["name"]:
        return None
    return out


def streamers(cfg) -> list[dict]:
    """The streamers list (the channel of the automatic mode of FireClips 1.0/1.1 becomes the first)."""
    raw = cfg.get("streamers") or []
    out = [x for x in (clean_streamer(s) for s in raw) if x]
    if not out:
        ch = (cfg.get("channel") or "").strip().lower()
        if ch:
            out = [clean_streamer({"login": ch, "name": cfg.get("streamer_name") or ch})]
    return [s for s in out if s]


def find(cfg, login: str) -> Optional[dict]:
    login = (login or "").strip().lower()
    for s in streamers(cfg):
        if s["login"] and s["login"] == login:
            return s
    return None


def for_vod(cfg, meta: dict) -> dict:
    """The profile used to dress a clip of this VOD."""
    login = str((meta or {}).get("login") or "").lower()
    s = find(cfg, login) if login else None
    if s is None:
        if login:
            s = clean_streamer({"login": login, "name": (meta or {}).get("display_name") or login})
        else:
            lst = streamers(cfg)
            s = lst[0] if lst else copy.deepcopy(STREAMER_DEFAULTS)
    return s


def watermark_text(prof: dict) -> str:
    if not prof or not prof.get("wm_on", True):
        return ""
    t = (prof.get("wm_text") or "").strip()
    if t:
        return t
    return f"twitch.tv/{prof['login']}" if prof.get("login") else ""


def display_name(prof: dict, meta: Optional[dict] = None) -> str:
    return (prof or {}).get("name") or (meta or {}).get("display_name") or (prof or {}).get("login") or ""
