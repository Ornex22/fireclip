"""The meme bank: a folder of sounds, pictures, videos and music the user fills with their own memes, plus the
real memes FireClips downloads from the internet on the first start (see memebank.py) and the emojis.

References stored in a clip edit list:
    "bank:Sons/vine.mp3"            a file of the bank folder (relative path)
    "web:sound/vine-boom-sound-70972" a meme downloaded from the internet (memebank/)
    "emoji:1f602"                   a built-in emoji picture (assets/emoji/1f602.webp)
    "C:\\...\\file.png"              any other file (absolute path)
Older references ("sfx:", "music:", "sticker:": the home-made pack of the 1.3 betas) find nothing any more.
"""
from __future__ import annotations

import json
import logging
import shutil
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from . import paths

log = logging.getLogger("fireclips.bank")

FOLDERS = {"sound": "Sons", "image": "Images", "video": "Vidéos", "music": "Musiques"}
EXTS = {
    "sound": {".wav", ".mp3", ".ogg", ".m4a", ".flac", ".aac", ".opus", ".wma"},
    "image": {".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp"},
    "video": {".mp4", ".mov", ".webm", ".mkv", ".avi", ".m4v"},
    "music": {".wav", ".mp3", ".ogg", ".m4a", ".flac", ".aac", ".opus", ".wma"},
}
SFX_DIR = paths.ASSETS / "sfx"
MUSIC_DIR = paths.ASSETS / "music"
EMOJI_DIR = paths.ASSETS / "emoji"
STICKER_DIR = paths.ASSETS / "stickers"
STARTER_VERSION = 1
# the home-made starter sounds FireClips 1.2 copied into the bank (name: size): hidden while untouched (the
# real memes come from the internet now); old clips that use them still play them
STARTER_12 = {"applaudissements": 347012, "ba-dum-tss": 165858, "bip": 61782, "boing": 79424, "boom": 210232,
              "buzzer": 83834, "coeur": 195572, "criquets": 282284, "ding": 271468, "glitch": 59510,
              "klaxon": 130576, "pop": 14156, "scratch": 66194, "suspense": 229364, "tada": 240252,
              "trombone-triste": 316536, "whoosh": 158804}

README_FR = """FireClips - banque de memes
============================

Mets ici tes memes. FireClips les montre dans le Studio : un clic et c'est dans le clip.

  Sons\\       bruitages et sons de memes (.mp3, .wav, .ogg...)
  Images\\     images et GIF animés (.png avec transparence conseillé, .jpg, .gif, .webp)
  Vidéos\\     petites vidéos de memes (.mp4, .webm...). Les vidéos sur fond vert
              sont détourées toutes seules.
  Musiques\\   musiques de fond. Le son de la musique baisse quand tu parles.
              Attention aux droits d'auteur sur TikTok / YouTube.

Les memes que FireClips télécharge sur internet (sons MyInstants, emotes Twitch,
images, fonds verts, musiques de Kevin MacLeod) sont déjà dans le Studio : pas
besoin de les copier ici.

----------------------------------------------------------------------------
FireClips - meme bank: put your sounds, pictures, GIFs, videos and music here.
"""


@dataclass
class Item:
    kind: str        # sound | image | video | music | emoji | sfx
    name: str        # what the user sees
    ref: str         # what is stored in the edit list
    path: Path


def bank_dir(cfg) -> Path:
    custom = (cfg.get("bank_dir") or "").strip() if cfg is not None else ""
    return Path(custom) if custom else paths.default_output_dir() / "Banque"


_ensure_lock = threading.Lock()


def ensure(cfg) -> Path:
    """Create the bank folders (and copy the starter sounds the first time)."""
    root = bank_dir(cfg)
    with _ensure_lock:
        try:
            for sub in FOLDERS.values():
                (root / sub).mkdir(parents=True, exist_ok=True)
            marker = root / ".fireclips.json"
            state = {}
            if marker.exists():
                try:
                    state = json.loads(marker.read_text(encoding="utf-8"))
                except (OSError, ValueError):
                    state = {}
            if int(state.get("starter") or 0) < STARTER_VERSION:
                for f in sorted(SFX_DIR.glob("*.wav")):
                    dst = root / FOLDERS["sound"] / f.name
                    if not dst.exists():
                        shutil.copy2(f, dst)
                readme = root / "LISEZMOI.txt"
                if not readme.exists():
                    readme.write_text(README_FR, encoding="utf-8")
                state["starter"] = STARTER_VERSION
                marker.write_text(json.dumps(state), encoding="utf-8")
                _hide(marker)
        except OSError as e:
            log.warning("meme bank %s: %s", root, e)
    return root


def _hide(path: Path) -> None:
    try:
        import sys
        if sys.platform == "win32":
            import ctypes
            ctypes.windll.kernel32.SetFileAttributesW(str(path), 0x02)
    except Exception:  # noqa: BLE001
        pass


def list_items(cfg, kind: str) -> list[Item]:
    """Files of one bank folder (sound | image | video | music), sorted by name."""
    root = bank_dir(cfg)
    folder = root / FOLDERS[kind]
    out: list[Item] = []
    if not folder.is_dir():
        return out
    try:
        files = sorted((p for p in folder.rglob("*") if p.is_file() and p.suffix.lower() in EXTS[kind]),
                       key=lambda p: str(p.relative_to(folder)).lower())
    except OSError:
        return out
    for p in files:
        if kind == "sound" and p.parent == folder and p.suffix.lower() == ".wav" and p.stem in STARTER_12:
            try:
                if p.stat().st_size == STARTER_12[p.stem]:
                    continue            # untouched copy of a FireClips 1.2 starter sound (now in the pack)
            except OSError:
                pass
        rel = p.relative_to(root).as_posix()
        out.append(Item(kind, p.stem, "bank:" + rel, p))
    return out


_emoji_cache: Optional[dict] = None


def _emoji_index() -> dict:
    global _emoji_cache
    if _emoji_cache is None:
        try:
            data = json.loads((EMOJI_DIR / "index.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            data = {}
        if isinstance(data, list):          # FireClips 1.2 format
            data = {"groups": [], "emojis": data}
        _emoji_cache = data
    return _emoji_cache


def emojis() -> list[dict]:
    """Built-in emoji pictures: [{"code", "char", "fr", "en", "group", "tags"}]."""
    return list(_emoji_index().get("emojis") or [])


def emoji_groups() -> list[dict]:
    return list(_emoji_index().get("groups") or [])


def emoji_path(code: str) -> Optional[Path]:
    for ext in (".webp", ".png"):
        p = EMOJI_DIR / f"{code}{ext}"
        if p.is_file():
            return p
    return None


_pack_cache: dict = {}


def pack_sounds() -> list[dict]:
    """The sounds that come with FireClips: [{"id", "cat", "fr", "en", "tags", "dur", "wave"}]."""
    if "sfx" not in _pack_cache:
        try:
            data = json.loads((SFX_DIR / "index.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            data = {}
        _pack_cache["sfx"] = data
    return list(_pack_cache["sfx"].get("sounds") or [])


def sound_cats() -> list[dict]:
    pack_sounds()
    return list(_pack_cache["sfx"].get("cats") or [])


def pack_music() -> list[dict]:
    """The music loops that come with FireClips: [{"id", "fr", "en", "tags", "dur"}]."""
    if "music" not in _pack_cache:
        try:
            _pack_cache["music"] = json.loads((MUSIC_DIR / "index.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            _pack_cache["music"] = []
    return list(_pack_cache["music"])


def pack_sound(sid: str) -> Optional[dict]:
    for s in pack_sounds():
        if s["id"] == sid:
            return s
    return None


def emoji_char(code: str) -> str:
    for e in emojis():
        if e["code"] == code:
            return e["char"]
    return ""


def sfx_names() -> list[str]:
    return sorted({p.stem for p in SFX_DIR.glob("*.ogg")} | {p.stem for p in SFX_DIR.glob("*.wav")})


def _first(*cands: Path) -> Path:
    for c in cands:
        if c.is_file():
            return c
    return cands[0]


def resolve(ref: str, cfg=None) -> Optional[Path]:
    """The file behind a reference (None when it does not exist any more)."""
    ref = (ref or "").strip()
    if not ref:
        return None
    if ref.startswith("web:"):
        from . import memebank
        return memebank.path_of(ref)
    if ref.startswith("sfx:"):
        p = _first(SFX_DIR / (ref[4:] + ".ogg"), SFX_DIR / (ref[4:] + ".wav"))
    elif ref.startswith("music:"):
        p = MUSIC_DIR / (ref[6:] + ".ogg")
    elif ref.startswith("emoji:"):
        p = emoji_path(ref[6:]) or EMOJI_DIR / (ref[6:] + ".webp")
    elif ref.startswith("sticker:"):
        p = STICKER_DIR / (ref[8:] + ".png")
    elif ref.startswith("bank:"):
        p = bank_dir(cfg) / ref[5:]
        if not p.exists() and ref[5:].startswith(FOLDERS["sound"] + "/"):
            # a starter sound the user deleted from the bank: the built-in copy still works
            stem = Path(ref[5:]).stem
            alt = _first(SFX_DIR / (stem + ".ogg"), SFX_DIR / (stem + ".wav"))
            if alt.exists():
                p = alt
    else:
        p = Path(ref)
    try:
        return p if p.is_file() else None
    except OSError:
        return None


def display_name(ref: str, lang: str = "") -> str:
    if not lang:
        try:
            from .i18n import language
            lang = language()
        except Exception:  # noqa: BLE001
            lang = "fr"
    if ref.startswith("emoji:"):
        return emoji_char(ref[6:]) or ref[6:]
    if ref.startswith("web:"):
        from . import memebank
        return memebank.name_of(ref, lang)
    if ref.startswith("sfx:"):
        s = pack_sound(ref[4:])
        return (s.get(lang) or s.get("fr")) if s else ref[4:]
    if ref.startswith("music:"):
        for mu in pack_music():
            if mu["id"] == ref[6:]:
                return mu.get(lang) or mu.get("fr") or ref[6:]
        return ref[6:]
    if ref.startswith("sticker:"):
        from .fxlib import stickers
        for st in stickers():
            if st["id"] == ref[8:]:
                return st.get(lang) or st.get("fr") or ref[8:]
        return ref[8:]
    return Path(ref.split(":", 1)[-1]).stem


def kind_of_file(path: Path) -> Optional[str]:
    ext = path.suffix.lower()
    if ext in EXTS["image"]:
        return "image"
    if ext in EXTS["video"]:
        return "video"
    if ext in EXTS["sound"]:
        return "sound"
    return None


def add_file(cfg, src: Path) -> Optional[Item]:
    """Copy a file dropped on the Studio into the right bank folder."""
    kind = kind_of_file(src)
    if kind is None:
        return None
    root = ensure(cfg)
    dst = root / FOLDERS[kind] / src.name
    i = 2
    while dst.exists():
        try:
            if dst.stat().st_size == src.stat().st_size:
                break
        except OSError:
            pass
        dst = root / FOLDERS[kind] / f"{src.stem} ({i}){src.suffix}"
        i += 1
    if not dst.exists():
        shutil.copy2(src, dst)
    return Item(kind, dst.stem, "bank:" + dst.relative_to(root).as_posix(), dst)


_dur_cache: dict = {}


def duration(path: Path) -> float:
    """Length of a sound / video file in seconds (0 for a still picture)."""
    try:
        key = (str(path), path.stat().st_mtime)
    except OSError:
        return 0.0
    if key in _dur_cache:
        return _dur_cache[key]
    d = 0.0
    if path.suffix.lower() in (".png", ".jpg", ".jpeg", ".bmp"):
        d = 0.0
    elif path.suffix.lower() in (".gif", ".webp"):
        try:
            from PIL import Image
            with Image.open(path) as im:
                n = getattr(im, "n_frames", 1)
                if n > 1:
                    tot = 0
                    for i in range(n):
                        im.seek(i)
                        tot += int(im.info.get("duration") or 100)
                    d = tot / 1000.0
        except Exception:  # noqa: BLE001
            d = 0.0
    else:
        try:
            from . import tools
            d = float(tools.probe(path).get("duration") or 0.0)
        except Exception:  # noqa: BLE001
            d = 0.0
    _dur_cache[key] = d
    return d
