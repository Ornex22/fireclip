"""Adding your own memes to the bank: from a link (YouTube, TikTok, MyInstants, a direct file...), from a
YouTube search, from a passage of your VODs, or recorded with the microphone (the window records, this
module keeps the file). Downloads use yt-dlp (it comes with FireClips); cuts use ffmpeg."""
from __future__ import annotations

import html
import json
import logging
import os
import re
import shutil
import time
from pathlib import Path
from typing import Callable, Optional
from urllib.parse import urljoin, urlparse

from . import bank, tools
from .errors import UserError, classify_tool_error
from .util import run, run_streaming, sanitize_filename

log = logging.getLogger("fireclips.memes")

Progress = Callable[[float, str], None]
MAX_WHOLE = 600.0          # longer than this: only a passage is downloaded
MAX_KEEP = 60.0            # a meme kept in the bank lasts at most this long
MEDIA_EXT = {".mp3", ".wav", ".ogg", ".m4a", ".opus", ".aac", ".flac", ".mp4", ".webm", ".mkv", ".mov", ".gif",
             ".png", ".jpg", ".jpeg", ".webp"}
UA = "FireClips/1.3 (+meme bank)"


def _noop(_f: float = 0.0, _m: str = "") -> None:
    pass


def tmp_dir(cfg) -> Path:
    """Downloads waiting to be cut (cleaned after a day)."""
    d = Path(cfg.work_dir) / "memes_tmp"
    d.mkdir(parents=True, exist_ok=True)
    now = time.time()
    for f in d.iterdir():
        try:
            if f.is_file() and now - f.stat().st_mtime > 86400:
                f.unlink()
        except OSError:
            pass
    return d


# --------------------------------------------------------------------------- links


def kind_of_link(url: str) -> str:
    """myinstants | direct | ytdlp"""
    u = urlparse(url.strip())
    host = (u.netloc or "").lower()
    if "myinstants.com" in host:
        return "myinstants"
    if Path(u.path).suffix.lower() in MEDIA_EXT:
        return "direct"
    return "ytdlp"


def check_url(url: str) -> str:
    url = (url or "").strip()
    if url.startswith("www."):
        url = "https://" + url
    if not re.match(r"^https?://[^\s/]+\.[^\s]+", url):
        raise UserError("err_meme_link_bad")
    return url


def _ytdlp_base() -> list[str]:
    yt = tools.require("ytdlp")
    return [str(yt), "--no-warnings", "--no-playlist", "--no-progress"]


def info(url: str) -> dict:
    """What a link is (title, length) before downloading it."""
    url = check_url(url)
    k = kind_of_link(url)
    if k != "ytdlp":
        name = Path(urlparse(url).path).stem or "meme"
        return {"url": url, "title": name.replace("-", " ").replace("_", " "), "duration": 0.0, "kind": k}
    r = run(_ytdlp_base() + ["-J", url], timeout=90)
    if r.returncode != 0:
        raise UserError(classify_meme_error((r.stderr or "").splitlines()), (r.stderr or "")[-800:])
    try:
        d = json.loads(r.stdout or "{}")
    except ValueError as e:
        raise UserError("err_meme_link_failed", str(e)) from e
    if d.get("_type") == "playlist" and d.get("entries"):
        d = d["entries"][0]
    if d.get("is_live"):
        raise UserError("err_meme_live")
    return {"url": url, "title": d.get("title") or "meme", "duration": float(d.get("duration") or 0.0),
            "kind": k, "uploader": d.get("uploader") or d.get("channel") or "",
            "thumbnail": d.get("thumbnail") or ""}


def search(query: str, n: int = 12) -> list[dict]:
    """YouTube search (no download): [{"id", "title", "duration", "channel", "url"}]."""
    q = (query or "").strip()
    if not q:
        return []
    r = run(_ytdlp_base() + ["-J", "--flat-playlist", f"ytsearch{int(n)}:{q}"], timeout=90)
    if r.returncode != 0:
        raise UserError(classify_meme_error((r.stderr or "").splitlines()), (r.stderr or "")[-800:])
    try:
        d = json.loads(r.stdout or "{}")
    except ValueError as e:
        raise UserError("err_meme_link_failed", str(e)) from e
    out = []
    for e in d.get("entries") or []:
        vid = e.get("id")
        if not vid:
            continue
        out.append({"id": vid, "title": e.get("title") or vid, "duration": float(e.get("duration") or 0.0),
                    "channel": e.get("channel") or e.get("uploader") or "",
                    "url": e.get("url") if str(e.get("url") or "").startswith("http")
                    else f"https://www.youtube.com/watch?v={vid}"})
    return out


def classify_meme_error(lines: list[str]) -> str:
    text = "\n".join(lines).lower()
    if "unsupported url" in text or "no video formats" in text or "is not a valid url" in text:
        return "err_meme_link_unsupported"
    if "private video" in text or "sign in" in text or "login" in text or "age" in text and "confirm" in text:
        return "err_meme_link_private"
    if "not available" in text or "removed" in text or "404" in text:
        return "err_meme_link_gone"
    code = classify_tool_error(lines)
    return code if code in ("err_network", "err_disk_full") else "err_meme_link_failed"


def _http_get(url: str, dest: Path, progress: Progress, cancel=None) -> Path:
    import requests
    with requests.get(url, stream=True, timeout=30, headers={"User-Agent": UA}) as r:
        if r.status_code != 200:
            raise UserError("err_meme_link_gone" if r.status_code in (403, 404, 410) else "err_meme_link_failed",
                            f"HTTP {r.status_code}")
        total = int(r.headers.get("content-length") or 0)
        got = 0
        with dest.open("wb") as fh:
            for chunk in r.iter_content(65536):
                if cancel is not None and cancel.is_set():
                    raise UserError("cancelled")
                fh.write(chunk)
                got += len(chunk)
                if got > 300 * 1024 * 1024:
                    raise UserError("err_meme_too_big")
                if total:
                    progress(min(1.0, got / total), "download")
    return dest


def myinstants_mp3(page_url: str) -> str:
    """The sound file of a MyInstants page."""
    import requests
    r = requests.get(page_url, timeout=30, headers={"User-Agent": UA})
    if r.status_code != 200:
        raise UserError("err_meme_link_gone", f"HTTP {r.status_code}")
    m = re.search(r"""(/media/sounds/[^'"\s<>]+?\.(?:mp3|wav|ogg|m4a))""", r.text)
    if not m:
        raise UserError("err_meme_link_unsupported", "no sound on the page")
    return urljoin(page_url, html.unescape(m.group(1)))


def fetch(url: str, cfg, progress: Progress = _noop, cancel=None, section: Optional[tuple] = None,
          title: str = "") -> dict:
    """Download what a link points to (a passage of it for long videos). Returns
    {"path", "title", "duration", "has_video", "has_audio", "width", "height", "image"}."""
    url = check_url(url)
    k = kind_of_link(url)
    d = tmp_dir(cfg)
    stamp = time.strftime("%Y%m%d_%H%M%S") + f"_{os.getpid()}"      # two downloads at once never mix
    if k == "myinstants":
        snd = myinstants_mp3(url)
        title = Path(urlparse(snd).path).stem.replace("-", " ").replace("_", " ")
        path = _http_get(snd, d / f"link_{stamp}{Path(urlparse(snd).path).suffix.lower() or '.mp3'}", progress, cancel)
    elif k == "direct":
        ext = Path(urlparse(url).path).suffix.lower()
        title = Path(urlparse(url).path).stem.replace("-", " ").replace("_", " ")
        path = _http_get(url, d / f"link_{stamp}{ext}", progress, cancel)
    else:
        ff = tools.require("ffmpeg")
        tmpl = d / f"link_{stamp}.%(ext)s"
        cmd = [str(tools.require("ytdlp")), "--no-warnings", "--no-playlist", "--newline",
               "-f", "b[height<=720]/bv*[height<=720]+ba/b/ba", "--merge-output-format", "mp4",
               "--ffmpeg-location", str(ff), "--force-overwrites", "--no-part", "--max-filesize", "400M",
               "-o", str(tmpl)]
        if section:
            cmd += ["--download-sections", f"*{float(section[0]):.2f}-{float(section[1]):.2f}",
                    "--force-keyframes-at-cuts"]
        cmd.append(url)
        pat = re.compile(r"\[download\]\s+([\d.]+)%")

        def on_line(line: str) -> None:
            mm = pat.search(line)
            if mm:
                progress(min(1.0, float(mm.group(1)) / 100.0), "download")
        code, last = run_streaming(cmd, on_line, cwd=str(d), cancel=cancel)
        found = sorted((p for p in d.glob(f"link_{stamp}.*") if p.suffix.lower() in MEDIA_EXT),
                       key=lambda p: p.stat().st_size, reverse=True)
        if code != 0 or not found:
            if cancel is not None and cancel.is_set():
                raise UserError("cancelled")
            raise UserError(classify_meme_error(last), "\n".join(last[-8:]))
        path = found[0]
    res = describe(path)
    res["title"] = title or res.get("title") or "meme"
    return res


def describe(path: Path) -> dict:
    """What a media file holds."""
    path = Path(path)
    out = {"path": str(path), "title": path.stem, "duration": 0.0, "has_video": False, "has_audio": False,
           "width": 0, "height": 0, "image": False}
    if path.suffix.lower() in (".png", ".jpg", ".jpeg", ".webp", ".gif"):
        out["image"] = True
        try:
            from PIL import Image
            with Image.open(path) as im:
                out["width"], out["height"] = im.size
                out["duration"] = bank.duration(path)
        except Exception:  # noqa: BLE001
            pass
        if path.suffix.lower() != ".gif" or not out["duration"]:
            return out
    try:
        inf = tools.probe(path)
        out.update(duration=float(inf.get("duration") or 0.0), has_video=bool(inf.get("has_video")),
                   has_audio=bool(inf.get("has_audio")), width=int(inf.get("width") or 0),
                   height=int(inf.get("height") or 0))
    except Exception as e:  # noqa: BLE001
        log.info("probe %s: %s", path, e)
    return out


# --------------------------------------------------------------------------- into the bank


def _target(cfg, kind: str, name: str, ext: str) -> Path:
    root = bank.ensure(cfg)
    folder = root / bank.FOLDERS["sound" if kind == "sound" else "video" if kind == "video" else "image"]
    folder.mkdir(parents=True, exist_ok=True)
    stem = sanitize_filename(name or "meme", 60).strip(" .") or "meme"
    p = folder / f"{stem}{ext}"
    i = 2
    while p.exists():
        p = folder / f"{stem} ({i}){ext}"
        i += 1
    return p


def cut(cfg, src: str, start: float, end: float, kind: str, name: str, cancel=None) -> bank.Item:
    """Keep [start, end] of a file in the bank: as a sound (mp3, level evened out), a video meme (mp4,
    720p at most) or a picture / GIF (copied)."""
    src_p = Path(src)
    if not src_p.is_file():
        raise UserError("err_meme_file_missing", str(src))
    if kind == "image":
        dst = _target(cfg, "image", name, src_p.suffix.lower())
        shutil.copy2(src_p, dst)
        return _item(cfg, "image", dst)
    start = max(0.0, float(start or 0.0))
    dur = float(end or 0.0) - start
    if dur <= 0.05:
        full = describe(src_p).get("duration") or 0.0
        dur = max(0.1, full - start)
    dur = min(dur, MAX_KEEP)
    ff = tools.require("ffmpeg")
    if kind == "sound":
        dst = _target(cfg, "sound", name, ".mp3")
        fo = max(0.0, dur - 0.04)
        cmd = [str(ff), "-y", "-hide_banner", "-v", "error", "-ss", f"{start:.3f}", "-t", f"{dur:.3f}", "-i", str(src_p),
               "-vn", "-af", f"afade=t=in:d=0.008,afade=t=out:st={fo:.3f}:d=0.04,loudnorm=I=-16:LRA=11:TP=-1.5,"
               f"aresample=48000", "-ac", "2", "-ar", "48000", "-c:a", "libmp3lame", "-q:a", "2", str(dst)]
    else:
        dst = _target(cfg, "video", name, ".mp4")
        cmd = [str(ff), "-y", "-hide_banner", "-v", "error", "-ss", f"{start:.3f}", "-t", f"{dur:.3f}", "-i", str(src_p),
               "-vf", "scale='trunc(min(1280,iw)/2)*2':-2,fps=30", "-c:v", "libx264", "-preset", "veryfast", "-crf",
               "20", "-pix_fmt", "yuv420p", "-af", "loudnorm=I=-16:LRA=11:TP=-1.5,aresample=48000", "-c:a", "aac",
               "-b:a", "160k", "-movflags", "+faststart", str(dst)]
        if not describe(src_p).get("has_audio"):
            i = cmd.index("-af")
            del cmd[i:i + 2]
            i = cmd.index("-c:a")
            del cmd[i:i + 4]
            cmd.insert(-1, "-an")
    code, last = run_streaming(cmd, lambda _l: None, cancel=cancel)
    if code != 0 or not dst.exists():
        try:
            dst.unlink()
        except OSError:
            pass
        raise UserError("err_meme_cut_failed", "\n".join(last[-6:]))
    return _item(cfg, kind, dst)


def _item(cfg, kind: str, path: Path) -> bank.Item:
    root = bank.bank_dir(cfg)
    k = "sound" if kind == "sound" else "video" if kind == "video" else "image"
    return bank.Item(k, path.stem, "bank:" + path.relative_to(root).as_posix(), path)


def vod_cut(ref, cfg, start: float, end: float, kind: str, name: str, progress: Progress = _noop,
            cancel=None) -> bank.Item:
    """Keep a passage of a VOD as a meme (sound from the VOD sound, video from a piece of the VOD)."""
    from . import media
    start, end = float(start), float(end)
    if end - start < 0.2:
        raise UserError("err_meme_too_short")
    if kind == "sound":
        audio = ref.audio_file()
        if audio is not None:
            progress(0.5, "cut")
            return cut(cfg, str(audio), start, end, "sound", name, cancel)
    seg = media.get_segment(ref, cfg, start, end, "export", lambda f, m="": progress(0.8 * f, "download"), cancel)
    s0 = float(seg["vod_start"])
    progress(0.85, "cut")
    return cut(cfg, seg["path"], start - s0, end - s0, kind, name, cancel)


def keep_recording(cfg, path: str, name: str, trim: bool = True) -> bank.Item:
    """A microphone recording into the bank (silence at both ends cut off, level evened out)."""
    src = Path(path)
    if not src.is_file():
        raise UserError("err_meme_file_missing", path)
    ff = tools.require("ffmpeg")
    dst = _target(cfg, "sound", name or "micro", ".mp3")
    flt = "loudnorm=I=-16:LRA=11:TP=-1.5,aresample=48000"
    if trim:
        flt = ("silenceremove=start_periods=1:start_threshold=-45dB:start_silence=0.05,areverse,"
               "silenceremove=start_periods=1:start_threshold=-45dB:start_silence=0.08,areverse," + flt)
    code, last = run_streaming([str(ff), "-y", "-hide_banner", "-v", "error", "-i", str(src), "-af", flt, "-ac", "2",
                                "-ar", "48000", "-c:a", "libmp3lame", "-q:a", "2", str(dst)], lambda _l: None)
    if code != 0 or not dst.exists():
        raise UserError("err_meme_cut_failed", "\n".join(last[-6:]))
    return _item(cfg, "sound", dst)
