"""Compilations: the chosen clips of a VOD one after the other (with the YouTube chapters ready to
paste), and "all the kills in 60 seconds" (each kill cut short, the biggest fame first if they do not fit)."""
from __future__ import annotations

import logging
import shutil
import threading
from pathlib import Path
from typing import Callable, Optional

from . import montage, tools
from .errors import UserError
from .export import vod_date
from .util import fmt_time, run, sanitize_filename, unique_path

log = logging.getLogger("fireclips.compile")


def _concat(parts: list[Path], out: Path, title: str) -> None:
    ff = tools.require("ffmpeg")
    lst = out.with_suffix(".txt.tmp")
    lst.write_text("".join(f"file '{p.as_posix()}'\n" for p in parts), encoding="utf-8")
    try:
        r = run([str(ff), "-y", "-hide_banner", "-v", "error", "-f", "concat", "-safe", "0", "-i", str(lst),
                 "-c", "copy", "-movflags", "+faststart", "-metadata", f"title={title}", str(out)], timeout=1800)
        if r.returncode != 0 or not out.exists():
            raise UserError("err_export_failed", (r.stderr or "")[-1500:])
    finally:
        try:
            lst.unlink()
        except OSError:
            pass


def _chapters_text(titles: list[str], lengths: list[float], lang: str) -> str:
    t = 0.0
    lines = []
    for title, ln in zip(titles, lengths):
        lines.append(f"{fmt_time(t)} {title}")
        t += ln
    head = ("Chapitres (à coller dans la description YouTube) :\n" if lang == "fr"
            else "Chapters (paste them in the YouTube description):\n")
    return head + "\n".join(lines) + "\n"


def best_of(ref, cfg, items: list[dict], fmt: str, out_dir: Path, progress: Callable[[float, str], None],
            cancel: Optional[threading.Event] = None, lang: str = "fr") -> dict:
    """All the given clips (in the order of the live) in one video."""
    items = sorted(items, key=lambda m: float(m["start"]))
    if not items:
        raise UserError("err_clip_too_short")
    work = ref.p("tmp", f"compile_{fmt}")
    shutil.rmtree(work, ignore_errors=True)
    work.mkdir(parents=True, exist_ok=True)
    parts, lengths, titles = [], [], []
    for i, it in enumerate(items):
        rep: dict = {}
        p = montage.render(ref, cfg, it, fmt, work, lambda f, m="", i=i: progress((i + 0.95 * f) / len(items), m),
                           cancel, out_path=work / f"part{i:03d}.mp4", report=rep)
        parts.append(p)
        dur = float(tools.probe(p).get("duration") or rep.get("total") or 0)
        lengths.append(dur)
        titles.append((it.get("title") or "").strip() or f"Clip {i + 1}")
    out_dir.mkdir(parents=True, exist_ok=True)
    tag = "9x16" if fmt == "vertical" else "16x9"
    name = sanitize_filename(f"{vod_date(ref.meta)}_Best-of_{ref.meta.get('title') or ''}", 90)
    out = unique_path(out_dir / f"{name}_{tag}.mp4")
    _concat(parts, out, f"Best-of — {ref.meta.get('title') or ''}")
    chapters = out.with_suffix(".txt")
    chapters.write_text(_chapters_text(titles, lengths, lang), encoding="utf-8-sig")
    shutil.rmtree(work, ignore_errors=True)
    progress(1.0, "done")
    return {"path": str(out), "chapters": str(chapters), "clips": len(parts), "duration": round(sum(lengths), 1)}


def kills_reel(ref, cfg, kills: list[dict], fmt: str, out_dir: Path, progress: Callable[[float, str], None],
               cancel: Optional[threading.Event] = None, max_len: float = 60.0, before: float = 3.5,
               after: float = 2.0) -> dict:
    """Every kill shortened to a few seconds (zoom + kill card), the biggest fame first if they do
    not all fit in max_len seconds, then put back in the order of the live."""
    shots = []
    for k in kills:
        offs = [float(h["t"]) for h in k.get("fx") or [] if h.get("kind") in ("kill", "assist")]
        if not offs and k.get("peak") is not None:
            offs = [float(k["peak"])]
        for o in offs:
            shots.append((o, k))
    if not shots:
        raise UserError("err_no_kills")
    # biggest kills first, then keep what fits
    shots.sort(key=lambda s: -float(s[1].get("fame") or 0))
    chosen, total, used = [], 0.0, []
    for o, k in shots:
        if any(abs(o - u) < before + after for u in used):
            continue
        if total + before + after > max_len and chosen:
            break
        chosen.append((o, k))
        used.append(o)
        total += before + after
    chosen.sort(key=lambda s: s[0])
    work = ref.p("tmp", f"killreel_{fmt}")
    shutil.rmtree(work, ignore_errors=True)
    work.mkdir(parents=True, exist_ok=True)
    parts = []
    for i, (o, k) in enumerate(chosen):
        item = dict(k)
        item["start"], item["end"] = max(0.0, o - before), o + after
        item["peak"] = o
        m = montage.effective(k, cfg)
        # keep the kill effects, drop the slow parts (no cuts / cold open in a 5 s shot)
        m.update({"jumpcuts": False, "cold_open": False})
        item["montage"] = m
        p = montage.render(ref, cfg, item, fmt, work, lambda f, msg="", i=i: progress((i + 0.95 * f) / len(chosen), msg),
                           cancel, out_path=work / f"kill{i:03d}.mp4", window=(item["start"], item["end"]))
        parts.append(p)
    out_dir.mkdir(parents=True, exist_ok=True)
    tag = "9x16" if fmt == "vertical" else "16x9"
    name = sanitize_filename(f"{vod_date(ref.meta)}_{len(parts)} kills en {int(round(total))} s", 90)
    out = unique_path(out_dir / f"{name}_{tag}.mp4")
    _concat(parts, out, f"{len(parts)} kills — {ref.meta.get('title') or ''}")
    shutil.rmtree(work, ignore_errors=True)
    progress(1.0, "done")
    return {"path": str(out), "clips": len(parts), "duration": round(total, 1)}
