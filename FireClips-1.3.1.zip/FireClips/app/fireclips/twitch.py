"""Talking to Twitch: VOD links, VOD info, viewer clips, channel VOD list, live status.

Uses Twitch's public GraphQL endpoint with the same queries as TwitchDownloader, so no
Twitch developer account is needed.
"""
from __future__ import annotations

import logging
import os
import re
import time
from datetime import datetime, timezone
from typing import Optional

import requests

from .errors import UserError

log = logging.getLogger("fireclips.twitch")

GQL_URL = os.environ.get("FIRECLIPS_GQL_URL", "https://gql.twitch.tv/gql")
CLIENT_ID_WEB = "kimne78kx3ncx6brgo4mv6wki5h1ko"     # used for video/clip info (as TwitchDownloader)
CLIENT_ID_LIST = "kd1unb4b3q4t58fwlpcbzcbnm76a8fp"    # used for channel video/clip lists (as TwitchDownloader)
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) FireClips/1.3"


class TwitchError(UserError):
    """A Twitch problem with a message that can be shown to the user (code = i18n key)."""


# --------------------------------------------------------------------------- links

_VOD_PATTERNS = [
    re.compile(r"twitch\.tv/videos/(\d+)", re.I),
    re.compile(r"twitch\.tv/[\w-]+/v(?:ideo)?/(\d+)", re.I),
    re.compile(r"[?&]video=v?(\d+)", re.I),
]
_CLIP_PATTERNS = [
    re.compile(r"clips\.twitch\.tv/([\w-]+)", re.I),
    re.compile(r"twitch\.tv/[\w-]+/clip/([\w-]+)", re.I),
]
_CHANNEL_PATTERN = re.compile(r"twitch\.tv/([A-Za-z0-9_]{2,25})/?(?:[?#].*)?$", re.I)
_LOGIN_RE = re.compile(r"^[A-Za-z0-9_]{2,25}$")


def parse_input(text: str) -> tuple[str, str]:
    """Classify what the user pasted: ('vod', id) | ('clip', slug) | ('channel', login) | ('unknown', text)."""
    t = (text or "").strip().strip("<>\"'")
    if re.fullmatch(r"v?\d{6,}", t):
        return "vod", t.lstrip("v")
    for p in _VOD_PATTERNS:
        m = p.search(t)
        if m:
            return "vod", m.group(1)
    for p in _CLIP_PATTERNS:
        m = p.search(t)
        if m:
            return "clip", m.group(1)
    m = _CHANNEL_PATTERN.search(t)
    if m and m.group(1).lower() not in ("videos", "directory", "settings", "downloads", "p", "search"):
        return "channel", m.group(1).lower()
    return "unknown", t


def clean_login(login: str) -> str:
    login = (login or "").strip()
    kind, val = parse_input(login)
    if kind == "channel":
        login = val
    login = login.lstrip("@").lower()
    if not _LOGIN_RE.match(login):
        raise TwitchError("err_channel_invalid", login)
    return login


# --------------------------------------------------------------------------- GQL

_session: Optional[requests.Session] = None


def _sess() -> requests.Session:
    global _session
    if _session is None:
        _session = requests.Session()
        _session.headers["User-Agent"] = UA
    return _session


def gql(query: str, client_id: str = CLIENT_ID_WEB, oauth: str = "", timeout: float = 20,
        retries: int = 3) -> dict:
    headers = {"Client-ID": client_id, "Content-Type": "application/json"}
    if oauth:
        headers["Authorization"] = "OAuth " + oauth.replace("OAuth ", "").replace("oauth:", "").strip()
    last_exc: Optional[Exception] = None
    for attempt in range(retries):
        try:
            r = _sess().post(GQL_URL, json={"query": query, "variables": {}}, headers=headers, timeout=timeout)
            if r.status_code >= 500 or r.status_code == 429:
                raise requests.HTTPError(f"HTTP {r.status_code}")
            if r.status_code == 401 and oauth:
                # a bad/expired OAuth token: retry without it
                oauth = ""
                headers.pop("Authorization", None)
                continue
            r.raise_for_status()
            data = r.json()
            if not isinstance(data, dict):
                raise TwitchError("err_twitch_unexpected", str(data)[:200])
            if data.get("errors") and not data.get("data"):
                raise TwitchError("err_twitch_unexpected", str(data["errors"])[:300])
            return data
        except TwitchError:
            raise
        except (requests.RequestException, ValueError) as e:
            last_exc = e
            time.sleep(1.5 * (attempt + 1))
    raise TwitchError("err_twitch_network", str(last_exc))


def _parse_dt(s: str) -> Optional[datetime]:
    if not s:
        return None
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00"))
    except ValueError:
        return None


def get_video_info(vod_id: str, oauth: str = "") -> dict:
    q = ('query{video(id:"%s"){title,createdAt,lengthSeconds,owner{id,displayName,login},viewCount,'
         'game{id,displayName},status}}' % re.sub(r"\D", "", vod_id))
    data = gql(q, CLIENT_ID_WEB, oauth)
    v = (data.get("data") or {}).get("video")
    if not v:
        raise TwitchError("err_vod_not_found", vod_id)
    owner = v.get("owner") or {}
    return {
        "vod_id": str(vod_id),
        "title": v.get("title") or "",
        "created_at": v.get("createdAt") or "",
        "duration": float(v.get("lengthSeconds") or 0),
        "login": owner.get("login") or "",
        "display_name": owner.get("displayName") or owner.get("login") or "",
        "game": (v.get("game") or {}).get("displayName") or "",
        "status": v.get("status") or "",
    }


CHAPTERS_OP = "VideoPlayer_ChapterSelectButtonVideo"      # the query the Twitch website uses (also yt-dlp)
CHAPTERS_HASH = "8d2793384aac3773beab5e59bd5d6f585aedb923d292800119e03d40cd0f9b41"


def _gql_persisted(operation: str, sha256: str, variables: dict, timeout: float = 20) -> dict:
    r = _sess().post(GQL_URL, json={"operationName": operation, "variables": variables,
                                    "extensions": {"persistedQuery": {"version": 1, "sha256Hash": sha256}}},
                     headers={"Client-ID": CLIENT_ID_WEB, "Content-Type": "application/json"}, timeout=timeout)
    r.raise_for_status()
    data = r.json()
    if isinstance(data, list):
        data = data[0] if data else {}
    return data if isinstance(data, dict) else {}


def get_chapters(vod_id: str, duration: float = 0.0, oauth: str = "") -> list[dict]:
    """Game changes of a VOD (Twitch "chapters"): [{"start", "end", "game"}]. Empty when there are none
    (a VOD on a single game) or when Twitch does not answer."""
    vid = re.sub(r"\D", "", vod_id)
    edges = None
    try:
        data = _gql_persisted(CHAPTERS_OP, CHAPTERS_HASH, {"includePrivate": False, "videoID": vid})
        v = (data.get("data") or {}).get("video")
        if v is not None:
            edges = ((v.get("moments") or {}).get("edges")) or []
    except (requests.RequestException, ValueError) as e:
        log.info("chapters of %s (persisted query): %s", vod_id, e)
    if edges is None:
        q = ('query{video(id:"%s"){moments(momentRequestType: VIDEO_CHAPTER_MARKERS){edges{node{'
             'positionMilliseconds,durationMilliseconds,description,type,'
             'details{... on GameChangeMomentDetails{game{id,displayName}}}}}}}}' % vid)
        try:
            data = gql(q, CLIENT_ID_WEB, oauth, retries=2)
        except TwitchError as e:
            log.info("chapters of %s: %s", vod_id, e)
            return []
        v = (data.get("data") or {}).get("video") or {}
        edges = ((v.get("moments") or {}).get("edges")) or []
    out = []
    for e in edges:
        n = (e or {}).get("node") or {}
        if n.get("positionMilliseconds") is None:
            continue
        game = (((n.get("details") or {}).get("game")) or {}).get("displayName") or n.get("description") or ""
        start = float(n["positionMilliseconds"]) / 1000.0
        dur = float(n.get("durationMilliseconds") or 0) / 1000.0
        out.append({"start": round(start, 1), "end": round(start + dur, 1) if dur > 0 else None, "game": str(game)})
    out.sort(key=lambda c: c["start"])
    for i, c in enumerate(out):
        if c["end"] is None:
            c["end"] = out[i + 1]["start"] if i + 1 < len(out) else (float(duration) or c["start"])
    return out


def get_channel_videos(login: str, limit: int = 10) -> list[dict]:
    """Latest past broadcasts (archives) of a channel, newest first."""
    login = clean_login(login)
    q = ('query{user(login:"%s"){videos(first: %d, type: ARCHIVE) { edges { node { title, id, '
         'lengthSeconds, createdAt } } }}}' % (login, max(1, min(limit, 50))))
    data = gql(q, CLIENT_ID_LIST)
    user = (data.get("data") or {}).get("user")
    if user is None:
        raise TwitchError("err_channel_not_found", login)
    out = []
    for e in ((user.get("videos") or {}).get("edges") or []):
        n = e.get("node") or {}
        if not n.get("id"):
            continue
        out.append({"vod_id": str(n["id"]), "title": n.get("title") or "", "created_at": n.get("createdAt") or "",
                    "duration": float(n.get("lengthSeconds") or 0)})
    out.sort(key=lambda x: x["created_at"], reverse=True)
    return out


def is_live(login: str) -> Optional[bool]:
    """True/False, or None if Twitch did not say."""
    try:
        data = gql('query{user(login:"%s"){stream{id}}}' % clean_login(login), CLIENT_ID_WEB, retries=2)
        user = (data.get("data") or {}).get("user")
        if user is None:
            return None
        return user.get("stream") is not None
    except Exception as e:  # noqa: BLE001
        log.info("live check failed: %s", e)
        return None


def _clip_period(created_at: str) -> str:
    dt = _parse_dt(created_at)
    if not dt:
        return "ALL_TIME"
    age_days = (datetime.now(timezone.utc) - dt).total_seconds() / 86400
    if age_days < 6:
        return "LAST_WEEK"
    if age_days < 29:
        return "LAST_MONTH"
    return "ALL_TIME"


def get_vod_clips(vod_id: str, login: str, created_at: str, max_pages: int = 12) -> list[dict]:
    """Clips viewers made from this VOD, with their position in the VOD."""
    login = clean_login(login)
    period = _clip_period(created_at)
    vod_start = _parse_dt(created_at)
    fields_ext = ("id, slug, title, createdAt, durationSeconds, viewCount, videoOffsetSeconds, video { id }, "
                  "curator { displayName }")
    fields_basic = "id, slug, title, createdAt, curator { id, displayName }, durationSeconds, viewCount"
    clips: list[dict] = []

    def fetch(fields: str) -> list[dict]:
        nodes, cursor = [], ""
        for _page in range(max_pages):
            after = f', after: "{cursor}"' if cursor else ""
            q = ('query{user(login:"%s"){clips(first: 50%s, criteria: { period: %s }) { edges { cursor, '
                 'node { %s } }, pageInfo { hasNextPage } }}}' % (login, after, period, fields))
            data = gql(q, CLIENT_ID_LIST)
            user = (data.get("data") or {}).get("user") or {}
            conn = user.get("clips") or {}
            edges = conn.get("edges") or []
            for e in edges:
                if e.get("node"):
                    nodes.append(e["node"])
            if not edges or not (conn.get("pageInfo") or {}).get("hasNextPage"):
                break
            cursor = edges[-1].get("cursor") or ""
            if not cursor:
                break
        return nodes

    try:
        nodes = fetch(fields_ext)
        extended = True
    except TwitchError as e:
        log.info("extended clip query failed (%s), using basic query", e)
        nodes = fetch(fields_basic)
        extended = False

    for n in nodes:
        dt = _parse_dt(n.get("createdAt") or "")
        if vod_start and dt and dt < vod_start:
            continue  # created before this stream started: cannot come from this VOD
        if not extended:
            try:
                d = gql('query{clip(slug:"%s"){videoOffsetSeconds,video{id},durationSeconds,viewCount}}'
                        % re.sub(r"[^\w-]", "", n.get("slug", "")), CLIENT_ID_WEB, retries=2)
                info = (d.get("data") or {}).get("clip") or {}
                n.update({k: info.get(k) for k in ("videoOffsetSeconds", "video") if k in info})
            except TwitchError:
                continue
        vid = (n.get("video") or {}).get("id")
        off = n.get("videoOffsetSeconds")
        if str(vid) != str(vod_id) or off is None:
            continue
        clips.append({
            "slug": n.get("slug") or "",
            "title": n.get("title") or "",
            "views": int(n.get("viewCount") or 0),
            "duration": float(n.get("durationSeconds") or 30),
            "offset": float(off),
            "created_at": n.get("createdAt") or "",
            "curator": (n.get("curator") or {}).get("displayName") or "",
        })
    clips.sort(key=lambda c: c["offset"])
    return clips


def vod_url(vod_id: str) -> str:
    return f"https://www.twitch.tv/videos/{vod_id}"
