"""Background worker: the window starts this in a separate process for every long job, so the
interface never freezes and a crash in a job cannot take the app down.

    python -m fireclips.worker analyze  --key tw_123
    python -m fireclips.worker export   --key tw_123 --items '[...]'|@items.json --overrides '{...}'
    python -m fireclips.worker render   --key tw_123 --items @items.json --formats vertical --out prev.mp4
    python -m fireclips.worker segment  --key tw_123 --start 10 --end 40
    python -m fireclips.worker albion   --key tw_123     (fetch the Albion kills again)
    python -m fireclips.worker albion-check --overrides '{"albion_links": [...]}'
    python -m fireclips.worker selfcheck --plain        (used by the installer)
    python -m fireclips.worker meme-search --query "vine boom"     (memes for the bank)
    python -m fireclips.worker meme-info|meme-fetch --url URL [--start a --end b]
    python -m fireclips.worker meme-cut --src FILE --start a --end b --kind sound|video|image --name N
    python -m fireclips.worker meme-vod --key tw_123 --start a --end b --kind sound|video --name N

Talks to the window with one JSON object per line on stdout.
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
import threading
import time
import traceback
from pathlib import Path

from . import __version__, paths
from .config import Config, from_snapshot
from .errors import UserError
from .i18n import set_language, tr
from .util import Cancelled, setup_logging

log = logging.getLogger("fireclips.worker")
_plain = False
_out_lock = threading.Lock()


def emit(ev: str, **data) -> None:
    data["ev"] = ev
    if _plain:
        _plain_print(data)
        return
    line = json.dumps(data, ensure_ascii=False, default=str)
    with _out_lock:
        try:
            sys.stdout.write(line + "\n")
            sys.stdout.flush()
        except (OSError, AttributeError, ValueError):
            pass


_last_plain = {"t": 0.0, "pct": -1}


def _plain_print(d: dict) -> None:
    ev = d.get("ev")
    if ev == "progress":
        pct = int(100 * float(d.get("frac", d.get("overall", 0))))
        now = time.time()
        if pct != _last_plain["pct"] and (now - _last_plain["t"] > 1.0 or pct >= 100):
            _last_plain.update(t=now, pct=pct)
            print(f"   ... {pct} %", flush=True)
    elif ev in ("log", "result", "check"):
        msg = d.get("msg") or d.get("text") or ""
        if msg:
            print("   " + msg, flush=True)
    elif ev == "warning":
        print("   ! " + tr(d.get("code", ""), **(d.get("fmt") or {})), flush=True)
    elif ev == "error":
        print("   X " + tr(d.get("code", "err_unexpected"), **(d.get("fmt") or {})), flush=True)
        if d.get("detail"):
            print("     " + str(d["detail"])[-600:], flush=True)


def _lower_priority() -> None:
    try:
        import psutil
        p = psutil.Process()
        if sys.platform == "win32":
            p.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
        else:
            p.nice(5)
    except Exception:  # noqa: BLE001
        pass


def _cfg(args) -> Config:
    cfg = Config()
    if getattr(args, "overrides", None):
        try:
            snap = cfg.snapshot()
            snap.update(json.loads(args.overrides))
            cfg = from_snapshot(snap)
        except ValueError:
            pass
    set_language(cfg.get("language") or "fr")
    return cfg


def _ref(cfg, args):
    from .store import Library
    work = Path(args.work) if getattr(args, "work", None) else cfg.work_dir
    return Library(work).ref(args.key)


# --------------------------------------------------------------------------- commands

def cmd_analyze(args) -> int:
    from . import pipeline
    cfg = _cfg(args)
    ref = _ref(cfg, args)
    if not ref.dir.exists():
        emit("error", code="err_unexpected", detail=f"unknown VOD {args.key}", fmt={})
        return 1
    try:
        pipeline.analyze(ref, cfg, emit)
        return 0
    except Cancelled:
        return 2
    except Exception:  # noqa: BLE001 - already reported by the pipeline
        return 1


def cmd_transcribe(args) -> int:
    """Child process for the transcription only (so that a graphics card problem or a crash
    can be detected and retried on the processor)."""
    from . import transcribe
    opts = json.loads(args.opts)
    ref_dir = Path(args.work) / "vods" / args.key
    try:
        transcribe.run_transcription(ref_dir, Path(args.audio), float(args.duration), opts,
                                     lambda f, d="": emit("progress", frac=round(f, 4), detail=d),
                                     lambda m: emit("log", msg=m))
        return 0
    except Cancelled:
        return 2
    except UserError as e:
        emit("error", code=e.code, kind="other", detail=e.detail)
        return 1
    except BaseException as e:  # noqa: BLE001
        kind = transcribe.classify_error(e)
        emit("error", code="err_transcribe_failed", kind=kind, detail=f"{type(e).__name__}: {e}"[-1500:])
        log.error("transcription failed: %s", traceback.format_exc())
        return 4 if kind == "oom" else (3 if kind == "cuda" else 1)


def cmd_segment(args) -> int:
    from . import media
    cfg = _cfg(args)
    ref = _ref(cfg, args)
    try:
        seg = media.get_segment(ref, cfg, float(args.start), float(args.end), args.purpose,
                                lambda f, m="": emit("progress", frac=round(f, 3), detail=m))
        emit("result", **seg)
        return 0
    except UserError as e:
        emit("error", code=e.code, detail=e.detail, fmt=e.fmt)
        return 1
    except Exception:  # noqa: BLE001
        emit("error", code="err_unexpected", detail=traceback.format_exc()[-2000:], fmt={})
        return 1


def _load_items(spec: str) -> list:
    """--items is JSON, or @file with the JSON inside (Windows limits the length of a command line)."""
    spec = spec or "[]"
    if spec.startswith("@"):
        f = Path(spec[1:])
        data = json.loads(f.read_text(encoding="utf-8"))
        try:
            f.unlink()          # a temporary file written by the window for this job
        except OSError:
            pass
        return data
    return json.loads(spec)


def _complete_items(ref, items: list) -> list:
    """Add what is kept in the VOD folder (montage of the clip, where memes fit) to the items."""
    from . import scoring
    doc = ref.moments() or {}
    by_id = {}
    for key, edits in (("moments", ref.edits()), ("kills", ref.albion_edits())):
        try:
            for m in scoring.apply_edits(doc, edits, key):
                by_id[m["id"]] = m
        except Exception:  # noqa: BLE001
            log.warning("could not read the clip edits of %s", ref.key)
    try:
        from . import montage_ai
        montage_ai.attach(ref, list(by_id.values()))        # the memes the AI placed (cache of the VOD)
    except Exception as e:  # noqa: BLE001
        log.info("AI montage plans: %s", e)
    out = []
    for it in items:
        full = dict(it)
        m = by_id.get(it.get("id"))
        if m:
            for k in ("fx", "montage", "montage_ai", "peak", "transcript", "category"):
                if k not in full and m.get(k) is not None:
                    full[k] = m[k]
        out.append(full)
    return out


def cmd_render(args) -> int:
    """Quick preview of the montage of one clip (half size, fast encoding)."""
    from . import montage
    cfg = _cfg(args)
    ref = _ref(cfg, args)
    try:
        items = _complete_items(ref, _load_items(args.items))
        it = items[0]
        fmt = (args.formats or "vertical").split(",")[0]
        window = (float(args.start), float(args.end)) if args.start and args.end else None
        out = Path(args.out)
        path = montage.render(ref, cfg, it, fmt, out.parent,
                              lambda f, m="": emit("progress", frac=round(f, 3), detail=m),
                              preview=True, out_path=out, window=window)
        from . import tools
        emit("result", path=str(path), duration=float(tools.probe(path).get("duration") or 0))
        return 0
    except Cancelled:
        return 2
    except UserError as e:
        emit("error", code=e.code, detail=e.detail, fmt=e.fmt)
        return 1
    except Exception:  # noqa: BLE001
        emit("error", code="err_export_failed", detail=traceback.format_exc()[-2000:], fmt={})
        return 1


def cmd_export(args) -> int:
    from . import export
    cfg = _cfg(args)
    ref = _ref(cfg, args)
    items = _complete_items(ref, _load_items(args.items))
    formats = [f for f in (args.formats or "").split(",") if f in ("landscape", "vertical")]
    if not formats:
        formats = ["vertical"]
    out_dir = Path(args.out) if args.out else cfg.output_dir / export.vod_folder_name(ref.meta)
    jobs = [(it, f) for it in items for f in formats]
    done = []
    failures = 0
    posts: dict = {}
    from . import publish
    from .i18n import language
    for i, (it, fmt) in enumerate(jobs):
        def prog(f, m="", i=i):
            emit("progress", frac=round((i + f) / len(jobs), 4), item=i, total=len(jobs), detail=m)
        try:
            report: dict = {}
            path = export.export_moment(ref, cfg, it, fmt, out_dir, prog, report=report)
            done.append(str(path))
            # ready-to-post text + cover picture next to the clip
            if cfg.get("post_texts", True):
                try:
                    if it.get("id") not in posts:
                        posts[it.get("id")] = publish.post_text(cfg, ref.meta, it, language())
                    publish.write_post_file(path, posts[it.get("id")], language())
                except Exception:  # noqa: BLE001
                    log.warning("post text: %s", traceback.format_exc()[-800:])
            if cfg.get("post_cover", True):
                title = (posts.get(it.get("id")) or {}).get("title") or it.get("title") or ""
                publish.make_cover(path, float(report.get("peak") or 1.0), title, fmt == "vertical")
            emit("exported", id=it.get("id"), fmt=fmt, path=str(path))
        except Cancelled:
            return 2
        except UserError as e:
            failures += 1
            emit("warning", code=e.code, detail=e.detail, fmt=e.fmt, id=it.get("id"))
        except Exception:  # noqa: BLE001
            failures += 1
            emit("warning", code="err_export_failed", detail=traceback.format_exc()[-2000:], fmt={}, id=it.get("id"))
    emit("done", files=done, folder=str(out_dir), failures=failures)
    return 0 if done or not jobs else 1


def cmd_albion(args) -> int:
    """Fetch the Albion kills of a VOD again, then update its ranking."""
    from . import albion, scoring
    cfg = _cfg(args)
    ref = _ref(cfg, args)
    if not ref.dir.exists():
        emit("error", code="err_unexpected", detail=f"unknown VOD {args.key}", fmt={})
        return 1
    links = albion.links_for_vod(cfg, ref.meta)
    if not links:
        emit("error", code="err_albion_no_link", detail="", fmt={"channel": ref.meta.get("login") or ""})
        return 1
    try:
        res = albion.fetch_for_vod(ref, cfg, links, lambda f: emit("progress", frac=round(0.9 * f, 4)),
                                   lambda m: emit("log", msg=m))
        if ref.moments() is not None:
            doc = scoring.compute_and_save(ref, cfg)
            ref.set_state(n_kills=sum(1 for k in doc.get("kills") or [] if not k.get("ignored")))
        emit("progress", frac=1.0)
        fails = [e for e in res.get("errors") or [] if e.get("code") != "warn_albion_failed"]
        for e in fails:
            emit("warning", code=e.get("code") or "warn_albion_failed", detail=str(e.get("detail") or ""),
                 fmt={"name": e.get("player", "")})
        if res.get("partial"):
            emit("warning", code="warn_albion_partial", detail="", fmt={})
        emit("result", n=len(res["events"]), partial=bool(res.get("partial")),
             errors=len(res.get("errors") or []), players=res.get("players") or [])
        return 0
    except albion.AlbionError as e:
        emit("error", code=e.code, detail=e.detail, fmt=e.fmt)
        return 1
    except Exception:  # noqa: BLE001
        emit("error", code="err_unexpected", detail=traceback.format_exc()[-2000:], fmt={})
        return 1


def cmd_albion_check(args) -> int:
    """Find the Albion players of the settings (name -> id, guild, fame)."""
    from . import albion
    cfg = _cfg(args)
    root = albion.data_root(cfg)
    out = []
    for link in albion.clean_links(cfg.get("albion_links")):
        try:
            info = albion.resolve_player(root, link["region"], link["player"], max_age=0)
            out.append(dict(link, ok=True, name=info["name"], guild=info.get("guild", ""),
                            kill_fame=info.get("kill_fame", 0), death_fame=info.get("death_fame", 0), id=info["id"]))
        except albion.AlbionError as e:
            out.append(dict(link, ok=False, code=e.code, detail=e.detail))
    emit("result", players=out)
    return 0


def cmd_compile(args) -> int:
    """Best-of of the given clips (--purpose bestof) or all the kills in 60 s (--purpose kills)."""
    from . import compile as C
    from . import export
    from .i18n import language
    cfg = _cfg(args)
    ref = _ref(cfg, args)
    items = _complete_items(ref, _load_items(args.items))
    formats = [f for f in (args.formats or "").split(",") if f in ("landscape", "vertical")] or ["vertical"]
    out_dir = Path(args.out) if args.out else cfg.output_dir / export.vod_folder_name(ref.meta)
    done = []
    try:
        for i, fmt in enumerate(formats):
            def prog(f, m="", i=i):
                emit("progress", frac=round((i + f) / len(formats), 4), item=i, total=len(formats), detail=m)
            if args.purpose == "kills":
                res = C.kills_reel(ref, cfg, items, fmt, out_dir, prog)
            else:
                res = C.best_of(ref, cfg, items, fmt, out_dir, prog, lang=language())
            done.append(res["path"])
            emit("exported", id="compilation", fmt=fmt, path=res["path"])
    except Cancelled:
        return 2
    except UserError as e:
        emit("error", code=e.code, detail=e.detail, fmt=e.fmt)
        return 1
    except Exception:  # noqa: BLE001
        emit("error", code="err_export_failed", detail=traceback.format_exc()[-2000:], fmt={})
        return 1
    emit("done", files=done, folder=str(out_dir), failures=0)
    return 0


def _discord_items(ref, cfg) -> list:
    """What is posted on Discord: the pinned clips + the best moments (not thrown away), then the kills."""
    from . import scoring
    doc = ref.moments() or {}
    moments = [m for m in scoring.apply_edits(doc, ref.edits()) if m.get("decision") != "reject"]
    pinned = [m for m in moments if m.get("trigger") or m.get("marker")]
    rest = sorted((m for m in moments if m not in pinned), key=lambda m: -float(m.get("score") or 0))
    n = max(1, int(cfg.get("discord_top") or 10))
    items = (pinned + rest)[:n]
    kills = [k for k in scoring.apply_edits(doc, ref.albion_edits(), "kills")
             if not k.get("ignored") and k.get("decision") != "reject"]
    kills.sort(key=lambda k: -float(k.get("fame") or 0))
    return items + kills[:max(0, min(5, n // 2))]


def cmd_discord(args) -> int:
    """discord-post / discord-votes / discord-check."""
    from . import discord, scoring
    from .i18n import language
    cfg = _cfg(args)
    try:
        if args.command == "discord-check":
            res = discord.check(cfg.get("discord_token") or "", cfg.get("discord_channel") or "")
            emit("result", **res)
            return 0
        ref = _ref(cfg, args)
        if args.command == "discord-post":
            items = _discord_items(ref, cfg)
            res = discord.post_clips(ref, cfg, items, lambda f: emit("progress", frac=round(f, 3)), language())
            emit("result", **res)
            return 0
        res = discord.read_votes(ref, cfg)
        if ref.moments() is not None:
            scoring.compute_and_save(ref, cfg)
        votes = res.get("votes") or []
        emit("result", n=len(votes), up=sum(v["up"] for v in votes), down=sum(v["down"] for v in votes))
        return 0
    except UserError as e:
        emit("error", code=e.code, detail=e.detail, fmt=e.fmt)
        return 1
    except Exception:  # noqa: BLE001
        emit("error", code="err_discord_network", detail=traceback.format_exc()[-2000:], fmt={})
        return 1


def cmd_diag(args) -> int:
    from . import diag
    cfg = _cfg(args)
    emit("result", text=diag.report(cfg))
    return 0


def cmd_test_ai(args) -> int:
    from . import llm
    cfg = _cfg(args)
    try:
        answer = llm.test_provider(cfg)
        emit("result", text=answer)
        return 0
    except UserError as e:
        emit("error", code=e.code, detail=e.detail, fmt=e.fmt)
        return 1
    except Exception as e:  # noqa: BLE001
        emit("error", code="err_ai_request", detail=str(e), fmt={})
        return 1


def cmd_ollama_pull(args) -> int:
    from . import llm
    cfg = _cfg(args)
    prov = llm.OllamaProvider(cfg.get("ollama_url") or "", args.model or cfg.get("ollama_model") or "")
    if not prov.available():
        emit("error", code="err_ollama_down", detail="", fmt={})
        return 1
    try:
        prov.pull(lambda f, s="": emit("progress", frac=round(f, 4), detail=s))
        emit("result", text=prov.model)
        return 0
    except UserError as e:
        emit("error", code=e.code, detail=e.detail, fmt=e.fmt)
        return 1


def cmd_download_model(args) -> int:
    from . import transcribe
    cfg = _cfg(args)
    name = args.model
    if not name or name == "auto":
        name = transcribe.auto_settings(cfg)["model"]
    emit("log", msg=tr("plain_model", name=name, size=transcribe.MODELS.get(name, {}).get("mb", "?")))
    try:
        transcribe.download_model(name, lambda f, m="": emit("progress", frac=round(f, 4)))
        emit("result", text=name, msg=tr("plain_ok"))
        return 0
    except UserError as e:
        emit("error", code=e.code, detail=e.detail, fmt=e.fmt)
        return 1


def cmd_selfcheck(args) -> int:
    """Check that everything needed is installed and working."""
    from . import tools, transcribe
    cfg = _cfg(args)
    ok = True

    def line(good: bool, text: str):
        nonlocal ok
        ok = ok and good
        emit("check", ok=good, msg=("OK   " if good else "!!   ") + text)

    for t in ("ffmpeg", "ffprobe", "tdcli", "ytdlp"):
        p = tools.find(t)
        line(p is not None, f"{t}: {p or tr('check_missing')}")
    g = tools.best_gpu()
    if g:
        line(True, f"GPU: {g.name} ({g.vram_mb} Mo), driver {g.driver}")
    else:
        emit("check", ok=True, msg="--   " + tr("check_no_gpu"))
    opts = transcribe.auto_settings(cfg)
    line(transcribe.model_ready(opts["model"]), f"Whisper {opts['model']}: "
         + (tr("check_ready") if transcribe.model_ready(opts["model"]) else tr("check_missing")))
    if g and transcribe.model_ready(opts["model"]):
        try:
            import numpy as np
            tr_ = transcribe.Transcriber(dict(opts, batch_size=1))
            tr_.load()
            tr_.transcribe_window(np.zeros(16000 * 2, dtype=np.int16))
            line(True, tr("check_cuda_ok", compute=tr_.opts["compute_type"]))
        except Exception as e:  # noqa: BLE001
            line(False, tr("check_cuda_fail") + f" ({type(e).__name__}: {str(e)[:200]})")
    try:
        from .signals import _yamnet_session
        _yamnet_session()
        line(True, tr("check_laugh_ok"))
    except Exception as e:  # noqa: BLE001
        line(False, f"YAMNet: {e}")
    if g and tools.find("ffmpeg"):
        line(tools.nvenc_available() or True, "NVENC: " + (tr("check_ready") if tools.nvenc_available()
                                                        else tr("check_nvenc_no")))
    emit("result", ok=ok, text="OK" if ok else "PROBLEM")
    return 0 if ok else 1


def cmd_meme(args) -> int:
    """Memes for the bank: search YouTube, read / download a link, keep a passage (Studio, "Add")."""
    from . import memes, tools
    cfg = _cfg(args)

    def prog(f, m=""):
        emit("progress", frac=round(float(f), 3), detail=m)
    try:
        c = args.command
        if c == "meme-search":
            emit("result", items=memes.search(args.query or "", 12))
        elif c == "meme-info":
            emit("result", **memes.info(args.url or ""))
        elif c == "meme-fetch":
            section = (float(args.start), float(args.end)) if args.start and args.end else None
            emit("result", **memes.fetch(args.url or "", cfg, prog, None, section, args.name or ""))
        elif c == "meme-cut":
            it = memes.cut(cfg, args.src or "", float(args.start or 0), float(args.end or 0), args.kind or "sound",
                           args.name or "meme")
            emit("result", kind=it.kind, ref=it.ref, path=str(it.path), name=it.name)
        elif c == "meme-vod":
            it = memes.vod_cut(_ref(cfg, args), cfg, float(args.start or 0), float(args.end or 0), args.kind or "sound",
                               args.name or "meme", prog)
            emit("result", kind=it.kind, ref=it.ref, path=str(it.path), name=it.name)
        else:
            emit("error", code="err_unexpected", detail=f"unknown command {c}", fmt={})
            return 1
        return 0
    except Cancelled:
        return 2
    except UserError as e:
        emit("error", code=e.code, detail=e.detail, fmt=e.fmt)
        return 1
    except tools.ToolMissing as e:
        emit("error", code="err_tool_missing", detail="", fmt={"tool": e.tool})
        return 1
    except Exception:  # noqa: BLE001
        emit("error", code="err_meme_link_failed", detail=traceback.format_exc()[-2000:], fmt={})
        return 1


def cmd_update_tools(args) -> int:
    """Update yt-dlp and TwitchDownloaderCLI (Twitch changes often break old versions)."""
    from . import tools
    from .util import run_streaming
    _cfg(args)
    ok = True
    yt = tools.find("ytdlp")
    if yt:
        code, last = run_streaming([yt, "-U"], lambda l: emit("log", msg="yt-dlp: " + l))
        ok = ok and code == 0
    td = tools.find("tdcli")
    if td:
        code, last = run_streaming([td, "update", "--force"], lambda l: emit("log", msg="TwitchDownloaderCLI: " + l))
        ok = ok and code == 0
    emit("result", ok=ok)
    return 0 if ok else 1


def cmd_bank(args) -> int:
    """The real memes from the internet (memebank.py): download what is missing (bank-sync, in the background) or
    one meme now (bank-get --url web:...)."""
    from . import memebank
    cfg = _cfg(args)
    try:
        if args.command == "bank-get":
            p = memebank.get(cfg, args.url or "")
            emit("result", ref=args.url, path=str(p))
            return 0
        if args.kind == "retry":
            memebank.clear_failures()
        if args.kind == "lists":
            memebank.refresh_lists(cfg, force=True)

        def prog(done, total, ref, name, ok):
            emit("progress", frac=round(done / max(1, total), 4), detail=f"{done}/{total}")
            emit("bank_item", ref=ref, name=name, ok=bool(ok), done=done, total=total)
        res = memebank.sync(cfg, prog)
        emit("result", **res)
        return 0
    except Exception as e:  # noqa: BLE001
        emit("error", code="err_bank_download", detail=traceback.format_exc()[-2000:], fmt={"err": str(e)[:200]})
        return 1


def cmd_montage_ai(args) -> int:
    """The AI places the memes of one clip (montage-ai --key K --items [moment]): the moment comes from the
    window (it may carry the user's start / end), the plan goes to the cache of the VOD and to the window."""
    from . import montage_ai
    cfg = _cfg(args)
    ref = _ref(cfg, args)
    try:
        items = _load_items(args.items)
        moment = items[0] if items and isinstance(items[0], dict) else {}
        if not moment.get("id"):
            raise ValueError("no moment")
        stats = montage_ai.plan_moments(ref, cfg, [moment], force=True)
        plan = moment.get("montage_ai")
        if not plan:
            raise UserError("err_ai_bad_answer", json.dumps(stats))
        emit("result", id=moment["id"], plan=plan)
        return 0
    except Cancelled:
        return 2
    except UserError as e:
        emit("error", code=e.code, detail=e.detail, fmt=e.fmt)
        return 1
    except Exception as e:  # noqa: BLE001
        emit("error", code="err_ai_request", detail=traceback.format_exc()[-2000:], fmt={"err": str(e)[:200]})
        return 1


def main(argv=None) -> int:
    global _plain
    ap = argparse.ArgumentParser(prog="fireclips.worker")
    ap.add_argument("command")
    ap.add_argument("--key")
    ap.add_argument("--work")
    ap.add_argument("--audio")
    ap.add_argument("--duration")
    ap.add_argument("--opts")
    ap.add_argument("--start")
    ap.add_argument("--end")
    ap.add_argument("--purpose", default="preview")
    ap.add_argument("--items")
    ap.add_argument("--formats")
    ap.add_argument("--out")
    ap.add_argument("--model")
    ap.add_argument("--overrides")
    ap.add_argument("--query")
    ap.add_argument("--url")
    ap.add_argument("--src")
    ap.add_argument("--kind")
    ap.add_argument("--name")
    ap.add_argument("--plain", action="store_true")
    args = ap.parse_args(argv)
    _plain = args.plain
    import os
    os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")
    os.environ.setdefault("DO_NOT_TRACK", "1")
    setup_logging("worker")
    paths.ensure_dirs()
    if args.command in ("analyze", "transcribe", "export", "render", "compile"):
        _lower_priority()
    cmds = {"analyze": cmd_analyze, "transcribe": cmd_transcribe, "segment": cmd_segment, "export": cmd_export,
            "test-ai": cmd_test_ai, "ollama-pull": cmd_ollama_pull, "download-model": cmd_download_model,
            "selfcheck": cmd_selfcheck, "update-tools": cmd_update_tools, "albion": cmd_albion,
            "albion-check": cmd_albion_check, "render": cmd_render, "discord-post": cmd_discord,
            "discord-votes": cmd_discord, "discord-check": cmd_discord, "compile": cmd_compile, "diag": cmd_diag,
            "meme-search": cmd_meme, "meme-info": cmd_meme, "meme-fetch": cmd_meme, "meme-cut": cmd_meme,
            "meme-vod": cmd_meme, "bank-sync": cmd_bank, "bank-get": cmd_bank, "montage-ai": cmd_montage_ai}
    fn = cmds.get(args.command)
    if fn is None:
        emit("error", code="err_unexpected", detail=f"unknown command {args.command}", fmt={})
        return 1
    log.info("worker %s %s (v%s)", args.command, args.key or "", __version__)
    return fn(args)


if __name__ == "__main__":
    sys.exit(main())
