"""Moments marked during the stream: a keyboard shortcut (or a Stream Deck button sending it, or the
tray menu) pressed live, and "!clip" typed in the chat by the streamer, a moderator or a VIP. Each one
becomes a clip pinned at the top of the list, like the trigger phrases."""
from __future__ import annotations

import json
import logging
import threading
import time
from pathlib import Path
from typing import Optional

from . import paths

log = logging.getLogger("fireclips.markers")
_lock = threading.Lock()
MERGE_GAP = 20.0          # marks closer than this are the same moment (several mods typing !clip)
ROLE_NAMES = {"b": "broadcaster", "m": "moderator", "v": "vip", "s": "subscriber"}


def marker_file() -> Path:
    return paths.ROOT / "markers.jsonl"


def add(t: Optional[float] = None, source: str = "hotkey", channels: Optional[list] = None, by: str = "",
        title: str = "") -> dict:
    """Write down a mark (real time, seconds since 1970)."""
    m = {"t": round(float(t if t is not None else time.time()), 2), "source": source,
         "channels": [c.lower() for c in channels or [] if c], "by": by, "title": title[:120]}
    with _lock:
        try:
            f = marker_file()
            f.parent.mkdir(parents=True, exist_ok=True)
            with f.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(m, ensure_ascii=False) + "\n")
        except OSError as e:
            log.warning("could not write the mark: %s", e)
    return m


def load_all() -> list[dict]:
    out = []
    try:
        with marker_file().open(encoding="utf-8") as fh:
            for line in fh:
                try:
                    m = json.loads(line)
                    if isinstance(m, dict) and m.get("t"):
                        out.append(m)
                except ValueError:
                    continue
    except OSError:
        return []
    return out


def chat_command(row: list, cmd: str, roles: set, login: str) -> Optional[str]:
    """The title given with "!clip [title]" when the sender may make clips, else None."""
    text = str(row[2] or "").strip()
    if not text.lower().startswith(cmd):
        return None
    rest = text[len(cmd):]
    if rest and rest[0].isalnum():          # "!clipper" is not "!clip"
        return None
    user = str(row[1] or "").lower()
    r = set(str(row[3] or "")) if len(row) > 3 else set()
    if not (r & roles) and not (login and user == login.lower()):
        return None
    return rest.strip(" :-–—").strip()[:80]


def for_vod(cfg, meta: dict, duration: float, chat: Optional[list] = None, knots: Optional[list] = None) -> list[dict]:
    """The marks that fall inside this VOD: [{"off", "source", "by", "title", "count"}]."""
    from . import albion, timemap
    out: list[dict] = []
    login = str(meta.get("login") or "").lower()
    start = albion.vod_start(meta)
    delay = float(cfg.get("albion_offset") or 0)        # OBS delay, same setting as for the kills
    if start:
        for m in load_all():
            chans = m.get("channels") or []
            if chans and login and login not in chans:
                continue
            off = timemap.vod_offset(float(m["t"]), float(start), knots) + delay
            if -5 <= off <= duration + 5:
                out.append({"off": round(max(0.0, min(duration, off)), 2), "source": m.get("source", "hotkey"),
                            "by": m.get("by", ""), "title": m.get("title", "")})
    cmd = str(cfg.get("chat_clip_command") or "!clip").strip().lower()
    roles = set(cfg.get("chat_clip_roles") or ["b", "m", "v"])
    if cmd and chat:
        for row in chat:
            title = chat_command(row, cmd, roles, login)
            if title is None:
                continue
            out.append({"off": round(float(row[0]), 2), "source": "chat", "by": str(row[1]), "title": title})
    out.sort(key=lambda m: m["off"])
    merged: list[dict] = []
    for m in out:
        if merged and m["off"] - merged[-1]["off"] < MERGE_GAP:
            last = merged[-1]
            last["count"] = last.get("count", 1) + 1
            if m.get("title") and not last.get("title"):
                last["title"] = m["title"]
            if m["by"] and m["by"] not in last.setdefault("others", []) and m["by"] != last.get("by"):
                last["others"].append(m["by"])
            continue
        m["count"] = 1
        merged.append(m)
    return merged
