"""Quick editing of a clip (the "Studio"): jump cuts, cold open, slow motion, freeze frames, zoom
punch, shake, memes (pictures, GIFs, videos, sounds), emojis, text, Albion kill card, bleeped swear
words, background music that gets quieter when the streamer talks, watermark, intro / outro and
loudness levelling - all rendered by ffmpeg in one go.

The edit list of a clip is stored in the clip edits under "montage":
    {"v": 1, "elements": [...], "jumpcuts": bool, "cold_open": bool, "hook": t, "music": ref,
     "music_vol": 0..100, "sub_style": "", "subs": None|bool, "bleep": bool, "auto": bool}
Element times ("t") are VOD times, so changing the start / end of the clip does not move them.
"""
from __future__ import annotations

import hashlib
import io
import logging
import math
import random
import re
import secrets
import shutil
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

from . import bank, fxlib, paths, profiles, subtitles, tools
from .errors import UserError
from .util import fmt_tag, run, run_streaming, unique_path

log = logging.getLogger("fireclips.montage")

OV_FPS = 30
AFMT = "aformat=sample_fmts=fltp:sample_rates=48000:channel_layouts=stereo"

KINDS = ("emoji", "image", "video", "sound", "text", "killcard", "zoom", "shake", "slowmo", "freeze", "bleep", "fx")
VISUAL = ("emoji", "image", "video", "text", "killcard")
EFFECTS = ("zoom", "shake", "slowmo", "freeze", "bleep")
DEFAULT_DUR = {"emoji": 1.6, "image": 2.2, "text": 2.4, "killcard": 3.4, "zoom": 1.1, "shake": 0.8,
               "slowmo": 2.0, "freeze": 1.2, "bleep": 0.5, "video": 0.0, "sound": 0.0, "fx": 2.0}
DEFAULT_SIZE = {"emoji": 0.22, "image": 0.42, "video": 0.62, "text": 1.0, "killcard": 1.0, "fx": 1.0}
DEFAULT_ANIM = {"emoji": "pop", "image": "pop", "text": "pop", "killcard": "slide"}
FX_SOUND = {"zoom": "kill", "freeze": "freeze", "shake": "", "slowmo": "", "killcard": ""}   # memebank roles


def new_id() -> str:
    return "e" + secrets.token_hex(3)


def _f(v, d: float, lo: Optional[float] = None, hi: Optional[float] = None) -> float:
    try:
        x = float(v)
    except (TypeError, ValueError):
        x = d
    if x != x or x in (float("inf"), float("-inf")):
        x = d
    if lo is not None:
        x = max(lo, x)
    if hi is not None:
        x = min(hi, x)
    return x


# --------------------------------------------------------------------------- edit list


def clean_card(c: dict) -> dict:
    out = {}
    for k in ("role", "me", "other", "guild", "alliance"):
        out[k] = str(c.get(k) or "")[:60]
    out["role"] = out["role"] if out["role"] in ("kill", "assist", "death") else "kill"
    for k in ("fame", "ip", "my_ip"):
        out[k] = int(_f(c.get(k), 0, 0))
    for k in ("weapon", "my_weapon"):
        w = c.get(k)
        if isinstance(w, (list, tuple)) and w and w[0]:
            out[k] = [str(w[0])[:80], int(_f(w[1] if len(w) > 1 else 1, 1, 1, 5))]
    out["region"] = str(c.get("region") or "europe")
    return out


def clean_element(e) -> Optional[dict]:
    if not isinstance(e, dict):
        return None
    kind = e.get("kind")
    if kind not in KINDS:
        return None
    out: dict = {"id": str(e.get("id") or new_id())[:16], "kind": kind, "t": round(_f(e.get("t"), 0.0, 0.0), 3)}
    if kind == "fx" and e.get("effect") not in fxlib.EFFECTS:
        return None
    if kind in ("sound", "video"):
        out["dur"] = round(_f(e.get("dur"), 0.0, 0.0, 60.0), 3)      # 0 = the whole file
    else:
        dd = fxlib.EFFECTS[e["effect"]]["dur"] if kind == "fx" else DEFAULT_DUR[kind]
        out["dur"] = round(_f(e.get("dur"), dd, 0.1, 60.0), 3)
    for k in ("file", "text", "group"):
        if e.get(k):
            out[k] = str(e[k])[:600]
    if kind == "fx":
        out["effect"] = e["effect"]
    if kind in VISUAL + ("zoom", "fx"):
        # position of the centre, in fractions of the game picture (the same place in 16:9 and 9:16)
        for k in ("x", "y"):
            if e.get(k) is not None:
                out[k] = round(_f(e[k], 0.5, -0.5, 1.5), 4)
        if e.get("size") is not None:
            out["size"] = round(_f(e["size"], DEFAULT_SIZE[kind], 0.03, 3.0), 4)
    if kind in ("emoji", "image", "text", "killcard"):
        if e.get("anim") in fxlib.ANIMS:
            out["anim"] = e["anim"]
        if e.get("rot"):
            out["rot"] = round(_f(e["rot"], 0.0, -180.0, 180.0), 1)
    if kind in ("sound", "video"):
        out["vol"] = int(_f(e.get("vol"), 100, 0, 300))
        out["duck"] = bool(e.get("duck", kind == "video"))
    if kind == "video":
        out["chroma"] = bool(e.get("chroma"))
        out["full"] = bool(e.get("full"))
    if kind == "zoom":
        out["amount"] = round(_f(e.get("amount"), 1.35, 1.05, 2.5), 3)
    if kind == "shake":
        out["amount"] = round(_f(e.get("amount"), 1.0, 0.2, 3.0), 3)
    if kind == "slowmo":
        out["speed"] = round(_f(e.get("speed"), 0.5, 0.2, 3.0), 3)       # < 1 slow motion, > 1 fast forward
    if kind in ("text", "fx"):
        if re.fullmatch(r"#[0-9A-Fa-f]{6}", str(e.get("color") or "")):
            out["color"] = e["color"]
    if kind == "text":
        out["style"] = e.get("style") if e.get("style") in fxlib.TEXT_STYLES else "classic"
    if kind == "killcard" and isinstance(e.get("card"), dict):
        out["card"] = clean_card(e["card"])
    if kind in ("emoji", "image", "sound", "video") and not out.get("file"):
        return None
    if kind == "text" and not (out.get("text") or "").strip():
        return None
    if kind == "killcard" and not out.get("card"):
        return None
    if e.get("auto"):
        out["auto"] = True
    return out


MIN_SEGMENT = 0.2


def clean_segments(v) -> Optional[list]:
    """The parts of the clip the user keeps ([[VOD start, VOD end], ...], sorted, not overlapping), None = all."""
    if not isinstance(v, (list, tuple)):
        return None
    out: list[list[float]] = []
    for seg in v[:200]:
        try:
            k0, k1 = float(seg[0]), float(seg[1])
        except (TypeError, ValueError, IndexError):
            continue
        if k1 - k0 < MIN_SEGMENT:
            continue
        out.append([round(k0, 3), round(k1, 3)])
    out.sort()
    kept: list[list[float]] = []
    for k0, k1 in out:
        if kept and k0 < kept[-1][1]:
            k0 = kept[-1][1]
            if k1 - k0 < MIN_SEGMENT:
                continue
        kept.append([k0, k1])
    return kept or None


def normalize(m) -> dict:
    m = m if isinstance(m, dict) else {}
    els = [x for x in (clean_element(e) for e in (m.get("elements") or [])[:300]) if x]
    els.sort(key=lambda e: e["t"])
    subs = m.get("subs")
    return {
        "v": 1,
        "elements": els,
        "segments": clean_segments(m.get("segments")),
        "jumpcuts": bool(m.get("jumpcuts")),
        "cold_open": bool(m.get("cold_open")),
        "hook": round(_f(m["hook"], 0.0, 0.0), 2) if m.get("hook") is not None else None,
        "music": str(m.get("music") or ""),
        "music_vol": int(_f(m.get("music_vol"), 18, 0, 100)),
        "sub_style": str(m.get("sub_style") or ""),
        "subs": None if subs is None else bool(subs),
        "bleep": bool(m.get("bleep")),
        "auto": bool(m.get("auto")),
        "ai": bool(m.get("ai")),
    }


def element(kind: str, t: float, **kw) -> dict:
    e = {"id": new_id(), "kind": kind, "t": round(float(t), 3)}
    e.update({k: v for k, v in kw.items() if v is not None})
    return clean_element(e) or e


def is_empty(m: Optional[dict]) -> bool:
    if not m:
        return True
    return not (m.get("elements") or m.get("jumpcuts") or m.get("cold_open") or m.get("music") or m.get("bleep")
                or m.get("sub_style") or m.get("subs") is not None or m.get("segments"))


# --------------------------------------------------------------------------- automatic montage


def _rnd(moment: dict) -> random.Random:
    key = f"{moment.get('id')}|{moment.get('start')}"
    return random.Random(int(hashlib.md5(key.encode("utf-8")).hexdigest()[:8], 16))


def hook_time(moment: dict) -> Optional[float]:
    """The best two seconds of the clip (for the cold open)."""
    a, b = float(moment["start"]), float(moment["end"])
    hints = [h for h in moment.get("fx") or [] if a <= h["t"] <= b]
    order = {"kill": 0, "death": 1, "laugh": 2, "chat_laugh": 3, "loud": 4, "assist": 5, "hype": 6}
    if hints:
        best = min(hints, key=lambda h: (order.get(h["kind"], 9), -float(h.get("v") or 0)))
        return float(best["t"])
    pk = moment.get("peak")
    if pk is not None and a <= float(pk) <= b:
        return float(pk)
    return None


def suggest(moment: dict, cfg, rnd: Optional[random.Random] = None) -> list[dict]:
    """Memes / effects placed from what happened in the clip: kills (zoom + kill card), deaths (skull +
    sad trombone), laughs (😂), yelling (shake), chat hype (🔥)."""
    rnd = rnd or _rnd(moment)
    a, b = float(moment["start"]), float(moment["end"])
    hints = [dict(h) for h in moment.get("fx") or [] if a - 0.3 <= float(h["t"]) <= b + 0.3]
    with_sound = bool(cfg.get("montage_fx_sounds", True))
    prio = {"kill": 0, "death": 1, "assist": 2, "laugh": 3, "chat_laugh": 4, "loud": 5, "hype": 6}
    hints.sort(key=lambda h: (prio.get(h["kind"], 9), -float(h.get("v") or 0)))
    limit = max(2, min(6, int((b - a) / 8)))
    positions = [(0.76, 0.30), (0.25, 0.32), (0.74, 0.68), (0.28, 0.66)]   # in the game picture
    rnd.shuffle(positions)
    taken: list[float] = []
    out: list[dict] = []
    pi = 0
    kills = 0
    from . import memebank
    for h in hints:
        t = min(max(float(h["t"]), a + 0.2), b - 0.5)
        if any(abs(t - x) < 3.5 for x in taken):
            continue
        if len(taken) >= limit:
            break
        g = new_id()
        k = h["kind"]
        x, y = positions[pi % len(positions)]
        if k == "kill":
            kills += 1
            out.append(element("zoom", t - 0.3, dur=1.1, amount=1.3, group=g, auto=True))
            snd = memebank.auto_sound("multikill" if kills > 1 else "kill")
            if with_sound and snd:
                out.append(element("sound", t - 0.3, file=snd, vol=85, group=g, auto=True))
            if h.get("card"):
                out.append(element("killcard", t + 0.1, dur=3.4, card=h["card"], group=g, auto=True))
        elif k == "assist":
            if not h.get("card") or float(h.get("v") or 0) < 0.6:
                continue
            out.append(element("killcard", t + 0.1, dur=3.0, card=h["card"], group=g, auto=True))
        elif k == "death":
            pi += 1
            out.append(element("emoji", t + 0.2, dur=2.2, file="emoji:1f480", x=x, y=y, group=g, auto=True))
            snd = memebank.auto_sound("death", rnd.randrange(8))
            if with_sound and snd:
                out.append(element("sound", t + 0.2, file=snd, vol=75, group=g, auto=True))
            if h.get("card"):
                out.append(element("killcard", t + 0.4, dur=3.0, card=h["card"], group=g, auto=True))
        elif k in ("laugh", "chat_laugh"):
            pi += 1
            code = rnd.choice(["1f602", "1f923", "1f602", "1f62d"])
            out.append(element("emoji", t - 0.3, dur=1.7, file=f"emoji:{code}", x=x, y=y, group=g, auto=True))
        elif k == "loud":
            out.append(element("shake", t - 0.2, dur=0.7, group=g, auto=True))
            if rnd.random() < 0.5:
                pi += 1
                code = rnd.choice(["1f631", "1f92f", "1f633"])
                out.append(element("emoji", t - 0.1, dur=1.5, file=f"emoji:{code}", x=x, y=y, group=g, auto=True))
        elif k == "hype":
            pi += 1
            code = rnd.choice(["1f525", "1f440", "1f4af"])
            out.append(element("emoji", t, dur=1.6, file=f"emoji:{code}", x=x, y=y, group=g, auto=True))
        else:
            continue
        taken.append(t)
    return [e for e in out if e]


def music_choices(cfg) -> list[str]:
    try:
        return [it.ref for it in bank.list_items(cfg, "music")]
    except Exception:  # noqa: BLE001
        return []


def auto_montage(moment: dict, cfg, music: Optional[list] = None) -> dict:
    """The edit list FireClips makes by itself for a clip (until the user changes it)."""
    m = normalize({})
    m["auto"] = True
    mid = str(moment.get("id") or "")
    rnd = _rnd(moment)
    jc = cfg.get("montage_jumpcuts") or "talk"
    m["jumpcuts"] = jc == "all" or (jc == "talk" and mid.startswith("m"))
    m["bleep"] = bool(cfg.get("montage_bleep"))
    a, b = float(moment["start"]), float(moment["end"])
    ai_music = ""
    if cfg.get("montage_auto", True):
        from . import montage_ai
        plan = moment.get("montage_ai")
        if cfg.get("montage_ai", True) and montage_ai.valid(plan, moment):
            # the AI read the clip: its memes, at its seconds
            m["elements"], ai_music, m["music_vol"] = montage_ai.elements(plan, moment, cfg, rnd)
            m["ai"] = True
        else:
            m["elements"] = suggest(moment, cfg, rnd)
    if cfg.get("montage_cold_open") and b - a >= 15:
        h = hook_time(moment)
        if h is not None and h - a >= 6:
            m["cold_open"] = True
            m["hook"] = round(h, 2)
    if ai_music:
        m["music"] = ai_music
    elif cfg.get("montage_music"):
        choices = music if music is not None else music_choices(cfg)
        if choices:
            m["music"] = rnd.choice(sorted(choices))
            m["music_vol"] = int(cfg.get("montage_music_vol") or 18)
    # the same ids every time this edit list is made (it is made again each time it is needed): the
    # Studio keeps what is picked, the random looks of the effects stay the same in the preview and export
    groups: dict = {}
    for i, e in enumerate(m["elements"]):
        e["id"] = "a" + hashlib.md5(f"{mid}|{moment.get('start')}|{i}".encode("utf-8")).hexdigest()[:6]
        if e.get("group"):
            e["group"] = groups.setdefault(e["group"], "g" + e["id"][1:])
    return m


def effective(moment: dict, cfg) -> dict:
    """The edit list used to render a clip: the user's one, else the automatic one."""
    if isinstance(moment.get("montage"), dict):
        return normalize(moment["montage"])
    return auto_montage(moment, cfg)


# --------------------------------------------------------------------------- timeline (pieces)


@dataclass
class Piece:
    kind: str                 # play | freeze
    a: float                  # VOD time
    b: float
    speed: float = 1.0
    hold: float = 0.0         # freeze: seconds
    hook: bool = False        # the cold open copy at the start
    out_a: float = 0.0        # where it starts in the clip
    zoom: float = 1.0         # small punch-in on every other jump cut

    @property
    def length(self) -> float:
        return self.hold if self.kind == "freeze" else (self.b - self.a) / self.speed

    @property
    def out_b(self) -> float:
        return self.out_a + self.length


def jump_cuts(a: float, b: float, words: list, protect=(), pad: float = 0.22) -> list[tuple[float, float]]:
    """The parts of [a, b] kept when the silences are cut out (talking clips). Silences around a
    protected time (a kill, a laugh, a meme the user placed...) are kept."""
    ws = sorted((max(a, float(s)), min(b, float(e))) for s, e, _t in words if float(e) > a and float(s) < b)
    if not ws:
        return [(a, b)]
    prot = sorted(float(p) for p in protect)

    def cuts_for(min_gap: float) -> list[tuple[float, float]]:
        spans: list[list[float]] = []
        for s, e in ws:
            if spans and s - spans[-1][1] < min_gap:
                spans[-1][1] = max(spans[-1][1], e)
            else:
                spans.append([s, e])
        gaps = []
        if spans[0][0] - a > min_gap * 0.8:
            gaps.append((a, spans[0][0], True, False))
        for (s0, e0), (s1, e1) in zip(spans, spans[1:]):
            gaps.append((e0, s1, False, False))
        if b - spans[-1][1] > min_gap * 0.8:
            gaps.append((spans[-1][1], b, False, True))
        out = []
        for g0, g1, lead, tail in gaps:
            if g1 - g0 < min_gap * (0.8 if lead or tail else 1.0):
                continue
            if any(g0 - 0.4 <= p <= g1 + 0.4 for p in prot):
                continue
            c0 = g0 if lead else g0 + pad
            c1 = g1 if tail else g1 - pad
            if c1 - c0 >= 0.25:
                out.append((c0, c1))
        return out

    cuts: list[tuple[float, float]] = []
    for min_gap in (0.9, 1.6, 2.8):
        cuts = cuts_for(min_gap)
        if sum(c1 - c0 for c0, c1 in cuts) <= 0.5 * (b - a):
            break
    else:
        cuts = []
    keep = []
    cur = a
    for c0, c1 in cuts:
        if c0 > cur + 0.04:
            keep.append((cur, c0))
        cur = max(cur, c1)
    if b > cur + 0.04:
        keep.append((cur, b))
    return keep or [(a, b)]


def segments_in(a: float, b: float, segments: Optional[list]) -> list[tuple[float, float]]:
    """The user's kept parts inside [a, b] (the whole clip when there are none)."""
    out = []
    for k0, k1 in segments or []:
        s0, s1 = max(a, float(k0)), min(b, float(k1))
        if s1 - s0 >= 0.1:
            out.append((s0, s1))
    return out or [(a, b)]


def plan(a: float, b: float, m: dict, words: list, protect=(), hook_t: Optional[float] = None) -> list[Piece]:
    segs = segments_in(a, b, m.get("segments"))
    keep: list[tuple[float, float]] = []
    for sa, sb in segs:
        keep += jump_cuts(sa, sb, words, protect) if m.get("jumpcuts") else [(sa, sb)]
    slows = sorted((e["t"], e["t"] + e["dur"], float(e.get("speed") or 0.5))
                   for e in m.get("elements") or [] if e["kind"] == "slowmo")
    pieces: list[Piece] = []
    for ka, kb in keep:
        cuts = {round(ka, 4), round(kb, 4)}
        for s0, s1, _sp in slows:
            for x in (s0, s1):
                if ka < x < kb:
                    cuts.add(round(x, 4))
        cuts_l = sorted(cuts)
        for c0, c1 in zip(cuts_l, cuts_l[1:]):
            if c1 - c0 < 0.04:
                continue
            mid = (c0 + c1) / 2
            sp = next((s for s0, s1, s in slows if s0 <= mid < s1), 1.0)
            pieces.append(Piece("play", c0, c1, speed=sp))
    freezes = [e for e in m.get("elements") or []
               if e["kind"] == "freeze" or (e["kind"] == "fx" and e.get("effect") in fxlib.FREEZE_EFFECTS)]
    for e in sorted(freezes, key=lambda e: e["t"]):
        t = float(e["t"])
        for i, p in enumerate(pieces):
            if p.kind != "play":
                continue
            if p.a + 0.04 < t < p.b - 0.04:
                pieces[i:i + 1] = [Piece("play", p.a, t, p.speed), Piece("freeze", t, t, hold=e["dur"]),
                                   Piece("play", t, p.b, p.speed)]
                break
            if abs(p.a - t) <= 0.04 or (p.a > t and p.a - t < 1.0):
                pieces.insert(i, Piece("freeze", p.a, p.a, hold=e["dur"]))
                break
    if m.get("jumpcuts") and len(keep) > 1:
        # a small punch-in on every other jump cut hides the jump; the cuts the user made stay plain cuts
        idx = 0
        prev_end = None
        for p in pieces:
            if p.kind != "play":
                continue
            if prev_end is not None and p.a - prev_end > 0.05 and \
                    any(sa <= prev_end + 1e-3 and p.a <= sb + 1e-3 for sa, sb in segs):
                idx += 1
            p.zoom = 1.08 if idx % 2 else 1.0
            prev_end = p.b
    if m.get("cold_open") and hook_t is not None:
        h0, h1 = max(a, hook_t - 1.2), min(b, hook_t + 1.4)
        if h1 - h0 >= 1.0 and h0 - a >= 3.0:
            pieces.insert(0, Piece("play", h0, h1, hook=True))
    t = 0.0
    for p in pieces:
        p.out_a = t
        t += p.length
    return pieces


def split_segments(moment: dict, m: dict, t: float) -> Optional[list]:
    """The segments after a cut at VOD time t (None: t is not inside a kept part, or too close to an edge)."""
    a, b = float(moment["start"]), float(moment["end"])
    segs = [list(x) for x in segments_in(a, b, m.get("segments"))]
    for i, (k0, k1) in enumerate(segs):
        if k0 + MIN_SEGMENT <= t <= k1 - MIN_SEGMENT:
            segs[i:i + 1] = [[k0, round(t, 3)], [round(t, 3), k1]]
            return segs
    return None


def segment_at(moment: dict, m: dict, t: float) -> Optional[int]:
    """Which kept part VOD time t is in."""
    a, b = float(moment["start"]), float(moment["end"])
    for i, (k0, k1) in enumerate(segments_in(a, b, m.get("segments"))):
        if k0 - 1e-3 <= t <= k1 + 1e-3:
            return i
    return None


def total_length(pieces: list[Piece]) -> float:
    return sum(p.length for p in pieces)


def map_time(pieces: list[Piece], t: float, tol: float = 0.05) -> list[float]:
    """Where VOD time t is in the clip (twice with a cold open: in the hook and in the clip)."""
    out = []
    for hook in (True, False):
        found = None
        for p in pieces:
            if p.hook != hook:
                continue
            if p.kind == "freeze":
                if abs(t - p.a) <= tol:
                    found = p.out_a
                    break
                continue
            if p.a - tol <= t < p.b:
                found = p.out_a + max(0.0, t - p.a) / p.speed
                break
        if found is None and not hook:
            # in a cut silence: at the next kept part
            nxt = [p for p in pieces if not p.hook and p.a >= t]
            if nxt and nxt[0].a - t < 4.0:
                found = nxt[0].out_a
        if found is not None:
            out.append(found)
    return out


def room_after(pieces: list[Piece], o: float, total: float) -> float:
    """How long an overlay starting at clip time o may last (the cold open copy stops at its end)."""
    for p in pieces:
        if p.hook and p.out_a - 1e-6 <= o < p.out_b:
            return p.out_b - o
    return total - o


def map_first(pieces: list[Piece], t: float) -> Optional[float]:
    """Clip time of VOD time t (the main occurrence, not the cold open copy)."""
    res = map_time(pieces, t)
    if not res:
        return None
    hook_len = sum(p.length for p in pieces if p.hook)
    main = [x for x in res if x >= hook_len - 1e-6]
    return main[0] if main else res[-1]


def unmap_time(pieces: list[Piece], o: float) -> Optional[float]:
    """VOD time shown at clip time o (None in a freeze frame)."""
    for p in pieces:
        if p.out_a - 1e-6 <= o < p.out_b + 1e-6:
            if p.kind == "freeze":
                return p.a
            return p.a + (o - p.out_a) * p.speed
    return None


def map_words(pieces: list[Piece], words: list) -> list[tuple]:
    """Transcript words placed on the clip timeline. Returns (start, end, text, index)."""
    out = []
    for p in pieces:
        if p.kind != "play":
            continue
        for i, (s, e, txt) in enumerate(words):
            s, e = float(s), float(e)
            if e <= p.a or s >= p.b:
                continue
            s2, e2 = max(s, p.a), min(e, p.b)
            if e2 - s2 < 0.5 * (e - s) and e2 - s2 < 0.12:
                continue
            out.append((p.out_a + (s2 - p.a) / p.speed, p.out_a + (e2 - p.a) / p.speed, txt, i))
    out.sort(key=lambda w: w[0])
    return out


# --------------------------------------------------------------------------- shared schedules
# Used by the export (render) and by the Studio live preview, so both show the same thing.


@dataclass
class ClipPlan:
    a: float
    b: float
    m: dict
    els: list
    words: list
    swear: set
    pieces: list
    total: float
    hook_t: Optional[float]


def make_plan(moment: dict, m: dict, words: list, window: Optional[tuple] = None) -> ClipPlan:
    """The timeline of a clip: kept parts (jump cuts, slow motion, freeze frames, cold open)."""
    a, b = float(moment["start"]), float(moment["end"])
    if window is not None:
        a, b = max(a, float(window[0])), min(b, float(window[1]))
        m = dict(m, cold_open=False)
    swear = subtitles.swear_indexes(words) if m.get("bleep") else set()
    els = [e for e in m["elements"] if a - 0.05 <= e["t"] < b - 0.05]
    protect = [float(h["t"]) for h in moment.get("fx") or []] + \
        [e["t"] for e in els if e["kind"] in VISUAL + ("sound", "fx")]
    hook_t = m.get("hook") if m.get("hook") is not None else hook_time(moment)
    pieces = plan(a, b, dict(m, elements=els), words, protect, hook_t) if b - a >= 0.5 else []
    return ClipPlan(a, b, m, els, words, swear, pieces, total_length(pieces), hook_t)


def visual_schedule(pl: ClipPlan, cfg=None) -> list[tuple[dict, float, float]]:
    """(element, clip time, length) of everything drawn on top of the video (memes, texts, kill cards,
    videos, animated effects), in drawing order."""
    out = []
    for e in pl.els:
        if e["kind"] not in VISUAL and e["kind"] != "fx":
            continue
        if e["kind"] == "fx" and not fxlib.EFFECTS[e["effect"]].get("overlay"):
            continue
        for o in map_time(pl.pieces, e["t"]):
            if e["kind"] == "video":
                vp = bank.resolve(e.get("file") or "", cfg)
                vdur = e["dur"] or (bank.duration(vp) if vp is not None else 0) or 4.0
                d = min(min(vdur, 30.0), room_after(pl.pieces, o, pl.total))
            else:
                d = min(e["dur"], room_after(pl.pieces, o, pl.total))
            if d > 0.05:
                out.append((e, o, d))
    return out


def sound_schedule(pl: ClipPlan, cfg) -> list[tuple[dict, Path, float, float]]:
    """(element, file, clip time, length or 0 = until the end of the file) of the sounds."""
    out = []
    for e in pl.els:
        if e["kind"] != "sound":
            continue
        path = bank.resolve(e["file"], cfg)
        if path is None:
            (log.info if str(e.get("file") or "").startswith("web:") else log.warning)("sound not found: %s", e.get("file"))
            continue
        for o in map_time(pl.pieces, e["t"]):
            if o >= pl.total - 0.05:
                continue
            room = room_after(pl.pieces, o, pl.total)
            d = min(e["dur"], room) if e.get("dur") else (room if room < pl.total - o - 1e-3 else 0)
            out.append((e, path, o, d))
    return out


def bleep_windows(pl: ClipPlan) -> list[tuple[float, float]]:
    out = []
    for e in pl.els:
        if e["kind"] == "bleep":
            for o in map_time(pl.pieces, e["t"]):
                out.append((o, min(pl.total, o + e["dur"])))
    if pl.swear:
        for s0, e0, _t, i in map_words(pl.pieces, pl.words):
            if i in pl.swear:
                out.append((max(0.0, s0 - 0.03), min(pl.total, e0 + 0.03)))
    return out


def zoom_windows(pl: ClipPlan) -> list[dict]:
    zwin = []
    for e in pl.els:
        if e["kind"] in ("zoom", "shake"):
            for o in map_time(pl.pieces, e["t"]):
                zwin.append({"kind": e["kind"], "o0": o, "o1": o + min(e["dur"], room_after(pl.pieces, o, pl.total)),
                             "amount": e.get("amount", 1.35 if e["kind"] == "zoom" else 1.0),
                             "cx": e.get("x", 0.5), "cy": e.get("y", 0.5)})
        elif e["kind"] == "fx" and fxlib.EFFECTS[e["effect"]].get("shake"):
            for o in map_time(pl.pieces, e["t"]):
                zwin.append({"kind": "shake", "o0": o, "o1": o + min(0.6, e["dur"], room_after(pl.pieces, o, pl.total)),
                             "amount": 1.4, "cx": 0.5, "cy": 0.5})
    for p in pl.pieces:
        if p.kind == "play" and p.zoom > 1.0:
            zwin.append({"kind": "cut", "o0": p.out_a, "o1": p.out_b, "amount": p.zoom})
    return zwin


def zoom_at(zwin: list[dict], o: float) -> tuple[float, float, float, float, float]:
    """(zoom, centre x, centre y, shake dx, shake dy) at clip time o - the same maths as zoom_fx()."""
    z, cx, cy, dx, dy = 0.0, 0.5, 0.5, 0.0, 0.0
    for w in zwin:
        o0, o1 = w["o0"], w["o1"]
        if w["kind"] == "cut":
            if o0 <= o <= o1 - 0.001:
                z += w["amount"] - 1
            continue
        if not o0 <= o <= o1:
            continue
        ramp_in = 0.06 if w["kind"] == "zoom" else 0.03
        win = min(1.0, (o - o0) / ramp_in) * min(1.0, (o1 - o) / 0.12)
        if w["kind"] == "zoom":
            z += (w["amount"] - 1) * win
            cx += w.get("cx", 0.5) - 0.5
            cy += w.get("cy", 0.5) - 0.5
        else:
            amp = 0.014 * w["amount"]
            z += 0.07 * w["amount"] * win
            dx += amp * math.sin(2 * math.pi * 17 * o) * win
            dy += amp * math.cos(2 * math.pi * 13 * o) * win
    return min(2.5, 1 + z), cx, cy, dx, dy


def filter_windows(pl: ClipPlan) -> dict[str, list[tuple[float, float]]]:
    """Animated effects that change the colours of the video: {effect: [(from, to) clip time]}."""
    out: dict[str, list] = {}
    for e in pl.els:
        if e["kind"] != "fx" or not fxlib.EFFECTS[e["effect"]].get("filter"):
            continue
        for o in map_time(pl.pieces, e["t"]):
            d = min(e["dur"], room_after(pl.pieces, o, pl.total))
            if d > 0.05:
                out.setdefault(e["effect"], []).append((o, o + d))
    return out


def duck_windows_for(pl: ClipPlan, sched: list) -> list[tuple[float, float]]:
    out = []
    for e, path, o, d in sched:
        if e.get("duck"):
            out.append((o, o + (e.get("dur") or bank.duration(path) or 1.0)))
    return out


# --------------------------------------------------------------------------- pictures (Pillow)


def _pil():
    Image, ImageDraw, _Filter, ImageFont = fxlib._pil()
    return Image, ImageDraw, ImageFont


FONT_FILES = fxlib.FONT_FILES


def _font(size: int, name: str = "Montserrat ExtraBold"):
    return fxlib.font(max(6, int(size)), name)


_hex = fxlib.hex_rgba
_ease_out_back = fxlib.ease_out_back
_ease_out_cubic = fxlib.ease_out_cubic


class Sequence:
    """A PNG sequence for one overlay (identical frames are encoded once)."""

    def __init__(self, folder: Path):
        self.folder = folder
        folder.mkdir(parents=True, exist_ok=True)
        self.n = 0
        self._last_key = None
        self._last_bytes = b""

    def add(self, img, key=None) -> None:
        if key is not None and key == self._last_key:
            data = self._last_bytes
        else:
            buf = io.BytesIO()
            img.save(buf, "PNG", compress_level=1)
            data = buf.getvalue()
            self._last_key, self._last_bytes = key, data
        (self.folder / f"{self.n:05d}.png").write_bytes(data)
        self.n += 1


def _with_alpha(img, factor: float):
    if factor >= 0.999:
        return img
    r, g, b, a = img.split()
    a = a.point(lambda v: int(v * max(0.0, factor)))
    Image, _D, _F = _pil()
    return Image.merge("RGBA", (r, g, b, a))


def _load_frames(path: Path, box: int) -> list[tuple]:
    """[(RGBA picture fitted in box x box, duration s)] - several for an animated GIF / WebP."""
    Image, _D, _F = _pil()
    out = []
    with Image.open(path) as im:
        n = getattr(im, "n_frames", 1) or 1
        for i in range(min(n, 400)):
            if n > 1:
                im.seek(i)
            fr = im.convert("RGBA")
            scale = box / max(fr.width, fr.height)
            fr = fr.resize((max(1, int(fr.width * scale)), max(1, int(fr.height * scale))), Image.LANCZOS)
            dur = float(im.info.get("duration") or 100) / 1000.0 if n > 1 else 0.0
            out.append((fr, max(0.02, dur) if n > 1 else 0.0))
    return out


_ANIM_BOUNDS = {"pop": (1.12, 0.0, 0.0), "bounce": (1.1, 0.0, 1.35), "shake": (1.06, 0.06, 0.0),
                "spin": (1.12, 0.0, 0.0), "pulse": (1.2, 0.0, 0.0), "float": (1.0, 0.0, 0.62),
                "grow": (1.27, 0.0, 0.0), "slide": (1.0, 0.0, 0.0), "fade": (1.0, 0.0, 0.0),
                "typewriter": (1.0, 0.0, 0.0), "none": (1.0, 0.0, 0.0)}


def _turn_extent(w: float, h: float, max_deg: float) -> tuple[float, float]:
    """Bounding box of a w x h picture turned by up to max_deg degrees (either way)."""
    if max_deg <= 0.05:
        return w, h
    if max_deg >= 90:
        d = math.hypot(w, h)
        return d, d
    a = math.radians(max_deg)

    def ext(p: float, q: float) -> float:
        if math.atan2(q, p) <= a:
            return math.hypot(p, q)
        return p * math.cos(a) + q * math.sin(a)
    return ext(w, h), ext(h, w)


def sprite_canvas(w0: int, h0: int, anim: str, rot: float = 0.0, wobble: bool = False) -> tuple[int, int]:
    """Size of the box an animated picture of w0 x h0 moves in (its rest position is the centre)."""
    anim = anim or "pop"
    smax, dxm, dym = _ANIM_BOUNDS.get(anim, (1.12, 0.0, 0.0))
    turn = 360.0 if anim == "spin" else abs(rot) + (9.5 if anim == "shake" else 0.0) + (7.5 if wobble else 0.0)
    bw, bh = _turn_extent(w0, h0, turn)
    return int(bw * smax + 2 * dxm * w0) + 4, int(bh * smax + 2 * dym * h0) + 4


def picture_source(e: dict, W: int, H: int, cfg=None, lang: str = "fr"):
    """What an element shows, before animation: (frames [(RGBA picture, seconds)], picture_at(tt) or None).
    picture_at is used by the typewriter text (a new picture for each letter)."""
    kind = e["kind"]
    size = e.get("size", DEFAULT_SIZE.get(kind, 1.0))
    if kind in ("emoji", "image"):
        path = bank.resolve(e["file"], cfg)
        if path is None:
            return [], None
        return _load_frames(path, int(min(W, H) * size)), None
    if kind == "text":
        style = e.get("style") or "classic"
        if e.get("anim") == "typewriter":
            text = e.get("text") or ""
            cache: dict = {}

            def at(tt: float, text=text):
                n = fxlib.typewriter_count(text, tt)
                if n not in cache:
                    cache[n] = fxlib.text_picture(text, W, H, size, e.get("color"), style, lang, reveal=n)
                return cache[n], n
            first, _n = at(1e9)
            return [(first, 0.0)], at
        return [(fxlib.text_picture(e["text"], W, H, size, e.get("color"), style, lang), 0.0)], None
    if kind == "killcard":
        return [(killcard_picture(e["card"], W, H, size, lang, cfg), 0.0)], None
    return [], None


def sprite_sequence(frames: list[tuple], dur: float, folder: Path, anim: str = "pop", wobble: bool = False,
                    rot: float = 0.0, fade_out: float = 0.18, picture_at=None) -> tuple[int, int]:
    """Animate a picture (see fxlib.anim_state) into a PNG sequence. Returns the canvas size; the
    picture rests at the centre of it."""
    Image, _D, _F = _pil()
    w0 = max(f[0].width for f in frames)
    h0 = max(f[0].height for f in frames)
    cw, ch = sprite_canvas(w0, h0, anim, rot, wobble)
    seq = Sequence(folder)
    n = max(1, int(round(dur * OV_FPS)))
    animated = len(frames) > 1
    total_anim = sum(d for _f, d in frames) if animated else 0.0
    slide = anim == "slide"
    for i in range(n):
        tt = i / OV_FPS
        if picture_at is not None:
            src, src_key = picture_at(tt)
        elif animated:
            pos = tt % total_anim if total_anim > 0 else 0
            k = 0
            acc = 0.0
            for k, (_fr, d) in enumerate(frames):
                acc += d
                if pos < acc:
                    break
            src, src_key = frames[k][0], k
        else:
            src, src_key = frames[0][0], 0
        s, ang, alpha, dx, dy = fxlib.anim_state(anim, tt, dur, wobble, fade_out)
        ang += rot
        px_dx = int(dx * (cw if slide else src.width))
        px_dy = int(dy * src.height)
        key = None
        if abs(s - 1.0) < 1e-3 and abs(ang - rot) < 0.05 and alpha >= 0.999 and px_dx == 0 and px_dy == 0:
            key = ("static", src_key)
        if key is not None and seq._last_key == key:
            seq.add(None, key)
            continue
        im = src
        if abs(s - 1.0) > 1e-3:
            im = im.resize((max(1, int(im.width * s)), max(1, int(im.height * s))), Image.BILINEAR)
        if abs(ang) >= 0.05:
            im = im.rotate(ang, Image.BICUBIC, expand=True)
        canvas = Image.new("RGBA", (cw, ch), (0, 0, 0, 0))
        pos = ((cw - im.width) // 2 + px_dx, (ch - im.height) // 2 + px_dy)
        if pos[0] >= 0 and pos[1] >= 0 and pos[0] + im.width <= cw and pos[1] + im.height <= ch:
            canvas.alpha_composite(im, pos)
        else:
            canvas.paste(im, pos, im)
        seq.add(_with_alpha(canvas, alpha), key)
    return cw, ch


def effect_scale(eid: str, preview: bool) -> float:
    """Effects are drawn at half size (they are soft anyway) - except the ones with writing on them."""
    if not preview and (fxlib.EFFECTS.get(eid, {}).get("text") or eid in ("vhs", "crack")):
        return 1.0
    return fxlib.OV_SCALE


def effect_sequence(e: dict, dur: float, W: int, H: int, game: tuple, folder: Path, lang: str = "fr",
                    scale: float = fxlib.OV_SCALE) -> bool:
    """PNG sequence of an animated effect (pictures of W*scale x H*scale). False when it draws nothing."""
    Image, _D, _F = _pil()
    seq = Sequence(folder)
    n = max(1, int(round(dur * OV_FPS)))
    drew = False
    empty = None
    last_raw, last_key = None, None
    for i in range(n):
        im = fxlib.effect_frame(e, i / OV_FPS, dur, W, H, game, lang, scale)
        if im is None:
            if empty is None:
                empty = Image.new("RGBA", (max(2, int(W * scale)), max(2, int(H * scale))), (0, 0, 0, 0))
            seq.add(empty, "empty")
            last_raw, last_key = None, None
            continue
        drew = True
        raw = im.tobytes()
        if last_key is not None and raw == last_raw:
            seq.add(None, last_key)
            continue
        last_raw, last_key = raw, ("fx", i)
        seq.add(im, last_key)
    return drew


def text_picture(text: str, W: int, H: int, size: float = 1.0, color: Optional[str] = "#FFFFFF",
                 style: str = "classic", lang: str = "fr"):
    """Big meme text (see fxlib.TEXT_STYLES)."""
    return fxlib.text_picture(text, W, H, size, color, style, lang)


def _icon(card: dict, key: str, size: int, cfg):
    """Albion item picture (downloaded once, kept in the Albion folder)."""
    w = card.get(key)
    if not w or cfg is None:
        return None
    try:
        from . import albion as A
        f = A.fetch_icon(A.data_root(cfg), w[0], int(w[1] if len(w) > 1 else 1), 128)
        if not f:
            return None
        Image, _D, _F = _pil()
        im = Image.open(f).convert("RGBA")
        return im.resize((size, size), Image.LANCZOS)
    except Exception as e:  # noqa: BLE001
        log.info("item icon: %s", e)
        return None


def _fit_text(draw_font_size: int, text: str, max_w: int, name: str = "Montserrat ExtraBold"):
    fs = draw_font_size
    while fs > 6:                      # small previews draw small cards: shrink before cutting the text
        font = _font(fs, name)
        if font.getlength(text) <= max_w:
            return font, text
        fs -= 2
    font = _font(fs, name)
    while text and font.getlength(text + "…") > max_w:
        text = text[:-1]
    return font, text + "…"


def killcard_picture(card: dict, W: int, H: int, size: float = 1.0, lang: str = "fr", cfg=None):
    """The kill card: [my weapon]  ME ⚔ VICTIM  [their weapon] / guild / fame and item power."""
    Image, ImageDraw, _F = _pil()
    from . import albion as A
    vertical = H > W
    cw = int((0.78 * W if vertical else 0.34 * W) * max(0.4, size))
    ch = int(cw * 0.25)
    pad = int(ch * 0.12)
    icon = ch - 2 * pad
    role = card.get("role") or "kill"
    accent = {"kill": "#3DDC84", "assist": "#FFB020", "death": "#FF4D4D"}.get(role, "#3DDC84")
    img = Image.new("RGBA", (cw, ch), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    radius = int(ch * 0.16)
    d.rounded_rectangle((0, 0, cw - 1, ch - 1), radius=radius, fill=(14, 16, 22, 228))
    bar = max(4, int(ch * 0.06))
    d.rounded_rectangle((0, 0, bar * 2, ch - 1), radius=radius, fill=_hex(accent))
    d.rectangle((bar, 0, bar * 2, ch - 1), fill=(14, 16, 22, 228))
    x0 = bar * 2 + pad
    left = _icon(card, "my_weapon", icon, cfg)
    right = _icon(card, "weapon", icon, cfg)
    if left is not None:
        img.alpha_composite(left, (x0, pad))
        x0 += icon + pad
    x1 = cw - pad - (icon + pad if right is not None else 0)
    if right is not None:
        img.alpha_composite(right, (cw - pad - icon, pad))
    tw = x1 - x0
    me = (card.get("me") or "").upper()
    other = (card.get("other") or "?").upper()
    if role == "death":
        names = (other, me)
        sep_code = "1f480"
    else:
        names = (me, other)
        sep_code = "2694-fe0f"
    f1, _t = _fit_text(int(ch * 0.27), f"{names[0]} WW {names[1]}", tw)
    sep_size = int(f1.size * 1.15)
    sep = None
    try:
        sp = bank.emoji_path(sep_code)
        if sp is not None:
            sep = Image.open(sp).convert("RGBA").resize((sep_size, sep_size), Image.LANCZOS)
    except OSError:
        pass
    y1 = int(ch * 0.10)
    n1, n2 = names
    w_n1 = f1.getlength(n1)
    w_n2 = f1.getlength(n2)
    avail = tw - sep_size - int(f1.size * 0.6)
    if w_n1 + w_n2 > avail:
        f1, _ = _fit_text(f1.size, n1 + n2, avail)
        w_n1, w_n2 = f1.getlength(n1), f1.getlength(n2)
    x = x0
    col_me, col_other = (255, 255, 255, 255), _hex(accent)
    if role == "death":
        col_me, col_other = _hex(accent), (255, 255, 255, 255)
    d.text((x, y1), n1, font=f1, fill=col_me, stroke_width=max(1, f1.size // 14), stroke_fill=(0, 0, 0, 255))
    x += int(w_n1 + f1.size * 0.3)
    if sep is not None:
        img.alpha_composite(sep, (x, y1 + int(f1.size * 0.05)))
    x += sep_size + int(f1.size * 0.3)
    d.text((x, y1), n2, font=f1, fill=col_other, stroke_width=max(1, f1.size // 14), stroke_fill=(0, 0, 0, 255))
    y2 = y1 + int(f1.size * 1.25)
    guild = card.get("guild") or ""
    if card.get("alliance"):
        guild = f"[{card['alliance']}] {guild}".strip()
    f2 = _font(int(ch * 0.15))
    if guild:
        f2b, gtxt = _fit_text(int(ch * 0.15), guild, tw)
        d.text((x0, y2), gtxt, font=f2b, fill=(200, 205, 215, 255))
        y2 += int(f2.size * 1.25)
    parts = []
    if card.get("fame"):
        parts.append(f"{A.fmt_fame(card['fame'], lang)} fame")
    if card.get("ip"):
        parts.append(f"IP {card['ip']}")
    label = {"kill": "KILL", "assist": "ASSIST", "death": "MORT" if lang == "fr" else "DEATH"}.get(role, "")
    info = "  ·  ".join(parts)
    f3, info = _fit_text(int(ch * 0.15), info, tw - int(ch * 0.15) * 4)
    d.text((x0, y2), info, font=f3, fill=(255, 213, 79, 255))
    if label:
        f4 = _font(int(ch * 0.13))
        lw = int(f4.getlength(label)) + int(ch * 0.12)
        lx = x1 - lw
        ly = ch - pad - int(f4.size * 1.35)
        d.rounded_rectangle((lx, ly, x1, ly + int(f4.size * 1.35)), radius=int(f4.size * 0.4), fill=_hex(accent))
        d.text((lx + int(ch * 0.06), ly + int(f4.size * 0.12)), label, font=f4, fill=(10, 12, 16, 255))
    return img


def watermark_picture(text: str, logo: Optional[Path], H: int, vertical: bool, size_pct: int = 100,
                      opacity: int = 85):
    Image, ImageDraw, _F = _pil()
    fs = max(10, int(H * (0.022 if vertical else 0.028) * size_pct / 100))
    font = _font(fs)
    stroke = max(1, int(fs * 0.09))
    tw = int(font.getlength(text)) if text else 0
    lg = None
    if logo is not None:
        try:
            lg = Image.open(logo).convert("RGBA")
            lh = int(fs * 1.7)
            lg = lg.resize((max(1, int(lg.width * lh / max(1, lg.height))), lh), Image.LANCZOS)
        except OSError:
            lg = None
    gap = int(fs * 0.4) if (lg is not None and text) else 0
    w = (lg.width if lg is not None else 0) + gap + tw + 2 * stroke + 4
    h = max(lg.height if lg is not None else 0, int(fs * 1.35)) + 2 * stroke
    if w <= 2 * stroke + 4:
        return None
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    x = stroke
    if lg is not None:
        img.alpha_composite(lg, (x, (h - lg.height) // 2))
        x += lg.width + gap
    if text:
        d.text((x + 2, (h - int(fs * 1.2)) // 2 + 2), text, font=font, fill=(0, 0, 0, 140))   # soft shadow
        d.text((x, (h - int(fs * 1.2)) // 2), text, font=font, fill=(255, 255, 255, 255),
               stroke_width=stroke, stroke_fill=(0, 0, 0, 200))
    return _with_alpha(img, opacity / 100.0)


def watermark_position(pos: str, w: int, h: int, W: int, H: int, vertical: bool) -> tuple[int, int]:
    mx = int(W * 0.035)
    if pos == "auto":
        pos = "bc" if vertical else "br"
    top = int(H * (0.085 if vertical else 0.04))
    bottom = int(H * (0.80 if vertical else 0.955)) - h
    if pos == "bc" and vertical:
        bottom = int(H * 0.80) - h // 2
    xs = {"l": mx, "c": (W - w) // 2, "r": W - w - mx}
    ys = {"t": top, "b": bottom}
    return xs.get(pos[1:2], (W - w) // 2), ys.get(pos[0:1], bottom)


# --------------------------------------------------------------------------- render


@dataclass
class Ctx:
    W: int
    H: int
    F: int
    fmt: str
    vertical: bool
    game: tuple
    work: Path
    cfg: object
    lang: str


def _speed_audio(speed: float) -> str:
    if abs(speed - 1.0) < 1e-3:
        return ""
    return f",asetrate={int(round(48000 * speed))},aresample=48000"


def _between(windows: list[tuple[float, float]]) -> str:
    return "+".join(f"between(t,{a:.3f},{b:.3f})" for a, b in windows)


def zoom_fx(windows: list[dict], F: int) -> Optional[Callable[[int, int], str]]:
    """zoompan filter for punch-in zooms and shakes (one filter, windows in clip time)."""
    if not windows:
        return None
    zs, cxs, cys, dxs, dys = [], [], [], [], []
    for w in windows:
        o0, o1 = w["o0"], w["o1"]
        if w["kind"] == "cut":
            win = f"between(it,{o0:.3f},{o1 - 0.001:.3f})"
            zs.append(f"{w['amount'] - 1:.3f}*{win}")
            continue
        ramp_in = 0.06 if w["kind"] == "zoom" else 0.03
        win = (f"between(it,{o0:.3f},{o1:.3f})*min(1,(it-{o0:.3f})/{ramp_in})"
               f"*min(1,({o1:.3f}-it)/0.12)")
        if w["kind"] == "zoom":
            zs.append(f"{w['amount'] - 1:.3f}*{win}")
            if abs(w.get("cx", 0.5) - 0.5) > 1e-3:
                cxs.append(f"{w['cx'] - 0.5:.3f}*between(it,{o0:.3f},{o1:.3f})")
            if abs(w.get("cy", 0.5) - 0.5) > 1e-3:
                cys.append(f"{w['cy'] - 0.5:.3f}*between(it,{o0:.3f},{o1:.3f})")
        else:  # shake
            amp = 0.014 * w["amount"]
            zs.append(f"{0.07 * w['amount']:.3f}*{win}")
            dxs.append(f"{amp:.4f}*sin(2*PI*17*it)*{win}")
            dys.append(f"{amp:.4f}*cos(2*PI*13*it)*{win}")
    z = "min(2.5,1+" + "+".join(zs) + ")" if zs else "1"
    cx = "(0.5" + "".join("+" + c for c in cxs) + ")"
    cy = "(0.5" + "".join("+" + c for c in cys) + ")"
    dx = "+".join(dxs) or "0"
    dy = "+".join(dys) or "0"

    def fx(w: int, h: int) -> str:
        x = f"max(0,min(iw-iw/zoom,{cx}*iw-iw/zoom/2+({dx})*iw))"
        y = f"max(0,min(ih-ih/zoom,{cy}*ih-ih/zoom/2+({dy})*ih))"
        return f"zoompan=z='{z}':x='{x}':y='{y}':d=1:s={w}x{h}:fps={F}"
    return fx


def _measure_loudness(src: Path, start: float, dur: float, cancel=None) -> Optional[float]:
    """Integrated loudness (LUFS) of the stream sound of the clip."""
    try:
        ff = tools.require("ffmpeg")
        r = run([str(ff), "-hide_banner", "-nostats", "-ss", f"{max(0.0, start):.3f}", "-t", f"{max(0.5, dur):.3f}",
                 "-i", str(src), "-vn", "-af", "ebur128", "-f", "null", "-"], timeout=240)
        m = re.findall(r"I:\s*(-?[\d.]+)\s*LUFS", r.stderr or "")
        if m:
            v = float(m[-1])
            return v if v > -60 else None
    except Exception as e:  # noqa: BLE001
        log.info("loudness: %s", e)
    return None


def _fetch_missing_memes(m: dict, cfg, cancel=None) -> None:
    """Memes of the internet bank this clip uses that are not downloaded yet: downloaded now (best effort -
    a meme that cannot be fetched is left out of the clip)."""
    refs = {e.get("file") for e in m.get("elements") or []} | {m.get("music")}
    refs = sorted(r for r in refs if r and str(r).startswith("web:") and bank.resolve(r, cfg) is None)
    if not refs:
        return
    from . import memebank
    for r in refs:
        if cancel is not None and cancel.is_set():
            return
        try:
            memebank.get(cfg, r, cancel)
        except Exception as e:  # noqa: BLE001
            log.info("meme %s left out: %s", r, e)


def render(ref, cfg, moment: dict, fmt: str, out_dir: Path, progress: Callable[[float, str], None],
           cancel: Optional[threading.Event] = None, preview: bool = False, out_path: Optional[Path] = None,
           window: Optional[tuple[float, float]] = None, report: Optional[dict] = None) -> Path:
    """Cut and dress one clip. preview=True: half size, fast encoding (Studio "exact render").
    window=(t0, t1): only this part (VOD times) - quick preview around the playhead.
    report: filled with {"total": clip length, "peak": clip time of the best moment, "intro": intro length}."""
    from . import export, media
    from .i18n import language

    a, b = float(moment["start"]), float(moment["end"])
    if window is not None:
        a, b = max(a, float(window[0])), min(b, float(window[1]))
    if b - a < 1.0:
        raise UserError("err_clip_too_short")
    m = effective(moment, cfg)
    prof = profiles.for_vod(cfg, ref.meta)
    _fetch_missing_memes(m, cfg, cancel)
    progress(0.0, "source")
    seg = media.get_segment(ref, cfg, a, b, "preview" if preview else "export",
                            lambda f, msg="": progress(0.3 * f, "source"), cancel)
    src = Path(seg["path"])
    seg0 = float(seg["vod_start"])
    info = tools.probe(src)
    if not info.get("has_video"):
        raise UserError("err_no_video")
    W, H = export.out_size(fmt, info, preview)
    src_fps = float(info.get("fps") or 30.0)
    F = 30 if preview else (60 if src_fps > 45 else 30)
    work = ref.p("tmp", f"{'prev' if preview else 'export'}_{moment.get('id', 'm')}_{fmt}")
    shutil.rmtree(work, ignore_errors=True)
    work.mkdir(parents=True, exist_ok=True)
    ctx = Ctx(W, H, F, fmt, H > W, export.game_rect(fmt, info, cfg, W, H), work, cfg, language())

    # ---- words (with the user's corrections), swear words, timeline
    words = export.clip_words(ref, moment, a, b)
    pl = make_plan(moment, m, words, window)
    m, pieces, total = pl.m, pl.pieces, pl.total
    if total < 0.5:
        raise UserError("err_clip_too_short")
    if report is not None:
        pk = moment.get("peak")
        pk = float(pk) if pk is not None and a <= float(pk) <= b else pl.hook_t
        po = map_first(pieces, pk) if pk is not None else None
        report.update({"total": round(total, 2), "peak": round(po, 2) if po is not None else round(total * 0.4, 2),
                       "intro": 0.0})
    progress(0.32, "prepare")

    inputs: list[list[str]] = []
    chains: list[str] = []

    def add_input(args: list[str]) -> int:
        inputs.append(args)
        return len(inputs) - 1

    main = [p for p in pieces if not p.hook]
    hook = [p for p in pieces if p.hook]
    base = min(p.a for p in main)
    span = max(p.b for p in main) - base + 0.5
    i_main = add_input(["-ss", f"{max(0.0, base - seg0):.3f}", "-t", f"{span:.3f}", "-i", str(src)])
    has_audio = bool(info.get("has_audio"))
    i_hook = None
    if hook:
        hp = hook[0]
        i_hook = add_input(["-ss", f"{max(0.0, hp.a - seg0):.3f}", "-t", f"{hp.b - hp.a + 0.3:.3f}", "-i", str(src)])

    # ---- pieces -> one stream
    n_main = len(main)
    n_play = sum(1 for p in main if p.kind == "play")
    vlabels = [f"sv{i}" for i in range(n_main)]
    if n_main > 1:
        chains.append(f"[{i_main}:v]split={n_main}" + "".join(f"[{x}]" for x in vlabels))
    else:
        vlabels = [f"{i_main}:v"]
    alabels = [f"sa{i}" for i in range(n_play)]
    if has_audio:
        if n_play > 1:
            chains.append(f"[{i_main}:a]{AFMT},asplit={n_play}" + "".join(f"[{x}]" for x in alabels))
        else:
            chains.append(f"[{i_main}:a]{AFMT}[sa0]")
    cat_v, cat_a = [], []
    if hook:
        hp = hook[0]
        chains.append(f"[{i_hook}:v]trim=duration={hp.b - hp.a:.4f},setpts=PTS-STARTPTS[hv]")
        cat_v.append("[hv]")
        if has_audio:
            ln = hp.b - hp.a
            chains.append(f"[{i_hook}:a]{AFMT},atrim=duration={ln:.4f},asetpts=PTS-STARTPTS,"
                          f"afade=t=in:d=0.04,afade=t=out:st={max(0.0, ln - 0.12):.4f}:d=0.12[ha]")
        else:
            chains.append(f"anullsrc=r=48000:cl=stereo,atrim=duration={hp.b - hp.a:.4f}[ha]")
        cat_a.append("[ha]")
    ai = 0
    cut_fades = n_main > 1
    for i, p in enumerate(main):
        ra, rb = p.a - base, p.b - base
        if p.kind == "play":
            chains.append(f"[{vlabels[i]}]trim=start={ra:.4f}:end={rb:.4f},setpts=(PTS-STARTPTS)/{p.speed:.4f}[pv{i}]")
            if has_audio:
                fades = ""
                if cut_fades:
                    ln = p.length
                    fades = f",afade=t=in:d=0.012,afade=t=out:st={max(0.0, ln - 0.012):.4f}:d=0.012"
                chains.append(f"[{alabels[ai] if n_play > 1 else 'sa0'}]atrim=start={ra:.4f}:end={rb:.4f},"
                              f"asetpts=PTS-STARTPTS{_speed_audio(p.speed)}{fades}[pa{i}]")
            else:
                chains.append(f"anullsrc=r=48000:cl=stereo,atrim=duration={p.length:.4f}[pa{i}]")
            ai += 1
        else:
            fr = 1.5 / max(10.0, src_fps)
            chains.append(f"[{vlabels[i]}]trim=start={max(0.0, ra - fr):.4f}:duration={fr:.4f},setpts=PTS-STARTPTS,"
                          f"tpad=stop_mode=clone:stop_duration={p.hold + 0.2:.3f},trim=duration={p.hold:.4f},"
                          f"setpts=PTS-STARTPTS[pv{i}]")
            chains.append(f"anullsrc=r=48000:cl=stereo,atrim=duration={p.hold:.4f}[pa{i}]")
        cat_v.append(f"[pv{i}]")
        cat_a.append(f"[pa{i}]")
    if len(cat_v) > 1:
        chains.append("".join(cat_v) + f"concat=n={len(cat_v)}:v=1:a=0[vcat]")
        chains.append("".join(cat_a) + f"concat=n={len(cat_a)}:v=0:a=1[acat]")
    else:
        chains.append(f"{cat_v[0]}null[vcat]")
        chains.append(f"{cat_a[0]}anull[acat]")
    chains.append(f"[vcat]fps={F},format=yuv420p,setsar=1[vb]")

    # ---- layout + zoom / shake on the game picture
    chains.append(export.layout_chain(fmt, info, cfg, W, H, "[vb]", "[vl]", zoom_fx(zoom_windows(pl), F)))
    cur = "vl"

    # ---- effects that change the colours of the video (glitch, VHS, sepia, black and white)
    fw = filter_windows(pl)
    fparts = []
    for eid in fxlib.EFFECT_ORDER:
        if eid not in fw:
            continue
        en = _between(fw[eid])
        fparts += [f"{f}:enable='{en}'" for f in fxlib.effect_filters(eid, W).split(",") if f]
    if fparts:
        chains.append(f"[{cur}]{','.join(fparts)}[vfx]")
        cur = "vfx"

    # ---- pictures on top (emoji, memes, stickers, text, kill cards, videos, animated effects)
    progress(0.34, "prepare")
    ov_n = 0
    duck_windows: list[tuple[float, float]] = []
    audio_extra: list[str] = []
    sources: dict[str, tuple] = {}
    sched = visual_schedule(pl, cfg)
    for j, (e, o, d) in enumerate(sched):
        kind = e["kind"]
        if kind == "video":
            path = bank.resolve(e["file"], cfg)
            if path is None:
                log.warning("meme file not found: %s", e.get("file"))
                continue
            box = int(min(W, H) * e.get("size", DEFAULT_SIZE["video"]))
            k = add_input(["-t", f"{d:.3f}", "-i", str(path)])
            vinfo = tools.probe(path)
            if e.get("full"):
                sc = (f"scale={W}:{H}:force_original_aspect_ratio=decrease,"
                      f"pad={W}:{H}:(ow-iw)/2:(oh-ih)/2:color=black")
                X, Y = 0, 0
            else:
                vw, vh = int(vinfo.get("width") or 16), int(vinfo.get("height") or 9)
                sv = box / max(vw, vh)
                ow, oh = export._even(vw * sv), export._even(vh * sv)
                sc = f"scale={ow}:{oh}"
                X, Y = place(e, ow, oh, ctx)
            key = ",colorkey=0x00D000:0.32:0.12" if e.get("chroma") else ""
            chains.append(f"[{k}:v]fps={F},{sc}{',format=rgba' + key if key else ''},format=yuva420p,"
                          f"setpts=PTS-STARTPTS+{o:.3f}/TB[ov{ov_n}]")
            chains.append(f"[{cur}][ov{ov_n}]overlay=x={X}:y={Y}:eof_action=pass:format=auto[vo{ov_n}]")
            cur = f"vo{ov_n}"
            ov_n += 1
            if vinfo.get("has_audio") and e.get("vol", 100) > 0:
                chains.append(f"[{k}:a]{AFMT},volume={e.get('vol', 100) / 100:.2f},"
                              f"adelay={int(o * 1000)}:all=1[va{ov_n}]")
                audio_extra.append(f"[va{ov_n}]")
                if e.get("duck", True):
                    duck_windows.append((o, o + d))
            continue
        folder = work / f"ov{ov_n}"
        if kind == "fx":
            sc_fx = effect_scale(e["effect"], preview)
            if not effect_sequence(e, d, W, H, ctx.game, folder, ctx.lang, sc_fx):
                shutil.rmtree(folder, ignore_errors=True)
                continue
            k = add_input(["-framerate", str(OV_FPS), "-i", f"ov{ov_n}/%05d.png"])
            up = f"scale={W}:{H}," if abs(sc_fx - 1.0) > 1e-3 else ""
            chains.append(f"[{k}:v]{up}setpts=PTS-STARTPTS+{o:.3f}/TB[ov{ov_n}]")
            chains.append(f"[{cur}][ov{ov_n}]overlay=x=0:y=0:eof_action=pass:format=auto[vo{ov_n}]")
        else:
            if e["id"] not in sources:
                try:
                    sources[e["id"]] = picture_source(e, W, H, cfg, ctx.lang)
                except OSError as ex:
                    log.warning("picture %s: %s", e.get("file"), ex)
                    sources[e["id"]] = ([], None)
            frames, picture_at = sources[e["id"]]
            if not frames:
                log.warning("meme file not found: %s", e.get("file"))
                continue
            anim = e.get("anim") or DEFAULT_ANIM.get(kind, "pop")
            cw, ch = sprite_sequence(frames, d, folder, anim, wobble=(kind == "emoji" and anim == "pop"),
                                     rot=float(e.get("rot") or 0.0), fade_out=0.25 if kind == "killcard" else 0.18,
                                     picture_at=picture_at)
            if kind == "killcard":
                X, Y = _killcard_pos(e, cw, ch, ctx)
            else:
                X, Y = place(e, cw, ch, ctx)
            k = add_input(["-framerate", str(OV_FPS), "-i", f"ov{ov_n}/%05d.png"])
            chains.append(f"[{k}:v]setpts=PTS-STARTPTS+{o:.3f}/TB[ov{ov_n}]")
            chains.append(f"[{cur}][ov{ov_n}]overlay=x={X}:y={Y}:eof_action=pass:format=auto[vo{ov_n}]")
        cur = f"vo{ov_n}"
        ov_n += 1
        progress(0.34 + 0.03 * (j + 1) / max(1, len(sched)), "prepare")
        if cancel is not None and cancel.is_set():
            raise UserError("cancelled")

    # ---- subtitles + title
    with_subs = cfg.get("subtitles") if m.get("subs") is None else m.get("subs")
    with_title = bool(cfg.get("title_overlay")) and bool(subtitles.clean_title(moment.get("title") or "")) \
        and (fmt == "vertical" or bool(cfg.get("title_overlay_landscape")))
    if with_subs or with_title:
        mw = map_words(pieces, words) if with_subs else []
        masked = {j for j, (_s, _e, _t, i) in enumerate(mw) if i in pl.swear}
        st = subtitles.resolve_style(m.get("sub_style") or prof.get("sub_style") or cfg.get("subtitle_style"), cfg)
        if mw or with_title:
            ass = subtitles.build_ass([(s0, e2, t) for s0, e2, t, _i in mw], 0.0, total, W, H,
                                      title=(moment.get("title") or "") if with_title else "",
                                      title_y=export.title_position(fmt, info, cfg, W, H), style=st, masked=masked)
            (work / "subs.ass").write_text(ass, encoding="utf-8")
            fonts = work / "fonts"
            fonts.mkdir(exist_ok=True)
            for f in (paths.ASSETS / "fonts").glob("*.ttf"):
                shutil.copy2(f, fonts / f.name)
            chains.append(f"[{cur}]subtitles=subs.ass:fontsdir=fonts[vsub]")
            cur = "vsub"

    # ---- watermark
    wm_text = profiles.watermark_text(prof)
    logo = bank.resolve(prof.get("wm_logo") or "", cfg) if prof.get("wm_on", True) and prof.get("wm_logo") else None
    if wm_text or logo is not None:
        pic = watermark_picture(wm_text, logo, H, ctx.vertical, int(prof.get("wm_size") or 100),
                                int(prof.get("wm_opacity") or 85))
        if pic is not None:
            pic.save(work / "wm.png")
            X, Y = watermark_position(prof.get("wm_pos") or "auto", pic.width, pic.height, W, H, ctx.vertical)
            k = add_input(["-loop", "1", "-framerate", str(F), "-t", f"{total:.3f}", "-i", "wm.png"])
            chains.append(f"[{cur}][{k}:v]overlay=x={X}:y={Y}:format=auto[vwm]")
            cur = "vwm"
    chains.append(f"[{cur}]format=yuv420p,setsar=1[vmain]")

    # ---- sound
    ssched = sound_schedule(pl, cfg)
    duck_windows += duck_windows_for(pl, ssched)
    gain_db = 0.0
    if cfg.get("loudnorm", True) and has_audio:
        lufs = _measure_loudness(src, a - seg0, b - a, cancel)
        if lufs is not None:
            gain_db = max(-12.0, min(18.0, -14.0 - lufs))
    achain = f"[acat]volume={gain_db:.2f}dB" if abs(gain_db) > 0.05 else "[acat]anull"
    bleeps = bleep_windows(pl)
    if bleeps:
        achain += f",volume=0:enable='{_between(bleeps)}'"
    if duck_windows:
        achain += f",volume=0.35:enable='{_between(duck_windows)}'"
    chains.append(achain + "[am]")
    mix = ["[am]"]
    for sfx_n, (e, path, o, d) in enumerate(ssched):
        args = ["-i", str(path)]
        if d:
            args = ["-t", f"{d:.3f}"] + args
        k = add_input(args)
        chains.append(f"[{k}:a]{AFMT},volume={e.get('vol', 100) / 100:.2f},adelay={int(o * 1000)}:all=1[sx{sfx_n}]")
        mix.append(f"[sx{sfx_n}]")
    mix += audio_extra
    if cfg.get("bleep_mode", "bip") == "bip":
        for j, (o0, o1) in enumerate(bleeps):
            chains.append(f"sine=frequency=1000:sample_rate=48000:duration={max(0.05, o1 - o0):.3f},{AFMT},"
                          f"volume=1.2,adelay={int(o0 * 1000)}:all=1[bp{j}]")
            mix.append(f"[bp{j}]")
    music = bank.resolve(m.get("music") or "", cfg) if m.get("music") else None
    if music is not None and m.get("music_vol", 18) > 0:
        k = add_input(["-stream_loop", "-1", "-i", str(music)])
        mv = m.get("music_vol", 18) / 100.0
        chains.append(f"[{k}:a]{AFMT},atrim=duration={total:.3f},volume={mv:.3f},afade=t=in:d=0.8,"
                      f"afade=t=out:st={max(0.0, total - 1.5):.3f}:d=1.5[mus]")
        chains.append("[am]asplit=2[am1][amsc]")
        mix[0] = "[am1]"
        chains.append("[mus][amsc]sidechaincompress=threshold=0.02:ratio=8:attack=20:release=450[musd]")
        mix.append("[musd]")
    if len(mix) > 1:
        chains.append("".join(mix) + f"amix=inputs={len(mix)}:duration=first:dropout_transition=0:normalize=0[amx]")
    else:
        chains.append(f"{mix[0]}anull[amx]")
    chains.append(f"[amx]alimiter=limit=0.89:attack=5:release=60:level=false,"
                  f"afade=t=in:d=0.05,afade=t=out:st={max(0.0, total - 0.25):.3f}:d=0.25[amain]")

    # ---- intro / outro (not in the quick previews)
    vout, aout = "[vmain]", "[amain]"
    if window is None and not preview:
        order: list[tuple[str, Optional[Path]]] = []
        ip = bank.resolve(prof.get("intro") or "", cfg) if prof.get("intro") else None
        op = bank.resolve(prof.get("outro") or "", cfg) if prof.get("outro") else None
        if ip is not None:
            order.append(("intro", ip))
        order.append(("main", None))
        if op is not None:
            order.append(("outro", op))
        if len(order) > 1:
            parts = []
            for name, p in order:
                if p is None:
                    parts.append("[vmain][amain]")
                    continue
                if bank.kind_of_file(p) == "image":
                    k = add_input(["-loop", "1", "-framerate", str(F), "-t", "2.0", "-i", str(p)])
                    dur_x, x_audio = 2.0, False
                else:
                    xi = tools.probe(p)
                    dur_x = min(30.0, float(xi.get("duration") or 3.0))
                    x_audio = bool(xi.get("has_audio"))
                    k = add_input(["-t", f"{dur_x:.3f}", "-i", str(p)])
                chains.append(fill_chain(f"[{k}:v]", W, H, F, ctx.vertical, dur_x, f"[{name}v]"))
                if x_audio:
                    chains.append(f"[{k}:a]{AFMT},atrim=duration={dur_x:.3f},asetpts=PTS-STARTPTS,"
                                  f"apad=whole_dur={dur_x:.3f}[{name}a]")
                else:
                    chains.append(f"anullsrc=r=48000:cl=stereo,atrim=duration={dur_x:.3f}[{name}a]")
                parts.append(f"[{name}v][{name}a]")
                total += dur_x
                if name == "intro" and report is not None:
                    report["intro"] = dur_x
                    report["peak"] = report.get("peak", 0) + dur_x
            chains.append("".join(parts) + f"concat=n={len(parts)}:v=1:a=1[vout][aout]")
            vout, aout = "[vout]", "[aout]"

    graph = ";\n".join(chains)
    (work / "graph.txt").write_text(graph, encoding="utf-8")
    progress(0.38, "encode")

    out_dir.mkdir(parents=True, exist_ok=True)
    final = out_path or unique_path(out_dir / export.clip_filename(ref.meta, moment, fmt))
    tmp_out = work / "out.mp4"
    ff = tools.require("ffmpeg")
    title = (moment.get("title") or "").strip()

    def cmd_for(enc_args: list) -> list:
        cmd = [str(ff), "-y", "-hide_banner", "-nostdin", "-v", "error"]
        for args in inputs:
            cmd += args
        cmd += _graph_args(graph, work)
        cmd += ["-map", vout, "-map", aout, "-c:a", "aac", "-b:a", "128k" if preview else "192k", "-ar", "48000"]
        cmd += enc_args + ["-r", str(F), "-movflags", "+faststart", "-metadata", f"title={title}",
                           "-metadata", f"comment=FireClips {ref.meta.get('vod_id') or ''} @ {fmt_tag(a)}",
                           "-progress", "pipe:1", "-nostats", str(tmp_out)]
        return cmd

    pat = re.compile(r"out_time_(?:us|ms)=(\d+)")

    def on_line(line: str) -> None:
        mm = pat.search(line)
        if mm:
            t = int(mm.group(1)) / 1_000_000
            progress(0.38 + 0.62 * min(1.0, t / max(0.1, total)), "encode")

    enc_args, enc_name = _encoder(cfg, preview)
    code, last = run_streaming(cmd_for(enc_args), on_line, cwd=str(work), cancel=cancel)
    if code != 0 and enc_name == "nvenc" and not (cancel is not None and cancel.is_set()):
        log.warning("NVENC failed, using the processor: %s", "\n".join(last[-5:]))
        enc_args, enc_name = _encoder(cfg, preview, force_cpu=True)
        code, last = run_streaming(cmd_for(enc_args), on_line, cwd=str(work), cancel=cancel)
    if code != 0 or not tmp_out.exists():
        log.error("render failed, graph in %s:\n%s", work / "graph.txt", "\n".join(last[-12:]))
        raise UserError("err_export_failed", "\n".join(last[-8:]))
    final.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(tmp_out), str(final))
    if not log.isEnabledFor(logging.DEBUG):
        shutil.rmtree(work, ignore_errors=True)
    progress(1.0, "done")
    return final


def fill_chain(src: str, W: int, H: int, F: int, blur: bool, dur: float, dst: str) -> str:
    """A video / picture shown full screen (intro, outro): blurred copy behind it in 9:16."""
    tail = f"setsar=1,fps={F},format=yuv420p,trim=duration={dur:.3f},setpts=PTS-STARTPTS{dst}"
    if not blur:
        return (f"{src}scale={W}:{H}:force_original_aspect_ratio=decrease,"
                f"pad={W}:{H}:(ow-iw)/2:(oh-ih)/2:color=black,{tail}")
    bw, bh = max(2, W // 4 // 2 * 2), max(2, H // 4 // 2 * 2)
    lab = dst.strip("[]")
    return (f"{src}split=2[{lab}b][{lab}f];"
            f"[{lab}b]scale={bw}:{bh}:force_original_aspect_ratio=increase,crop={bw}:{bh},gblur=sigma=12,"
            f"scale={W}:{H},eq=brightness=-0.07[{lab}bb];"
            f"[{lab}f]scale={W}:{H}:force_original_aspect_ratio=decrease[{lab}ff];"
            f"[{lab}bb][{lab}ff]overlay=(W-w)/2:(H-h)/2,{tail}")


DEFAULT_POS = {"emoji": (0.5, 0.35), "image": (0.5, 0.5), "video": (0.5, 0.5), "text": (0.5, 0.2)}


def place(e: dict, w: int, h: int, ctx: Ctx) -> tuple[int, int]:
    """Top-left corner of a picture of size w x h centred on the element position (fractions of
    the game picture), kept on screen."""
    gx, gy, gw, gh = ctx.game
    dx, dy = DEFAULT_POS.get(e["kind"], (0.5, 0.5))
    cx = gx + float(e["x"] if e.get("x") is not None else dx) * gw
    cy = gy + float(e["y"] if e.get("y") is not None else dy) * gh
    X = int(cx - w / 2)
    Y = int(cy - h / 2)
    X = max(-int(w * 0.25), min(ctx.W - int(w * 0.75), X))
    Y = max(-int(h * 0.25), min(ctx.H - int(h * 0.75), Y))
    return X, Y


def to_game_xy(fmt_x: float, fmt_y: float, game: tuple, W: int, H: int) -> tuple[float, float]:
    """Frame fractions (where the user clicked on a preview) -> element position."""
    gx, gy, gw, gh = game
    return (fmt_x * W - gx) / max(1, gw), (fmt_y * H - gy) / max(1, gh)


def _killcard_pos(e: dict, cw: int, ch: int, ctx: Ctx) -> tuple[int, int]:
    W, H = ctx.W, ctx.H
    if e.get("x") is not None and e.get("y") is not None:
        return place(e, cw, ch, ctx)
    gx, gy, gw, gh = ctx.game
    if ctx.vertical:
        return (W - cw) // 2, gy + int(gh * 0.06)
    return int(W * 0.03), int(H * 0.05)


def _encoder(cfg, preview: bool, force_cpu: bool = False) -> tuple[list, str]:
    choice = "cpu" if force_cpu else (cfg.get("encoder") or "auto")
    use_nvenc = choice == "nvenc" or (choice == "auto" and tools.nvenc_available())
    if use_nvenc:
        if preview:
            return (["-c:v", "h264_nvenc", "-preset", "p2", "-rc", "vbr", "-cq", "27", "-b:v", "0",
                     "-pix_fmt", "yuv420p"], "nvenc")
        return (["-c:v", "h264_nvenc", "-preset", "p5", "-tune", "hq", "-rc", "vbr", "-cq", "21", "-b:v", "0",
                 "-maxrate", "25M", "-bufsize", "50M", "-profile:v", "high", "-pix_fmt", "yuv420p"], "nvenc")
    if preview:
        return (["-c:v", "libx264", "-preset", "ultrafast", "-crf", "26", "-pix_fmt", "yuv420p"], "x264")
    return (["-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-profile:v", "high",
             "-pix_fmt", "yuv420p"], "x264")


_ff_major: Optional[int] = None


def ffmpeg_major() -> int:
    global _ff_major
    if _ff_major is None:
        _ff_major = 7
        try:
            r = run([str(tools.require("ffmpeg")), "-hide_banner", "-version"], timeout=30)
            first = (r.stdout or "").splitlines()[0] if r.stdout else ""
            mm = re.search(r"version\s+n?(\d+)\.", first)
            if mm:
                _ff_major = int(mm.group(1))
            elif re.search(r"version\s+N-", first):
                _ff_major = 99         # build from the development branch
        except Exception:  # noqa: BLE001
            pass
    return _ff_major


def _graph_args(graph: str, work: Path) -> list[str]:
    """Short graphs go on the command line; long ones in a file (Windows limits command lines)."""
    if len(graph) < 6000:
        return ["-filter_complex", graph]
    (work / "graph_in.txt").write_text(graph, encoding="utf-8")
    if ffmpeg_major() >= 7:
        return ["-/filter_complex", "graph_in.txt"]
    return ["-filter_complex_script", "graph_in.txt"]
