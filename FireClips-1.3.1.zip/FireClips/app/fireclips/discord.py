"""Discord: post the best clips of a VOD in a channel of your server (one message each, with the cover
picture and the Twitch link at the right second), your mods vote with 👍 / 👎, and FireClips reads the
votes back: they count in the score of the clips.

Needs a Discord bot (free): its token, invited on the server with the rights "View channel", "Send
messages", "Attach files", "Add reactions", "Read message history" in that channel."""
from __future__ import annotations

import json
import logging
import os
import time
from pathlib import Path
from typing import Callable, Optional
from urllib.parse import quote

import requests

from . import __version__
from .errors import UserError
from .util import fmt_tag, read_json, write_json

log = logging.getLogger("fireclips.discord")
API = os.environ.get("FIRECLIPS_DISCORD_API", "https://discord.com/api/v10")
UP, DOWN = "👍", "👎"
UA = f"DiscordBot (https://github.com/fireclips, {__version__})"


class DiscordError(UserError):
    pass


def _clean_token(token: str) -> str:
    t = (token or "").strip()
    return t[4:].strip() if t.lower().startswith("bot ") else t


def _req(method: str, path: str, token: str, retries: int = 5, **kw) -> requests.Response:
    headers = kw.pop("headers", {})
    headers.update({"Authorization": "Bot " + _clean_token(token), "User-Agent": UA})
    last = None
    for _attempt in range(retries):
        try:
            r = requests.request(method, API + path, headers=headers, timeout=30, **kw)
        except requests.RequestException as e:
            last = e
            time.sleep(2)
            continue
        if r.status_code == 429:
            try:
                wait = float(r.json().get("retry_after") or 1.0)
            except ValueError:
                wait = float(r.headers.get("Retry-After") or 1.0)
            time.sleep(min(30.0, wait) + 0.1)
            continue
        if r.status_code == 401:
            raise DiscordError("err_discord_token")
        if r.status_code == 403:
            raise DiscordError("err_discord_perm", r.text[:300])
        if r.status_code == 404 and path.count("/") <= 2:
            raise DiscordError("err_discord_channel", r.text[:300])
        if r.status_code >= 500:
            last = requests.HTTPError(f"HTTP {r.status_code}")
            time.sleep(2)
            continue
        return r
    raise DiscordError("err_discord_network", str(last or "rate limited"))


def check(token: str, channel: str) -> dict:
    """{"name": channel name} or raises DiscordError."""
    if not _clean_token(token):
        raise DiscordError("err_discord_token")
    if not str(channel or "").strip().isdigit():
        raise DiscordError("err_discord_channel")
    r = _req("GET", f"/channels/{str(channel).strip()}", token)
    if r.status_code != 200:
        raise DiscordError("err_discord_channel", r.text[:300])
    return {"name": r.json().get("name") or ""}


def _link(meta: dict, t: float) -> str:
    if meta.get("vod_id") and meta.get("kind") != "local":
        return f"https://www.twitch.tv/videos/{meta['vod_id']}?t={fmt_tag(max(0.0, t - 3))}"
    return ""


def _cover_for(m: dict) -> Optional[Path]:
    for p in m.get("exported") or []:
        c = Path(p)
        c = c.with_name(c.stem + "_cover.jpg")
        if c.exists():
            return c
    return None


def message_text(meta: dict, m: dict, rank: int, lang: str = "fr") -> str:
    from .util import fmt_time
    title = (m.get("title") or "").strip() or "Clip"
    head = f"**{rank}. {title}**"
    bits = []
    if m.get("score") is not None and not str(m.get("id", "")).startswith("k"):
        bits.append(f"score {float(m['score']):.0f}")
    if str(m.get("id", "")).startswith("k") and m.get("fame"):
        from .albion import fmt_fame
        bits.append(f"{fmt_fame(m['fame'], lang)} fame")
    bits.append(fmt_time(float(m["end"]) - float(m["start"])))
    link = _link(meta, float(m["start"]))
    vote = "Vote : 👍 on le poste / 👎 poubelle" if lang == "fr" else "Vote: 👍 post it / 👎 bin it"
    return f"{head}  ·  " + " · ".join(bits) + (f"\n▶ <{link}>" if link else "") + f"\n{vote}"


def post_clips(ref, cfg, items: list[dict], progress: Callable[[float], None] = lambda f: None,
               lang: str = "fr") -> dict:
    """Post one message per clip (+ 👍 👎), remember the messages in the VOD folder."""
    token, channel = cfg.get("discord_token") or "", str(cfg.get("discord_channel") or "").strip()
    check(token, channel)
    posted = read_json(ref.p("discord.json"), {}) or {}
    meta = ref.meta
    title = meta.get("title") or ref.key
    head = (f"🔥 **FireClips — {title}** : les meilleurs moments, votez !" if lang == "fr"
            else f"🔥 **FireClips — {title}**: the best moments, vote!")
    _req("POST", f"/channels/{channel}/messages", token,
         json={"content": head, "allowed_mentions": {"parse": []}})
    n = 0
    for i, m in enumerate(items, 1):
        payload = {"content": message_text(meta, m, i, lang)[:1900], "allowed_mentions": {"parse": []}}
        cover = _cover_for(m)
        if cover is not None:
            with cover.open("rb") as fh:
                r = _req("POST", f"/channels/{channel}/messages", token,
                         data={"payload_json": json.dumps(payload, ensure_ascii=False)},
                         files={"files[0]": (cover.name, fh, "image/jpeg")})
        else:
            r = _req("POST", f"/channels/{channel}/messages", token, json=payload)
        if r.status_code not in (200, 201):
            raise DiscordError("err_discord_post", r.text[:300])
        mid = str(r.json().get("id"))
        for emo in (UP, DOWN):
            _req("PUT", f"/channels/{channel}/messages/{mid}/reactions/{quote(emo)}/@me", token)
            time.sleep(0.3)
        posted[m["id"]] = {"message": mid, "channel": channel, "start": m["start"], "end": m["end"],
                           "title": m.get("title") or "", "at": time.time()}
        write_json(ref.p("discord.json"), posted)
        n += 1
        progress(i / max(1, len(items)))
    return {"posted": n}


def read_votes(ref, cfg) -> dict:
    """Read the 👍 / 👎 of the posted clips. Saved as discord_votes.json (used by the ranking)."""
    token = cfg.get("discord_token") or ""
    posted = read_json(ref.p("discord.json"), {}) or {}
    votes = []
    for mid_key, p in posted.items():
        r = _req("GET", f"/channels/{p['channel']}/messages/{p['message']}", token)
        if r.status_code == 404:
            continue            # message deleted
        if r.status_code != 200:
            raise DiscordError("err_discord_network", r.text[:300])
        up = down = 0
        for rc in r.json().get("reactions") or []:
            name = (rc.get("emoji") or {}).get("name")
            cnt = int(rc.get("count") or 0) - (1 if rc.get("me") else 0)
            if name == UP:
                up += max(0, cnt)
            elif name == DOWN:
                down += max(0, cnt)
        votes.append({"id": mid_key, "start": p["start"], "end": p["end"], "up": up, "down": down})
    write_json(ref.p("discord_votes.json"), {"at": time.time(), "votes": votes})
    return {"votes": votes}


def votes_for(doc_votes: Optional[dict], a: float, b: float, mid: Optional[str] = None) -> Optional[dict]:
    """The votes of the posted clip with this id, or matching [a, b] (the ranking may have moved it)."""
    votes = (doc_votes or {}).get("votes") or []
    if mid:
        for v in votes:
            if v.get("id") == mid:
                return v
    best, best_iou = None, 0.0
    for v in votes:
        inter = min(b, v["end"]) - max(a, v["start"])
        union = max(b, v["end"]) - min(a, v["start"])
        iou = inter / union if union > 0 else 0.0
        if iou > best_iou:
            best, best_iou = v, iou
    return best if best is not None and best_iou >= 0.4 else None
