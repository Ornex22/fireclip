"""Real memes from the internet, downloaded on the user's PC (in the background, on the first start).

    - the MyInstants top sounds (vine boom, bruh, emotional damage...): assets/catalog.json "sounds"
    - Twitch emotes: the ones of the user's channels (7TV, BetterTTV, FrankerFaceZ), the most used ones (counted
      over the 7TV emote sets of big channels) and the BetterTTV classics
    - the imgflip top meme pictures (the list is refreshed from the imgflip API)
    - green screen memes from YouTube (the first short result of a search, through yt-dlp)
    - Kevin MacLeod's music (incompetech.com, CC BY 4.0: the credit goes in the post text of the clip)

None of these files ship with FireClips: they come from those sites, on the user's PC, into
<FireClips folder>/memebank/<kind>/. index.json says what is there. References in an edit list:
"web:sound/<id>", "web:image/<id>", "web:emote/<id>", "web:green/<id>", "web:music/<id>"."""
from __future__ import annotations

import json
import logging
import os
import re
import shutil
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional
from urllib.parse import quote, quote_plus, urljoin, urlparse

from . import paths

log = logging.getLogger("fireclips.memebank")

KINDS = ("sound", "emote", "image", "music", "green")
BROWSER_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
              "Chrome/131.0.0.0 Safari/537.36")
MYI_PAGE = "https://www.myinstants.com/en/instant/{id}/"
MYI_SEARCH = "https://www.myinstants.com/en/search/?name={q}"
INCOMPETECH_MP3 = "https://incompetech.com/music/royalty-free/mp3-royaltyfree/{title}.mp3"
INCOMPETECH_PAGE = "https://incompetech.com/music/royalty-free/index.html?title={title}"
LISTS_EVERY = 7 * 86400          # emote / imgflip lists are fetched again after a week
MAX_TRIES = 3                    # a download that failed 3 times waits a week before the next try
GREEN_MAX = 20.0                 # seconds kept of a green screen meme

Progress = Callable[[float, str], None]


def _noop(_f: float = 0.0, _m: str = "") -> None:
    pass


# --------------------------------------------------------------------------- the catalog (assets/catalog.json)

_cat: Optional[dict] = None


def catalog() -> dict:
    global _cat
    if _cat is None:
        try:
            _cat = json.loads((paths.ASSETS / "catalog.json").read_text(encoding="utf-8"))
        except (OSError, ValueError) as e:
            log.warning("meme catalog: %s", e)
            _cat = {}
    return _cat


def sound_cats() -> list[dict]:
    return list(catalog().get("sound_cats") or [])


def auto_sound(role: str, pick: int = 0) -> str:
    """The sound the automatic montage uses for a kill, a death... ("" when there is none). Among several, a
    downloaded one is preferred (the chosen one plays anyway once it is downloaded)."""
    v = (catalog().get("auto") or {}).get(role)
    cands = list(v) if isinstance(v, list) else ([v] if v else [])
    if not cands:
        return ""
    k = pick % len(cands)
    order = cands[k:] + cands[:k]
    for c in order:
        if path_of(f"web:sound/{c}") is not None:
            return f"web:sound/{c}"
    return f"web:sound/{order[0]}"


def music_credit(ref: str, lang: str = "fr") -> str:
    """The credit line to put under a clip that uses a Kevin MacLeod track ("" for other music)."""
    if not (ref or "").startswith("web:music/"):
        return ""
    mid = ref.split("/", 1)[1]
    for mu in catalog().get("music") or []:
        if mu["id"] == mid:
            head = "Musique" if lang == "fr" else "Music"
            return f"{head} : « {mu['title']} » — {catalog().get('music_credit', 'Kevin MacLeod (incompetech.com)')}" \
                if lang == "fr" else f"{head}: “{mu['title']}” by {catalog().get('music_credit', 'Kevin MacLeod')}"
    return ""


# --------------------------------------------------------------------------- the folder and its index


def root() -> Path:
    return paths.ROOT / "memebank"


_idx_lock = threading.RLock()
_idx_cache: dict = {"mtime": None, "data": None}


def _empty_index() -> dict:
    return {"v": 1, "items": {}, "fail": {}, "lists": {}}


def load_index() -> dict:
    """What is downloaded (read again when another process changed it)."""
    p = root() / "index.json"
    with _idx_lock:
        try:
            mt = p.stat().st_mtime_ns
        except OSError:
            return _empty_index()
        if _idx_cache["mtime"] == mt and _idx_cache["data"] is not None:
            return _idx_cache["data"]
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                raise ValueError("not a dict")
        except (OSError, ValueError) as e:
            log.warning("meme bank index: %s", e)
            data = _empty_index()
        for k, v in _empty_index().items():
            data.setdefault(k, v)
        _idx_cache.update(mtime=mt, data=data)
        return data


class _FileLock:
    """A lock between processes (the background download and a single download the user asked for)."""

    def __init__(self, path: Path, wait: float = 10.0):
        self.path = path
        self.wait = wait
        self.fd = None

    def __enter__(self):
        end = time.time() + self.wait
        while True:
            try:
                self.fd = os.open(str(self.path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                return self
            except FileExistsError:
                try:
                    if time.time() - self.path.stat().st_mtime > 30:      # left by a process that was killed
                        self.path.unlink()
                        continue
                except OSError:
                    pass
                if time.time() > end:
                    return self                  # better a rare lost line in the index than a frozen download
                time.sleep(0.05)

    def __exit__(self, *_a):
        if self.fd is not None:
            os.close(self.fd)
            try:
                self.path.unlink()
            except OSError:
                pass
        return False


def update_index(fn: Callable[[dict], None]) -> dict:
    """Change the index on disk (read it fresh, change it, write it whole)."""
    r = root()
    r.mkdir(parents=True, exist_ok=True)
    p = r / "index.json"
    with _idx_lock, _FileLock(r / "index.lock"):
        _idx_cache["mtime"] = None
        data = load_index()
        data = json.loads(json.dumps(data))           # a copy: the cached one stays as it was if writing fails
        fn(data)
        tmp = r / f"index.{os.getpid()}.tmp"
        tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, p)
        _idx_cache["mtime"] = None
    return load_index()


# --------------------------------------------------------------------------- what the bank holds


@dataclass
class Entry:
    ref: str                  # web:<kind>/<id>
    kind: str                 # sound | emote | image | music | green
    id: str
    name: str
    group: str = ""           # sound: its family; emote: mine | top | classic; image: imgflip
    rank: int = 0
    src: dict = field(default_factory=dict)
    path: Optional[Path] = None
    info: dict = field(default_factory=dict)     # dur, wave, w, h (once downloaded)


def _file_of(idx: dict, ref: str) -> tuple[Optional[Path], dict]:
    rec = idx["items"].get(ref)
    if not rec:
        return None, {}
    p = root() / rec.get("file", "")
    try:
        return (p, rec) if p.is_file() else (None, {})
    except OSError:
        return None, {}


def _imgflip_entries(idx: dict) -> list[dict]:
    seen, out = set(), []
    live = (idx["lists"].get("imgflip") or [])
    for im in list(catalog().get("images") or []) + live:
        if im["url"] in seen:
            continue
        seen.add(im["url"])
        out.append(im)
    return out


def entries(kind: str) -> list[Entry]:
    """Everything of one kind the bank can hold, downloaded or not (path None: not yet)."""
    idx = load_index()
    cat = catalog()
    out: list[Entry] = []
    if kind == "sound":
        for s in cat.get("sounds") or []:
            out.append(Entry(f"web:sound/{s['id']}", "sound", s["id"], s["name"], s.get("cat", ""),
                             int(s.get("rank") or 0), {"page": MYI_PAGE.format(id=s["id"])}))
    elif kind == "image":
        for i, im in enumerate(_imgflip_entries(idx)):
            out.append(Entry(f"web:image/{im['id']}", "image", im["id"], im["name"], "imgflip", i + 1,
                             {"url": im["url"]}, info={"w": im.get("w"), "h": im.get("h")}))
    elif kind == "emote":
        for i, em in enumerate(idx["lists"].get("emotes") or []):
            out.append(Entry(f"web:emote/{em['id']}", "emote", em["id"], em["code"], em.get("group", ""),
                             int(em.get("rank") or i + 1), {"urls": em.get("urls") or [], "provider": em.get("provider")},
                             info={"animated": bool(em.get("animated"))}))
    elif kind == "green":
        for i, g in enumerate(cat.get("greens") or []):
            out.append(Entry(f"web:green/{g['id']}", "green", g["id"], g["name"], "", i + 1, {"q": g["q"]}))
    elif kind == "music":
        for i, mu in enumerate(cat.get("music") or []):
            out.append(Entry(f"web:music/{mu['id']}", "music", mu["id"], mu["title"], "", i + 1,
                             {"title": mu["title"]}, info={"fr": mu.get("fr", ""), "en": mu.get("en", "")}))
    lim = int(os.environ.get("FIRECLIPS_BANK_LIMIT") or 0)      # tests: a small bank
    if lim:
        out = out[:lim]
    for e in out:
        e.path, rec = _file_of(idx, e.ref)
        if rec:
            e.info.update({k: rec[k] for k in ("dur", "wave", "w", "h") if k in rec})
    return out


def path_of(ref: str) -> Optional[Path]:
    """The downloaded file of a web: reference (None when it is not there)."""
    if not (ref or "").startswith("web:"):
        return None
    p, _rec = _file_of(load_index(), ref)
    return p


_names: dict = {"key": None, "map": {}}


def name_of(ref: str, lang: str = "fr") -> str:
    """What the user sees for a web: reference."""
    if not (ref or "").startswith("web:"):
        return ""
    idx = load_index()
    rec = idx["items"].get(ref) or {}
    if rec.get("name"):
        return rec["name"]
    key = (id(idx), _idx_cache.get("mtime"))
    if _names["key"] != key:
        mp = {}
        cat = catalog()
        for s in cat.get("sounds") or []:
            mp[f"web:sound/{s['id']}"] = s["name"]
        for g in cat.get("greens") or []:
            mp[f"web:green/{g['id']}"] = g["name"]
        for mu in cat.get("music") or []:
            mp[f"web:music/{mu['id']}"] = mu["title"]
        for im in _imgflip_entries(idx):
            mp[f"web:image/{im['id']}"] = im["name"]
        for em in idx["lists"].get("emotes") or []:
            mp[f"web:emote/{em['id']}"] = em["code"]
        _names.update(key=key, map=mp)
    return _names["map"].get(ref) or ref.rsplit("/", 1)[-1]


def counts() -> dict:
    """How much of the bank is downloaded: {"have", "total", "kinds": {kind: [have, total]}}."""
    out = {"have": 0, "total": 0, "kinds": {}}
    idx = load_index()
    for k in KINDS:
        es = entries(k)
        have = sum(1 for e in es if e.path is not None)
        out["kinds"][k] = [have, len(es)]
        out["have"] += have
        out["total"] += len(es)
    out["lists"] = bool(idx["lists"].get("t_emotes"))
    return out


def missing_count() -> int:
    """How many memes are not downloaded yet and will still be tried (the ones that failed 3 times wait a week)."""
    return len(_todo(load_index()))


def needs_sync() -> bool:
    """Something is missing (or the lists are old): the background download has work to do."""
    idx = load_index()
    now = time.time()
    if now - float(idx["lists"].get("t_emotes") or 0) > LISTS_EVERY:
        return True
    if now - float(idx["lists"].get("t_imgflip") or 0) > LISTS_EVERY:
        return True
    return bool(_todo(idx))


def _todo(idx: dict, kinds=None) -> list[Entry]:
    now = time.time()
    out = []
    for k in kinds or KINDS:
        for e in entries(k):
            if e.path is not None:
                continue
            f = idx["fail"].get(e.ref) or {}
            if int(f.get("n") or 0) >= MAX_TRIES and now - float(f.get("t") or 0) < LISTS_EVERY:
                continue
            out.append(e)
    return out


# --------------------------------------------------------------------------- downloading


def _url(u: str) -> str:
    """Tests send every request to a local server (FIRECLIPS_NET_BASE)."""
    if u.startswith("//"):
        u = "https:" + u
    base = os.environ.get("FIRECLIPS_NET_BASE")
    if not base:
        return u
    p = urlparse(u)
    return f"{base.rstrip('/')}/net/{p.netloc}{p.path}" + (f"?{p.query}" if p.query else "")


_sess_local = threading.local()


def _sess():
    import requests
    s = getattr(_sess_local, "s", None)
    if s is None:
        s = requests.Session()
        s.headers.update({"User-Agent": BROWSER_UA, "Accept": "*/*", "Accept-Language": "en-US,en;q=0.8,fr;q=0.6"})
        _sess_local.s = s
    return s


def _get_json(url: str, timeout: float = 30):
    r = _sess().get(_url(url), timeout=timeout)
    if r.status_code != 200:
        raise OSError(f"HTTP {r.status_code} {url}")
    return r.json()


def _get_text(url: str, timeout: float = 30) -> str:
    r = _sess().get(_url(url), timeout=timeout)
    if r.status_code != 200:
        raise OSError(f"HTTP {r.status_code} {url}")
    return r.text


def _magic_ext(head: bytes, default: str = "") -> str:
    if head[:6] in (b"GIF87a", b"GIF89a"):
        return ".gif"
    if head[:8] == b"\x89PNG\r\n\x1a\n":
        return ".png"
    if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
        return ".webp"
    if head[:3] == b"\xff\xd8\xff":
        return ".jpg"
    if head[:3] == b"ID3" or head[:2] in (b"\xff\xfb", b"\xff\xf3", b"\xff\xf2"):
        return ".mp3"
    if head[4:8] == b"ftyp":
        return ".mp4"
    if head[:4] == b"OggS":
        return ".ogg"
    if head[:4] == b"RIFF" and head[8:12] == b"WAVE":
        return ".wav"
    return default


def _download(url: str, folder: Path, stem: str, default_ext: str, cancel=None,
              max_bytes: int = 80 * 1024 * 1024) -> Path:
    """GET url into folder/stem + its real extension (read from the first bytes)."""
    folder.mkdir(parents=True, exist_ok=True)
    part = folder / f"{stem}.{os.getpid()}.{threading.get_ident()}.part"
    r = _sess().get(_url(url), timeout=40, stream=True)
    head = b""
    try:
        if r.status_code != 200:
            raise OSError(f"HTTP {r.status_code} {url}")
        got = 0
        with part.open("wb") as fh:
            for chunk in r.iter_content(65536):
                if cancel is not None and cancel.is_set():
                    raise InterruptedError("cancelled")
                if not head:
                    head = chunk[:16]
                fh.write(chunk)
                got += len(chunk)
                if got > max_bytes:
                    raise OSError("file too big")
        if got < 64:
            raise OSError("empty file")
    except BaseException:
        try:
            part.unlink()
        except OSError:
            pass
        raise
    finally:
        r.close()
    dest = folder / (stem + _magic_ext(head, default_ext))
    os.replace(part, dest)
    return dest


def _ffmpeg():
    from . import tools
    return tools.find("ffmpeg")


def _wave(path: Path, n: int = 48) -> tuple[list, float]:
    """Loudness of a sound in n steps (0..99) and its length."""
    try:
        import numpy as np
        from . import preview
        x = preview.sound_of(path, 0.0, 120.0)
        if not len(x):
            return [], 0.0
        dur = len(x) / 48000.0
        m = np.abs(x).max(axis=1)
        chunks = np.array_split(m, n)
        pk = np.array([c.max() if len(c) else 0.0 for c in chunks])
        pk = pk / max(1e-9, pk.max())
        return [int(round(v * 99)) for v in pk], round(dur, 3)
    except Exception as e:  # noqa: BLE001
        log.info("wave %s: %s", path, e)
        return [], 0.0


def _even_sound(src: Path, dest: Path) -> Path:
    """Same loudness for every sound of the bank (they come very loud or very quiet from the internet)."""
    ff = _ffmpeg()
    if ff is not None:
        from .util import run
        tmp = dest.with_name(dest.stem + f".{os.getpid()}.even.mp3")
        r = run([str(ff), "-y", "-hide_banner", "-v", "error", "-i", str(src), "-vn", "-af",
                 "loudnorm=I=-16:LRA=11:TP=-1.5,aresample=48000", "-ac", "2", "-ar", "48000", "-c:a", "libmp3lame",
                 "-q:a", "3", str(tmp)], timeout=120)
        if r.returncode == 0 and tmp.is_file() and tmp.stat().st_size > 256:
            os.replace(tmp, dest)
            try:
                src.unlink()
            except OSError:
                pass
            return dest
        log.info("even sound %s: %s", src.name, (r.stderr or "")[-300:])
        try:
            tmp.unlink()
        except OSError:
            pass
    keep = dest.with_suffix(src.suffix)            # as it came
    os.replace(src, keep)
    return keep


_MYI_MP3 = re.compile(r"""(/media/sounds/[^'"\s<>]+?\.(?:mp3|wav|ogg|m4a))""")
_MYI_LINK = re.compile(r"""href=["']((?:https?://www\.myinstants\.com)?/(?:[a-z]{2}/)?instant/[^'"\s<>/]+/?)["']""")


def _myi_mp3(page_url: str, page: str) -> str:
    import html
    m = _MYI_MP3.search(page)
    return urljoin(page_url, html.unescape(m.group(1))) if m else ""


def _sound_url(e: Entry) -> str:
    """The mp3 of a MyInstants button: its page, or (renamed / removed button) the first result of a search
    by its name."""
    try:
        u = _myi_mp3(e.src["page"], _get_text(e.src["page"]))
        if u:
            return u
        first: Exception = OSError("no sound on the MyInstants page")
    except OSError as ex:
        first = ex
    words = " ".join(re.sub(r"""[()\[\]{}?!.,:;"*/\\]""", " ", e.name).split())
    s_url = MYI_SEARCH.format(q=quote_plus(words))
    try:
        page = _get_text(s_url)
    except OSError:
        raise first
    u = _myi_mp3(s_url, page)
    if not u:
        m = _MYI_LINK.search(page)
        if m:
            p_url = urljoin(s_url, m.group(1))
            try:
                u = _myi_mp3(p_url, _get_text(p_url))
            except OSError:
                u = ""
    if not u:
        raise first
    log.info("sound %s: found by a search (%s)", e.id, u.rsplit("/", 1)[-1])
    return u


def _get_sound(e: Entry, cancel=None) -> Path:
    url = _sound_url(e)
    raw = _download(url, root() / "sound", e.id + ".dl", ".mp3", cancel)
    return _even_sound(raw, root() / "sound" / f"{e.id}.mp3")


def _get_picture(e: Entry, folder: str, cancel=None) -> Path:
    urls = e.src.get("urls") or [e.src.get("url")]
    last = None
    for u in [u for u in urls if u]:
        try:
            return _download(u, root() / folder, e.id, ".png", cancel, max_bytes=25 * 1024 * 1024)
        except (OSError, ValueError) as ex:
            last = ex
    raise OSError(str(last or "no address"))


def _get_music(e: Entry, cancel=None) -> Path:
    title = e.src["title"]
    try:
        return _download(INCOMPETECH_MP3.format(title=quote(title)), root() / "music", e.id, ".mp3", cancel)
    except OSError as first:
        page = _get_text(INCOMPETECH_PAGE.format(title=quote(title)))
        m = re.search(r"""([^'"\s<>]*mp3-royaltyfree/[^'"<>]+?\.mp3)""", page)
        if not m:
            raise first
        url = urljoin(INCOMPETECH_PAGE.format(title=quote(title)), m.group(1).replace(" ", "%20"))
        return _download(url, root() / "music", e.id, ".mp3", cancel)


def _get_green(e: Entry, cfg, cancel=None) -> Path:
    from . import memes
    res = memes.search(e.src["q"], 8)
    if not res:
        raise OSError("no video found")

    def good(r):
        return 2.0 <= float(r.get("duration") or 0) <= 75.0
    cands = [r for r in res if good(r) and any(w in r["title"].lower() for w in ("green", "chroma", "greenscreen"))]
    cands += [r for r in res if good(r) and r not in cands]
    if not cands:
        raise OSError("no short green screen video")
    pick = cands[0]
    dur = float(pick.get("duration") or GREEN_MAX)
    got = memes.fetch(pick["url"], cfg, section=(0.0, min(dur, GREEN_MAX)) if dur > GREEN_MAX else None,
                      cancel=cancel)
    src = Path(got["path"])
    dest = root() / "green" / f"{e.id}.mp4"
    dest.parent.mkdir(parents=True, exist_ok=True)
    ff = _ffmpeg()
    from .util import run
    keep = min(GREEN_MAX, float(got.get("duration") or GREEN_MAX))
    cmd = [str(ff), "-y", "-hide_banner", "-v", "error", "-t", f"{keep:.2f}", "-i", str(src),
           "-vf", "scale='trunc(min(1280,iw)/2)*2':-2,fps=30", "-c:v", "libx264", "-preset", "veryfast", "-crf", "21",
           "-pix_fmt", "yuv420p"]
    if got.get("has_audio"):
        cmd += ["-af", "loudnorm=I=-16:LRA=11:TP=-1.5,aresample=48000", "-c:a", "aac", "-b:a", "160k"]
    else:
        cmd += ["-an"]
    cmd += ["-movflags", "+faststart", str(dest)]
    r = run(cmd, timeout=300)
    try:
        src.unlink()
    except OSError:
        pass
    if r.returncode != 0 or not dest.is_file():
        raise OSError("green screen cut failed: " + (r.stderr or "")[-300:])
    return dest


def _fetch(e: Entry, cfg, cancel=None) -> dict:
    """Download one thing; returns its index record."""
    if e.kind == "sound":
        p = _get_sound(e, cancel)
    elif e.kind == "image":
        p = _get_picture(e, "image", cancel)
    elif e.kind == "emote":
        p = _get_picture(e, "emote", cancel)
    elif e.kind == "music":
        p = _get_music(e, cancel)
    elif e.kind == "green":
        p = _get_green(e, cfg, cancel)
    else:
        raise ValueError(e.kind)
    rec = {"file": p.relative_to(root()).as_posix(), "t": time.time(), "name": e.name, "size": p.stat().st_size}
    if e.kind in ("sound", "music"):
        wave, dur = _wave(p, 96 if e.kind == "music" else 48)
        rec.update(wave=wave, dur=dur)
    elif e.kind in ("image", "emote"):
        try:
            from PIL import Image
            with Image.open(p) as im:
                rec.update(w=im.width, h=im.height, frames=int(getattr(im, "n_frames", 1) or 1))
        except Exception as ex:  # noqa: BLE001 - not a picture: refused
            try:
                p.unlink()
            except OSError:
                pass
            raise OSError(f"not a picture: {ex}") from ex
    return rec


def get(cfg, ref: str, cancel=None) -> Path:
    """Download one thing now (the user picked it before the background download got to it)."""
    p = path_of(ref)
    if p is not None:
        return p
    kind = ref[4:].partition("/")[0]
    e = next((x for x in entries(kind) if x.ref == ref), None) if kind in KINDS else None
    if e is None:
        raise ValueError(f"unknown meme {ref}")
    try:
        rec = _fetch(e, cfg, cancel)
    except Exception as ex:
        _record_fail(e.ref, ex)
        raise
    update_index(lambda d: (d["items"].__setitem__(e.ref, rec), d["fail"].pop(e.ref, None)))
    return root() / rec["file"]


def _record_fail(ref: str, ex: Exception) -> None:
    def fn(d):
        f = d["fail"].get(ref) or {}
        d["fail"][ref] = {"n": int(f.get("n") or 0) + 1, "t": time.time(), "err": str(ex)[:300]}
    try:
        update_index(fn)
    except OSError:
        pass


# --------------------------------------------------------------------------- lists from the internet


def _twitch_ids(logins: list[str]) -> dict:
    """{login: Twitch user id} (through Twitch's own API, like the rest of FireClips)."""
    from . import twitch
    out: dict = {}
    logins = [twitch.clean_login(x) for x in logins if x]
    for i in range(0, len(logins), 30):
        part = logins[i:i + 30]
        q = "query{" + " ".join(f'u{j}:user(login:"{lg}"){{id login}}' for j, lg in enumerate(part)) + "}"
        try:
            data = twitch.gql(q, retries=2)
        except Exception as e:  # noqa: BLE001
            log.info("twitch ids: %s", e)
            continue
        for j, lg in enumerate(part):
            u = ((data or {}).get("data") or {}).get(f"u{j}") or {}
            if u.get("id"):
                out[lg] = str(u["id"])
    return out


def _7tv_url(em: dict) -> list[str]:
    data = em.get("data") or em
    host = data.get("host") or {}
    base = host.get("url") or f"//cdn.7tv.app/emote/{data.get('id') or em.get('id')}"
    names = [f.get("name") for f in host.get("files") or [] if f.get("name")]
    prefs = ["4x.webp", "3x.webp", "4x.gif", "3x.gif", "4x.png", "3x.png", "2x.webp"]
    order = [n for n in prefs if n in names] or ["4x.webp", "3x.webp"]
    return ["https:" + base + "/" + n if base.startswith("//") else base + "/" + n for n in order[:3]]


def _7tv_set(twitch_id: str) -> list[dict]:
    d = _get_json(f"https://7tv.io/v3/users/twitch/{twitch_id}")
    out = []
    for em in ((d.get("emote_set") or {}).get("emotes") or []):
        data = em.get("data") or {}
        eid = data.get("id") or em.get("id")
        name = em.get("name") or data.get("name")
        if eid and name:
            out.append({"id": f"7tv-{eid}", "code": name, "provider": "7tv", "urls": _7tv_url(em),
                        "animated": bool(data.get("animated"))})
    return out


def _bttv(url: str) -> list[dict]:
    d = _get_json(url)
    rows = d if isinstance(d, list) else (d.get("channelEmotes") or []) + (d.get("sharedEmotes") or [])
    out = []
    for em in rows:
        if em.get("id") and em.get("code"):
            out.append({"id": f"bttv-{em['id']}", "code": em["code"], "provider": "bttv",
                        "urls": [f"https://cdn.betterttv.net/emote/{em['id']}/3x"],
                        "animated": bool(em.get("animated")) or em.get("imageType") == "gif"})
    return out


def _ffz(twitch_id: str) -> list[dict]:
    d = _get_json(f"https://api.frankerfacez.com/v1/room/id/{twitch_id}")
    out = []
    for s in (d.get("sets") or {}).values():
        for em in s.get("emoticons") or []:
            urls = em.get("urls") or {}
            u = urls.get("4") or urls.get("2") or urls.get("1")
            if em.get("id") and em.get("name") and u:
                out.append({"id": f"ffz-{em['id']}", "code": em["name"], "provider": "ffz", "urls": [u],
                            "animated": bool(em.get("animated"))})
    return out


def my_channels(cfg) -> list[str]:
    logins = []
    for s in cfg.get("streamers") or []:
        if s.get("login"):
            logins.append(s["login"])
    if cfg.get("channel"):
        logins.append(cfg["channel"])
    seen, out = set(), []
    for lg in logins:
        lg = lg.strip().lower()
        if lg and lg not in seen:
            seen.add(lg)
            out.append(lg)
    return out


def refresh_lists(cfg, force: bool = False, progress: Progress = _noop) -> dict:
    """Fetch again the lists that change (emotes, imgflip top) when they are a week old or the channels changed."""
    idx = load_index()
    lists = dict(idx["lists"])
    now = time.time()
    mine_logins = my_channels(cfg)
    changed = False
    if force or now - float(lists.get("t_imgflip") or 0) > LISTS_EVERY:
        try:
            d = _get_json(catalog().get("imgflip_api") or "https://api.imgflip.com/get_memes")
            skip = [s.lower() for s in catalog().get("imgflip_skip") or []]
            out = []
            for mm in ((d.get("data") or {}).get("memes") or []):
                name = mm.get("name") or ""
                if not mm.get("url") or any(s in name.lower() for s in skip):
                    continue
                sid = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")[:50] or str(mm.get("id"))
                out.append({"id": sid, "name": name, "url": mm["url"], "w": mm.get("width"), "h": mm.get("height")})
            lists["imgflip"] = out
            lists["t_imgflip"] = now
            changed = True
        except Exception as e:  # noqa: BLE001
            log.info("imgflip list: %s", e)
    if force or now - float(lists.get("t_emotes") or 0) > LISTS_EVERY or lists.get("emote_for") != mine_logins:
        progress(0.0, "emotes")
        emotes: list[dict] = []
        seen: set = set()

        def add(rows: list[dict], group: str) -> None:
            for r in rows:
                if r["id"] not in seen:
                    seen.add(r["id"])
                    emotes.append(dict(r, group=group, rank=len(emotes) + 1))
        big = list(catalog().get("emote_channels") or [])
        ids = _twitch_ids(mine_logins + big)
        ok = False
        for lg in mine_logins:                         # the user's own channels first
            tid = ids.get(lg)
            if not tid:
                continue
            for fn, arg in ((_7tv_set, tid), (_bttv, f"https://api.betterttv.net/3/cached/users/twitch/{tid}"),
                            (_ffz, tid)):
                try:
                    add(fn(arg), "mine")
                    ok = True
                except Exception as e:  # noqa: BLE001
                    log.info("emotes of %s (%s): %s", lg, getattr(fn, "__name__", "?"), e)
        counts_: dict = {}
        best: dict = {}
        for k, lg in enumerate(big):                    # the most used emotes: in the most big channels
            tid = ids.get(lg)
            if not tid:
                continue
            progress(0.1 + 0.8 * k / max(1, len(big)), "emotes")
            try:
                rows = _7tv_set(tid)
                ok = True
            except Exception as e:  # noqa: BLE001
                log.info("7tv set of %s: %s", lg, e)
                continue
            for r in rows:
                key = r["code"].lower()
                counts_[key] = counts_.get(key, 0) + 1
                b = best.setdefault(key, {})
                b[r["id"]] = (b.get(r["id"], (0, r))[0] + 1, r)
        top_n = int(catalog().get("emote_top") or 150)
        ranked = sorted((k for k, n in counts_.items() if n >= 3), key=lambda k: (-counts_[k], k))[:top_n]
        add([max(best[k].values(), key=lambda v: v[0])[1] for k in ranked], "top")
        try:
            add(_bttv("https://api.betterttv.net/3/cached/emotes/global"), "classic")
            ok = True
        except Exception as e:  # noqa: BLE001
            log.info("bttv global: %s", e)
        if ok or not lists.get("emotes"):
            lists["emotes"] = emotes or lists.get("emotes") or []
            lists["t_emotes"] = now if ok else float(lists.get("t_emotes") or 0)
            lists["emote_for"] = mine_logins
            changed = True
    if changed:
        update_index(lambda d: d.__setitem__("lists", lists))
    return lists


# --------------------------------------------------------------------------- the background download

PRIORITY = {"sound": 0, "emote": 1, "image": 2, "music": 3, "green": 4}


def plan(idx: Optional[dict] = None, kinds=None) -> list[Entry]:
    """What to download, the most useful first (the sounds of the automatic montage, then the sounds, emotes
    of the user's channel, the top emotes, the pictures, the music, the green screens)."""
    idx = idx or load_index()
    todo = _todo(idx, kinds)
    auto = set()
    for role in ("kill", "death", "freeze", "multikill"):
        v = (catalog().get("auto") or {}).get(role)
        for x in v if isinstance(v, list) else [v]:
            if x:
                auto.add(f"web:sound/{x}")
    grp = {"mine": 0, "top": 1, "classic": 2}
    todo.sort(key=lambda e: (0 if e.ref in auto else 1, PRIORITY.get(e.kind, 9),
                             grp.get(e.group, 0) if e.kind == "emote" else 0, e.rank))
    return todo


def sync(cfg, progress: Callable[[int, int, str, str, bool], None], cancel=None, kinds=None) -> dict:
    """Download what is missing. progress(done, total, ref, name, ok) after each one."""
    from concurrent.futures import ThreadPoolExecutor, as_completed
    try:
        refresh_lists(cfg)
    except Exception as e:  # noqa: BLE001
        log.info("meme lists: %s", e)
    todo = plan(kinds=kinds)
    total = len(todo)
    done = 0
    ok_n = fail_n = 0
    pending: dict = {}
    last_save = [time.time()]
    lock = threading.Lock()

    def flush(force: bool = False) -> None:
        with lock:
            if not pending or (not force and time.time() - last_save[0] < 2.0):
                return
            batch = dict(pending)
            pending.clear()
            last_save[0] = time.time()

        def fn(d):
            for ref, rec in batch.items():
                if "fail" in rec:
                    f = d["fail"].get(ref) or {}
                    d["fail"][ref] = {"n": int(f.get("n") or 0) + 1, "t": time.time(), "err": rec["fail"]}
                else:
                    d["items"][ref] = rec
                    d["fail"].pop(ref, None)
        update_index(fn)

    def one(e: Entry):
        if cancel is not None and cancel.is_set():
            return e, None, "cancelled"
        try:
            return e, _fetch(e, cfg, cancel), ""
        except Exception as ex:  # noqa: BLE001 - one meme that fails does not stop the others
            log.info("meme %s: %s", e.ref, ex)
            return e, None, str(ex)[:300]

    web = [e for e in todo if e.kind != "green"]
    slow = [e for e in todo if e.kind == "green"]
    with ThreadPoolExecutor(max_workers=4) as pool:
        futs = [pool.submit(one, e) for e in web]
        for fut in as_completed(futs):
            e, rec, err = fut.result()
            done += 1
            if rec is not None:
                ok_n += 1
                with lock:
                    pending[e.ref] = rec
            elif err != "cancelled":
                fail_n += 1
                with lock:
                    pending[e.ref] = {"fail": err}
            flush()
            progress(done, total, e.ref, e.name, rec is not None)
            if cancel is not None and cancel.is_set():
                for f in futs:
                    f.cancel()
                break
    for e in slow:
        if cancel is not None and cancel.is_set():
            break
        e, rec, err = one(e)
        done += 1
        if rec is not None:
            ok_n += 1
            pending[e.ref] = rec
        elif err != "cancelled":
            fail_n += 1
            pending[e.ref] = {"fail": err}
        flush(True)
        progress(done, total, e.ref, e.name, rec is not None)
    flush(True)
    c = counts()
    return {"downloaded": ok_n, "failed": fail_n, "have": c["have"], "total": c["total"]}


def clear_failures() -> None:
    """Try again what failed (the user asked for a new download)."""
    update_index(lambda d: d.__setitem__("fail", {}))


def remove_all() -> None:
    shutil.rmtree(root(), ignore_errors=True)
    _idx_cache["mtime"] = None
