"""TikTok-style burned-in subtitles (ASS format): big bold words, a few at a time, the word
being said highlighted in colour, with a small "pop" when a new group appears.

Several looks ("styles") are available; the user settings (size, position, words at once,
capitals, highlight colour) apply on top of the chosen style."""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional

FONT_NAME = "Montserrat ExtraBold"

# mode: highlight = the word being said is coloured | reveal = words appear one by one |
#       word = one big word at a time | plain = the whole group, no colour change
STYLES: dict[str, dict] = {
    "classic": {"font": "Montserrat ExtraBold", "size": 1.0, "color": "#FFFFFF", "hi": None, "outline": "#000000",
                "ow": 0.09, "shadow": 0.035, "mode": "highlight", "pop": True},
    "reveal": {"font": "Montserrat ExtraBold", "size": 1.0, "color": "#FFFFFF", "hi": None, "outline": "#000000",
               "ow": 0.09, "shadow": 0.035, "mode": "reveal", "pop": False, "words": 4},
    "box": {"font": "Poppins ExtraBold", "size": 0.9, "color": "#FFFFFF", "hi": None, "outline": "#000000",
            "ow": 0.20, "shadow": 0.0, "mode": "highlight", "pop": True, "box": 0x00},
    "fire": {"font": "Luckiest Guy", "size": 1.0, "color": "#FFD23F", "hi": "#FFFFFF", "outline": "#8E1407",
             "ow": 0.10, "shadow": 0.03, "mode": "highlight", "pop": True, "glow": "#FF6A00", "chars": 0.85},
    "word": {"font": "Anton", "size": 1.45, "color": "#FFFFFF", "hi": None, "outline": "#000000", "ow": 0.07,
             "shadow": 0.04, "mode": "word", "pop": True, "words": 1, "cycle": ["#FFFFFF", None, "#7CFF6B"]},
    "comic": {"font": "Bangers", "size": 1.2, "color": "#FFFFFF", "hi": None, "outline": "#000000", "ow": 0.11,
              "shadow": 0.05, "mode": "highlight", "pop": True, "rot": -3, "spacing": 2, "chars": 1.1},
    "minimal": {"font": "Poppins SemiBold", "size": 0.66, "color": "#FFFFFF", "hi": None, "outline": "#000000",
                "ow": 0.05, "shadow": 0.0, "blur": 1.5, "mode": "plain", "pop": False, "upper": False,
                "words": 7, "chars": 1.9},
}
STYLE_ORDER = ["classic", "reveal", "box", "fire", "word", "comic", "minimal"]


def resolve_style(style_id: Optional[str], cfg=None) -> dict:
    """A style preset with the user's settings applied (size %, position, words, capitals, colour)."""
    sid = style_id if style_id in STYLES else "classic"
    st = dict(STYLES[sid])
    st["id"] = sid
    get = (cfg.get if cfg is not None else (lambda k, d=None: d))
    st["size_pct"] = int(get("subtitle_size") or 100)
    st["position_pct"] = int(get("subtitle_position") or 68)
    accent = get("subtitle_highlight") or "#FFE14D"
    if st.get("hi") is None:
        st["hi"] = accent
    if st.get("cycle"):
        st["cycle"] = [c or accent for c in st["cycle"]]
    if st.get("words") is None:
        st["words"] = int(get("subtitle_words") or 3)
    if st.get("upper") is None:
        up = get("subtitle_uppercase")
        st["upper"] = True if up is None else bool(up)
    return st


def _ass_time(t: float) -> str:
    t = max(0.0, t)
    cs = int(round(t * 100))
    h, cs = divmod(cs, 360000)
    m, cs = divmod(cs, 6000)
    s, cs = divmod(cs, 100)
    return f"{h}:{m:02d}:{s:02d}.{cs:02d}"


def _ass_color(hex_rgb: str, alpha: int = 0) -> str:
    h = (hex_rgb or "#FFFFFF").lstrip("#")
    if len(h) != 6 or not re.fullmatch(r"[0-9a-fA-F]{6}", h):
        h = "FFFFFF"
    r, g, b = h[0:2], h[2:4], h[4:6]
    return f"&H{alpha:02X}{b}{g}{r}".upper()


def _tag_color(hex_rgb: str) -> str:
    """Colour for an override tag: &HBBGGRR& (no alpha byte)."""
    return _ass_color(hex_rgb)[4:].join(("&H", "&"))


def _clean_word(w: str, upper: bool) -> str:
    w = w.strip()
    w = w.replace("{", "(").replace("}", ")").replace("\\", "/")
    w = re.sub(r"[,.;:…]+$", "", w)         # keep ? and ! (they carry the tone)
    w = re.sub(r"^[,.;:]+", "", w)
    return w.upper() if upper else w


def make_cards(words: list, max_words: int = 3, max_chars: int = 18) -> list[list]:
    """Group (start, end, text) words into small cards shown one after the other."""
    cards: list[list] = []
    cur: list = []
    for i, (s, e, t) in enumerate(words):
        if not t:
            continue
        if cur:
            prev_s, prev_e, prev_t = cur[-1]
            chars = sum(len(x[2]) + 1 for x in cur) + len(t)
            if (len(cur) >= max_words or s - prev_e > 0.6 or re.search(r"[.!?…]$", prev_t.strip())
                    or chars > max_chars):
                cards.append(cur)
                cur = []
        cur.append((s, e, t))
    if cur:
        cards.append(cur)
    return cards


@dataclass
class SubLook:
    """How the subtitles of a clip look (sizes in pixels of the clip picture)."""
    font: str
    size: int
    outline: int              # outline of the words (0 with a box)
    shadow: int
    color: str
    outline_color: str
    hi: str
    spacing: int
    blur: float
    rot: float
    x: int
    y: int
    box: Optional[int]        # box behind the group: its alpha (0 = opaque), None = no box
    box_pad: int              # room around the words inside the box
    glow: Optional[str]
    glow_bord: int
    glow_blur: int
    pop: bool
    mode: str
    width: int
    height: int
    tsize: int                # title
    toutline: int
    tshadow: int
    tmargin: int
    ty: int


@dataclass
class SubEvent:
    """One state of a subtitle card (or the title), shown from start to end (clip time)."""
    start: float
    end: float
    words: list
    hi: Optional[int] = None          # index of the word being said (coloured)
    hidden_from: Optional[int] = None  # "reveal": the words from this index are not shown yet
    color: Optional[str] = None       # "word": colour of the word
    first: bool = False               # a new card: small pop
    fade: bool = False                # "plain": fades in and out (60 ms)
    title: bool = False

    @property
    def text(self) -> str:
        return " ".join(self.words)


def layout(words: list, clip_start: float, clip_end: float, width: int, height: int,
           uppercase: bool = True, size_pct: int = 100, highlight: str = "#FFE14D",
           position_pct: Optional[int] = None, max_words: int = 3, title: str = "",
           title_y: Optional[int] = None, style: Optional[dict] = None,
           masked: Optional[set] = None) -> tuple[SubLook, list]:
    """The subtitles of a clip: their look and their events (clip time). Shared by the export (ASS file
    burned by ffmpeg) and the Studio live preview (drawn on screen), so both show the same thing."""
    if style is None:
        style = dict(STYLES["classic"], id="classic", hi=highlight, words=max_words, upper=uppercase,
                     size_pct=size_pct, position_pct=position_pct)
    vertical = height > width
    uppercase = bool(style.get("upper", True))
    size_pct = int(style.get("size_pct") or 100)
    max_words = max(1, int(style.get("words") or 3))
    position_pct = style.get("position_pct") if vertical else None
    font = style.get("font") or FONT_NAME
    base = (128 if vertical else 84) * float(style.get("size") or 1.0)
    size = max(24, int(base * size_pct / 100 * (height / (1920 if vertical else 1080))))
    outline = max(2, int(size * float(style.get("ow", 0.09))))
    shadow = int(size * float(style.get("shadow", 0.035)))
    if not position_pct:
        position_pct = 68 if vertical else 84
    y = int(height * int(position_pct) / 100)
    x = width // 2
    max_chars = int((16 if vertical else 30) * float(style.get("chars", 1.0)) * 100 / max(60, size_pct))
    tsize = max(20, int((76 if vertical else 54) * min(1.15, max(0.85, size_pct / 100))
                        * (height / (1920 if vertical else 1080))))
    box = int(style["box"]) if style.get("box") is not None else None
    box_pad = outline if box is not None else 0
    if box is not None:
        outline, shadow = 0, 0
    glow = style.get("glow")
    look = SubLook(font=font, size=size, outline=outline, shadow=shadow, color=style.get("color") or "#FFFFFF",
                   outline_color=style.get("outline") or "#000000", hi=style.get("hi") or highlight,
                   spacing=int(style.get("spacing") or 0), blur=float(style.get("blur") or 0),
                   rot=float(style.get("rot") or 0), x=x, y=y, box=box, box_pad=box_pad, glow=glow,
                   glow_bord=int(outline * 2.2), glow_blur=max(4, int(size * 0.08)), pop=bool(style.get("pop")),
                   mode=style.get("mode") or "highlight", width=width, height=height, tsize=tsize,
                   toutline=max(3, int(tsize * 0.1)), tshadow=max(1, int(tsize * 0.035)),
                   tmargin=int(width * 0.07),
                   ty=int(title_y if title_y is not None else height * (0.12 if vertical else 0.09)))
    masked = masked or set()
    inside = []
    for i, (s, e, t) in enumerate(words):
        if e > clip_start + 0.05 and s < clip_end - 0.05:
            if i in masked:
                t = mask_word(t)
            inside.append((max(s, clip_start), min(e, clip_end), t))
    cleaned = [(s - clip_start, e - clip_start, _clean_word(t, uppercase)) for s, e, t in inside]
    cleaned = [w for w in cleaned if w[2]]
    cards = make_cards(cleaned, max_words=max_words, max_chars=max_chars)
    events: list[SubEvent] = []
    clip_len = clip_end - clip_start
    mode = look.mode
    cycle = style.get("cycle") or []
    word_no = 0
    for ci, card in enumerate(cards):
        next_start = cards[ci + 1][0][0] if ci + 1 < len(cards) else clip_len
        card_end = min(next_start, card[-1][1] + 0.35, clip_len)
        texts = [t for _s, _e, t in card]
        if mode == "plain":
            events.append(SubEvent(card[0][0], card_end, texts, fade=card_end - card[0][0] > 0.3))
            continue
        for wi, (s, e, t) in enumerate(card):
            ev_end = card[wi + 1][0] if wi + 1 < len(card) else card_end
            if mode == "word":
                c = cycle[word_no % len(cycle)] if cycle else None
                word_no += 1
                events.append(SubEvent(s, ev_end, [t], color=c, first=True))
                continue
            events.append(SubEvent(s, ev_end, list(texts), hi=wi, hidden_from=wi + 1 if mode == "reveal" else None,
                                   first=wi == 0))
    events = [ev for ev in events if ev.end - ev.start >= 0.04]
    t = clean_title(title)
    if t:
        events.append(SubEvent(0.0, clip_len, [t], title=True))
    return look, events


def build_ass(words: list, clip_start: float, clip_end: float, width: int, height: int,
              uppercase: bool = True, size_pct: int = 100, highlight: str = "#FFE14D",
              position_pct: Optional[int] = None, max_words: int = 3, title: str = "",
              title_y: Optional[int] = None, style: Optional[dict] = None, masked: Optional[set] = None) -> str:
    """words: [(start, end, text)] in VOD time. Returns the .ass file content (clip time).
    title: shown for the whole clip, centred at height title_y (TikTok-style caption).
    style: a resolved style (resolve_style); without it the classic look with the given options.
    masked: indexes (in `words`) of words to show as "p****" (bleeped swear words)."""
    lk, events = layout(words, clip_start, clip_end, width, height, uppercase, size_pct, highlight, position_pct,
                        max_words, title, title_y, style, masked)
    col = _ass_color(lk.color)
    ocol = _ass_color(lk.outline_color)
    tag_base = _tag_color(lk.color)
    tag_hi = _tag_color(lk.hi)
    box_line = ""
    if lk.box is not None:
        # one box behind the whole group (layer 0, BorderStyle 3 = box in the outline colour), the
        # words drawn on top without outline (a box per word would overlap and look patchy)
        bcol = _ass_color(lk.outline_color, lk.box)
        box_line = (f"Style: Box,{lk.font},{lk.size},&HFF000000,&HFF000000,{bcol},{bcol},0,0,0,0,100,100,{lk.spacing},0,3,"
                    f"{lk.box_pad},0,5,60,60,40,1\n")
    border_style, back = 1, "&H90000000"
    header = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {width}
PlayResY: {height}
WrapStyle: 0
ScaledBorderAndShadow: yes
YCbCr Matrix: TV.709

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Pop,{lk.font},{lk.size},{col},{col},{ocol},{back},0,0,0,0,100,100,{lk.spacing},0,{border_style},{lk.outline},{lk.shadow},5,60,60,40,1
{box_line}Style: Title,{lk.font},{lk.tsize},&H00FFFFFF,&H00FFFFFF,&H00000000,&HA0000000,0,0,0,0,100,100,0,0,1,{lk.toutline},{lk.tshadow},5,{lk.tmargin},{lk.tmargin},40,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    lines = []
    base_tags = f"\\an5\\pos({lk.x},{lk.y})" + (f"\\blur{lk.blur:g}" if lk.blur else "") + \
        (f"\\frz{lk.rot:g}" if lk.rot else "")
    pop_tag = "\\fscx112\\fscy112\\t(0,90,\\fscx100\\fscy100)" if lk.pop else ""
    glow_tags = (f"\\bord{lk.glow_bord}\\blur{lk.glow_blur}\\3c{_tag_color(lk.glow)}\\1a&HFF&\\shad0"
                 if lk.glow else "")
    for ev in events:
        if ev.title:
            lines.append(f"Dialogue: 2,{_ass_time(ev.start)},{_ass_time(ev.end)},Title,,0,0,0,,"
                         f"{{\\an5\\pos({lk.x},{lk.ty})\\fad(150,0)}}{ev.words[0]}")
            continue
        if lk.mode == "plain":
            text_tags, text = ("\\fad(60,60)" if ev.fade else ""), ev.text
        elif lk.mode == "word":
            text_tags, text = (f"\\1c{_tag_color(ev.color)}" if ev.color else ""), ev.words[0]
        else:
            parts = []
            for wj, t2 in enumerate(ev.words):
                if wj == ev.hi:
                    parts.append(f"{{\\1c{tag_hi}}}{t2}{{\\1c{tag_base}}}")
                elif ev.hidden_from is not None and wj >= ev.hidden_from:
                    parts.append(f"{{\\alpha&HFF&}}{t2}{{\\alpha&H00&}}")
                else:
                    parts.append(t2)
            text_tags, text = "", " ".join(parts)
        tags = base_tags + (pop_tag if ev.first else "")
        start, end = _ass_time(ev.start), _ass_time(ev.end)
        if box_line:
            lines.append(f"Dialogue: 0,{start},{end},Box,,0,0,0,,{{{tags}}}{_strip_tags(text)}")
        if lk.glow:
            lines.append(f"Dialogue: 0,{start},{end},Pop,,0,0,0,,{{{tags}{glow_tags}}}{_strip_tags(text)}")
        lines.append(f"Dialogue: 1,{start},{end},Pop,,0,0,0,,{{{tags}{text_tags}}}{text}")
    return header + "\n".join(lines) + "\n"


def _strip_tags(text: str) -> str:
    return re.sub(r"\{[^}]*\}", "", text)


# --------------------------------------------------------------------------- swear words (bleep)

_SWEAR_EXACT = {
    # French
    "putain", "ptn", "merde", "merdes", "bordel", "connard", "connards", "connasse", "connasses", "con",
    "conne", "connes", "salope", "salopes", "salaud", "salauds", "pute", "putes", "fdp", "ntm", "nique", "niquer",
    "niqué", "niquez", "couille", "couilles", "batard", "bâtard", "batards", "bâtards", "enculé",
    "enculés", "enculer", "encule", "pd", "tg", "chiasse", "emmerde", "emmerder", "fils de pute",
    "ta gueule", "ferme ta gueule", "nique ta mère", "ntm",
    # English
    "shit", "shits", "bullshit", "bitch", "bitches", "asshole", "assholes", "dick", "dicks", "cunt", "cunts",
    "bastard", "bastards", "pussy", "wanker", "twat",
}
_SWEAR_PREFIX = ("fuck", "motherfuck", "putain", "enculé", "encule", "connard", "salop")


def _norm_swear(w: str) -> str:
    return re.sub(r"[^\w']", "", (w or "").lower()).strip("'")


def is_swear(word: str) -> bool:
    w = _norm_swear(word)
    if not w:
        return False
    return w in _SWEAR_EXACT or any(w.startswith(p) for p in _SWEAR_PREFIX)


def swear_indexes(words: list) -> set:
    """Indexes of the swear words in a [(start, end, text)] list (also two-word insults)."""
    out = set()
    toks = [_norm_swear(t) for _s, _e, t in words]
    for i, tok in enumerate(toks):
        if is_swear(tok):
            out.add(i)
        if i + 1 < len(toks) and f"{tok} {toks[i + 1]}" in _SWEAR_EXACT:
            out.update((i, i + 1))
        if i + 2 < len(toks) and f"{tok} {toks[i + 1]} {toks[i + 2]}" in _SWEAR_EXACT:
            out.update((i, i + 1, i + 2))
    return out


def mask_word(word: str) -> str:
    """'putain' -> 'p*****' (keeps the punctuation)."""
    m = re.match(r"^(\W*)(\w)(\w*)(.*)$", word.strip())
    if not m:
        return word
    lead, first, rest, tail = m.groups()
    return (" " if word.startswith(" ") else "") + lead + first + "*" * len(rest) + tail


def clean_title(title: str) -> str:
    """A clip title for the burned-in caption (no ASS codes, no surrounding quotes)."""
    t = re.sub("[\U0001F000-\U0001FAFF☀-➿️‍]", "", title or "")   # no emoji in the font
    t = re.sub(r"\s+", " ", t).strip().strip("«»\"' ").strip()
    t = t.replace("{", "(").replace("}", ")").replace("\\", "/")
    return t[:90]


def words_from_transcript(transcript: Optional[dict], a: float, b: float) -> list:
    out = []
    if not transcript:
        return out
    for seg in transcript.get("segments", []):
        if seg["e"] < a - 1 or seg["s"] > b + 1:
            continue
        ws = seg.get("w") or []
        if ws:
            for w in ws:
                text = w[0]
                # Whisper splits "aujourd'hui" / "j'ai" into pieces: glue pieces without a leading
                # space back onto the previous word
                if out and text and not text[0].isspace() and float(w[1]) - out[-1][1] < 0.6:
                    ps, pe, pt = out[-1]
                    out[-1] = (ps, max(pe, float(w[2])), pt + text)
                    continue
                out.append((float(w[1]), float(w[2]), text))
        else:  # no word timings: spread the words evenly over the segment
            toks = (seg.get("t") or "").split()
            if not toks:
                continue
            step = (seg["e"] - seg["s"]) / len(toks)
            for i, tk in enumerate(toks):
                out.append((seg["s"] + i * step, seg["s"] + (i + 1) * step, tk))
    out.sort()
    return out


def _norm_tok(w: str) -> str:
    from .util import strip_accents
    return re.sub(r"[^\w]", "", strip_accents(w.lower()))


def retime(words: list, new_text: str, a: float, b: float) -> list:
    """Put the user's corrected text on the timing of the original words.
    words: [(start, end, text)] of the clip [a, b]; new_text: what the subtitles should say.
    Words that did not change keep their exact timing; changed / added words share the time of
    the words they replace (or of the gap where they were added)."""
    from difflib import SequenceMatcher
    new_words: list[str] = []
    for w in (new_text or "").split():
        if new_words and not re.search(r"\w", w):      # "ARMURE !" -> "ARMURE!" (French spacing)
            new_words[-1] += w
        elif w.strip():
            new_words.append(w)
    if not new_words:
        return []
    orig = [(float(s), float(e), t) for s, e, t in words if e > a and s < b]
    if not orig:
        # nothing was said (or not understood): spread the text over the clip
        step = (b - a) / len(new_words)
        return [(a + i * step, a + (i + 1) * step, " " + w) for i, w in enumerate(new_words)]
    o_tok = [_norm_tok(t) for _s, _e, t in orig]
    n_tok = [_norm_tok(w) for w in new_words]
    out: list = [None] * len(new_words)
    sm = SequenceMatcher(None, o_tok, n_tok, autojunk=False)
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if j2 <= j1:
            continue
        if tag == "equal":
            for k in range(j2 - j1):
                s0, e0, _t = orig[i1 + k]
                out[j1 + k] = (s0, e0, " " + new_words[j1 + k])
            continue
        if i2 > i1:                       # replaced words: same time span
            t0, t1 = orig[i1][0], orig[i2 - 1][1]
        else:                             # added words: in the gap between the neighbours
            t0 = orig[i1 - 1][1] if i1 > 0 else max(a, orig[0][0] - 0.3 * (j2 - j1))
            t1 = orig[i1][0] if i1 < len(orig) else min(b, t0 + 0.3 * (j2 - j1))
            if t1 - t0 < 0.12 * (j2 - j1):
                t1 = t0 + 0.12 * (j2 - j1)
        chars = [max(1, len(new_words[j])) for j in range(j1, j2)]
        tot = float(sum(chars))
        pos = t0
        for n, j in enumerate(range(j1, j2)):
            d = (t1 - t0) * chars[n] / tot
            out[j] = (pos, pos + d, " " + new_words[j])
            pos += d
    res = [w for w in out if w is not None]
    res.sort(key=lambda w: w[0])
    return res
