"""Small helpers shared by the app and the background worker."""
from __future__ import annotations

import json
import logging
import logging.handlers
import math
import os
import re
import subprocess
import sys
import threading
import time
import unicodedata
from collections import deque
from pathlib import Path
from typing import Callable, Iterable, Optional

from . import paths

IS_WINDOWS = sys.platform == "win32"

# --------------------------------------------------------------------------- logging

_log_ready = False


def setup_logging(name: str = "fireclips") -> logging.Logger:
    """Log to logs/<name>.log (rotating) and stderr."""
    global _log_ready
    logger = logging.getLogger("fireclips")
    if _log_ready:
        return logger
    _log_ready = True
    logger.setLevel(logging.INFO)
    fmt = logging.Formatter("%(asctime)s %(levelname)s [%(name)s] %(message)s")
    try:
        paths.LOGS.mkdir(parents=True, exist_ok=True)
        fh = logging.handlers.RotatingFileHandler(paths.LOGS / f"{name}.log", maxBytes=2_000_000,
                                                  backupCount=3, encoding="utf-8")
        fh.setFormatter(fmt)
        logger.addHandler(fh)
    except OSError:
        pass
    if sys.stderr is not None:
        sh = logging.StreamHandler(sys.stderr)
        sh.setFormatter(fmt)
        sh.setLevel(logging.WARNING)
        logger.addHandler(sh)
    return logger


log = logging.getLogger("fireclips.util")

# --------------------------------------------------------------------------- processes


def no_window_flags() -> int:
    """creationflags that stop a black console window from flashing on Windows."""
    if IS_WINDOWS:
        return getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
    return 0


def run(cmd: list, timeout: Optional[float] = None, cwd=None, env=None, check=False) -> subprocess.CompletedProcess:
    """Run a command quietly and capture its output as text."""
    res = subprocess.run([str(c) for c in cmd], stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                         stderr=subprocess.PIPE, timeout=timeout, cwd=cwd, env=env,
                         creationflags=no_window_flags())
    out = res.stdout.decode("utf-8", "replace")
    err = res.stderr.decode("utf-8", "replace")
    cp = subprocess.CompletedProcess(res.args, res.returncode, out, err)
    if check and res.returncode != 0:
        raise subprocess.CalledProcessError(res.returncode, res.args, out, err)
    return cp


def popen(cmd: list, **kw) -> subprocess.Popen:
    kw.setdefault("stdin", subprocess.DEVNULL)
    kw.setdefault("creationflags", no_window_flags())
    return subprocess.Popen([str(c) for c in cmd], **kw)


class Cancelled(Exception):
    """Raised when the user cancels a job."""


def run_streaming(cmd: list, on_line: Optional[Callable[[str], None]] = None, cwd=None, env=None,
                  cancel: Optional[threading.Event] = None, tail: int = 60) -> tuple[int, list[str]]:
    """Run a command, calling on_line for every output line (splitting on \\r and \\n so that
    progress lines that overwrite themselves are seen too). Returns (exit code, last lines)."""
    proc = popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, cwd=cwd, env=env)
    last: deque[str] = deque(maxlen=tail)
    buf = b""
    try:
        assert proc.stdout is not None
        while True:
            if cancel is not None and cancel.is_set():
                kill_tree(proc.pid)
                raise Cancelled()
            chunk = proc.stdout.read1(65536) if hasattr(proc.stdout, "read1") else proc.stdout.read(4096)
            if not chunk:
                break
            buf += chunk
            parts = re.split(rb"[\r\n]", buf)
            buf = parts.pop()
            for p in parts:
                line = p.decode("utf-8", "replace").strip()
                if line:
                    last.append(line)
                    if on_line:
                        on_line(line)
        if buf.strip():
            line = buf.decode("utf-8", "replace").strip()
            last.append(line)
            if on_line:
                on_line(line)
        code = proc.wait()
    except BaseException:
        try:
            kill_tree(proc.pid)
        except Exception:
            pass
        raise
    return code, list(last)


def kill_tree(pid: int) -> None:
    """Kill a process and all its children (Windows does not do this by itself)."""
    try:
        import psutil
        parent = psutil.Process(pid)
        procs = parent.children(recursive=True) + [parent]
        for p in procs:
            try:
                p.kill()
            except Exception:
                pass
        psutil.wait_procs(procs, timeout=5)
    except Exception:
        if IS_WINDOWS:
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)], stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL, creationflags=no_window_flags())
        else:
            try:
                os.kill(pid, 9)
            except OSError:
                pass


def pid_alive(pid: int) -> bool:
    try:
        import psutil
        return psutil.pid_exists(pid) and psutil.Process(pid).status() != "zombie"
    except Exception:
        return False


# --------------------------------------------------------------------------- time formats


def fmt_time(sec: float, decimals: int = 0) -> str:
    """3725.4 -> '1:02:05' (or '1:02:05.4' with decimals=1); 65 -> '1:05'."""
    if sec is None or (isinstance(sec, float) and math.isnan(sec)):
        return "--:--"
    neg = sec < 0
    sec = abs(sec)
    if decimals:
        total = round(sec, decimals)
        whole = int(total)
        frac = total - whole
    else:
        whole = int(round(sec))
        frac = 0.0
    if whole == 0 and round(frac, decimals) == 0:
        neg = False                    # no "-0:00.0"
    h, rem = divmod(whole, 3600)
    m, s = divmod(rem, 60)
    out = f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"
    if decimals:
        out += f"{frac:.{decimals}f}"[1:]
    return ("-" if neg else "") + out


def fmt_hms(sec: float) -> str:
    """Always H:MM:SS (used in prompts so the AI sees one consistent format)."""
    whole = int(max(0, sec))
    h, rem = divmod(whole, 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}"


def fmt_tag(sec: float) -> str:
    """3725 -> '1h02m05s' (for file names)."""
    whole = int(max(0, sec))
    h, rem = divmod(whole, 3600)
    m, s = divmod(rem, 60)
    return f"{h}h{m:02d}m{s:02d}s"


def fmt_duration(sec: float) -> str:
    sec = int(round(max(0, sec)))
    h, rem = divmod(sec, 3600)
    m, s = divmod(rem, 60)
    if h:
        return f"{h} h {m:02d}"
    if m:
        return f"{m} min {s:02d}"
    return f"{s} s"


_UNIT_RE = re.compile(r"^(?:(\d+(?:\.\d+)?)h)?(?:(\d+(?:\.\d+)?)m(?!s))?(?:(\d+(?:\.\d+)?)s)?$")


def parse_time(text) -> Optional[float]:
    """Parse '1:02:05', '62:05', '1:02:05.5', '3725', '1h2m5s', '2m', '45s'. None if invalid."""
    if text is None:
        return None
    if isinstance(text, (int, float)):
        return float(text)
    t = str(text).strip().lower().replace(",", ".")
    if not t:
        return None
    try:
        if ":" in t:
            parts = [float(p) for p in t.split(":")]
            if len(parts) > 3 or any(p < 0 for p in parts):
                return None
            val = 0.0
            for p in parts:
                val = val * 60 + p
            return val
        if re.fullmatch(r"\d+(\.\d+)?", t):
            return float(t)
        m = _UNIT_RE.match(t.replace(" ", ""))
        if m and any(m.groups()):
            h, mi, s = (float(g) if g else 0.0 for g in m.groups())
            return h * 3600 + mi * 60 + s
    except ValueError:
        return None
    return None


# --------------------------------------------------------------------------- files


def read_json(path: Path, default=None):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def write_json(path: Path, data, indent: Optional[int] = 1) -> None:
    """Atomic JSON write (never leaves a half-written file if the PC crashes)."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=indent, default=_json_default)
        f.flush()
        try:
            os.fsync(f.fileno())
        except OSError:
            pass
    for attempt in range(10):
        try:
            os.replace(tmp, path)
            return
        except PermissionError:  # file briefly locked (antivirus, other reader) on Windows
            time.sleep(0.2 * (attempt + 1))
    os.replace(tmp, path)


def _json_default(o):
    try:
        import numpy as np
        if isinstance(o, np.integer):
            return int(o)
        if isinstance(o, np.floating):
            return float(o)
        if isinstance(o, np.ndarray):
            return o.tolist()
    except ImportError:
        pass
    if isinstance(o, Path):
        return str(o)
    raise TypeError(f"not JSON serializable: {type(o)}")


_ILLEGAL = re.compile(r'[<>:"/\\|?*\x00-\x1f]')
_EMOJI = re.compile("[\U0001F000-\U0001FAFF\U00002600-\U000027BF\U0001F900-\U0001F9FF️‍]")


def sanitize_filename(name: str, maxlen: int = 80) -> str:
    """Make a string safe to use as a Windows file name (keeps accents)."""
    s = _EMOJI.sub("", name or "")
    s = _ILLEGAL.sub(" ", s)
    s = re.sub(r"\s+", " ", s).strip(" .")
    if len(s) > maxlen:
        s = s[:maxlen].rsplit(" ", 1)[0] if " " in s[:maxlen] else s[:maxlen]
        s = s.strip(" .")
    reserved = {"CON", "PRN", "AUX", "NUL"} | {f"COM{i}" for i in range(1, 10)} | {f"LPT{i}" for i in range(1, 10)}
    if s.upper() in reserved:
        s = "_" + s
    return s or "clip"


def unique_path(path: Path) -> Path:
    if not path.exists():
        return path
    stem, suf = path.stem, path.suffix
    for i in range(2, 1000):
        p = path.with_name(f"{stem} ({i}){suf}")
        if not p.exists():
            return p
    return path


def human_size(n: float) -> str:
    for unit in ("o", "Ko", "Mo", "Go", "To"):
        if abs(n) < 1024 or unit == "To":
            return f"{n:.0f} {unit}" if unit in ("o", "Ko") else f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} To"


def dir_size(path: Path) -> int:
    total = 0
    for root, _dirs, files in os.walk(path):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(root, f))
            except OSError:
                pass
    return total


def free_space(path: Path) -> int:
    import shutil
    p = Path(path)
    while not p.exists() and p.parent != p:
        p = p.parent
    try:
        return shutil.disk_usage(p).free
    except OSError:
        return 0


def strip_accents(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")


def open_in_explorer(path: Path) -> None:
    path = Path(path)
    if IS_WINDOWS:
        if path.is_file():
            subprocess.Popen(["explorer", "/select,", str(path)])
        else:
            os.startfile(str(path))  # type: ignore[attr-defined]
    else:
        subprocess.Popen(["xdg-open", str(path if path.is_dir() else path.parent)],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def chunked(seq: list, n: int) -> Iterable[list]:
    for i in range(0, len(seq), n):
        yield seq[i:i + n]
