"""The "Kills Albion" tab: the kills / assists / deaths of the linked Albion player(s) during the
selected VOD, each one an adjustable clip like the AI moments, with a killboard card (gear,
fame, participants). Also the background collector that writes down the kills while the app
is open (the Albion API only keeps the 10 latest of each player)."""
from __future__ import annotations

import logging
import time
from datetime import datetime
from typing import Callable, Optional

from PySide6.QtCore import (QAbstractTableModel, QModelIndex, QObject, QRunnable, QSortFilterProxyModel, Qt,
                            QThreadPool, QTimer, QUrl, Signal)
from PySide6.QtGui import QDesktopServices, QPixmap
from PySide6.QtWidgets import (QAbstractItemView, QCheckBox, QFrame, QGridLayout, QHBoxLayout, QHeaderView, QLabel,
                               QPushButton, QScrollArea, QSpinBox, QSplitter, QStackedWidget, QTableView,
                               QToolButton, QVBoxLayout, QWidget)

from .. import albion
from ..i18n import language, tr
from ..util import fmt_time
from . import theme
from .widgets import ElidedLabel

log = logging.getLogger("fireclips.albion_ui")

SORT_ROLE = Qt.UserRole + 1
COLS = ["kcol_check", "kcol_time", "kcol_type", "kcol_vs", "kcol_fame", "kcol_ip", "kcol_len"]
ROLE_ICON = {"kill": "⚔", "assist": "🤝", "death": "💀", "mixed": "⚔"}


# --------------------------------------------------------------------------- background work

class _Bridge(QObject):
    done = Signal(object, object)          # tag, result


class _Task(QRunnable):
    def __init__(self, fn, tag, bridge: _Bridge):
        super().__init__()
        self.fn, self.tag, self.bridge = fn, tag, bridge

    def run(self) -> None:
        try:
            res = self.fn()
        except Exception as e:  # noqa: BLE001
            res = e
        try:
            self.bridge.done.emit(self.tag, res)
        except RuntimeError:     # window already closed
            pass


class AlbionCollector(QObject):
    """Every 2 minutes (90 s when live), writes down the 10 latest kills and deaths of each linked
    player. With FireClips open during the stream, no kill is missed."""
    status = Signal(str)

    def __init__(self, cfg, parent=None):
        super().__init__(parent)
        self.cfg = cfg
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.poll_now)
        self.bridge = _Bridge()
        self.bridge.done.connect(self._done)
        self.busy = False
        self.live: Optional[bool] = None
        self.last_ok = 0.0
        self.last_new = 0.0
        self.total_new = 0
        self.failures = 0
        self.pool = QThreadPool(self)
        self.pool.setMaxThreadCount(1)

    def links(self) -> list:
        return albion.clean_links(self.cfg.get("albion_links"))

    def apply(self) -> None:
        if self.cfg.get("albion_collect") and self.links():
            self._schedule()
            QTimer.singleShot(4000, self.poll_now)
            self.status.emit(tr("alb_collect_on"))
        else:
            self.timer.stop()
            self.status.emit(tr("alb_collect_off") if self.links() else "")

    def set_live(self, live: Optional[bool]) -> None:
        if live != self.live:
            self.live = live
            if self.timer.isActive():
                self._schedule()
                if live:
                    QTimer.singleShot(1000, self.poll_now)

    def _schedule(self) -> None:
        if self.failures >= 3:
            sec = 600
        elif self.live:
            sec = 90
        elif self.live is False and time.time() - self.last_new > 3600:
            sec = 300
        else:
            sec = 120
        self.timer.start(sec * 1000)

    def poll_now(self) -> None:
        if self.busy or not self.cfg.get("albion_collect"):
            return
        links = self.links()
        if not links:
            return
        self.busy = True
        root = albion.data_root(self.cfg)

        def work():
            new, errors = 0, []
            for link in links:
                try:
                    new += albion.poll_latest(root, link)
                except Exception as e:  # noqa: BLE001
                    errors.append(f"{link['player']}: {getattr(e, 'detail', '') or e}")
            return new, errors
        self.pool.start(_Task(work, "poll", self.bridge))

    def _done(self, _tag, res) -> None:
        self.busy = False
        if isinstance(res, Exception):
            res = (0, [str(res)])
        new, errors = res
        now = time.time()
        if errors and not new:
            self.failures += 1
            log.info("albion collector: %s", "; ".join(errors)[:500])
        else:
            self.failures = 0
            self.last_ok = now
        if new:
            self.last_new = now
            self.total_new += new
        self._schedule()
        when = datetime.now().strftime("%H:%M")
        if self.failures:
            self.status.emit(tr("alb_collect_fail", time=when))
        else:
            self.status.emit(tr("alb_collect_ok", time=when, n=self.total_new))


class IconCache(QObject):
    """Item pictures from render.albiononline.com, downloaded once and kept on disk."""
    ready = Signal(str)

    def __init__(self, root_getter: Callable, parent=None):
        super().__init__(parent)
        self.root_getter = root_getter
        self._pix: dict[str, QPixmap] = {}
        self._pending: set = set()
        self.bridge = _Bridge()
        self.bridge.done.connect(self._loaded)
        self.pool = QThreadPool(self)
        self.pool.setMaxThreadCount(4)

    @staticmethod
    def key(type_code: str, quality: int) -> str:
        return f"{type_code}|{int(quality or 1)}"

    def get(self, type_code: str, quality: int, size: int) -> Optional[QPixmap]:
        k = self.key(type_code, quality)
        pm = self._pix.get(k)
        if pm is None:
            f = albion.icon_file(self.root_getter(), type_code, quality, 64)
            if f.exists() and f.stat().st_size > 0:
                pm = QPixmap(str(f))
                if not pm.isNull():
                    self._pix[k] = pm
            if pm is None or pm.isNull():
                if k not in self._pending:
                    self._pending.add(k)
                    root = self.root_getter()
                    self.pool.start(_Task(lambda: albion.fetch_icon(root, type_code, quality, 64), k, self.bridge))
                return None
        return pm.scaled(size, size, Qt.KeepAspectRatio, Qt.SmoothTransformation)

    def _loaded(self, k, res) -> None:
        self._pending.discard(k)
        if res and not isinstance(res, Exception):
            pm = QPixmap(str(res))
            if not pm.isNull():
                self._pix[k] = pm
                self.ready.emit(k)


# --------------------------------------------------------------------------- table

class KillsModel(QAbstractTableModel):
    checked_changed = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.items: list[dict] = []

    def set_items(self, items: list[dict]) -> None:
        self.beginResetModel()
        self.items = items
        self.endResetModel()
        self.checked_changed.emit()

    def rowCount(self, parent=QModelIndex()) -> int:  # noqa: N802
        return 0 if parent.isValid() else len(self.items)

    def columnCount(self, parent=QModelIndex()) -> int:  # noqa: N802
        return len(COLS)

    def headerData(self, section, orientation, role=Qt.DisplayRole):  # noqa: N802
        if orientation == Qt.Horizontal and role == Qt.DisplayRole:
            return tr(COLS[section])
        if orientation == Qt.Horizontal and role == Qt.ToolTipRole:
            return tr(COLS[section] + "_tip")
        return None

    def flags(self, idx):
        f = Qt.ItemIsEnabled | Qt.ItemIsSelectable
        if idx.column() == 0:
            f |= Qt.ItemIsUserCheckable
        return f

    @staticmethod
    def type_text(k: dict) -> str:
        n = k.get("n_kills", 0) + k.get("n_assists", 0)
        if k.get("kind") == "death":
            return "💀 " + (tr("ktype_death") if k.get("n_deaths", 1) == 1 else f"×{k['n_deaths']}")
        if n > 1 or k.get("kind") == "mixed":
            s = f"⚔ ×{n}"
            return s + (" 💀" if k.get("n_deaths") else "")
        return ROLE_ICON.get(k.get("kind"), "⚔") + " " + tr("ktype_" + (k.get("kind") or "kill"))

    def data(self, idx, role=Qt.DisplayRole):
        if not idx.isValid():
            return None
        k = self.items[idx.row()]
        c = idx.column()
        if role == Qt.CheckStateRole and c == 0:
            return Qt.Checked if k.get("checked") else Qt.Unchecked
        if role == SORT_ROLE:
            return [int(bool(k.get("checked"))), k.get("peak", 0), k.get("kind", ""), (k.get("opponent") or "").lower(),
                    k.get("fame", 0), k.get("ip", 0), k["end"] - k["start"]][c]
        if role == Qt.DisplayRole:
            if c == 1:
                return fmt_time(k.get("peak", k["start"]))
            if c == 2:
                return self.type_text(k)
            if c == 3:
                names = [r.get("name", "") for r in k.get("reasons", []) if r.get("kind") == "albion_event"]
                uniq = []
                for n in names:
                    if n not in uniq:
                        uniq.append(n)
                txt = ", ".join(uniq[:2]) + ("…" if len(uniq) > 2 else "")
                guild = next((r.get("guild") for r in k.get("reasons", []) if r.get("guild")), "")
                done = " ✅" if k.get("exported") else ""
                mont = " 🎬" if isinstance(k.get("montage"), dict) else ""
                return txt + (f"  [{guild}]" if guild and len(uniq) == 1 else "") + mont + done
            if c == 4:
                return albion.fmt_fame(k.get("fame", 0), language())
            if c == 5:
                mine, theirs = k.get("my_ip") or 0, k.get("ip") or 0
                return f"{mine} / {theirs}" if mine and theirs else (str(theirs or mine or ""))
            if c == 6:
                return fmt_time(k["end"] - k["start"])
        if role == Qt.ToolTipRole:
            from ..scoring import reason_label
            lines = [f"<b>{k.get('title') or ''}</b>"] + ["• " + reason_label(r, tr) for r in k.get("reasons", [])]
            if k.get("ignored"):
                lines.append("<i>" + tr("k_ignored_tip") + "</i>")
            return "<br>".join(lines)
        if role == Qt.ForegroundRole:
            if k.get("ignored") or k.get("decision") == "reject":
                from PySide6.QtGui import QColor
                return QColor(theme.MUTED)
            if c == 4:
                from PySide6.QtGui import QColor
                return QColor(theme.ACCENT_2 if k.get("kind") != "death" else theme.BAD)
        if role == Qt.FontRole and c == 4:
            from PySide6.QtGui import QFont
            f = QFont()
            f.setBold(True)
            return f
        if role == Qt.TextAlignmentRole and c in (1, 4, 5, 6):
            return int(Qt.AlignCenter)
        return None

    def setData(self, idx, value, role=Qt.EditRole) -> bool:  # noqa: N802
        if not idx.isValid():
            return False
        k = self.items[idx.row()]
        if role == Qt.CheckStateRole and idx.column() == 0:
            k["checked"] = (value == Qt.Checked or value == Qt.Checked.value or value == 2)
            self.dataChanged.emit(idx, idx)
            self.checked_changed.emit()
            return True
        return False

    def checked(self) -> list[dict]:
        return [k for k in self.items if k.get("checked")]

    def set_all_checked(self, value: bool, visible: Optional[Callable] = None) -> None:
        for k in self.items:
            if visible is None or visible(k):
                k["checked"] = value
        if self.items:
            self.dataChanged.emit(self.index(0, 0), self.index(len(self.items) - 1, 0))
        self.checked_changed.emit()

    def row_of(self, kid: str) -> int:
        for i, k in enumerate(self.items):
            if k["id"] == kid:
                return i
        return -1

    def refresh_row(self, row: int) -> None:
        if 0 <= row < len(self.items):
            self.dataChanged.emit(self.index(row, 0), self.index(row, len(COLS) - 1))


class KillsProxy(QSortFilterProxyModel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setSortRole(SORT_ROLE)
        self.show_ignored = False

    def set_show_ignored(self, on: bool) -> None:
        self.show_ignored = on
        self.invalidateFilter()

    def filterAcceptsRow(self, row, parent) -> bool:  # noqa: N802
        m = self.sourceModel()
        if m is None or row >= len(m.items):
            return False
        return self.show_ignored or not m.items[row].get("ignored")

    def lessThan(self, a, b) -> bool:  # noqa: N802
        va, vb = a.data(SORT_ROLE), b.data(SORT_ROLE)
        try:
            return va < vb
        except TypeError:
            return str(va) < str(vb)


# --------------------------------------------------------------------------- killboard card

class EventCard(QFrame):
    """One kill / death like on a killboard: both players with their gear, fame, damage."""

    def __init__(self, e: dict, icons: IconCache, vod_start: Optional[float], parent=None):
        super().__init__(parent)
        self.setObjectName("KillCard")
        self.icons = icons
        self._labels: dict[str, list] = {}
        icons.ready.connect(self._icon_ready)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(12, 10, 12, 10)
        lay.setSpacing(6)
        role = e.get("role", "kill")
        killer, victim = e.get("killer") or {}, e.get("victim") or {}
        lang = language()
        color = theme.GOOD if role == "kill" else (theme.ACCENT_2 if role == "assist" else theme.BAD)

        def who(p):
            g = f" <span style='color:{theme.MUTED}'>[{p.get('guild')}]</span>" if p.get("guild") else ""
            return f"<b>{p.get('name', '?')}</b>{g}"
        verb = tr({"kill": "kc_killed", "assist": "kc_assist", "death": "kc_killed"}.get(role, "kc_killed"))
        head = QLabel(f"<span style='color:{color}; font-size:11pt'>{ROLE_ICON.get(role, '⚔')}</span> "
                      f"{who(killer)} <span style='color:{theme.MUTED}'>{verb}</span> {who(victim)}"
                      f"<span style='color:{theme.ACCENT_2}; font-weight:700'>&nbsp;&nbsp;"
                      f"{albion.fmt_fame(e.get('fame', 0), lang)} fame</span>")
        head.setTextFormat(Qt.RichText)
        head.setWordWrap(True)
        lay.addWidget(head)
        when = []
        if e.get("off") is not None:
            when.append(tr("kc_at", t=fmt_time(e["off"])))
        try:
            when.append(datetime.fromtimestamp(float(e["t"])).strftime("%H:%M:%S"))
        except (KeyError, ValueError, OSError, TypeError):
            pass
        if e.get("n_part"):
            when.append(tr("kc_parts", n=e["n_part"]))
        area = {"OPEN_WORLD": tr("kc_open_world")}.get(e.get("area"), (e.get("area") or "").replace("_", " ").title())
        if area:
            when.append(area)
        sub = QLabel(" · ".join(when))
        sub.setObjectName("Muted")
        sub.setStyleSheet("font-size: 8.5pt;")
        lay.addWidget(sub)
        grid = QGridLayout()
        grid.setHorizontalSpacing(4)
        grid.setVerticalSpacing(4)
        for row, (p, side) in enumerate(((killer, "killer"), (victim, "victim"))):
            name = QLabel(f"<b>{p.get('name', '?')}</b><br><span style='color:{theme.MUTED}; font-size:8pt'>"
                          f"IP {p.get('ip', 0)}</span>")
            name.setTextFormat(Qt.RichText)
            name.setMinimumWidth(110)
            grid.addWidget(name, row, 0)
            for col, slot in enumerate(albion.GEAR_SLOTS, 1):
                it = (p.get("eq") or {}).get(slot)
                lbl = QLabel()
                lbl.setFixedSize(42, 42)
                lbl.setAlignment(Qt.AlignCenter)
                lbl.setStyleSheet(f"background: {theme.PANEL_2}; border: 1px solid {theme.BORDER}; border-radius: 6px;")
                if it:
                    lbl.setToolTip(f"{albion.pretty_item(it[0])}\n{it[0]}  (q{it[1]})")
                    pm = icons.get(it[0], it[1], 40)
                    if pm is not None:
                        lbl.setPixmap(pm)
                    else:
                        lbl.setText("…")
                        self._labels.setdefault(IconCache.key(it[0], it[1]), []).append(lbl)
                grid.addWidget(lbl, row, col)
        grid.setColumnStretch(len(albion.GEAR_SLOTS) + 1, 1)
        lay.addLayout(grid)
        parts = sorted(e.get("participants") or [], key=lambda p: -(p.get("dmg", 0) + p.get("heal", 0)))
        if len(parts) > 1 or (parts and role == "assist"):
            def num(n):
                return f"{int(n):,}".replace(",", " ")
            txt = " · ".join(f"{p.get('name')} {num(p.get('dmg', 0))}"
                             + (" " + tr("kc_heal", n=num(p["heal"])) if p.get("heal") else "")
                             for p in parts[:6])
            pl = QLabel(tr("kc_damage") + " " + txt)
            pl.setWordWrap(True)
            pl.setStyleSheet("font-size: 8.5pt;")
            lay.addWidget(pl)
        inv = [x for x in (victim.get("inv") or []) if x]
        bottom = QHBoxLayout()
        if inv:
            loot = QLabel(tr("kc_loot", n=len(inv)))
            loot.setObjectName("Muted")
            loot.setStyleSheet("font-size: 8.5pt;")
            bottom.addWidget(loot)
        bottom.addStretch(1)
        url = albion.killboard_url(e.get("region") or "europe", e.get("id"))
        if url:
            link = QLabel(f"<a href='{url}' style='color:{theme.ACCENT_2}'>{tr('kc_open_kb')} ↗</a>")
            link.setTextFormat(Qt.RichText)
            link.setOpenExternalLinks(False)
            link.linkActivated.connect(lambda u: QDesktopServices.openUrl(QUrl(u)))
            bottom.addWidget(link)
        lay.addLayout(bottom)

    def _icon_ready(self, key: str) -> None:
        for lbl in self._labels.pop(key, []):
            try:
                t, q = key.split("|")
                pm = self.icons.get(t, int(q), 40)
                if pm is not None:
                    lbl.setText("")
                    lbl.setPixmap(pm)
            except (RuntimeError, ValueError):   # the card was closed meanwhile
                pass


class KillDetails(QScrollArea):
    """The events of the selected clip (a fight can contain several kills)."""

    def __init__(self, icons: IconCache, parent=None):
        super().__init__(parent)
        self.icons = icons
        self.setWidgetResizable(True)
        self.setFrameShape(QFrame.NoFrame)
        self.setMinimumHeight(150)
        self._empty()

    def _empty(self, text: str = "") -> None:
        w = QLabel(text or tr("kc_pick"))
        w.setObjectName("Muted")
        w.setAlignment(Qt.AlignCenter)
        w.setWordWrap(True)
        self.setWidget(w)

    def show_clip(self, clip: Optional[dict], events_by_id: dict, vod_start: Optional[float]) -> None:
        if not clip:
            self._empty()
            return
        box = QWidget()
        v = QVBoxLayout(box)
        v.setContentsMargins(0, 0, 4, 0)
        v.setSpacing(8)
        for eid in clip.get("events") or []:
            e = events_by_id.get(eid)
            if e is not None:
                v.addWidget(EventCard(e, self.icons, vod_start))
        v.addStretch(1)
        self.setWidget(box)


# --------------------------------------------------------------------------- the tab

class AlbionPanel(QWidget):
    selection_changed = Signal(object)        # the selected clip (dict) or None
    checked_changed = Signal()
    filters_changed = Signal()                # types / threshold changed: re-rank
    offset_changed = Signal(float)            # timing correction for this VOD
    refresh_requested = Signal()
    settings_requested = Signal()
    play_requested = Signal()

    def __init__(self, cfg, icons: IconCache, parent=None):
        super().__init__(parent)
        self.cfg = cfg
        self.icons = icons
        self.events_by_id: dict = {}
        self.vod_start: Optional[float] = None
        self._block = False
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 6, 0, 0)
        lay.setSpacing(6)

        top = QHBoxLayout()
        self.who = QLabel("")
        self.who.setTextFormat(Qt.RichText)
        top.addWidget(self.who, 1)
        self.btn_refresh = QPushButton(tr("alb_refresh"))
        self.btn_refresh.setToolTip(tr("alb_refresh_tip"))
        self.btn_refresh.clicked.connect(self.refresh_requested)
        top.addWidget(self.btn_refresh)
        b = QToolButton()
        b.setText("⚙")
        b.setToolTip(tr("alb_settings_tip"))
        b.clicked.connect(self.settings_requested)
        top.addWidget(b)
        lay.addLayout(top)

        row = QHBoxLayout()
        row.setSpacing(10)
        types = set(cfg.get("albion_types") or [])
        self.chk = {}
        for t, label in (("kill", "⚔ " + tr("ktypes_kill")), ("assist", "🤝 " + tr("ktypes_assist")),
                         ("death", "💀 " + tr("ktypes_death"))):
            c = QCheckBox(label)
            c.setChecked(t in types)
            c.setToolTip(tr("ktypes_" + t + "_tip"))
            c.toggled.connect(self._filters_edited)
            self.chk[t] = c
            row.addWidget(c)
        row.addSpacing(8)
        row.addWidget(QLabel(tr("alb_min_fame")))
        self.min_fame = QSpinBox()
        self.min_fame.setRange(0, 1_000_000_000)
        self.min_fame.setSingleStep(25_000)
        self.min_fame.setGroupSeparatorShown(True)
        self.min_fame.setValue(int(cfg.get("albion_min_fame") or 0))
        self.min_fame.setToolTip(tr("alb_min_fame_tip"))
        self.min_fame.setKeyboardTracking(False)
        self.min_fame.valueChanged.connect(self._filters_edited)
        row.addWidget(self.min_fame)
        self.show_ignored = QCheckBox(tr("alb_show_ignored"))
        self.show_ignored.setToolTip(tr("alb_show_ignored_tip"))
        self.show_ignored.setChecked(bool(cfg.get("albion_show_ignored")))
        self.show_ignored.toggled.connect(self._show_ignored)
        row.addWidget(self.show_ignored)
        row.addStretch(1)
        lay.addLayout(row)

        row2 = QHBoxLayout()
        row2.addWidget(QLabel(tr("alb_shift")))
        self.shift = QSpinBox()
        self.shift.setRange(-600, 600)
        self.shift.setSuffix(" s")
        self.shift.setToolTip(tr("alb_shift_tip"))
        self.shift.setKeyboardTracking(False)
        self.shift.valueChanged.connect(lambda v: not self._block and self.offset_changed.emit(float(v)))
        row2.addWidget(self.shift)
        hint = ElidedLabel(tr("alb_shift_hint"))
        hint.setObjectName("Muted")
        hint.setStyleSheet("font-size: 8.5pt;")
        row2.addWidget(hint, 1)
        b1 = QPushButton(tr("btn_check_all"))
        b1.setObjectName("Flat")
        b1.clicked.connect(lambda: self.model.set_all_checked(True, self._visible))
        b2 = QPushButton(tr("btn_check_none"))
        b2.setObjectName("Flat")
        b2.clicked.connect(lambda: self.model.set_all_checked(False))
        row2.addWidget(b1)
        row2.addWidget(b2)
        lay.addLayout(row2)
        self._filter_timer = QTimer(self)
        self._filter_timer.setSingleShot(True)
        self._filter_timer.setInterval(500)
        self._filter_timer.timeout.connect(self.filters_changed)

        self.stack = QStackedWidget()
        lay.addWidget(self.stack, 1)
        # page 0: message
        msg = QFrame()
        msg.setObjectName("Panel")
        mv = QVBoxLayout(msg)
        mv.setContentsMargins(30, 30, 30, 30)
        mv.addStretch(1)
        self.msg = QLabel("")
        self.msg.setWordWrap(True)
        self.msg.setAlignment(Qt.AlignCenter)
        self.msg.setTextFormat(Qt.RichText)
        mv.addWidget(self.msg)
        r = QHBoxLayout()
        r.addStretch(1)
        self.msg_btn = QPushButton("")
        self.msg_btn.setObjectName("Primary")
        self.msg_btn.clicked.connect(self._msg_action)
        r.addWidget(self.msg_btn)
        r.addStretch(1)
        mv.addLayout(r)
        mv.addStretch(2)
        self.stack.addWidget(msg)
        self._msg_kind = ""
        # page 1: table + card
        split = QSplitter(Qt.Vertical)
        split.setChildrenCollapsible(False)
        self.model = KillsModel(self)
        self.model.checked_changed.connect(self.checked_changed)
        self.proxy = KillsProxy(self)
        self.proxy.setSourceModel(self.model)
        self.proxy.set_show_ignored(self.show_ignored.isChecked())
        self.table = QTableView()
        self.table.setModel(self.proxy)
        self.table.setSortingEnabled(True)
        self.table.sortByColumn(1, Qt.AscendingOrder)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setAlternatingRowColors(True)
        self.table.verticalHeader().hide()
        self.table.verticalHeader().setDefaultSectionSize(32)
        self.table.setShowGrid(False)
        self.table.setWordWrap(False)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        hh = self.table.horizontalHeader()
        for col, mode, w in ((0, QHeaderView.Fixed, 34), (1, QHeaderView.Fixed, 70), (2, QHeaderView.Fixed, 96),
                             (3, QHeaderView.Stretch, 0), (4, QHeaderView.Fixed, 84), (5, QHeaderView.Fixed, 96),
                             (6, QHeaderView.Fixed, 62)):
            hh.setSectionResizeMode(col, mode)
            if w:
                hh.resizeSection(col, w)
        self.table.selectionModel().currentRowChanged.connect(self._on_row)
        self.table.doubleClicked.connect(lambda _i: self.play_requested.emit())
        split.addWidget(self.table)
        self.details = KillDetails(icons)
        split.addWidget(self.details)
        split.setSizes([300, 260])
        self.stack.addWidget(split)

        self.foot = QLabel("")
        self.foot.setObjectName("Muted")
        self.foot.setStyleSheet("font-size: 8.5pt;")
        self.foot.setWordWrap(True)
        lay.addWidget(self.foot)
        self.collector_text = ""

    # ------------------------------------------------------------------ data
    def _visible(self, k: dict) -> bool:
        return self.show_ignored.isChecked() or not k.get("ignored")

    def visible_count(self) -> int:
        return sum(1 for k in self.model.items if not k.get("ignored"))

    def current(self) -> Optional[dict]:
        idx = self.table.currentIndex()
        if not idx.isValid() or self.stack.currentIndex() != 1:
            return None
        row = self.proxy.mapToSource(idx).row()
        return self.model.items[row] if 0 <= row < len(self.model.items) else None

    def set_vod(self, ref, doc: Optional[dict], items: list, links: list, albion_doc: Optional[dict],
                shift: float, running: bool = False) -> None:
        self.events_by_id = {}
        self.vod_start = None
        if albion_doc:
            self.vod_start = albion_doc.get("vod_start")
            offset = albion.vod_offset(self.cfg, {"offset": shift})
            dur = float((doc or {}).get("duration") or (ref.meta.get("duration") if ref else 0) or 0)
            for e in albion.map_events(albion_doc, offset, dur):
                self.events_by_id[e["id"]] = e
        self._block = True
        self.shift.setValue(int(round(shift)))
        self._block = False
        if links:
            parts = [f"<b>{l['player']}</b> <span style='color:{theme.MUTED}'>({tr('region_' + l['region'])})</span>"
                     + (f" ↔ {l['channel']}" if l.get("channel") else "") for l in links]
            self.who.setText("⚔ " + " · ".join(parts))
        else:
            self.who.setText(f"<span style='color:{theme.MUTED}'>{tr('alb_no_link_short')}</span>")
        self.model.set_items(items)
        self.table.sortByColumn(self.table.horizontalHeader().sortIndicatorSection(),
                                self.table.horizontalHeader().sortIndicatorOrder())
        info = (doc or {}).get("albion_info") or {}
        n_all = len(items)
        n_vis = self.visible_count()
        self.btn_refresh.setEnabled(bool(links) and ref is not None and not running)
        if ref is None:
            self._message("", tr("alb_pick_vod"))
        elif not links:
            self._message("settings", tr("alb_no_link", channel=(ref.meta.get("login") or "?")), tr("alb_link_btn"))
        elif albion_doc is None:
            self._message("refresh", tr("alb_not_fetched"), tr("alb_fetch_btn"))
        elif n_all == 0:
            self._message("refresh", tr("alb_no_events", names=", ".join(l["player"] for l in links)),
                          tr("alb_refresh"))
        elif n_vis == 0 and not self.show_ignored.isChecked():
            self._message("show", tr("alb_all_ignored", n=n_all, fame=albion.fmt_fame(self.min_fame.value(), language())),
                          tr("alb_show_btn"))
        else:
            self.stack.setCurrentIndex(1)
            if self.proxy.rowCount():
                self.table.selectRow(0)
        foot = []
        if albion_doc:
            n_ev = len(self.events_by_id)
            when = ""
            try:
                when = datetime.fromtimestamp(float(albion_doc.get("fetched_at"))).strftime("%d/%m %H:%M")
            except (TypeError, ValueError, OSError):
                pass
            foot.append(tr("alb_foot", n=n_ev, clips=n_vis, time=when))
            if info.get("partial") or albion_doc.get("partial"):
                foot.append("⚠ " + tr("alb_partial_short"))
        if self.collector_text:
            foot.append(self.collector_text)
        self.foot.setText("   ·   ".join(foot))

    def set_collector_status(self, text: str) -> None:
        self.collector_text = text
        base = self.foot.text().split("   ·   ")
        base = [b for b in base if b and not b.startswith("📡")]
        if text:
            base.append(text)
        self.foot.setText("   ·   ".join(base))

    def _message(self, kind: str, text: str, button: str = "") -> None:
        self._msg_kind = kind
        self.msg.setText(text)
        self.msg_btn.setVisible(bool(button))
        self.msg_btn.setText(button)
        self.stack.setCurrentIndex(0)
        self.details.show_clip(None, {}, None)
        self.selection_changed.emit(None)

    def _msg_action(self) -> None:
        if self._msg_kind == "settings":
            self.settings_requested.emit()
        elif self._msg_kind == "refresh":
            self.refresh_requested.emit()
        elif self._msg_kind == "show":
            self.show_ignored.setChecked(True)

    def _on_row(self, _cur, _prev) -> None:
        k = self.current()
        self.details.show_clip(k, self.events_by_id, self.vod_start)
        self.selection_changed.emit(k)

    def select_id(self, kid: str) -> None:
        row = self.model.row_of(kid)
        if row >= 0:
            idx = self.proxy.mapFromSource(self.model.index(row, 1))
            if idx.isValid():
                self.table.selectRow(idx.row())

    # ------------------------------------------------------------------ filters
    def filter_values(self) -> dict:
        return {"albion_types": [t for t, c in self.chk.items() if c.isChecked()],
                "albion_min_fame": int(self.min_fame.value())}

    def set_filter_values(self) -> None:
        self._block = True
        types = set(self.cfg.get("albion_types") or [])
        for t, c in self.chk.items():
            c.blockSignals(True)
            c.setChecked(t in types)
            c.blockSignals(False)
        self.min_fame.blockSignals(True)
        self.min_fame.setValue(int(self.cfg.get("albion_min_fame") or 0))
        self.min_fame.blockSignals(False)
        self._block = False

    def _filters_edited(self, *_a) -> None:
        if not self._block:
            self._filter_timer.start()

    def _show_ignored(self, on: bool) -> None:
        self.proxy.set_show_ignored(on)
        self.cfg["albion_show_ignored"] = bool(on)
        self.cfg.save()
        if on and self.stack.currentIndex() == 0 and self._msg_kind == "show":
            self.stack.setCurrentIndex(1)
            if self.proxy.rowCount():
                self.table.selectRow(0)
