"""Windows to add your own memes to the bank (Studio → ➕ Add):
- from a link (YouTube, TikTok, MyInstants, a file on the web): download, pick the passage, keep it;
- from a YouTube search;
- from a passage of one of your VODs;
- recorded with the microphone;
- files from the PC.
Downloads and cuts run in the background worker; the window shows the progress."""
from __future__ import annotations

import logging
import os
import time
from pathlib import Path
from typing import Callable, Optional

from PySide6.QtCore import QPointF, QRectF, Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QColor, QFont, QPainter, QPen
from PySide6.QtWidgets import (QApplication, QButtonGroup, QCheckBox, QComboBox, QDialog, QFileDialog, QHBoxLayout,
                               QLabel, QLineEdit, QListWidget, QListWidgetItem, QMessageBox, QProgressBar, QPushButton,
                               QRadioButton, QStackedWidget, QVBoxLayout, QWidget)

from .. import bank, memes
from ..i18n import tr
from ..util import fmt_time, open_in_explorer, sanitize_filename
from . import theme
from .jobs import Job
from .widgets import TimeSpinBox

log = logging.getLogger("fireclips.memes_ui")


def run(kind: str, host, parent) -> None:
    """Start one of the ways to add memes."""
    if kind == "files":
        add_files(host, parent)
    elif kind == "folder":
        try:
            open_in_explorer(bank.ensure(host.cfg))
        except Exception as e:  # noqa: BLE001
            log.info("open bank: %s", e)
    elif kind in ("link", "youtube"):
        MemeDialog(host, parent, kind).exec()
    elif kind == "vod":
        VodPassageDialog(host, parent).exec()
    elif kind == "mic":
        MicDialog(host, parent).exec()


def _studio(host):
    w = getattr(host, "studio_win", None)
    return w if w is not None and w.isVisible() and w.moment is not None else None


def _after_add(host, item_kind: str, ref: str, put_in_clip: bool) -> None:
    host.bank_changed()
    st = _studio(host)
    if put_in_clip and st is not None:
        st.add_item(f"{item_kind}:{ref}")


def add_files(host, parent) -> None:
    exts = sorted(bank.EXTS["sound"] | bank.EXTS["image"] | bank.EXTS["video"])
    flt = tr("meme_files_filter") + " (" + " ".join("*" + e for e in exts) + ")"
    files, _f = QFileDialog.getOpenFileNames(parent, tr("lib_add_files"), str(Path.home()), flt)
    add_paths(host, files)


def add_paths(host, files: list) -> None:
    """Copy sound / picture / video files into the bank (files picked, or dropped on the library)."""
    added = 0
    for f in files:
        try:
            if bank.add_file(host.cfg, Path(f)):
                added += 1
        except OSError as e:
            log.warning("bank add %s: %s", f, e)
    if added:
        host.bank_changed()
        st = _studio(host)
        if st is not None:
            st._set_status(tr("meme_files_added", n=added))


# =========================================================================== running a worker job


class _Runner:
    """Runs one worker job at a time for a dialog: progress bar, then on_done(result) or an error message."""

    def __init__(self, host, bar: QProgressBar, label: QLabel):
        self.host = host
        self.bar = bar
        self.label = label
        self.job: Optional[Job] = None

    def start(self, kind: str, args: list, text: str, on_done: Callable[[dict], None],
              on_fail: Optional[Callable[[], None]] = None) -> None:
        self.cancel()
        job = Job(kind, args)
        self.job = job
        self.bar.setRange(0, 0)
        self.bar.show()
        self.label.setText(text)

        def ev(e: dict) -> None:
            if e.get("ev") == "progress":
                self.bar.setRange(0, 1000)
                self.bar.setValue(int(1000 * float(e.get("frac") or 0)))

        def done(j: Job) -> None:
            if j is not self.job:
                return
            self.job = None
            self.bar.hide()
            if j.cancelled:
                self.label.setText("")
                return
            if j.exit_code == 0 and j.result is not None:
                self.label.setText("")
                on_done(j.result)
            else:
                e = j.last_error or {}
                msg = tr(e.get("code") or "err_meme_link_failed", **(e.get("fmt") or {}))
                self.label.setText("⚠ " + msg)
                log.warning("meme job %s failed: %s", kind, (e.get("detail") or j.stderr_tail())[-800:])
                if on_fail is not None:
                    on_fail()
        job.event.connect(ev)
        job.finished.connect(done)
        self.host.jobs.submit(job, "preview")

    def cancel(self) -> None:
        if self.job is not None:
            self.job.cancel()
            self.job = None
        self.bar.hide()

    @property
    def busy(self) -> bool:
        return self.job is not None


def _status_row(v: QVBoxLayout) -> tuple[QProgressBar, QLabel]:
    bar = QProgressBar()
    bar.setRange(0, 1000)
    bar.hide()
    lab = QLabel("")
    lab.setWordWrap(True)
    lab.setObjectName("Muted")
    v.addWidget(bar)
    v.addWidget(lab)
    return bar, lab


# =========================================================================== picking the passage


class RangeWave(QWidget):
    """The sound of a file with the part kept (drag the two edges), the playhead, click to listen from there."""
    changed = Signal(float, float)
    seek = Signal(float)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.wave: list = []
        self.dur = 1.0
        self.a, self.b = 0.0, 1.0
        self.pos: Optional[float] = None
        self._drag = None
        self.setMinimumHeight(86)
        self.setMouseTracking(True)

    def set_media(self, wave: list, dur: float) -> None:
        self.wave = list(wave or [])
        self.dur = max(0.1, float(dur))
        self.update()

    def set_range(self, a: float, b: float) -> None:
        self.a, self.b = max(0.0, a), min(self.dur, b)
        self.update()

    def _x(self, t: float) -> float:
        return 8 + (self.width() - 16) * t / self.dur

    def _t(self, x: float) -> float:
        return max(0.0, min(self.dur, (x - 8) / max(1.0, self.width() - 16) * self.dur))

    def paintEvent(self, _e) -> None:  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        p.fillRect(self.rect(), QColor(theme.PANEL_2))
        xa, xb = self._x(self.a), self._x(self.b)
        p.fillRect(QRectF(xa, 0, xb - xa, h), QColor(255, 106, 61, 45))
        if self.wave:
            n = len(self.wave)
            mid = h / 2
            for i, v in enumerate(self.wave):
                x = 8 + (w - 16) * i / n
                t = self.dur * i / n
                bh = max(1.5, (h - 16) * v / 99.0)
                inside = self.a <= t <= self.b
                p.fillRect(QRectF(x, mid - bh / 2, max(1.0, (w - 16) / n - 0.8), bh),
                           QColor(theme.ACCENT if inside else "#5a5a68"))
        for x in (xa, xb):
            p.setPen(QPen(QColor("#ffffff"), 2))
            p.drawLine(QPointF(x, 2), QPointF(x, h - 2))
            p.setBrush(QColor("#ffffff"))
            p.drawRoundedRect(QRectF(x - 5, h / 2 - 12, 10, 24), 3, 3)
        if self.pos is not None:
            x = self._x(self.pos)
            p.setPen(QPen(QColor(theme.BAD), 2))
            p.drawLine(QPointF(x, 0), QPointF(x, h))
        p.setPen(QColor(theme.MUTED))
        f = QFont(self.font())
        f.setPointSizeF(8)
        p.setFont(f)
        p.drawText(QRectF(8, h - 16, 200, 14), Qt.AlignLeft, "0:00")
        p.drawText(QRectF(w - 208, h - 16, 200, 14), Qt.AlignRight, fmt_time(self.dur, 1))
        p.end()

    def mousePressEvent(self, ev) -> None:  # noqa: N802
        x = ev.position().x()
        if abs(x - self._x(self.a)) < 9:
            self._drag = "a"
        elif abs(x - self._x(self.b)) < 9:
            self._drag = "b"
        else:
            self._drag = None
            self.seek.emit(self._t(x))

    def mouseMoveEvent(self, ev) -> None:  # noqa: N802
        x = ev.position().x()
        if self._drag is None:
            near = abs(x - self._x(self.a)) < 9 or abs(x - self._x(self.b)) < 9
            self.setCursor(Qt.SizeHorCursor if near else Qt.PointingHandCursor)
            return
        t = self._t(x)
        if self._drag == "a":
            self.a = min(t, self.b - 0.1)
        else:
            self.b = max(t, self.a + 0.1)
        self.update()
        self.changed.emit(self.a, self.b)

    def mouseReleaseEvent(self, _ev) -> None:  # noqa: N802
        self._drag = None


def _wave_of(path: str, n: int = 240) -> list:
    try:
        import numpy as np
        from .. import preview
        x = preview.decode_audio(path, 0.0, 600.0)
        if not len(x):
            return []
        m = np.abs(x).max(axis=1)
        chunks = np.array_split(m, n)
        pk = np.array([c.max() if len(c) else 0.0 for c in chunks])
        pk = pk / max(1e-9, pk.max())
        return [int(round(v * 99)) for v in pk]
    except Exception:  # noqa: BLE001
        return []


class CutPage(QWidget):
    """The downloaded meme: listen, pick the passage, keep it as a sound or a video meme."""
    kept = Signal(str, str)          # kind (sound | video | image), bank reference

    def __init__(self, host, parent=None):
        super().__init__(parent)
        self.host = host
        self.media: dict = {}
        v = QVBoxLayout(self)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(8)
        self.title = QLabel("")
        self.title.setWordWrap(True)
        self.title.setStyleSheet("font-weight: 700; font-size: 11pt;")
        v.addWidget(self.title)
        self.video_box = QVBoxLayout()
        v.addLayout(self.video_box, 1)
        self._video = None
        self._pic = QLabel()                 # a picture / GIF meme: shown as it is
        self._pic.setAlignment(Qt.AlignCenter)
        self._pic.setMinimumHeight(160)
        self._pic.hide()
        self.video_box.addWidget(self._pic)
        self._movie = None
        self.wave = RangeWave()
        self.wave.changed.connect(self._wave_changed)
        self.wave.seek.connect(self._play_from)
        v.addWidget(self.wave)
        row = QHBoxLayout()
        self.btn_play = QPushButton("▶ " + tr("meme_listen_part"))
        self.btn_play.clicked.connect(self._play_part)
        row.addWidget(self.btn_play)
        row.addSpacing(8)
        self.lbl_a = QLabel(tr("player_start"))
        row.addWidget(self.lbl_a)
        self.start = TimeSpinBox()
        self.start.setMinimumWidth(90)
        row.addWidget(self.start)
        self.lbl_b = QLabel(tr("player_end"))
        row.addWidget(self.lbl_b)
        self.end = TimeSpinBox()
        self.end.setMinimumWidth(90)
        row.addWidget(self.end)
        self.len_lbl = QLabel("")
        self.len_lbl.setObjectName("Muted")
        row.addWidget(self.len_lbl, 1)
        v.addLayout(row)
        self.start.valueChanged.connect(self._spin_changed)
        self.end.valueChanged.connect(self._spin_changed)
        row = QHBoxLayout()
        row.addWidget(QLabel(tr("meme_keep_as")))
        self.grp = QButtonGroup(self)
        self.r_sound = QRadioButton("🔊 " + tr("meme_as_sound"))
        self.r_video = QRadioButton("🎞 " + tr("meme_as_video"))
        self.r_image = QRadioButton("🖼 " + tr("meme_as_image"))
        for r in (self.r_sound, self.r_video, self.r_image):
            self.grp.addButton(r)
            row.addWidget(r)
        row.addStretch(1)
        v.addLayout(row)
        self.green = QLabel("")
        self.green.setStyleSheet("color: #7CFF6B;")
        v.addWidget(self.green)
        row = QHBoxLayout()
        row.addWidget(QLabel(tr("meme_name")))
        self.name = QLineEdit()
        row.addWidget(self.name, 1)
        v.addLayout(row)
        self.chk_clip = QCheckBox(tr("meme_put_in_clip"))
        self.chk_clip.setChecked(True)
        v.addWidget(self.chk_clip)
        self.bar, self.status = _status_row(v)
        row = QHBoxLayout()
        row.addStretch(1)
        self.btn_keep = QPushButton("✔ " + tr("meme_keep"))
        self.btn_keep.setObjectName("Primary")
        self.btn_keep.clicked.connect(self._keep)
        row.addWidget(self.btn_keep)
        v.addLayout(row)
        self.runner = _Runner(host, self.bar, self.status)
        self._player = None
        self._stop_at: Optional[float] = None
        self._tick = QTimer(self)
        self._tick.setInterval(40)
        self._tick.timeout.connect(self._on_tick)

    def set_media(self, media: dict) -> None:
        self.media = media
        dur = float(media.get("duration") or 0.0)
        self.title.setText(media.get("title") or Path(media.get("path", "")).stem)
        self.name.setText(sanitize_filename(media.get("title") or "meme", 40))
        img = bool(media.get("image")) and not media.get("has_video")
        self.r_image.setVisible(img)
        self.r_video.setVisible(bool(media.get("has_video")) and not img)
        self.r_sound.setVisible(bool(media.get("has_audio")))
        (self.r_image if img else self.r_video if media.get("has_video") and not media.get("has_audio")
         else self.r_sound).setChecked(True)
        if media.get("has_video") and media.get("has_audio") and dur <= 12:
            self.r_video.setChecked(True)
        for w in (self.start, self.end):
            w.setRange(0, max(0.1, dur))
        self.start.setValue(0.0)
        self.end.setValue(min(dur, memes.MAX_KEEP) if dur else 0.0)
        self.wave.set_media(_wave_of(media["path"]) if media.get("has_audio") else [], dur or 1.0)
        self.wave.set_range(0.0, min(dur, memes.MAX_KEEP) if dur else 1.0)
        self.wave.setVisible(not img)
        # a sound alone: no picture to show, the waveform gets the room (easier to pick the passage)
        has_v = bool(media.get("has_video")) or img
        lay = self.layout()
        lay.setStretchFactor(self.video_box, 1 if has_v else 0)
        lay.setStretchFactor(self.wave, 0 if has_v else 1)
        self.wave.setMinimumHeight(86 if has_v else 150)
        self._show_picture(media["path"] if img else "")
        for w in (self.btn_play, self.lbl_a, self.start, self.lbl_b, self.end, self.len_lbl):
            w.setVisible(not img)
        self._update_len()
        green = False
        if media.get("has_video"):
            from .studio_library import looks_green_file
            green = looks_green_file(Path(media["path"]))
        self.green.setText("🟩 " + tr("meme_green_found") if green else "")
        self.green.setVisible(green)
        st = _studio(self.host)
        self.chk_clip.setVisible(st is not None)
        self._setup_player()

    def _show_picture(self, path: str) -> None:
        from PySide6.QtGui import QMovie, QPixmap
        if self._movie is not None:
            self._movie.stop()
            self._movie = None
        self._pic.clear()
        self._pic.setVisible(bool(path))
        if not path:
            return
        if path.lower().endswith(".gif"):
            mv = QMovie(path)
            if mv.isValid():
                mv.jumpToFrame(0)
                size = mv.currentImage().size()
                if size.height() > 300:
                    mv.setScaledSize(size.scaled(10000, 300, Qt.KeepAspectRatio))
                self._movie = mv
                self._pic.setMovie(mv)
                mv.start()
                return
        pm = QPixmap(path)
        if not pm.isNull():
            self._pic.setPixmap(pm.scaled(min(pm.width(), 640), min(pm.height(), 300), Qt.KeepAspectRatio,
                                          Qt.SmoothTransformation))

    def _setup_player(self) -> None:
        try:
            from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
            from PySide6.QtMultimediaWidgets import QVideoWidget
        except Exception:  # noqa: BLE001
            return
        if self._player is None:
            self._player = QMediaPlayer(self)
            if not os.environ.get("FIRECLIPS_NO_AUDIO"):
                self._out = QAudioOutput(self)
                self._out.setVolume(0.85)
                self._player.setAudioOutput(self._out)
        if self.media.get("has_video") and self._video is None:
            self._video = QVideoWidget()
            self._video.setMinimumHeight(180)
            self.video_box.addWidget(self._video)
            self._player.setVideoOutput(self._video)
        if self._video is not None:
            self._video.setVisible(bool(self.media.get("has_video")))
        self._player.setSource(QUrl.fromLocalFile(self.media["path"]))

    def _update_len(self) -> None:
        self.len_lbl.setText(tr("player_len", len=fmt_time(max(0.0, self.end.value() - self.start.value()), 1)))

    def _wave_changed(self, a: float, b: float) -> None:
        self.start.blockSignals(True)
        self.end.blockSignals(True)
        self.start.setValue(a)
        self.end.setValue(b)
        self.start.blockSignals(False)
        self.end.blockSignals(False)
        self._update_len()

    def _spin_changed(self, _v=None) -> None:
        a, b = self.start.value(), self.end.value()
        if b <= a:
            b = a + 0.1
        self.wave.set_range(a, b)
        self._update_len()

    def _play_from(self, t: float) -> None:
        if self._player is None:
            return
        self._stop_at = None
        self._player.setPosition(int(t * 1000))
        self._player.play()
        self._tick.start()

    def _play_part(self) -> None:
        if self._player is None:
            return
        from PySide6.QtMultimedia import QMediaPlayer
        if self._player.playbackState() == QMediaPlayer.PlayingState:
            self._player.pause()
            return
        self._player.setPosition(int(self.start.value() * 1000))
        self._stop_at = self.end.value()
        self._player.play()
        self._tick.start()

    def _on_tick(self) -> None:
        if self._player is None:
            return
        t = self._player.position() / 1000.0
        self.wave.pos = t
        self.wave.update()
        if self._stop_at is not None and t >= self._stop_at:
            self._player.pause()
            self._stop_at = None

    def stop(self) -> None:
        self._tick.stop()
        if self._movie is not None:
            self._movie.stop()
        if self._player is not None:
            self._player.stop()
        self.runner.cancel()

    def _keep(self) -> None:
        if self.runner.busy or not self.media:
            return
        kind = "image" if self.r_image.isChecked() else "video" if self.r_video.isChecked() else "sound"
        name = sanitize_filename(self.name.text().strip() or "meme", 60)
        if self._player is not None:
            self._player.pause()
        args = ["--src", self.media["path"], "--start", f"{self.start.value():.3f}", "--end", f"{self.end.value():.3f}",
                "--kind", kind, "--name", name]
        self.btn_keep.setEnabled(False)

        def done(res: dict) -> None:
            self.btn_keep.setEnabled(True)
            self.kept.emit(res.get("kind") or kind, res.get("ref") or "")
        self.runner.start("meme-cut", args, tr("meme_cutting"), done, lambda: self.btn_keep.setEnabled(True))


# =========================================================================== link / YouTube search


class MemeDialog(QDialog):
    """From a link, or from a YouTube search, to a meme in the bank."""

    def __init__(self, host, parent=None, mode: str = "link"):
        super().__init__(parent)
        self.host = host
        self.mode = mode
        self.setWindowTitle(tr("lib_add_link") if mode == "link" else tr("lib_add_youtube"))
        self.resize(760, 640)
        v = QVBoxLayout(self)
        v.setSpacing(8)
        self.stack = QStackedWidget()
        v.addWidget(self.stack, 1)
        # ---- page 1: the link / the search
        p1 = QWidget()
        p1v = QVBoxLayout(p1)
        p1v.setContentsMargins(0, 0, 0, 0)
        intro = QLabel(tr("meme_link_intro") if mode == "link" else tr("meme_search_intro"))
        intro.setWordWrap(True)
        p1v.addWidget(intro)
        row = QHBoxLayout()
        self.input = QLineEdit()
        self.input.setObjectName("BigInput")
        self.input.setPlaceholderText(tr("meme_link_ph") if mode == "link" else tr("meme_search_ph"))
        self.input.returnPressed.connect(self._go)
        row.addWidget(self.input, 1)
        self.btn_go = QPushButton(tr("meme_link_go") if mode == "link" else tr("meme_search_go"))
        self.btn_go.setObjectName("Primary")
        self.btn_go.clicked.connect(self._go)
        row.addWidget(self.btn_go)
        p1v.addLayout(row)
        self.results = QListWidget()
        self.results.setVisible(mode == "youtube")
        self.results.itemDoubleClicked.connect(lambda _it: self._take())
        p1v.addWidget(self.results, 1)
        self.btn_take = QPushButton("⬇ " + tr("meme_take"))
        self.btn_take.setVisible(mode == "youtube")
        self.btn_take.setEnabled(False)
        self.btn_take.clicked.connect(self._take)
        self.results.currentItemChanged.connect(lambda cur, _p: self.btn_take.setEnabled(cur is not None))
        p1v.addWidget(self.btn_take, 0, Qt.AlignRight)
        # a long video: only a passage is downloaded
        self.part = QWidget()
        pr = QHBoxLayout(self.part)
        pr.setContentsMargins(0, 0, 0, 0)
        self.part_lbl = QLabel("")
        self.part_lbl.setWordWrap(True)
        pr.addWidget(self.part_lbl, 1)
        pr.addWidget(QLabel(tr("player_start")))
        self.part_a = TimeSpinBox()
        pr.addWidget(self.part_a)
        pr.addWidget(QLabel(tr("player_end")))
        self.part_b = TimeSpinBox()
        pr.addWidget(self.part_b)
        b = QPushButton("⬇ " + tr("meme_part_go"))
        b.clicked.connect(self._fetch_part)
        pr.addWidget(b)
        self.part.hide()
        p1v.addWidget(self.part)
        self.bar, self.status = _status_row(p1v)
        rights = QLabel(tr("meme_rights"))
        rights.setWordWrap(True)
        rights.setObjectName("Muted")
        rights.setStyleSheet("font-size: 8pt;")
        p1v.addWidget(rights)
        if mode == "link":
            p1v.addStretch(1)
        self.stack.addWidget(p1)
        # ---- page 2: the passage to keep
        self.cut = CutPage(host)
        self.cut.kept.connect(self._kept)
        self.stack.addWidget(self.cut)
        row = QHBoxLayout()
        self.btn_back = QPushButton("← " + tr("meme_back"))
        self.btn_back.setObjectName("Flat")
        self.btn_back.clicked.connect(self._back)
        self.btn_back.hide()
        row.addWidget(self.btn_back)
        row.addStretch(1)
        b = QPushButton(tr("meme_close"))
        b.clicked.connect(self.reject)
        row.addWidget(b)
        v.addLayout(row)
        self.runner = _Runner(host, self.bar, self.status)
        self._info: dict = {}
        if mode == "link":
            clip = QApplication.clipboard().text().strip()
            if clip.startswith("http") and len(clip) < 500 and "\n" not in clip:
                self.input.setText(clip)

    def _go(self) -> None:
        text = self.input.text().strip()
        if not text or self.runner.busy:
            return
        self.part.hide()
        if self.mode == "youtube":
            self.results.clear()

            def done(res: dict) -> None:
                items = res.get("items") or []
                for r in items:
                    d = float(r.get("duration") or 0)
                    it = QListWidgetItem(f"{r.get('title')}\n{r.get('channel') or ''}" + (f"  ·  {fmt_time(d, 0)}" if d else ""))
                    it.setData(Qt.UserRole, r)
                    self.results.addItem(it)
                if not items:
                    self.status.setText(tr("lib_nothing"))
            self.runner.start("meme-search", ["--query", text], tr("meme_searching"), done)
            return
        self._info_then_fetch(text)

    def _take(self) -> None:
        it = self.results.currentItem()
        if it is None or self.runner.busy:
            return
        r = it.data(Qt.UserRole) or {}
        self._info = {"url": r.get("url"), "title": r.get("title"), "duration": float(r.get("duration") or 0)}
        self._after_info(self._info)

    def _info_then_fetch(self, url: str) -> None:
        self.runner.start("meme-info", ["--url", url], tr("meme_reading_link"), self._after_info)

    def _after_info(self, inf: dict) -> None:
        self._info = inf
        d = float(inf.get("duration") or 0)
        if d > memes.MAX_WHOLE:
            self.part_lbl.setText(tr("meme_long", len=fmt_time(d, 0)))
            for w in (self.part_a, self.part_b):
                w.setRange(0, d)
            self.part_a.setValue(0)
            self.part_b.setValue(min(d, 20))
            self.part.show()
            return
        self._fetch(None)

    def _fetch_part(self) -> None:
        a, b = self.part_a.value(), self.part_b.value()
        if b - a < 0.5:
            return
        self._fetch((a, min(b, a + 180)))

    def _fetch(self, section) -> None:
        args = ["--url", self._info.get("url") or "", "--name", (self._info.get("title") or "")[:120]]
        if section:
            args += ["--start", f"{section[0]:.2f}", "--end", f"{section[1]:.2f}"]
        self.runner.start("meme-fetch", args, tr("meme_downloading"), self._fetched)

    def _fetched(self, media: dict) -> None:
        if not media.get("path"):
            self.status.setText("⚠ " + tr("err_meme_link_failed"))
            return
        self.cut.set_media(media)
        self.stack.setCurrentWidget(self.cut)
        self.btn_back.show()

    def _back(self) -> None:
        self.cut.stop()
        self.stack.setCurrentIndex(0)
        self.btn_back.hide()

    def _kept(self, kind: str, ref: str) -> None:
        _after_add(self.host, kind, ref, self.cut.chk_clip.isVisible() and self.cut.chk_clip.isChecked())
        self.cut.stop()
        QMessageBox.information(self, "FireClips", tr("meme_kept", name=bank.display_name(ref)))
        self.accept()

    def done(self, r: int) -> None:  # noqa: D401 - closing the window stops what runs
        self.runner.cancel()
        self.cut.stop()
        super().done(r)


# =========================================================================== a passage of a VOD


class VodPassageDialog(QDialog):
    """Keep a cult moment of a stream as a meme sound / video."""

    def __init__(self, host, parent=None):
        super().__init__(parent)
        self.host = host
        self.setWindowTitle(tr("lib_add_vod"))
        self.resize(620, 360)
        v = QVBoxLayout(self)
        intro = QLabel(tr("meme_vod_intro"))
        intro.setWordWrap(True)
        v.addWidget(intro)
        row = QHBoxLayout()
        row.addWidget(QLabel(tr("meme_vod")))
        self.vod = QComboBox()
        row.addWidget(self.vod, 1)
        v.addLayout(row)
        cur = getattr(host, "current", None)
        try:
            refs = [r for r in host.lib.all() if r.status() == "done"]
        except Exception:  # noqa: BLE001
            refs = [cur] if cur is not None else []
        from .main_window import vod_title
        for r in refs:
            self.vod.addItem(vod_title(r), r.key)
        if cur is not None:
            i = self.vod.findData(cur.key)
            if i < 0:
                self.vod.insertItem(0, vod_title(cur), cur.key)
                i = 0
            self.vod.setCurrentIndex(i)
        row = QHBoxLayout()
        row.addWidget(QLabel(tr("player_start")))
        self.a = TimeSpinBox()
        self.b = TimeSpinBox()
        row.addWidget(self.a)
        row.addWidget(QLabel(tr("player_end")))
        row.addWidget(self.b)
        self.len_lbl = QLabel("")
        self.len_lbl.setObjectName("Muted")
        row.addWidget(self.len_lbl, 1)
        v.addLayout(row)
        for w in (self.a, self.b):
            w.setRange(0, 24 * 3600)
            w.valueChanged.connect(self._len)
        t = self._guess_time()
        self.a.setValue(max(0.0, t - 2.0))
        self.b.setValue(t + 3.0)
        row = QHBoxLayout()
        self.btn_listen = QPushButton("▶ " + tr("meme_listen_part"))
        self.btn_listen.clicked.connect(self._listen)
        row.addWidget(self.btn_listen)
        row.addStretch(1)
        v.addLayout(row)
        row = QHBoxLayout()
        row.addWidget(QLabel(tr("meme_keep_as")))
        self.r_sound = QRadioButton("🔊 " + tr("meme_as_sound"))
        self.r_video = QRadioButton("🎞 " + tr("meme_as_video"))
        self.r_sound.setChecked(True)
        row.addWidget(self.r_sound)
        row.addWidget(self.r_video)
        row.addStretch(1)
        v.addLayout(row)
        row = QHBoxLayout()
        row.addWidget(QLabel(tr("meme_name")))
        self.name = QLineEdit()
        st = _studio(host)
        self.name.setText(sanitize_filename((st.moment.get("title") if st else "") or tr("meme_vod_default"), 40))
        row.addWidget(self.name, 1)
        v.addLayout(row)
        self.chk_clip = QCheckBox(tr("meme_put_in_clip"))
        self.chk_clip.setVisible(st is not None)
        self.chk_clip.setChecked(False)
        v.addWidget(self.chk_clip)
        self.bar, self.status = _status_row(v)
        row = QHBoxLayout()
        row.addStretch(1)
        b = QPushButton(tr("meme_close"))
        b.clicked.connect(self.reject)
        row.addWidget(b)
        self.btn_keep = QPushButton("✔ " + tr("meme_keep"))
        self.btn_keep.setObjectName("Primary")
        self.btn_keep.clicked.connect(self._keep)
        row.addWidget(self.btn_keep)
        v.addLayout(row)
        self.runner = _Runner(host, self.bar, self.status)
        self._player = None
        self._len()

    def _guess_time(self) -> float:
        st = _studio(self.host)
        if st is not None and st.comp is not None:
            t = st.comp.vod_time(st.player.position())
            if t is not None:
                return float(t)
        pl = getattr(self.host, "player", None)
        if pl is not None and pl.src:
            return float(pl.vod_pos())
        return 0.0

    def _len(self, _v=None) -> None:
        self.len_lbl.setText(tr("player_len", len=fmt_time(max(0.0, self.b.value() - self.a.value()), 1)))

    def _ref(self):
        key = self.vod.currentData()
        return self.host.lib.ref(key) if key else None

    def _listen(self) -> None:
        ref = self._ref()
        audio = ref.audio_file() if ref is not None else None
        if audio is None:
            self.status.setText(tr("meme_vod_no_audio"))
            return
        try:
            from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
        except Exception:  # noqa: BLE001
            return
        if self._player is None:
            self._player = QMediaPlayer(self)
            if not os.environ.get("FIRECLIPS_NO_AUDIO"):
                self._out = QAudioOutput(self)
                self._out.setVolume(0.85)
                self._player.setAudioOutput(self._out)
        self._player.setSource(QUrl.fromLocalFile(str(audio)))
        a, b = self.a.value(), self.b.value()

        def go() -> None:
            self._player.setPosition(int(a * 1000))
            self._player.play()
            QTimer.singleShot(int(max(0.1, b - a) * 1000), self._player.pause)
        QTimer.singleShot(150, go)

    def _keep(self) -> None:
        ref = self._ref()
        if ref is None or self.runner.busy:
            return
        a, b = self.a.value(), self.b.value()
        if b - a < 0.2:
            self.status.setText("⚠ " + tr("err_meme_too_short"))
            return
        kind = "video" if self.r_video.isChecked() else "sound"
        args = ["--key", ref.key, "--work", str(self.host.cfg.work_dir), "--start", f"{a:.3f}", "--end", f"{b:.3f}",
                "--kind", kind, "--name", sanitize_filename(self.name.text().strip() or "meme", 60)]

        def done(res: dict) -> None:
            _after_add(self.host, res.get("kind") or kind, res.get("ref") or "", self.chk_clip.isChecked())
            QMessageBox.information(self, "FireClips", tr("meme_kept", name=bank.display_name(res.get("ref") or "")))
            self.accept()
        self.runner.start("meme-vod", args, tr("meme_cutting"), done)

    def done(self, r: int) -> None:  # noqa: D401
        self.runner.cancel()
        if self._player is not None:
            self._player.stop()
        super().done(r)


# =========================================================================== the microphone


class MicDialog(QDialog):
    """Record a sound with the microphone."""

    def __init__(self, host, parent=None):
        super().__init__(parent)
        self.host = host
        self.setWindowTitle(tr("lib_add_mic"))
        self.resize(520, 300)
        v = QVBoxLayout(self)
        intro = QLabel(tr("meme_mic_intro"))
        intro.setWordWrap(True)
        v.addWidget(intro)
        row = QHBoxLayout()
        row.addWidget(QLabel(tr("meme_mic_device")))
        self.dev = QComboBox()
        row.addWidget(self.dev, 1)
        v.addLayout(row)
        self.time_lbl = QLabel("● 0:00.0")
        self.time_lbl.setAlignment(Qt.AlignCenter)
        self.time_lbl.setStyleSheet("font-size: 20pt; font-weight: 700;")
        v.addWidget(self.time_lbl)
        row = QHBoxLayout()
        self.btn_rec = QPushButton("⏺ " + tr("meme_mic_record"))
        self.btn_rec.setObjectName("Primary")
        self.btn_rec.clicked.connect(self._toggle)
        row.addWidget(self.btn_rec)
        self.btn_play = QPushButton("▶ " + tr("meme_listen"))
        self.btn_play.setEnabled(False)
        self.btn_play.clicked.connect(self._play)
        row.addWidget(self.btn_play)
        v.addLayout(row)
        row = QHBoxLayout()
        row.addWidget(QLabel(tr("meme_name")))
        self.name = QLineEdit(tr("meme_mic_default"))
        row.addWidget(self.name, 1)
        v.addLayout(row)
        self.chk_clip = QCheckBox(tr("meme_put_in_clip"))
        self.chk_clip.setVisible(_studio(host) is not None)
        self.chk_clip.setChecked(True)
        v.addWidget(self.chk_clip)
        self.status = QLabel("")
        self.status.setWordWrap(True)
        self.status.setObjectName("Muted")
        v.addWidget(self.status)
        row = QHBoxLayout()
        row.addStretch(1)
        b = QPushButton(tr("meme_close"))
        b.clicked.connect(self.reject)
        row.addWidget(b)
        self.btn_keep = QPushButton("✔ " + tr("meme_keep"))
        self.btn_keep.setObjectName("Primary")
        self.btn_keep.setEnabled(False)
        self.btn_keep.clicked.connect(self._keep)
        row.addWidget(self.btn_keep)
        v.addLayout(row)
        self.file: Optional[Path] = None
        self._rec = None
        self._session = None
        self._t0 = 0.0
        self._timer = QTimer(self)
        self._timer.setInterval(100)
        self._timer.timeout.connect(self._tick)
        self._player = None
        self._devices = []
        if not os.environ.get("FIRECLIPS_NO_AUDIO"):          # (test machines without sound)
            try:
                from PySide6.QtMultimedia import QMediaDevices
                self._devices = list(QMediaDevices.audioInputs())
            except Exception:  # noqa: BLE001
                self._devices = []
        for d in self._devices:
            self.dev.addItem(d.description())
        if not self._devices:
            self.status.setText("⚠ " + tr("meme_mic_none"))
            self.btn_rec.setEnabled(False)

    def _toggle(self) -> None:
        if self._rec is not None:
            self._stop()
            return
        try:
            from PySide6.QtMultimedia import QAudioInput, QMediaCaptureSession, QMediaFormat, QMediaRecorder
        except Exception as e:  # noqa: BLE001
            self.status.setText(f"⚠ {e}")
            return
        out = memes.tmp_dir(self.host.cfg) / f"micro_{time.strftime('%Y%m%d_%H%M%S')}.wav"
        self._session = QMediaCaptureSession(self)
        self._input = QAudioInput(self._devices[self.dev.currentIndex()], self)
        self._session.setAudioInput(self._input)
        self._rec = QMediaRecorder(self)
        self._session.setRecorder(self._rec)
        fmt = QMediaFormat()
        fmt.setFileFormat(QMediaFormat.Wave)
        self._rec.setMediaFormat(fmt)
        self._rec.setQuality(QMediaRecorder.HighQuality)
        self._rec.setOutputLocation(QUrl.fromLocalFile(str(out)))
        self._rec.errorOccurred.connect(lambda _e, msg="": self.status.setText("⚠ " + (msg or tr("meme_mic_error"))))
        self._rec.record()
        self.file = out
        self._t0 = time.time()
        self._timer.start()
        self.btn_rec.setText("⏹ " + tr("meme_mic_stop"))
        self.btn_play.setEnabled(False)
        self.btn_keep.setEnabled(False)
        self.time_lbl.setStyleSheet(f"font-size: 20pt; font-weight: 700; color: {theme.BAD};")

    def _stop(self) -> None:
        if self._rec is not None:
            self._rec.stop()
        self._rec = None
        self._timer.stop()
        self.time_lbl.setStyleSheet("font-size: 20pt; font-weight: 700;")
        self.btn_rec.setText("⏺ " + tr("meme_mic_again"))
        QTimer.singleShot(400, self._recorded)

    def _recorded(self) -> None:
        ok = self.file is not None and self.file.exists() and self.file.stat().st_size > 2000
        self.btn_play.setEnabled(ok)
        self.btn_keep.setEnabled(ok)
        if not ok:
            self.status.setText("⚠ " + tr("meme_mic_error"))

    def _tick(self) -> None:
        d = time.time() - self._t0
        self.time_lbl.setText(f"● {fmt_time(d, 1)}")
        if d > 60:
            self._stop()

    def _play(self) -> None:
        if self.file is None:
            return
        try:
            from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
        except Exception:  # noqa: BLE001
            return
        if self._player is None:
            self._player = QMediaPlayer(self)
            if not os.environ.get("FIRECLIPS_NO_AUDIO"):
                self._out = QAudioOutput(self)
                self._out.setVolume(0.9)
                self._player.setAudioOutput(self._out)
        self._player.setSource(QUrl.fromLocalFile(str(self.file)))
        self._player.play()

    def _keep(self) -> None:
        if self.file is None:
            return
        if self._player is not None:
            self._player.stop()
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            it = memes.keep_recording(self.host.cfg, str(self.file), self.name.text().strip() or "micro")
        except Exception as e:  # noqa: BLE001
            QApplication.restoreOverrideCursor()
            code = getattr(e, "code", "err_meme_cut_failed")
            self.status.setText("⚠ " + tr(code))
            return
        QApplication.restoreOverrideCursor()
        _after_add(self.host, "sound", it.ref, self.chk_clip.isVisible() and self.chk_clip.isChecked())
        QMessageBox.information(self, "FireClips", tr("meme_kept", name=it.name))
        self.accept()

    def done(self, r: int) -> None:  # noqa: D401
        if self._rec is not None:
            self._rec.stop()
        if self._player is not None:
            self._player.stop()
        super().done(r)
