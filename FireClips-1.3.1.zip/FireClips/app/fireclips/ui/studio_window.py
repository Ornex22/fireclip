"""The Studio: a window to dress one clip, CapCut style.

    library (left)  |  the clip, live (centre)  |  settings of what is picked (right)
    ------------------------------------------------------------------------------------
    timeline: video, subtitles, memes, effects, sounds, music

Nothing is rendered to see the result: the picture and the sound are made live from the same code as
the export (see preview.py). "Exact render" still makes the real file when you want to check it."""
from __future__ import annotations

import copy
import logging
import time
from typing import Optional

from PySide6.QtCore import QSize, Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QKeySequence, QShortcut
from PySide6.QtWidgets import (QFrame, QHBoxLayout, QLabel, QMainWindow, QMenu, QPushButton,
                               QStackedWidget, QToolButton, QVBoxLayout, QWidget)

from .. import bank, fxlib, montage, preview, profiles
from ..i18n import language, tr
from ..util import fmt_time
from . import theme
from .live_preview import PreviewCanvas, PreviewPlayer
from .studio_inspector import Inspector
from .studio_library import Library, looks_green_file
from .studio_timeline import TimelinePanel
from .widgets import ElidedLabel, GripSplitter

log = logging.getLogger("fireclips.studio")

NEXT_POS = [(0.76, 0.30), (0.25, 0.32), (0.74, 0.68), (0.28, 0.66), (0.5, 0.45)]
# where a new picture may go when nothing says where (fractions of the game picture), best first: the first
# spot that hides nothing already on screen at that time is used (emojis: NEXT_POS, started further each time)
SPOTS = {"emoji": NEXT_POS + [(0.5, 0.12), (0.5, 0.88)],
         "image": [(0.5, 0.45), (0.28, 0.42), (0.72, 0.42), (0.5, 0.74), (0.5, 0.2)],
         "text": [(0.5, 0.2), (0.5, 0.8), (0.5, 0.5), (0.5, 0.35), (0.5, 0.65)]}


def _inter(a: tuple, b: tuple) -> float:
    """Area shared by two rectangles (x, y, w, h)."""
    w = min(a[0] + a[2], b[0] + b[2]) - max(a[0], b[0])
    h = min(a[1] + a[3], b[1] + b[3]) - max(a[1], b[1])
    return w * h if w > 0 and h > 0 else 0.0


def _src_info(path: str) -> dict:
    """Width / height / frame rate of a video file (for the picture layout)."""
    info = {"has_video": True}
    try:
        rd = preview.VideoReader(path)
        info.update(width=rd.src_w, height=rd.src_h, fps=rd.fps, duration=rd.duration)
        rd.close()
    except Exception as e:  # noqa: BLE001
        log.info("probe %s: %s", path, e)
        info.update(width=1920, height=1080, fps=30.0)
    return info


class StudioWindow(QMainWindow):
    navigate = Signal(int)            # -1 / +1: the clip before / after in the list
    closed = Signal()

    def __init__(self, cfg, host=None, parent=None):
        super().__init__(parent)
        self.cfg = cfg
        self.host = host
        self.ref = None
        self.moment: Optional[dict] = None
        self.m: dict = montage.normalize({})
        self.words: list = []
        self.src: Optional[dict] = None
        self.src_info: dict = {}
        self.fmt = "vertical"
        self.comp: Optional[preview.Composition] = None
        self.prof: dict = {}
        self.sel = ""
        self._undo: list = []
        self._redo: list = []
        self._undo_key = ("", 0.0)
        self._pos_i = 0
        self._clipboard: Optional[dict] = None
        self._drag_comp: Optional[preview.Composition] = None
        self._listen_player = None
        self._listen_item = ""
        self._ai_waiting = ""                # the clip id the AI is reading for ✨ Montage auto
        self._nav_info = (0, 0)
        self.setWindowTitle("FireClips Studio")
        self.setWindowIcon(theme.app_icon())
        self.resize(1500, 920)
        self.setMinimumSize(1100, 680)
        self._build()
        self._rebuild_timer = QTimer(self)
        self._rebuild_timer.setSingleShot(True)
        self._rebuild_timer.setInterval(30)
        self._rebuild_timer.timeout.connect(lambda: self._rebuild(sound=False))
        self._sound_timer = QTimer(self)
        self._sound_timer.setSingleShot(True)
        self._sound_timer.setInterval(350)
        self._sound_timer.timeout.connect(self._rebuild_sound)
        self._save_timer = QTimer(self)
        self._save_timer.setSingleShot(True)
        self._save_timer.setInterval(500)
        self._save_timer.timeout.connect(self._save)
        self._dirty = set()

    # =================================================================== building
    def _build(self) -> None:
        root = QWidget()
        self.setCentralWidget(root)
        outer = QVBoxLayout(root)
        outer.setContentsMargins(10, 8, 10, 8)
        outer.setSpacing(8)

        # ---- toolbar
        bar = QHBoxLayout()
        bar.setSpacing(6)
        self.btn_prev = QToolButton()
        self.btn_prev.setText("◀")
        self.btn_prev.setToolTip(tr("st_prev_clip") + " (Page ↑)")
        self.btn_prev.clicked.connect(lambda: self._go(-1))
        self.btn_next = QToolButton()
        self.btn_next.setText("▶")
        self.btn_next.setToolTip(tr("st_next_clip") + " (Page ↓)")
        self.btn_next.clicked.connect(lambda: self._go(+1))
        bar.addWidget(self.btn_prev)
        bar.addWidget(self.btn_next)
        self.title_lbl = ElidedLabel("")
        self.title_lbl.setStyleSheet("font-size: 12pt; font-weight: 700;")
        bar.addWidget(self.title_lbl, 1)
        self.fmt_v = QToolButton()
        self.fmt_v.setObjectName("Seg")
        self.fmt_v.setText("9:16")
        self.fmt_v.setCheckable(True)
        self.fmt_v.setToolTip(tr("st_fmt_tip"))
        self.fmt_h = QToolButton()
        self.fmt_h.setObjectName("Seg")
        self.fmt_h.setText("16:9")
        self.fmt_h.setCheckable(True)
        self.fmt_h.setToolTip(tr("st_fmt_tip"))
        self.fmt_v.clicked.connect(lambda: self.set_format("vertical"))
        self.fmt_h.clicked.connect(lambda: self.set_format("landscape"))
        bar.addWidget(self.fmt_v)
        bar.addWidget(self.fmt_h)
        bar.addSpacing(10)
        b = QPushButton("✨ " + tr("st_auto"))
        self.btn_auto = b
        b.setToolTip(tr("st_auto_tip"))
        b.clicked.connect(self._auto)
        bar.addWidget(b)
        b = QPushButton("🗑 " + tr("st_clear"))
        b.setObjectName("Flat")
        b.setToolTip(tr("st_clear_tip"))
        b.clicked.connect(self._clear)
        bar.addWidget(b)
        self.btn_undo = QToolButton()
        self.btn_undo.setText("↶")
        self.btn_undo.setToolTip(tr("st_undo") + " (Ctrl+Z)")
        self.btn_undo.clicked.connect(self.undo)
        self.btn_redo = QToolButton()
        self.btn_redo.setText("↷")
        self.btn_redo.setToolTip(tr("st_redo") + " (Ctrl+Y)")
        self.btn_redo.clicked.connect(self.redo)
        bar.addWidget(self.btn_undo)
        bar.addWidget(self.btn_redo)
        bar.addSpacing(10)
        self.btn_exact = QPushButton("👁 " + tr("st_exact"))
        self.btn_exact.setToolTip(tr("st_exact_tip"))
        self.btn_exact.clicked.connect(self._exact)
        bar.addWidget(self.btn_exact)
        self.btn_export = QPushButton("⬇ " + tr("st_export_clip"))
        self.btn_export.setObjectName("Primary")
        self.btn_export.setToolTip(tr("st_export_clip_tip"))
        self.btn_export.clicked.connect(self._export)
        bar.addWidget(self.btn_export)
        outer.addLayout(bar)

        # ---- body: library | preview | settings, timeline below
        vsplit = GripSplitter(Qt.Vertical)
        vsplit.setChildrenCollapsible(False)
        self.vsplit = vsplit
        outer.addWidget(vsplit, 1)
        hsplit = GripSplitter(Qt.Horizontal)
        hsplit.setChildrenCollapsible(False)
        vsplit.addWidget(hsplit)

        self.library = Library(self.cfg)
        self.library.setMinimumWidth(300)
        self.library.add.connect(self.add_item)
        self.library.listen.connect(self._listen)
        self.library.use_music.connect(self._use_music)
        self.library.import_requested.connect(self._import)
        self.library.files_dropped.connect(self._files_dropped)
        self.library.download_requested.connect(
            lambda: self.host is not None and hasattr(self.host, "bank_sync") and self.host.bank_sync(mode="retry"))
        hsplit.addWidget(self.library)

        center = QFrame()
        center.setObjectName("Panel")
        cv = QVBoxLayout(center)
        cv.setContentsMargins(8, 8, 8, 6)
        cv.setSpacing(6)
        self.player = PreviewPlayer(self)
        self.player.position_changed.connect(self._on_position)
        self.player.playing_changed.connect(self._on_playing)
        self.player.audio.mixing.connect(self._on_mixing)
        self.center_stack = QStackedWidget()
        self.canvas = PreviewCanvas(self.player)
        self.canvas.picked.connect(self._pick)
        self.canvas.moved.connect(self._canvas_moved)
        self.canvas.resized.connect(self._canvas_resized)
        self.canvas.turned.connect(self._canvas_turned)
        self.canvas.edit_done.connect(lambda _id: self._commit_drag())
        self.canvas.dropped.connect(self._dropped_on_canvas)
        self.center_stack.addWidget(self.canvas)
        self.exact_page = self._build_exact_page()
        self.center_stack.addWidget(self.exact_page)
        cv.addWidget(self.center_stack, 1)
        tr_row = QHBoxLayout()
        tr_row.setSpacing(6)
        b = QToolButton()
        b.setText("⏮")
        b.setToolTip(tr("st_to_start"))
        b.clicked.connect(lambda: self.player.seek(0.0))
        tr_row.addWidget(b)
        self.btn_play = QPushButton("▶")
        self.btn_play.setObjectName("Primary")
        self.btn_play.setFixedWidth(64)
        self.btn_play.setToolTip(tr("player_playpause") + (" (Espace)" if language() == "fr" else " (Space)"))
        self.btn_play.clicked.connect(self._play_clicked)
        tr_row.addWidget(self.btn_play)
        self.time_lbl = QLabel("0:00.0 / 0:00.0")
        self.time_lbl.setStyleSheet("font-family: Consolas, monospace;")
        tr_row.addWidget(self.time_lbl)
        tr_row.addStretch(1)
        self.status_lbl = ElidedLabel("")
        self.status_lbl.setObjectName("Muted")
        tr_row.addWidget(self.status_lbl, 2)
        self.btn_loop = QToolButton()
        self.btn_loop.setText("🔁")
        self.btn_loop.setCheckable(True)
        self.btn_loop.setChecked(True)
        self.btn_loop.setToolTip(tr("player_loop"))
        self.btn_loop.toggled.connect(lambda on: setattr(self.player, "loop", on))
        tr_row.addWidget(self.btn_loop)
        self.btn_mute = QToolButton()
        self.btn_mute.setText("🔊")
        self.btn_mute.setCheckable(True)
        self.btn_mute.toggled.connect(self._mute)
        tr_row.addWidget(self.btn_mute)
        cv.addLayout(tr_row)
        hsplit.addWidget(center)

        self.inspector = Inspector(self.cfg)
        self.inspector.setMinimumWidth(300)
        self.inspector.changed.connect(self._element_changed)
        self.inspector.clip_changed.connect(self._clip_changed)
        self.inspector.delete_requested.connect(self.delete_element)
        self.inspector.duplicate_requested.connect(self.duplicate_element)
        self.inspector.seek_to.connect(self.player.seek)
        self.inspector.nudge.connect(self._nudge)
        self.inspector.range_edit.connect(self._set_range)
        self.inspector.range_reset.connect(self._reset_range)
        self.inspector.title_edit.connect(self._set_title)
        self.inspector.hook_here.connect(self._hook_here)
        self.inspector.edit_subs.connect(self._edit_subs)
        self.inspector.show_music.connect(lambda: self.library.show_page("music"))
        self.inspector.pick_emoji.connect(self._pick_fx_emoji)
        self.inspector.listen.connect(lambda path: self._listen("inspector", path))
        self.inspector.seg_cut_here.connect(self._cut_here)
        self.inspector.seg_delete.connect(self._segment_delete)
        self.inspector.seg_cut_side.connect(self._cut_side)
        self.inspector.seg_reset.connect(self._cuts_reset)
        self.inspector.seg_speed.connect(self._segment_speed)
        self.inspector.seg_go.connect(self._segment_go)
        hsplit.addWidget(self.inspector)
        hsplit.setStretchFactor(0, 0)
        hsplit.setStretchFactor(1, 1)
        hsplit.setStretchFactor(2, 0)
        hsplit.setSizes([360, 760, 340])

        self.timeline = TimelinePanel()
        tl = self.timeline.canvas
        tl.seek.connect(self.player.seek)
        tl.selected.connect(self._tl_pick)
        tl.moved.connect(self._tl_moved)
        tl.resized.connect(self._tl_resized)
        tl.edit_done.connect(lambda _id: self._commit_drag())
        tl.trimmed.connect(self._trimmed)
        tl.delete_requested.connect(self.delete_element)
        tl.duplicate_requested.connect(self.duplicate_element)
        tl.dropped.connect(self._dropped_on_timeline)
        tl.edit_subs.connect(self._edit_subs)
        tl.cut_here.connect(self._cut_here)
        tl.segment_delete.connect(self._segment_delete)
        tl.cut_side.connect(self._cut_side)
        tl.cuts_reset.connect(self._cuts_reset)
        tl.segment_trimmed.connect(self._segment_trimmed)
        vsplit.addWidget(self.timeline)
        vsplit.setStretchFactor(0, 1)
        vsplit.setStretchFactor(1, 0)
        vsplit.setSizes([620, 290])

        # ---- keyboard
        keys = (("Space", self._play_clicked), ("Ctrl+Z", self.undo), ("Ctrl+Y", self.redo),
                ("Ctrl+Shift+Z", self.redo), ("Delete", self._delete_key),
                ("Ctrl+C", self._copy), ("Ctrl+V", self._paste), ("Ctrl+D", lambda: self.sel and self.duplicate_element(self.sel)),
                ("Left", lambda: self._step(-1 / 30)), ("Right", lambda: self._step(1 / 30)),
                ("Shift+Left", lambda: self._step(-1.0)), ("Shift+Right", lambda: self._step(1.0)),
                ("Home", lambda: self.player.seek(0.0)), ("End", lambda: self.player.seek(self.player.total())),
                ("Escape", lambda: self._pick("")), ("PgUp", lambda: self._go(-1)), ("PgDown", lambda: self._go(1)),
                ("Ctrl+E", self._export), ("S", self._cut_here), ("Ctrl+B", self._cut_here))
        self._shortcuts = []
        for key, fn in keys:
            sc = QShortcut(QKeySequence(key), self, activated=fn)
            sc.setContext(Qt.WindowShortcut)
            self._shortcuts.append(sc)

    def _build_exact_page(self) -> QWidget:
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(0, 0, 0, 0)
        bar = QFrame()
        bar.setObjectName("Panel")
        bl = QHBoxLayout(bar)
        bl.setContentsMargins(10, 4, 6, 4)
        lab = QLabel("👁 " + tr("st_exact_mode"))
        lab.setStyleSheet(f"color: {theme.ACCENT_2}; font-weight: 600;")
        bl.addWidget(lab, 1)
        b = QPushButton("✕ " + tr("st_exact_back"))
        b.setObjectName("Flat")
        b.clicked.connect(self._exact_close)
        bl.addWidget(b)
        v.addWidget(bar)
        self._exact_box = QVBoxLayout()
        v.addLayout(self._exact_box, 1)
        self._exact_player = None
        return w

    # =================================================================== loading a clip
    def load(self, ref, moment: dict, words: list, src: Optional[dict], fmt: str = "", nav: tuple = (0, 0)) -> None:
        """Show a clip (moment: the dict of the list, changed in place by the Studio)."""
        same = self.moment is moment and self.ref is ref
        self._save_now()
        self._exact_close()
        self.ref = ref
        self.moment = moment
        self.words = list(words or [])
        self.prof = profiles.for_vod(self.cfg, getattr(ref, "meta", {}) or {})
        self.m = montage.effective(moment, self.cfg)
        self._nav_info = nav
        if not same:
            self._undo, self._redo = [], []
            self.sel = ""
            self.player.pause()
            self.player.pos = 0.0
        if fmt:
            self.fmt = fmt
        self.fmt_v.setChecked(self.fmt == "vertical")
        self.fmt_h.setChecked(self.fmt != "vertical")
        self.library.set_cards(any(h.get("card") for h in moment.get("fx") or []))
        self.library.set_music(self.m.get("music") or "")
        self.set_source(src)
        self._update_title()
        self._update_undo_buttons()
        self._rebuild(sound=True)
        if not self.sel:
            self.inspector.set_clip(self.moment, self.m)
        if not same:
            self._ai_waiting = ""
            self.btn_auto.setEnabled(True)
            self._maybe_ai_first()

    def _maybe_ai_first(self) -> None:
        """A clip that was never edited and that the AI has not read yet (analysed before 1.3.1, or the AI was
        down): ask the AI now; its memes replace the automatic cues if the clip is still untouched when it answers."""
        from .. import montage_ai
        if self.moment is None or not self._ai_available() or isinstance(self.moment.get("montage"), dict):
            return
        if montage_ai.valid(self.moment.get("montage_ai"), self.moment) or self.moment.get("montage_ai_tried"):
            return
        self.moment["montage_ai_tried"] = True
        self._ai_waiting = self.moment.get("id")
        self.btn_auto.setEnabled(False)
        self._set_status(tr("st_ai_working"), 0)
        self.host.studio_montage_ai(self.moment, self._ai_first_done)

    def _ai_first_done(self, mid: str, plan: Optional[dict], err: str) -> None:
        self._ai_waiting = ""
        self.btn_auto.setEnabled(True)
        if self.moment is None or self.moment.get("id") != mid:
            return
        if plan is None:
            self._set_status(tr("st_ai_failed", err=err or "?"), 8000)
            return
        self.moment["montage_ai"] = plan
        if self._undo or not self.m.get("auto"):
            return                       # the user started editing meanwhile: the plan waits for ✨ Montage auto
        self._apply_auto()
        self._undo.clear()
        self._update_undo_buttons()

    def set_source(self, src: Optional[dict]) -> None:
        """The stream video covering the clip (None while it downloads)."""
        if src is not None and self.moment is not None:
            a, b = float(self.moment["start"]), float(self.moment["end"])
            if not src.get("full") and not (src["vod_start"] <= a + 0.05 and src["vod_start"] + src["duration"] >= b - 0.05):
                src = None
        changed = (src or {}).get("path") != (self.src or {}).get("path")
        self.src = src
        if src is None:
            self.canvas.set_message(tr("st_loading_video"))
            self.player.set_source(None)
            if self.moment is not None and self.host is not None and hasattr(self.host, "studio_segment"):
                self.host.studio_segment(float(self.moment["start"]), float(self.moment["end"]))
            return
        self.canvas.set_message("")
        if changed:
            self.src_info = _src_info(src["path"])
            self.timeline.canvas.set_source(src)
            self._rebuild(sound=False)
            self.player.set_source(src)

    def set_words(self, words: list) -> None:
        """The transcript arrived (or changed): new subtitles."""
        self.words = list(words or [])
        self._changed(sound=True, edit=False)

    def set_format(self, fmt: str) -> None:
        self.fmt = fmt
        self.fmt_v.setChecked(fmt == "vertical")
        self.fmt_h.setChecked(fmt != "vertical")
        self._rebuild(sound=False)

    def _update_title(self) -> None:
        m = self.moment or {}
        i, n = self._nav_info
        pos = f"  ·  {i}/{n}" if n else ""
        self.title_lbl.setText(f"🎬 {m.get('title') or tr('st_untitled')}{pos}")
        self.setWindowTitle(f"FireClips Studio — {m.get('title') or ''}")
        self.btn_prev.setEnabled(i > 1)
        self.btn_next.setEnabled(bool(n) and i < n)

    # =================================================================== the composition
    def _design_info(self) -> dict:
        info = dict(self.src_info or {"width": 1920, "height": 1080})
        w, h = float(info.get("width") or 1920), float(info.get("height") or 1080)
        if h < 1000:           # small preview video: the picture is still drawn at the full preview size
            info["width"], info["height"] = int(round(w * 1080 / h)), 1080
        return info

    def _rebuild(self, sound: bool = True) -> None:
        if self.moment is None:
            return
        try:
            mo = dict(self.moment)
            comp = preview.Composition(mo, self.m, self.words, self.cfg, self.fmt, self._design_info(), self.prof,
                                       language())
        except Exception as e:  # noqa: BLE001
            log.exception("studio composition: %s", e)
            return
        if comp.total < 0.3:
            return
        self.comp = comp
        self.player.set_comp(comp, mo, sound=False)
        self.canvas.set_comp(comp)
        self.timeline.canvas.set_comp(comp, self.cfg)
        self.timeline._sync()
        self._fit_timeline()
        self.canvas.set_selected(self.sel)
        if not self.timeline.canvas.sel.startswith("seg:") or self.sel:
            self.timeline.canvas.set_selected(self.sel)
        self._update_time(self.player.position())
        e = self._el(self.sel)
        if e is not None:
            self.inspector.set_time(self._o_of(e))
        if sound:
            self._sound_timer.start()

    def _rebuild_sound(self) -> None:
        if self.comp is not None:
            self.player.audio.rebuild(self.comp, self.src, dict(self.moment or {}))

    def _fit_timeline(self) -> None:
        """Make the timeline tall enough to show all its tracks (more lanes when things overlap), taking
        the room from the picture as long as the picture stays big enough. Never makes it smaller: the
        size the user gave it is kept. When even that is not enough, the timeline scrolls."""
        sizes = self.vsplit.sizes()
        if len(sizes) != 2 or sum(sizes) <= 0:
            return
        top, bottom = sizes
        need = self.timeline.wanted_height()
        if bottom >= need:
            return
        grow = min(need - bottom, max(0, top - 430))
        if grow > 0:
            self.vsplit.setSizes([top - grow, bottom + grow])

    def _changed(self, key: str = "", sound: bool = True, now: bool = True, edit: bool = True) -> None:
        """Something changed: show it, keep it. edit=False: only the clip range / title changed (an
        automatic edit list stays automatic: it is made again for the new range)."""
        if edit:
            self.m["auto"] = False
            self._dirty.add("montage")
        if now:
            self._rebuild(sound=False)
        else:
            self._rebuild_timer.start()
        if sound:
            self._sound_timer.start()
        self._save_timer.start()

    def _snapshot(self) -> dict:
        mo = self.moment or {}
        return {"m": copy.deepcopy(self.m), "start": mo.get("start"), "end": mo.get("end"), "title": mo.get("title")}

    def _push_undo(self, key: str = "") -> None:
        now = time.monotonic()
        if key and self._undo_key[0] == key and now - self._undo_key[1] < 2.0:
            self._undo_key = (key, now)
            return
        self._undo_key = (key, now)
        self._undo.append(self._snapshot())
        if len(self._undo) > 120:
            self._undo.pop(0)
        self._redo.clear()
        self._update_undo_buttons()

    def _restore(self, snap: dict) -> None:
        mo = self.moment
        if mo is None:
            return
        self.m = copy.deepcopy(snap["m"])
        range_changed = (mo.get("start"), mo.get("end")) != (snap["start"], snap["end"])
        if range_changed:
            mo["start"], mo["end"] = snap["start"], snap["end"]
            self._dirty.add("range")
            self._reload_words()
        if snap.get("title") != mo.get("title"):
            mo["title"] = snap.get("title")
            self._dirty.add("title")
            self._update_title()
        if self.sel and self._el(self.sel) is None:
            self.sel = ""
        self._changed(edit=not self.m.get("auto"))
        self._show_selection()

    def undo(self) -> None:
        if not self._undo:
            return
        self._redo.append(self._snapshot())
        self._restore(self._undo.pop())
        self._undo_key = ("", 0.0)
        self._update_undo_buttons()

    def redo(self) -> None:
        if not self._redo:
            return
        self._undo.append(self._snapshot())
        self._restore(self._redo.pop())
        self._undo_key = ("", 0.0)
        self._update_undo_buttons()

    def _update_undo_buttons(self) -> None:
        self.btn_undo.setEnabled(bool(self._undo))
        self.btn_redo.setEnabled(bool(self._redo))

    # =================================================================== saving (through the main window)
    def _save(self) -> None:
        if self.moment is None or not self._dirty:
            return
        what, self._dirty = set(self._dirty), set()
        if "montage" in what:
            self.moment["montage"] = copy.deepcopy(montage.normalize(self.m))
        if self.host is not None and hasattr(self.host, "studio_saved"):
            try:
                self.host.studio_saved(self.moment, what)
            except Exception as e:  # noqa: BLE001
                log.warning("studio save: %s", e)

    def _save_now(self) -> None:
        if self._save_timer.isActive():
            self._save_timer.stop()
        self._save()

    # =================================================================== picking
    def _el(self, eid: str) -> Optional[dict]:
        if not eid:
            return None
        return next((e for e in self.m["elements"] if e["id"] == eid), None)

    def _o_of(self, e: dict) -> float:
        if self.comp is None:
            return 0.0
        o = montage.map_first(self.comp.pl.pieces, e["t"])
        return o if o is not None else 0.0

    def _pick(self, eid: str) -> None:
        if eid in ("subs", "music"):
            self.sel = ""
            self.canvas.set_selected("")
            self.timeline.canvas.set_selected(eid)
            self.inspector.set_clip(self.moment, self.m)
            if eid == "music":
                self.library.show_page("music")
            return
        if eid.startswith("seg:"):
            self.sel = ""
            self.canvas.set_selected("")
            self.timeline.canvas.set_selected(eid)
            self._show_segment(int(eid[4:]))
            return
        self.sel = eid or ""
        if not eid:
            self.timeline.canvas.set_selected("")
        self._show_selection()

    # =================================================================== cuts: the kept parts of the video
    def _segments(self) -> list:
        mo = self.moment or {}
        return [list(x) for x in montage.segments_in(float(mo.get("start", 0)), float(mo.get("end", 1)),
                                                     self.m.get("segments"))]

    def _show_segment(self, i: int) -> None:
        segs = self._segments()
        if not segs:
            return
        i = max(0, min(len(segs) - 1, i))
        self.timeline.canvas.set_selected(f"seg:{i}")
        self.inspector.set_segment(i, segs, self._segment_speed_of(i))

    def _selected_segment(self) -> Optional[int]:
        return self.timeline.canvas.selected_segment()

    def _delete_key(self) -> None:
        i = self._selected_segment()
        if i is not None:
            self._segment_delete(i)
        elif self.sel:
            self.delete_element(self.sel)

    def _set_segments(self, segs: Optional[list], pick: Optional[int] = None) -> None:
        """Keep these parts of the video (None = the whole clip), one undo step."""
        self._push_undo()
        self.m["segments"] = montage.clean_segments(segs) if segs else None
        if self.m["segments"] is not None and len(self.m["segments"]) == 1:
            mo = self.moment or {}
            k0, k1 = self.m["segments"][0]
            if abs(k0 - float(mo["start"])) < 0.02 and abs(k1 - float(mo["end"])) < 0.02:
                self.m["segments"] = None             # the whole clip: nothing to keep in the edit list
        self._changed()
        if pick is None:
            self._pick("")
        else:
            self._show_segment(pick)

    def _cut_here(self) -> None:
        """✂ at the red line: the video is cut in two kept parts (delete one, drag their edges)."""
        if self.moment is None or self.comp is None:
            return
        t = self._here()
        segs = montage.split_segments(self.moment, self.m, t)
        if segs is None:
            self._set_status(tr("st_cut_nowhere"))
            return
        i = montage.segment_at(dict(self.moment), dict(self.m, segments=segs), t + 0.01)
        self._set_segments(segs, pick=i)
        self._set_status(tr("st_cut_done", at=fmt_time(self.player.position(), 1)), 6000)

    def _segment_delete(self, i: int) -> None:
        segs = self._segments()
        if len(segs) < 2 or not (0 <= i < len(segs)):
            self._set_status(tr("st_seg_last"))
            return
        k0, k1 = segs[i]
        del segs[i]
        self._set_segments(segs, pick=min(i, len(segs) - 1))
        self._set_status(tr("st_seg_deleted", len=fmt_time(k1 - k0, 1)), 6000)

    def _cut_side(self, side: str) -> None:
        """Remove everything before / after the red line."""
        if self.moment is None or self.comp is None:
            return
        t = self._here()
        mo = self.moment
        segs = self._segments()
        out = []
        for k0, k1 in segs:
            if side == "before":
                if k1 <= t + montage.MIN_SEGMENT:
                    continue
                out.append([max(k0, round(t, 3)), k1])
            else:
                if k0 >= t - montage.MIN_SEGMENT:
                    continue
                out.append([k0, min(k1, round(t, 3))])
        out = [x for x in out if x[1] - x[0] >= montage.MIN_SEGMENT]
        if not out or out == segs:
            self._set_status(tr("st_cut_nowhere"))
            return
        total = sum(k1 - k0 for k0, k1 in out)
        self._set_segments(out, pick=0 if side == "before" else len(out) - 1)
        self._set_status(tr("st_cut_side_done", len=fmt_time(float(mo["end"]) - float(mo["start"]) - total, 1)), 6000)

    def _cuts_reset(self) -> None:
        if self.m.get("segments") is None:
            return
        self._set_segments(None)
        self._set_status(tr("st_cuts_reset_done"))

    def _segment_trimmed(self, i: int, side: str, delta: float) -> None:
        """An inner edge of a kept part was dragged (delta: clip seconds, + = to the right)."""
        segs = self._segments()
        if not (0 <= i < len(segs)):
            return
        mo = self.moment
        a, b = float(mo["start"]), float(mo["end"])
        k0, k1 = segs[i]
        if side == "left":
            lo = segs[i - 1][1] if i > 0 else a
            new = min(max(k0 + delta, lo), k1 - montage.MIN_SEGMENT)
            segs[i][0] = round(new, 3)
        else:
            hi = segs[i + 1][0] if i + 1 < len(segs) else b
            new = max(min(k1 + delta, hi), k0 + montage.MIN_SEGMENT)
            segs[i][1] = round(new, 3)
        self._set_segments(segs, pick=i)

    def _segment_speed_of(self, i: int) -> float:
        segs = self._segments()
        if not (0 <= i < len(segs)):
            return 1.0
        k0, k1 = segs[i]
        for e in self.m["elements"]:
            if e["kind"] == "slowmo" and abs(e["t"] - k0) < 0.05 and abs(e["t"] + e["dur"] - k1) < 0.05:
                return float(e.get("speed") or 0.5)
        return 1.0

    def _segment_speed(self, i: int, speed: float) -> None:
        """The speed of a whole kept part: a slow motion / fast forward effect covering it."""
        segs = self._segments()
        if not (0 <= i < len(segs)):
            return
        k0, k1 = segs[i]
        self._push_undo()
        self.m["elements"] = [e for e in self.m["elements"]
                              if not (e["kind"] == "slowmo" and abs(e["t"] - k0) < 0.05 and abs(e["t"] + e["dur"] - k1) < 0.05)]
        if abs(speed - 1.0) > 0.01:
            self.m["elements"].append(montage.element("slowmo", k0, dur=round(k1 - k0, 3), speed=speed))
        self._changed()
        self._show_segment(i)
        self._set_status(tr("st_seg_speed_set", speed=f"{speed:g}") if abs(speed - 1.0) > 0.01 else tr("st_seg_speed_normal"))

    def _segment_go(self, i: int) -> None:
        segs = self._segments()
        if 0 <= i < len(segs) and self.comp is not None:
            o = montage.map_first(self.comp.pl.pieces, segs[i][0])
            if o is not None:
                self.player.seek(o + 0.02)

    def _tl_pick(self, eid: str) -> None:
        """Picked on the timeline: when it is not on the picture right now, the red line goes to it (so
        it can be seen, moved and sized on the picture)."""
        self._pick(eid)
        e = self._el(self.sel)
        if e is None or self.comp is None or self.player.playing:
            return
        o0, o1 = self._span(e)
        pos = self.player.position()
        if not (o0 - 1e-3 <= pos < o1):
            self.player.seek(min(o1 - 0.02, o0 + min(0.35, (o1 - o0) * 0.4)))

    def _span(self, e: dict) -> tuple[float, float]:
        """Clip times where an element starts and ends (its main occurrence)."""
        comp = self.comp
        o0 = self._o_of(e)
        best = None
        for e2, oo, d in comp.visuals:          # (twice with a cold open: the main one is wanted)
            if e2["id"] == e["id"] and (best is None or abs(oo - o0) < abs(best[0] - o0)):
                best = (oo, d)
        if best is not None:
            return best[0], best[0] + max(0.05, best[1])
        try:
            ln = self.timeline.canvas._length(e, o0)
        except Exception:  # noqa: BLE001
            ln = float(e.get("dur") or 1.0)
        return o0, min(comp.total, o0 + max(0.05, ln))

    def _show_selection(self) -> None:
        self.canvas.set_selected(self.sel)
        e = self._el(self.sel)
        if e is None:
            self.sel = ""
            i = self._selected_segment()
            if i is not None and i < len(self._segments()):
                self._show_segment(i)             # a kept part of the video stays picked
            else:
                self.timeline.canvas.set_selected("")
                self.inspector.set_clip(self.moment, self.m)
        else:
            self.timeline.canvas.set_selected(self.sel)
            self.inspector.set_element(e, self._o_of(e))

    # =================================================================== adding things
    def _here(self) -> float:
        """VOD time under the red line (inside the clip)."""
        mo = self.moment or {}
        a, b = float(mo.get("start", 0)), float(mo.get("end", 1))
        t = None
        if self.comp is not None:
            t = self.comp.vod_time(self.player.position())
        if t is None:
            t = a + min(2.0, (b - a) / 3)
        return min(max(a, t), b - 0.3)

    def _vod_at(self, o: float) -> float:
        comp = self._drag_comp or self.comp
        mo = self.moment or {}
        a, b = float(mo.get("start", 0)), float(mo.get("end", 1))
        t = comp.vod_time(o) if comp is not None else None
        if t is None:
            t = a
        return min(max(a, t), b - 0.1)

    def _next_pos(self) -> tuple[float, float]:
        p = NEXT_POS[self._pos_i % len(NEXT_POS)]
        self._pos_i += 1
        return p

    def _place_free(self, e: dict) -> None:
        """Put a new picture (emoji, sticker, text) where it hides nothing already on screen at that time:
        the first free spot of a short list, else the least covered one."""
        comp = self.comp
        spots = list(SPOTS.get(e["kind"]) or [])
        if not spots:
            return
        if e["kind"] == "emoji":            # not always the same place for emojis added one after the other
            k = self._pos_i % len(NEXT_POS)
            self._pos_i += 1
            spots = NEXT_POS[k:] + NEXT_POS[:k] + spots[len(NEXT_POS):]
        e["x"], e["y"] = spots[0]
        if comp is None:
            return
        try:
            frames, _at = comp._source(e, slow_ok=False)
            o = comp.clip_time(e["t"])
            if not frames or o is None:
                return
            size = (max(f[0].width for f in frames), max(f[0].height for f in frames))
            dur = float(e.get("dur") or montage.DEFAULT_DUR.get(e["kind"], 2.0) or 2.0)
            taken = self._taken(o, dur)
            if not taken:
                return
            best, best_cost = spots[0], None
            for i, (x, y) in enumerate(spots):
                r = self._rect_at(e, size, x, y)
                cover = sum(_inter(r, t2) for t2 in taken) / max(1.0, r[2] * r[3])
                if cover < 0.04:
                    best = (x, y)
                    break
                cost = cover + 0.01 * i
                if best_cost is None or cost < best_cost:
                    best, best_cost = (x, y), cost
            e["x"], e["y"] = best
        except Exception as ex:  # noqa: BLE001 - placing is only a nicety
            log.info("free spot: %s", ex)

    def _rect_at(self, e: dict, size: tuple, x: float, y: float) -> tuple:
        """Where the picture of e (w x h) rests on the frame when centred on (x, y)."""
        w0, h0 = size
        anim = e.get("anim") or montage.DEFAULT_ANIM.get(e["kind"], "pop")
        cw, ch = montage.sprite_canvas(w0, h0, anim, float(e.get("rot") or 0.0), e["kind"] == "emoji" and anim == "pop")
        X, Y = montage.place(dict(e, x=x, y=y), cw, ch, self.comp.ctx)
        return (X + (cw - w0) / 2, Y + (ch - h0) / 2, w0, h0)

    def _taken(self, o: float, dur: float) -> list[tuple]:
        """Rectangles (x, y, w, h) of the pictures and subtitles on screen between clip times o and o + dur."""
        comp = self.comp
        out = []
        for e2, o0, d in comp.visuals:
            if e2["kind"] not in ("emoji", "image", "text", "killcard") or o0 >= o + dur or o0 + d <= o:
                continue
            frames, _at = comp._source(e2, slow_ok=False)
            if not frames:
                if e2["kind"] == "killcard":            # not drawn yet: about where it goes
                    gx, gy, gw, gh = comp.game
                    out.append((comp.W * 0.04, gy + gh * 0.06, comp.W * 0.92, comp.H * 0.1) if comp.vertical
                               else (comp.W * 0.03, comp.H * 0.05, comp.W * 0.42, comp.H * 0.2))
                continue
            box = comp.element_box(e2)
            if box is None:
                continue
            cw, ch, X, Y = box
            w0, h0 = max(f[0].width for f in frames), max(f[0].height for f in frames)
            out.append((X + (cw - w0) / 2, Y + (ch - h0) / 2, w0, h0))
        subs = comp.subtitles()
        lk = subs.look
        if lk is not None:
            evs = [(i, ev) for i, ev in enumerate(subs.events) if not (ev.start >= o + dur or ev.end <= o)]
            if len(evs) > 12:                          # a sample is enough (the cards are about the same size)
                evs = evs[::len(evs) // 12 + 1] + evs[-1:]
            for i, ev in evs:
                im = subs.picture(i)
                if im is not None:
                    x, y = (lk.x, lk.ty) if ev.title else (lk.x, lk.y)
                    out.append((x - im.width / 2, y - im.height / 2, im.width, im.height))
        return out

    # ---- memes from the internet that are not downloaded yet
    def _needs_download(self, ref: str) -> bool:
        return bool(ref) and ref.startswith("web:") and bank.resolve(ref, self.cfg) is None

    def _fetch_then(self, ref: str, then, item: str = "") -> None:
        """Download a meme of the internet bank now, then do what was asked with it."""
        if self.host is None or not hasattr(self.host, "bank_get"):
            return
        name = bank.display_name(ref)
        self._set_status("⬇ " + tr("st_bank_getting", name=name), 0)
        self.library.loading_item = item
        self.library.set_playing(self.library.playing_item)

        def done(path):
            if self.library.loading_item == item:
                self.library.loading_item = ""
                self.library.set_playing(self.library.playing_item)
            if path:
                self._set_status("")
                then(path)
            else:
                self._set_status("⚠ " + tr("st_bank_get_failed", name=name), 10000)
        self.host.bank_get(ref, done)

    def add_item(self, item: str, t: Optional[float] = None, pos: Optional[tuple] = None) -> None:
        """Put a library thing in the clip (at the red line, or at VOD time t / position pos)."""
        if self.moment is None or not item:
            return
        kind, _s, rest = item.partition(":")
        t = self._here() if t is None else t
        if kind in ("sound", "image", "video") and self._needs_download(rest):
            self._fetch_then(rest, lambda _p, t=t: self.add_item(item, t, pos), item)
            return
        g = montage.new_id()
        snd = bool(self.cfg.get("montage_fx_sounds", True))
        els: list[dict] = []
        xy = {}
        if pos is not None:
            xy = {"x": pos[0], "y": pos[1]}
        if kind == "emoji":
            els.append(montage.element("emoji", t, dur=1.7, file=f"emoji:{rest}", **xy))
        elif kind == "sound":
            els.append(montage.element("sound", t, file=rest))
        elif kind == "image":
            els.append(montage.element("image", t, dur=2.2, file=rest, **(xy or {"x": 0.5, "y": 0.45})))
        elif kind == "video":
            chroma = looks_green_file(bank.resolve(rest, self.cfg))
            els.append(montage.element("video", t, file=rest, chroma=chroma, duck=True, **(xy or {"x": 0.5, "y": 0.5})))
        elif kind == "text":
            style, _s2, more = rest.partition("|")
            color, _s3, text = more.partition("|")
            els.append(montage.element("text", t, dur=2.4, text=text or tr("lib_text_default"), style=style or "classic",
                                       color=color or None, **(xy or {"x": 0.5, "y": 0.2})))
        elif kind == "fx":
            fx = fxlib.EFFECTS.get(rest)
            if fx is None:
                return
            extra = dict(xy) if fx.get("pos") else {}
            if fx.get("text"):
                extra["text"] = fxlib.default_effect_text(rest, language(),
                                                          profiles.display_name(self.prof, getattr(self.ref, "meta", {})))
            if fx.get("emoji"):
                extra["file"] = "emoji:1f602"
            els.append(montage.element("fx", t, effect=rest, dur=fx["dur"], group=g, **extra))
            if snd and fx.get("sound") and bank.resolve(fx["sound"], self.cfg) is not None:
                els.append(montage.element("sound", t, file=fx["sound"], vol=90, group=g))
        elif kind == "edit":
            els += self._edit_effect(rest, t, g, snd)
        elif kind == "music":
            self._use_music(rest)
            return
        els = [e for e in els if e]
        if not els:
            return
        if not xy and els[0]["kind"] in SPOTS:
            self._place_free(els[0])
        self._push_undo()
        self.m["elements"].extend(els)
        self.m = montage.normalize(self.m)
        self.sel = els[0]["id"]
        self._changed()
        self._show_selection()
        self._set_status(tr("st_added", what=self._label(els[0])))

    def _edit_effect(self, kind: str, t: float, g: str, snd: bool) -> list[dict]:
        from .. import memebank
        els = []
        boom = memebank.auto_sound("kill")
        scratch = memebank.auto_sound("freeze")
        if kind == "zoom":
            els.append(montage.element("zoom", t, dur=1.1, amount=1.35, group=g))
            if snd and boom and bank.resolve(boom, self.cfg) is not None:
                els.append(montage.element("sound", t, file=boom, vol=85, group=g))
        elif kind == "slowmo":
            els.append(montage.element("slowmo", max(float(self.moment["start"]), t - 0.3), dur=2.0, speed=0.5, group=g))
        elif kind == "fast":
            els.append(montage.element("slowmo", t, dur=4.0, speed=2.0, group=g))
        elif kind == "freeze":
            els.append(montage.element("freeze", t, dur=1.2, group=g))
            if snd and scratch and bank.resolve(scratch, self.cfg) is not None:
                els.append(montage.element("sound", t, file=scratch, vol=90, group=g))
        elif kind == "shake":
            els.append(montage.element("shake", t, dur=0.8, group=g))
        elif kind == "bleep":
            els.append(montage.element("bleep", t, dur=0.5, group=g))
        elif kind == "killcard":
            cards = [h for h in (self.moment or {}).get("fx") or [] if h.get("card")]
            if cards:
                h = min(cards, key=lambda c: abs(float(c["t"]) - t))
                els.append(montage.element("killcard", float(h["t"]) + 0.1, dur=3.4, card=h["card"], group=g))
        return els

    @staticmethod
    def _label(e: dict) -> str:
        from .studio_timeline import element_label
        return element_label(e)

    def _dropped_on_canvas(self, item: str, x: float, y: float) -> None:
        self.add_item(item, pos=(x, y))

    def _dropped_on_timeline(self, item: str, o: float, _track: str) -> None:
        self.add_item(item, t=self._vod_at(o))

    def _use_music(self, ref: str) -> None:
        if self.moment is None:
            return
        if self._needs_download(ref):
            self._fetch_then(ref, lambda _p: self._use_music(ref))
            return
        self._push_undo()
        self.m["music"] = ref or ""
        if ref and not self.m.get("music_vol"):
            self.m["music_vol"] = int(self.cfg.get("montage_music_vol") or 18)
        self.library.set_music(ref)
        self._changed()
        if not self.sel:
            self.inspector.set_clip(self.moment, self.m)
        self._set_status(tr("st_music_set", name=bank.display_name(ref)) if ref else tr("st_music_removed"))

    # =================================================================== changing things
    def delete_element(self, eid: str) -> None:
        e = self._el(eid)
        if e is None:
            return
        self._push_undo()
        g = e.get("group")
        # the sound that came with an effect goes with it
        self.m["elements"] = [x for x in self.m["elements"] if x["id"] != eid and not (
            g and x.get("group") == g and x["kind"] == "sound" and e["kind"] != "sound")]
        if self.sel == eid:
            self.sel = ""
        self._changed()
        self._show_selection()

    def duplicate_element(self, eid: str) -> None:
        e = self._el(eid)
        if e is None:
            return
        self._push_undo()
        d = copy.deepcopy(e)
        d["id"] = montage.new_id()
        d.pop("group", None)
        d.pop("auto", None)
        ln = float(e.get("dur") or 1.0)
        d["t"] = round(min(float(self.moment["end"]) - 0.3, e["t"] + ln), 3)
        self.m["elements"].append(d)
        self.m = montage.normalize(self.m)
        self.sel = d["id"]
        self._changed()
        self._show_selection()

    def _copy(self) -> None:
        e = self._el(self.sel)
        if e is not None:
            self._clipboard = copy.deepcopy(e)
            self._set_status(tr("st_copied"))

    def _paste(self) -> None:
        if self._clipboard is None or self.moment is None:
            return
        self._push_undo()
        d = copy.deepcopy(self._clipboard)
        d["id"] = montage.new_id()
        d.pop("group", None)
        d["t"] = round(self._here(), 3)
        self.m["elements"].append(d)
        self.m = montage.normalize(self.m)
        self.sel = d["id"]
        self._changed()
        self._show_selection()

    def _element_changed(self, key: str) -> None:
        self._push_undo(key)
        self.m = montage.normalize(self.m)
        e = self._el(self.sel)
        self._changed(sound=any(x in key for x in ("vol", "duck", "dur", "file", "speed", "freeze")) or
                      (e is not None and e["kind"] in ("sound", "video", "slowmo", "freeze", "bleep", "fx")))
        e = self._el(self.sel)
        if e is not None:
            self.inspector.e = e
            if key.endswith(":style") or key.endswith(":anim"):
                self.inspector.set_element(e, self._o_of(e))

    def _clip_changed(self, key: str) -> None:
        self._push_undo("clip:" + key)
        self.m = montage.normalize(self.m)
        if key == "music":
            self.library.set_music(self.m.get("music") or "")
        self._changed(sound=key in ("jumpcuts", "cold_open", "bleep", "music", "music_vol"))
        self.inspector.m = self.m

    def _nudge(self, eid: str, d: float) -> None:
        e = self._el(eid)
        if e is None:
            return
        self._push_undo(f"{eid}:nudge")
        mo = self.moment
        e["t"] = round(min(float(mo["end"]) - 0.1, max(float(mo["start"]), e["t"] + d)), 3)
        e.pop("auto", None)
        self._changed()
        self.inspector.set_time(self._o_of(e))

    # ---- dragging on the picture / the timeline (one undo step per drag)
    def _begin_drag(self) -> None:
        if self._drag_comp is None:
            self._push_undo()
            self._drag_comp = self.comp

    def _commit_drag(self) -> None:
        self._drag_comp = None
        self.m = montage.normalize(self.m)
        self._changed(sound=True)
        self._show_selection()

    def _canvas_moved(self, eid: str, x: float, y: float) -> None:
        e = self._el(eid)
        if e is None:
            return
        self._begin_drag()
        e["x"], e["y"] = x, y
        e.pop("auto", None)
        self._changed(sound=False, now=False)

    def _canvas_resized(self, eid: str, factor: float) -> None:
        e = self._el(eid)
        if e is None:
            return
        if self._drag_comp is None:
            self._size0 = float(e.get("size") or montage.DEFAULT_SIZE.get(e["kind"], 1.0))
        self._begin_drag()
        e["size"] = round(max(0.03, min(3.0, self._size0 * factor)), 4)
        e.pop("auto", None)
        self._changed(sound=False, now=False)

    def _canvas_turned(self, eid: str, rot: float) -> None:
        e = self._el(eid)
        if e is None:
            return
        self._begin_drag()
        if rot:
            e["rot"] = rot
        else:
            e.pop("rot", None)
        e.pop("auto", None)
        self._changed(sound=False, now=False)

    def _tl_moved(self, eid: str, o: float) -> None:
        e = self._el(eid)
        if e is None:
            return
        self._begin_drag()
        e["t"] = round(self._vod_at(o), 3)
        e.pop("auto", None)
        self._changed(sound=False, now=False)

    def _tl_resized(self, eid: str, o0: float, ln: float) -> None:
        e = self._el(eid)
        if e is None:
            return
        self._begin_drag()
        t0 = self._vod_at(o0)
        if e["kind"] == "slowmo":
            comp = self._drag_comp or self.comp
            end_v = comp.vod_time(o0 + ln) if comp is not None else None
            sp = float(e.get("speed") or 0.5)
            e["dur"] = round(max(0.2, (end_v - t0) if end_v is not None and end_v > t0 else ln * sp), 3)
        else:
            e["dur"] = round(max(0.1, ln), 3)
        e["t"] = round(t0, 3)
        e.pop("auto", None)
        self._changed(sound=False, now=False)

    # ---- the clip: start / end, title, cold open hook, subtitles
    def _set_range(self, a: float, b: float) -> None:
        mo = self.moment
        if mo is None or b - a < 1.0:
            return
        if abs(a - float(mo["start"])) < 0.005 and abs(b - float(mo["end"])) < 0.005:
            return
        self._push_undo("range")
        segs = self.m.get("segments")
        if segs:
            # the parts touching the old edges follow the new edges (a longer clip shows the new part)
            if abs(segs[0][0] - float(mo["start"])) < 0.05:
                segs[0][0] = round(a, 3)
            if abs(segs[-1][1] - float(mo["end"])) < 0.05:
                segs[-1][1] = round(b, 3)
            self.m["segments"] = montage.clean_segments([[max(a, k0), min(b, k1)] for k0, k1 in segs])
        mo["start"], mo["end"] = round(a, 2), round(b, 2)
        self._dirty.add("range")
        self._reload_words()
        if self.m.get("auto"):
            self.m = montage.effective(dict(mo, montage=None), self.cfg)
        if self.src is not None and not self.src.get("full") and not (
                self.src["vod_start"] <= a + 0.05 and self.src["vod_start"] + self.src["duration"] >= b - 0.05):
            self.set_source(None)
        self._changed(edit=False)
        if not self.sel:
            self.inspector.set_clip(mo, self.m)

    def _trimmed(self, side: str, delta: float) -> None:
        mo = self.moment
        if mo is None or self.comp is None:
            return
        a, b = float(mo["start"]), float(mo["end"])
        if side == "start":
            if delta >= 0:
                a = a - delta
            else:
                v = self.comp.vod_time(-delta)
                a = v if v is not None else a - delta
        else:
            if delta >= 0:
                b = b + delta
            else:
                v = self.comp.vod_time(self.comp.total + delta)
                b = v if v is not None else b + delta
        a = max(0.0, a)
        if b - a < 1.0:
            return
        self._set_range(a, b)
        self._set_status(tr("st_range_set", start=fmt_time(a, 1), end=fmt_time(b, 1)))

    def _reset_range(self) -> None:
        mo = self.moment
        if mo is None or not mo.get("orig"):
            return
        self._set_range(float(mo["orig"][0]), float(mo["orig"][1]))
        self.inspector.set_clip(mo, self.m)

    def _set_title(self, title: str) -> None:
        mo = self.moment
        if mo is None or title == (mo.get("title") or ""):
            return
        self._push_undo("title")
        mo["title"] = title
        self._dirty.add("title")
        self._update_title()
        self._changed(sound=False, edit=False)

    def _hook_here(self) -> None:
        if self.moment is None:
            return
        self._push_undo()
        self.m["hook"] = round(self._here(), 2)
        self.m["cold_open"] = True
        self._changed()
        self.inspector.set_clip(self.moment, self.m)
        self._set_status(tr("st_hook_set"))

    def _reload_words(self) -> None:
        if self.host is not None and hasattr(self.host, "clip_words_for") and self.moment is not None:
            try:
                self.words = list(self.host.clip_words_for(self.moment) or [])
            except Exception:  # noqa: BLE001
                pass

    def _edit_subs(self) -> None:
        if self.host is not None and hasattr(self.host, "studio_edit_subtitles") and self.moment is not None:
            self.player.pause()
            if self.host.studio_edit_subtitles(self.moment):
                self._reload_words()
                self._changed(sound=False)

    def _ai_available(self) -> bool:
        """An AI is set up (with its key) and allowed to place the memes."""
        if not self.cfg.get("montage_ai", True) or self.host is None or not hasattr(self.host, "studio_montage_ai"):
            return False
        try:
            from .. import llm
            return llm.make_provider(self.cfg) is not None
        except Exception:  # noqa: BLE001 - no key, no model...
            return False

    def _auto(self) -> None:
        """✨ Montage auto: the AI reads the clip and places the memes (a few seconds); without an AI, the automatic
        cues (kills, laughs, yelling)."""
        if self.moment is None:
            return
        if self._ai_available() and not self._ai_waiting:
            self._ai_waiting = self.moment.get("id")
            self.btn_auto.setEnabled(False)
            self._set_status(tr("st_ai_working"), 0)
            self.host.studio_montage_ai(self.moment, self._ai_done)
            return
        self._apply_auto()

    def _ai_done(self, mid: str, plan: Optional[dict], err: str) -> None:
        """The AI answered (or not) for the clip mid."""
        self._ai_waiting = ""
        self.btn_auto.setEnabled(True)
        if self.moment is None or self.moment.get("id") != mid:
            return
        if plan is None:
            self._set_status(tr("st_ai_failed", err=err or "?"), 8000)
            self._apply_auto()
            return
        self.moment["montage_ai"] = plan
        self._apply_auto()

    def _apply_auto(self) -> None:
        self._push_undo()
        fresh = montage.auto_montage(dict(self.moment, montage=None), self.cfg)
        ai = bool(fresh.get("ai"))
        if not fresh["elements"] and not ai:
            h = montage.hook_time(self.moment) or self._here()
            fresh["elements"] = [montage.element("zoom", h - 0.3, dur=1.0, amount=1.3, auto=True),
                                 montage.element("emoji", h, dur=1.6, file="emoji:1f602", x=0.76, y=0.3, auto=True)]
        for e in fresh["elements"]:
            e["id"] = montage.new_id()
        self.m = montage.normalize(fresh)
        self.sel = ""
        self._changed()
        self._show_selection()
        self.library.set_music(self.m.get("music") or "")
        n = len(self.m["elements"])
        if ai:
            self._set_status(tr("st_ai_done", n=n) if n else tr("st_ai_none"), 8000)
        else:
            self._set_status(tr("st_auto_done", n=n))

    def _clear(self) -> None:
        if self.moment is None:
            return
        self._push_undo()
        self.m = montage.normalize({})
        self.sel = ""
        self._changed()
        self._show_selection()

    def _pick_fx_emoji(self, eid: str) -> None:
        e = self._el(eid)
        if e is None:
            return
        menu = QMenu(self)
        for ch in "😂💀🔥😭🤡👀💯😱🤯🗿❤️💸🎉⭐🍿🐐":
            code = fxlib.emoji_code_of(ch)
            if not code:
                continue
            from .studio_library import emoji_icon
            act = menu.addAction(emoji_icon(code, 24), "")
            act.triggered.connect(lambda _c=False, code=code: self._set_fx_emoji(eid, code))
        menu.exec(self.cursor().pos())

    def _set_fx_emoji(self, eid: str, code: str) -> None:
        e = self._el(eid)
        if e is None:
            return
        self._push_undo()
        e["file"] = f"emoji:{code}"
        self._changed(sound=False)
        self.inspector.set_element(e, self._o_of(e))

    # =================================================================== playing
    def _on_position(self, o: float) -> None:
        self._update_time(o)
        self.timeline.canvas.set_playhead(o)

    def _update_time(self, o: float) -> None:
        self.time_lbl.setText(f"{fmt_time(o, 1)} / {fmt_time(self.player.total(), 1)}")

    def _play_clicked(self) -> None:
        """▶ / ⏸: the live picture, or the exact render when it is shown."""
        if self.center_stack.currentWidget() is self.exact_page and self._exact_player is not None:
            from PySide6.QtMultimedia import QMediaPlayer
            if self._exact_player.playbackState() == QMediaPlayer.PlayingState:
                self._exact_player.pause()
                self.btn_play.setText("▶")
            else:
                self._exact_player.play()
                self.btn_play.setText("⏸")
            return
        self.player.toggle()

    def _on_playing(self, on: bool) -> None:
        self.btn_play.setText("⏸" if on else "▶")
        if on:
            self._stop_listen()
            if self._exact_player is not None:
                self._exact_player.pause()

    def _on_mixing(self, busy: bool) -> None:
        if busy:
            if self.status_lbl.text() != tr("st_sound_mixing"):
                self._status_before = (self.status_lbl.text(), time.monotonic())
            self.status_lbl.setText(tr("st_sound_mixing"))
        elif self.status_lbl.text() == tr("st_sound_mixing"):
            # back to what was said just before (a cut, a deleted part...) while it is still fresh
            text, when = getattr(self, "_status_before", ("", 0.0))
            self.status_lbl.setText(text if text and time.monotonic() - when < 6.0 else "")

    def _step(self, d: float) -> None:
        self.player.pause()
        self.player.seek(self.player.position() + d)

    def _mute(self, on: bool) -> None:
        self.btn_mute.setText("🔇" if on else "🔊")
        self.player.audio.set_muted(on)

    def _set_status(self, text: str, ms: int = 5000) -> None:
        self.status_lbl.setText(text)
        if ms and text:
            QTimer.singleShot(ms, lambda t=text: self.status_lbl.text() == t and self.status_lbl.setText(""))

    # ---- hearing a sound of the library
    def _listen(self, item: str, path: str) -> None:
        if not path:
            ref = item.split(":", 1)[1] if ":" in item else ""
            if item != self._listen_item and self._needs_download(ref):
                self._fetch_then(ref, lambda p: p and self._listen(item, str(p)), item)
                return
            self._stop_listen()
            return
        try:
            from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
        except Exception:  # noqa: BLE001
            return
        self.player.pause()
        if self._listen_player is None:
            self._listen_player = QMediaPlayer(self)
            import os
            if not os.environ.get("FIRECLIPS_NO_AUDIO"):
                self._listen_out = QAudioOutput(self)
                self._listen_out.setVolume(0.85)
                self._listen_player.setAudioOutput(self._listen_out)
            self._listen_player.playbackStateChanged.connect(self._listen_state)
        self._listen_player.stop()
        self._listen_item = item
        self.library.set_playing(item)
        self._listen_player.setSource(QUrl.fromLocalFile(path))
        self._listen_player.play()

    def _listen_state(self, state) -> None:
        from PySide6.QtMultimedia import QMediaPlayer
        if state == QMediaPlayer.StoppedState:
            self._listen_item = ""
            self.library.set_playing("")

    def _stop_listen(self) -> None:
        if self._listen_player is not None:
            self._listen_player.stop()
        self._listen_item = ""
        self.library.set_playing("")

    # =================================================================== exact render, export, other clips
    def _exact(self) -> None:
        if self.moment is None or self.host is None or not hasattr(self.host, "studio_render"):
            return
        self._save_now()
        self.player.pause()
        self.btn_exact.setEnabled(False)
        self._set_status(tr("st_rendering", pct=0), 0)
        self.host.studio_render(self.moment, copy.deepcopy(self.m), self.fmt)

    def render_progress(self, frac: float) -> None:
        self._set_status(tr("st_rendering", pct=int(100 * frac)), 0)

    def render_failed(self, msg: str) -> None:
        self.btn_exact.setEnabled(True)
        self._set_status("⚠ " + msg, 12000)

    def show_exact(self, path: str) -> None:
        """Play the real rendered file in place of the live picture."""
        self.btn_exact.setEnabled(True)
        self._set_status(tr("st_exact_ready"))
        try:
            from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
            from PySide6.QtMultimediaWidgets import QVideoWidget
        except Exception:  # noqa: BLE001
            return
        if self._exact_player is None:
            self._exact_video = QVideoWidget()
            self._exact_box.addWidget(self._exact_video)
            self._exact_player = QMediaPlayer(self)
            import os
            if not os.environ.get("FIRECLIPS_NO_AUDIO"):
                self._exact_out = QAudioOutput(self)
                self._exact_out.setVolume(0.85)
                self._exact_player.setAudioOutput(self._exact_out)
            self._exact_player.setVideoOutput(self._exact_video)
            self._exact_player.setLoops(QMediaPlayer.Infinite)
        self.player.pause()
        self._exact_path = path
        self._exact_player.setSource(QUrl.fromLocalFile(path))
        self.center_stack.setCurrentWidget(self.exact_page)
        self._exact_player.play()
        self.btn_play.setText("⏸")

    def _exact_close(self) -> None:
        if self._exact_player is not None:
            self._exact_player.stop()
            self._exact_player.setSource(QUrl())
        if self.center_stack.currentWidget() is not self.canvas:
            self.center_stack.setCurrentWidget(self.canvas)
            self.btn_play.setText("⏸" if self.player.playing else "▶")

    def _export(self) -> None:
        if self.moment is None or self.host is None or not hasattr(self.host, "studio_export"):
            return
        self._save_now()
        formats = self.host.studio_export(self.moment)
        if formats:
            names = {"vertical": "9:16", "landscape": "16:9"}
            self._set_status(tr("st_export_started", fmts=" + ".join(names.get(f, f) for f in formats)), 8000)

    def export_progress(self, text: str) -> None:
        self._set_status(text, 0 if text else 5000)

    def _go(self, d: int) -> None:
        self._save_now()
        self.navigate.emit(d)

    def bank_item_ready(self, ref: str) -> None:
        """A meme of the internet bank arrived: when this clip uses it, it is seen / heard now."""
        if not ref or self.moment is None:
            return
        used = ref == self.m.get("music") or any(e.get("file") == ref for e in self.m.get("elements") or [])
        if used:
            self._rebuild(sound=True)

    def _files_dropped(self, files: list) -> None:
        if self.host is not None and hasattr(self.host, "cfg"):
            from . import meme_dialogs
            meme_dialogs.add_paths(self.host, files)

    def _import(self, kind: str) -> None:
        if self.host is not None and hasattr(self.host, "studio_import"):
            self.player.pause()
            self.host.studio_import(kind, self)

    # =================================================================== window
    def closeEvent(self, e) -> None:  # noqa: N802
        self._save_now()
        self.player.pause()
        self._stop_listen()
        self._exact_close()
        try:
            self.cfg["ui_studio_geometry"] = bytes(self.saveGeometry().toBase64()).decode("ascii")
            self.cfg.save()
        except Exception:  # noqa: BLE001
            pass
        self.closed.emit()
        super().closeEvent(e)

    def restore_geometry(self) -> None:
        """The size and place the Studio had last time; the first time, as big as the screen allows (up to
        1500 x 920), centred."""
        g = self.cfg.get("ui_studio_geometry") or ""
        if g:
            from PySide6.QtCore import QByteArray
            try:
                if self.restoreGeometry(QByteArray.fromBase64(g.encode("ascii"))):
                    return
            except Exception:  # noqa: BLE001
                pass
        from PySide6.QtGui import QGuiApplication
        scr = self.screen() or QGuiApplication.primaryScreen()
        if scr is None:
            return
        av = scr.availableGeometry()
        w = max(self.minimumWidth(), min(1500, int(av.width() * 0.96)))
        h = max(self.minimumHeight(), min(920, int(av.height() * 0.92)))
        self.resize(w, h)
        self.move(av.x() + max(0, (av.width() - w) // 2), av.y() + max(0, (av.height() - h) // 2))

    def shutdown(self) -> None:
        """The app is closing: stop the threads."""
        self._save_now()
        self.player.close()

    def sizeHint(self) -> QSize:  # noqa: N802
        return QSize(1500, 920)
