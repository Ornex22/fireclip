"""Runs the background worker processes and turns their JSON lines into Qt signals."""
from __future__ import annotations

import json
import logging
import os
import sys
from collections import deque
from typing import Optional

from PySide6.QtCore import QObject, QProcess, QProcessEnvironment, Signal

from .. import paths
from ..util import kill_tree

log = logging.getLogger("fireclips.jobs")


def python_exe() -> str:
    exe = sys.executable
    # When the app runs with pythonw.exe (no console), use it for the workers too
    return exe


class Job(QObject):
    event = Signal(object)          # dict from the worker
    finished = Signal(object)       # the Job itself

    def __init__(self, kind: str, args: list, key: Optional[str] = None, label: str = "", parent=None):
        super().__init__(parent)
        self.kind = kind
        self.args = [str(a) for a in args]
        self.key = key
        self.label = label
        self.proc: Optional[QProcess] = None
        self.exit_code: Optional[int] = None
        self.last_error: Optional[dict] = None
        self.result: Optional[dict] = None
        self.warnings: list[dict] = []
        self.progress = 0.0
        self.detail = ""
        self.step = ""
        self.cancelled = False
        self._buf = b""
        self._err: deque = deque(maxlen=80)

    @property
    def running(self) -> bool:
        return self.proc is not None and self.proc.state() != QProcess.NotRunning

    def start(self) -> None:
        self.proc = QProcess(self)
        env = QProcessEnvironment.systemEnvironment()
        pp = str(paths.PACKAGE_DIR.parent)
        old = env.value("PYTHONPATH", "")
        env.insert("PYTHONPATH", pp + (os.pathsep + old if old else ""))
        env.insert("PYTHONUNBUFFERED", "1")
        env.insert("PYTHONIOENCODING", "utf-8")
        self.proc.setProcessEnvironment(env)
        self.proc.setWorkingDirectory(pp)
        self.proc.readyReadStandardOutput.connect(self._on_stdout)
        self.proc.readyReadStandardError.connect(self._on_stderr)
        self.proc.finished.connect(self._on_finished)
        self.proc.errorOccurred.connect(self._on_error)
        log.info("start job %s %s", self.kind, " ".join(self.args[:4]))
        self.proc.start(python_exe(), ["-m", "fireclips.worker", self.kind] + self.args)

    def cancel(self) -> None:
        self.cancelled = True
        if self.proc is not None and self.proc.state() != QProcess.NotRunning:
            pid = int(self.proc.processId() or 0)
            if pid:
                kill_tree(pid)
            self.proc.kill()

    def _on_stdout(self) -> None:
        assert self.proc is not None
        self._buf += bytes(self.proc.readAllStandardOutput())
        *lines, self._buf = self._buf.split(b"\n")
        for raw in lines:
            raw = raw.strip()
            if not raw:
                continue
            try:
                ev = json.loads(raw.decode("utf-8", "replace"))
            except ValueError:
                continue
            e = ev.get("ev")
            if e == "progress":
                self.progress = float(ev.get("overall", ev.get("frac", 0)) or 0)
                self.step = ev.get("step", self.step)
                self.detail = ev.get("detail", "")
            elif e == "error":
                self.last_error = ev
            elif e == "warning":
                self.warnings.append(ev)
            elif e in ("result", "done"):
                self.result = ev
            self.event.emit(ev)

    def _on_stderr(self) -> None:
        assert self.proc is not None
        txt = bytes(self.proc.readAllStandardError()).decode("utf-8", "replace")
        for line in txt.splitlines():
            if line.strip():
                self._err.append(line)

    def stderr_tail(self) -> str:
        return "\n".join(self._err)

    def _on_error(self, err) -> None:
        if err == QProcess.FailedToStart:
            self.last_error = {"code": "err_unexpected", "detail": "worker failed to start: " + python_exe(), "fmt": {}}
            self.exit_code = -1
            self.finished.emit(self)

    def _on_finished(self, code: int, _status) -> None:
        self._on_stdout()
        self.exit_code = int(code)
        if self.exit_code != 0 and not self.last_error and not self.cancelled:
            self.last_error = {"code": "err_unexpected", "detail": self.stderr_tail()[-3000:], "fmt": {}}
        log.info("job %s finished (%s)", self.kind, code)
        self.finished.emit(self)


class JobManager(QObject):
    """Queues that each run one job at a time (analysis / export / albion) plus quick preview jobs."""
    changed = Signal()
    job_event = Signal(object, object)       # job, event dict
    job_finished = Signal(object)             # job

    def __init__(self, parent=None):
        super().__init__(parent)
        # "bank": the real memes downloaded in the background (never keeps the app "busy")
        self.queues: dict[str, list[Job]] = {"analysis": [], "export": [], "albion": [], "bank": []}
        self.active: dict[str, Optional[Job]] = {"analysis": None, "export": None, "albion": None, "bank": None}
        self.previews: list[Job] = []

    def submit(self, job: Job, queue: str = "analysis") -> Job:
        job.event.connect(lambda ev, j=job: self.job_event.emit(j, ev))
        job.finished.connect(self._done)
        if queue == "preview":
            self.previews.append(job)
            job.start()
        else:
            self.queues[queue].append(job)
            job.setProperty("queue", queue)
            self._pump(queue)
        self.changed.emit()
        return job

    def _pump(self, queue: str) -> None:
        if self.active[queue] is None and self.queues[queue]:
            job = self.queues[queue].pop(0)
            self.active[queue] = job
            job.start()

    def _done(self, job: Job) -> None:
        if job in self.previews:
            self.previews.remove(job)
        for q, j in self.active.items():
            if j is job:
                self.active[q] = None
                self._pump(q)
        self.job_finished.emit(job)
        self.changed.emit()
        job.deleteLater()

    def analysis_job(self, key: str) -> Optional[Job]:
        a = self.active["analysis"]
        if a is not None and a.key == key:
            return a
        for j in self.queues["analysis"]:
            if j.key == key:
                return j
        return None

    def is_queued(self, key: str) -> bool:
        return any(j.key == key for j in self.queues["analysis"])

    def cancel_key(self, key: str) -> None:
        self.queues["analysis"] = [j for j in self.queues["analysis"] if j.key != key]
        a = self.active["analysis"]
        if a is not None and a.key == key:
            a.cancel()
        self.changed.emit()

    def cancel_export(self) -> None:
        self.queues["export"].clear()
        if self.active["export"] is not None:
            self.active["export"].cancel()
        self.changed.emit()

    def cancel_previews(self) -> None:
        for j in list(self.previews):
            j.cancel()

    def busy(self) -> bool:
        return any(j for q, j in self.active.items() if q != "bank") or \
            any(js for q, js in self.queues.items() if q != "bank")

    def stop_all(self) -> None:
        for q in self.queues.values():
            q.clear()
        for j in list(self.active.values()) + list(self.previews):
            if j is not None:
                j.cancel()
