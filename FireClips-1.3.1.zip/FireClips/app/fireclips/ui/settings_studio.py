"""Settings pages added in 1.2: the streamers (watermark, logo, subtitle look, intro / outro of
each channel) and the Studio (automatic montage, music, bleeps, loudness, meme bank)."""
from __future__ import annotations

import copy
import io
import logging
import subprocess
import tempfile
from pathlib import Path
from typing import Callable, Optional

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QImage, QPixmap
from PySide6.QtWidgets import (QCheckBox, QComboBox, QFileDialog, QFormLayout, QFrame, QHBoxLayout, QLabel,
                               QLineEdit, QListWidget, QListWidgetItem, QPushButton, QSlider, QSpinBox, QToolButton,
                               QVBoxLayout, QWidget)

from .. import bank, montage, paths, profiles, subtitles, tools
from ..i18n import tr
from ..util import no_window_flags, open_in_explorer
from . import theme

log = logging.getLogger("fireclips.settings")

WM_POS = ["auto", "tl", "tc", "tr", "bl", "bc", "br"]


def _hint(text: str) -> QLabel:
    lab = QLabel(text)
    lab.setWordWrap(True)
    lab.setObjectName("Muted")
    lab.setStyleSheet("font-size: 8.5pt;")
    return lab


def _pil_to_pixmap(img) -> QPixmap:
    buf = io.BytesIO()
    img.save(buf, "PNG")
    qi = QImage.fromData(buf.getvalue(), "PNG")
    return QPixmap.fromImage(qi)


def sample_frame(frame_getter: Optional[Callable], w: int, h: int):
    """A 9:16 picture to show the watermark / subtitles on (the player picture, or a plain gradient)."""
    from PIL import Image
    img = None
    if frame_getter is not None:
        try:
            q = frame_getter()
            if q is not None and not q.isNull():
                from PySide6.QtCore import QBuffer, QIODevice
                ba = QBuffer()
                ba.open(QIODevice.WriteOnly)
                q.save(ba, "PNG")
                img = Image.open(io.BytesIO(bytes(ba.data()))).convert("RGB")
        except Exception:  # noqa: BLE001
            img = None
    from PIL import ImageFilter, ImageOps
    canvas = ImageOps.colorize(Image.linear_gradient("L").resize((w, h)), (38, 28, 58), (96, 46, 52))
    if img is not None:
        # same look as the "blurred background" layout: picture in the middle
        bg = img.resize((max(1, int(h * img.width / max(1, img.height))), h)).filter(ImageFilter.GaussianBlur(14))
        canvas.paste(bg, ((w - bg.width) // 2, 0))
        fg = img.resize((w, max(1, int(w * img.height / max(1, img.width)))))
        canvas.paste(fg, (0, (h - fg.height) // 2))
    return canvas


# =========================================================================== streamers


class StreamersPage(QWidget):
    """The channels FireClips works for, each with its own dressing of the clips."""

    def __init__(self, cfg, frame_getter: Optional[Callable] = None, parent=None):
        super().__init__(parent)
        self.cfg = cfg
        self.frame_getter = frame_getter
        self.items: list[dict] = [copy.deepcopy(s) for s in profiles.streamers(cfg)]
        self._block = False
        self._sample = None
        v = QVBoxLayout(self)
        v.addWidget(_hint(tr("str_intro")))
        row = QHBoxLayout()
        left = QVBoxLayout()
        self.list = QListWidget()
        self.list.setMinimumWidth(190)
        self.list.setMaximumWidth(240)
        self.list.currentRowChanged.connect(self._show)
        left.addWidget(self.list, 1)
        b = QPushButton(tr("str_add"))
        b.clicked.connect(self._add)
        left.addWidget(b)
        self.btn_del = QPushButton(tr("str_remove"))
        self.btn_del.clicked.connect(self._remove)
        left.addWidget(self.btn_del)
        row.addLayout(left)
        right = QFrame()
        right.setObjectName("Panel")
        f = QFormLayout(right)
        f.setLabelAlignment(Qt.AlignRight | Qt.AlignVCenter)
        f.setHorizontalSpacing(12)
        self.login = QLineEdit()
        self.login.setPlaceholderText("elfirefemale")
        f.addRow(tr("str_login"), self.login)
        self.name = QLineEdit()
        self.name.setPlaceholderText("Fire")
        f.addRow(tr("str_name"), self.name)
        self.auto = QCheckBox(tr("str_auto"))
        f.addRow("", self.auto)
        self.wm_on = QCheckBox(tr("str_wm_on"))
        f.addRow("", self.wm_on)
        self.wm_text = QLineEdit()
        f.addRow(tr("str_wm_text"), self.wm_text)
        self.logo_row, self.logo = self._file_row(tr("str_pick_logo"), "Images (*.png *.jpg *.jpeg *.webp)")
        f.addRow(tr("str_wm_logo"), self.logo_row)
        self.wm_pos = QComboBox()
        for p in WM_POS:
            self.wm_pos.addItem(tr("wmpos_" + p), p)
        f.addRow(tr("str_wm_pos"), self.wm_pos)
        rowo = QHBoxLayout()
        self.wm_opacity = QSlider(Qt.Horizontal)
        self.wm_opacity.setRange(10, 100)
        self.wm_size = QSpinBox()
        self.wm_size.setRange(40, 250)
        self.wm_size.setSuffix(" %")
        self.wm_size.setMinimumWidth(90)
        rowo.addWidget(self.wm_opacity, 1)
        rowo.addWidget(QLabel(tr("str_wm_size")))
        rowo.addWidget(self.wm_size)
        f.addRow(tr("str_wm_opacity"), rowo)
        self.sub_style = QComboBox()
        self.sub_style.addItem(tr("st_style_default"), "")
        for sid in subtitles.STYLE_ORDER:
            self.sub_style.addItem(tr("substyle_" + sid), sid)
        f.addRow(tr("str_sub_style"), self.sub_style)
        vid = "Vidéos / images (*.mp4 *.mov *.webm *.mkv *.png *.jpg *.jpeg)"
        self.intro_row, self.intro = self._file_row(tr("str_pick_intro"), vid)
        f.addRow(tr("str_intro_file"), self.intro_row)
        self.outro_row, self.outro = self._file_row(tr("str_pick_outro"), vid)
        f.addRow(tr("str_outro_file"), self.outro_row)
        f.addRow("", _hint(tr("str_intro_hint")))
        row.addWidget(right, 1)
        self.preview = QLabel()
        self.preview.setFixedSize(162, 288)
        self.preview.setStyleSheet(f"border: 1px solid {theme.BORDER}; border-radius: 6px;")
        self.preview.setAlignment(Qt.AlignCenter)
        pv = QVBoxLayout()
        pv.addWidget(self.preview)
        pv.addWidget(_hint(tr("str_preview")))
        pv.addStretch(1)
        row.addLayout(pv)
        v.addLayout(row, 1)
        for w in (self.login, self.name, self.wm_text, self.logo, self.intro, self.outro):
            w.textChanged.connect(self._changed)
        for w in (self.auto, self.wm_on):
            w.toggled.connect(self._changed)
        for w in (self.wm_pos, self.sub_style):
            w.currentIndexChanged.connect(self._changed)
        self.wm_opacity.valueChanged.connect(self._changed)
        self.wm_size.valueChanged.connect(self._changed)
        self._preview_timer = QTimer(self)
        self._preview_timer.setSingleShot(True)
        self._preview_timer.setInterval(250)
        self._preview_timer.timeout.connect(self._update_preview)
        self._fill()

    def _file_row(self, title: str, filt: str) -> tuple[QWidget, QLineEdit]:
        w = QWidget()
        h = QHBoxLayout(w)
        h.setContentsMargins(0, 0, 0, 0)
        e = QLineEdit()
        e.setPlaceholderText(tr("str_none"))
        b = QPushButton(tr("btn_browse"))
        x = QToolButton()
        x.setText("✕")
        x.setToolTip(tr("str_clear_file"))

        def pick():
            start = str(bank.ensure(self.cfg))
            fn, _ = QFileDialog.getOpenFileName(self, title, start, filt)
            if fn:
                e.setText(fn)
        b.clicked.connect(pick)
        x.clicked.connect(lambda: e.setText(""))
        h.addWidget(e, 1)
        h.addWidget(b)
        h.addWidget(x)
        return w, e

    def _fill(self) -> None:
        self.list.clear()
        for s in self.items:
            self.list.addItem(QListWidgetItem(self._label(s)))
        if self.items:
            self.list.setCurrentRow(0)
        else:
            self._show(-1)

    @staticmethod
    def _label(s: dict) -> str:
        name = s.get("name") or s.get("login") or "?"
        return ("● " if s.get("auto") else "○ ") + name + (f"  ({s['login']})" if s.get("login") and s.get("name") else "")

    def _show(self, row: int) -> None:
        on = 0 <= row < len(self.items)
        for w in (self.login, self.name, self.auto, self.wm_on, self.wm_text, self.logo_row, self.wm_pos,
                  self.wm_opacity, self.wm_size, self.sub_style, self.intro_row, self.outro_row, self.btn_del):
            w.setEnabled(on)
        if not on:
            self.preview.clear()
            return
        s = self.items[row]
        self._block = True
        self.login.setText(s.get("login", ""))
        self.name.setText(s.get("name", ""))
        self.auto.setChecked(bool(s.get("auto", True)))
        self.wm_on.setChecked(bool(s.get("wm_on", True)))
        self.wm_text.setText(s.get("wm_text", ""))
        self.wm_text.setPlaceholderText(f"twitch.tv/{s.get('login') or '…'}")
        self.logo.setText(s.get("wm_logo", ""))
        self.wm_pos.setCurrentIndex(max(0, self.wm_pos.findData(s.get("wm_pos", "auto"))))
        self.wm_opacity.setValue(int(s.get("wm_opacity", 85)))
        self.wm_size.setValue(int(s.get("wm_size", 100)))
        self.sub_style.setCurrentIndex(max(0, self.sub_style.findData(s.get("sub_style", ""))))
        self.intro.setText(s.get("intro", ""))
        self.outro.setText(s.get("outro", ""))
        self._block = False
        self._preview_timer.start()

    def _changed(self, *_a) -> None:
        if self._block:
            return
        row = self.list.currentRow()
        if not 0 <= row < len(self.items):
            return
        s = self.items[row]
        s.update({"login": self.login.text().strip().lstrip("@").lower(), "name": self.name.text().strip(),
                  "auto": self.auto.isChecked(), "wm_on": self.wm_on.isChecked(), "wm_text": self.wm_text.text().strip(),
                  "wm_logo": self.logo.text().strip(), "wm_pos": self.wm_pos.currentData(),
                  "wm_opacity": self.wm_opacity.value(), "wm_size": self.wm_size.value(),
                  "sub_style": self.sub_style.currentData() or "", "intro": self.intro.text().strip(),
                  "outro": self.outro.text().strip()})
        self.wm_text.setPlaceholderText(f"twitch.tv/{s['login'] or '…'}")
        self.list.item(row).setText(self._label(s))
        self._preview_timer.start()

    def _add(self) -> None:
        self.items.append(copy.deepcopy(profiles.STREAMER_DEFAULTS))
        self.list.addItem(QListWidgetItem(self._label(self.items[-1])))
        self.list.setCurrentRow(len(self.items) - 1)
        self.login.setFocus()

    def _remove(self) -> None:
        row = self.list.currentRow()
        if 0 <= row < len(self.items):
            self.items.pop(row)
            self._fill()

    def _update_preview(self) -> None:
        row = self.list.currentRow()
        if not 0 <= row < len(self.items):
            return
        try:
            s = profiles.clean_streamer(self.items[row]) or profiles.STREAMER_DEFAULTS
            W, H = 324, 576
            if self._sample is None:
                self._sample = sample_frame(self.frame_getter, W, H)
            img = self._sample.copy().convert("RGBA")
            text = profiles.watermark_text(s)
            logo = bank.resolve(s.get("wm_logo") or "", self.cfg) if s.get("wm_on", True) and s.get("wm_logo") else None
            if text or logo is not None:
                pic = montage.watermark_picture(text, logo, H, True, int(s.get("wm_size") or 100),
                                                int(s.get("wm_opacity") or 85))
                if pic is not None:
                    x, y = montage.watermark_position(s.get("wm_pos") or "auto", pic.width, pic.height, W, H, True)
                    img.alpha_composite(pic, (max(0, x), max(0, y)))
            self.preview.setPixmap(_pil_to_pixmap(img.convert("RGB")).scaled(
                self.preview.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))
        except Exception as e:  # noqa: BLE001
            log.info("watermark preview: %s", e)

    def values(self) -> list[dict]:
        out = []
        for s in self.items:
            c = profiles.clean_streamer(s)
            if c and c.get("login"):
                out.append(c)
        return out


# =========================================================================== studio


def render_style_preview(style_id: str, cfg_values: dict, frame) -> Optional[QPixmap]:
    """The subtitle look drawn by libass (the same engine as the export) on a 9:16 picture."""
    ff = tools.find("ffmpeg")
    if not ff:
        return None
    W, H = 324, 576
    words = [(0.0, 0.4, " Oh"), (0.4, 0.8, " non"), (0.8, 1.3, " il"), (1.3, 1.8, " m'a"), (1.8, 2.4, " eue !")]
    st = subtitles.resolve_style(style_id, cfg_values)
    ass = subtitles.build_ass(words, 0.0, 3.0, W, H, style=st)
    with tempfile.TemporaryDirectory(prefix="fireclips-style-") as d:
        dd = Path(d)
        (dd / "s.ass").write_text(ass, encoding="utf-8")
        frame.save(dd / "bg.png")
        fonts = dd / "fonts"
        fonts.mkdir()
        import shutil
        for f in (paths.ASSETS / "fonts").glob("*.ttf"):
            shutil.copy2(f, fonts / f.name)
        try:
            r = subprocess.run([str(ff), "-v", "error", "-y", "-loop", "1", "-i", "bg.png", "-vf",
                                "subtitles=s.ass:fontsdir=fonts", "-ss", "0.9", "-frames:v", "1", "out.png"],
                               cwd=str(dd), capture_output=True, timeout=30, stdin=subprocess.DEVNULL,
                               creationflags=no_window_flags())
            if r.returncode == 0 and (dd / "out.png").exists():
                return QPixmap(str(dd / "out.png"))
        except Exception as e:  # noqa: BLE001
            log.info("style preview: %s", e)
    return None


class StudioPage(QWidget):
    """Default montage of the clips."""

    def __init__(self, cfg, frame_getter: Optional[Callable] = None, subs_values: Optional[Callable] = None,
                 parent=None):
        super().__init__(parent)
        self.cfg = cfg
        self.frame_getter = frame_getter
        self.subs_values = subs_values or (lambda: {})
        self._frame = None
        c = cfg
        f = QFormLayout(self)
        f.setLabelAlignment(Qt.AlignRight | Qt.AlignVCenter)
        f.setHorizontalSpacing(14)
        f.setVerticalSpacing(10)
        f.addRow(_hint(tr("stu_intro")))
        row = QHBoxLayout()
        self.style = QComboBox()
        for sid in subtitles.STYLE_ORDER:
            self.style.addItem(tr("substyle_" + sid), sid)
        self.style.setCurrentIndex(max(0, self.style.findData(c.get("subtitle_style") or "classic")))
        col = QVBoxLayout()
        col.addWidget(self.style)
        col.addWidget(_hint(tr("stu_style_hint")))
        col.addStretch(1)
        row.addLayout(col, 1)
        self.style_prev = QLabel()
        self.style_prev.setFixedSize(162, 288)
        self.style_prev.setStyleSheet(f"border: 1px solid {theme.BORDER}; border-radius: 6px;")
        self.style_prev.setAlignment(Qt.AlignCenter)
        row.addWidget(self.style_prev)
        f.addRow(tr("stu_style"), row)
        self.style.currentIndexChanged.connect(self._style_preview)

        self.auto = QCheckBox(tr("stu_auto"))
        self.auto.setChecked(bool(c.get("montage_auto", True)))
        f.addRow(tr("stu_montage"), self.auto)
        self.ai = QCheckBox(tr("stu_ai"))
        self.ai.setChecked(bool(c.get("montage_ai", True)))
        self.ai.setToolTip(tr("stu_ai_tip"))
        f.addRow("", self.ai)
        self.fx_sounds = QCheckBox(tr("stu_fx_sounds"))
        self.fx_sounds.setChecked(bool(c.get("montage_fx_sounds", True)))
        f.addRow("", self.fx_sounds)
        self.cuts = QComboBox()
        for v, k in (("off", "stu_cuts_off"), ("talk", "stu_cuts_talk"), ("all", "stu_cuts_all")):
            self.cuts.addItem(tr(k), v)
        self.cuts.setCurrentIndex(max(0, self.cuts.findData(c.get("montage_jumpcuts") or "talk")))
        f.addRow(tr("st_jumpcuts"), self.cuts)
        self.cold = QCheckBox(tr("stu_cold"))
        self.cold.setChecked(bool(c.get("montage_cold_open")))
        f.addRow("", self.cold)
        row = QHBoxLayout()
        self.music = QCheckBox(tr("stu_music"))
        self.music.setChecked(bool(c.get("montage_music", True)))
        self.music_vol = QSlider(Qt.Horizontal)
        self.music_vol.setRange(0, 60)
        self.music_vol.setValue(int(c.get("montage_music_vol") or 18))
        self.music_vol.setMaximumWidth(160)
        row.addWidget(self.music)
        row.addSpacing(10)
        row.addWidget(QLabel("🔉"))
        row.addWidget(self.music_vol)
        row.addStretch(1)
        f.addRow(tr("st_music"), row)
        f.addRow("", _hint(tr("stu_music_hint")))
        row = QHBoxLayout()
        self.bleep = QCheckBox(tr("stu_bleep"))
        self.bleep.setChecked(bool(c.get("montage_bleep")))
        self.bleep_mode = QComboBox()
        self.bleep_mode.addItem(tr("stu_bleep_bip"), "bip")
        self.bleep_mode.addItem(tr("stu_bleep_silence"), "silence")
        self.bleep_mode.setCurrentIndex(max(0, self.bleep_mode.findData(c.get("bleep_mode") or "bip")))
        row.addWidget(self.bleep)
        row.addWidget(self.bleep_mode)
        row.addStretch(1)
        f.addRow(tr("st_bleep"), row)
        self.loud = QCheckBox(tr("stu_loudnorm"))
        self.loud.setChecked(bool(c.get("loudnorm", True)))
        f.addRow(tr("stu_sound"), self.loud)
        w = QWidget()
        h = QHBoxLayout(w)
        h.setContentsMargins(0, 0, 0, 0)
        self.bank_dir = QLineEdit(c.get("bank_dir") or "")
        self.bank_dir.setPlaceholderText(str(paths.default_output_dir() / "Banque"))
        b = QPushButton(tr("btn_browse"))
        b.clicked.connect(self._pick_bank)
        o = QPushButton("📂")
        o.setToolTip(tr("st_bank_folder"))
        o.clicked.connect(lambda: open_in_explorer(bank.ensure({"bank_dir": self.bank_dir.text().strip()})))
        h.addWidget(self.bank_dir, 1)
        h.addWidget(b)
        h.addWidget(o)
        f.addRow(tr("stu_bank"), w)
        f.addRow("", _hint(tr("stu_bank_hint")))
        # the memes downloaded from the internet (memebank.py)
        w = QWidget()
        h = QHBoxLayout(w)
        h.setContentsMargins(0, 0, 0, 0)
        self.web_state = QLabel("")
        h.addWidget(self.web_state, 1)
        b = QPushButton("⬇ " + tr("stu_webbank_get"))
        b.clicked.connect(lambda: self._web_sync("retry"))
        h.addWidget(b)
        b = QPushButton("⟳ " + tr("stu_webbank_lists"))
        b.clicked.connect(lambda: self._web_sync("lists"))
        h.addWidget(b)
        f.addRow(tr("stu_webbank"), w)
        f.addRow("", _hint(tr("stu_webbank_hint")))
        self._web_count()
        QTimer.singleShot(50, self._style_preview)

    def _web_count(self) -> None:
        try:
            from .. import memebank
            c = memebank.counts()
            self.web_state.setText(tr("stu_webbank_state", have=c["have"], total=c["total"]))
        except Exception as e:  # noqa: BLE001
            log.info("meme bank: %s", e)

    def _web_sync(self, mode: str) -> None:
        from PySide6.QtWidgets import QApplication
        host = next((w for w in QApplication.topLevelWidgets() if hasattr(w, "bank_sync") and hasattr(w, "jobs")), None)
        if host is None:
            return
        if host.bank_job is not None:
            self.web_state.setText(tr("stu_webbank_busy"))
            return
        host.bank_sync(mode=mode)
        self.web_state.setText(tr("stu_webbank_started"))

    def _pick_bank(self) -> None:
        d = QFileDialog.getExistingDirectory(self, tr("btn_browse"), self.bank_dir.text() or str(paths.default_output_dir()))
        if d:
            self.bank_dir.setText(d)

    def _style_preview(self, *_a) -> None:
        try:
            if self._frame is None:
                self._frame = sample_frame(self.frame_getter, 324, 576)
            vals = dict(self.cfg.snapshot() if hasattr(self.cfg, "snapshot") else {})
            vals.update(self.subs_values() or {})
            pm = render_style_preview(self.style.currentData(), vals, self._frame)
            if pm is not None:
                self.style_prev.setPixmap(pm.scaled(self.style_prev.size(), Qt.KeepAspectRatio,
                                                    Qt.SmoothTransformation))
        except Exception as e:  # noqa: BLE001
            log.info("style preview: %s", e)

    def values(self) -> dict:
        return {"subtitle_style": self.style.currentData() or "classic", "montage_auto": self.auto.isChecked(),
                "montage_ai": self.ai.isChecked(), "montage_fx_sounds": self.fx_sounds.isChecked(), "montage_jumpcuts": self.cuts.currentData(),
                "montage_cold_open": self.cold.isChecked(), "montage_music": self.music.isChecked(),
                "montage_music_vol": self.music_vol.value(), "montage_bleep": self.bleep.isChecked(),
                "bleep_mode": self.bleep_mode.currentData(), "loudnorm": self.loud.isChecked(),
                "bank_dir": self.bank_dir.text().strip()}
