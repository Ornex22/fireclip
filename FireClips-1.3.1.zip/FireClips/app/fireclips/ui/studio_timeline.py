"""The Studio timeline (CapCut style): the clip as it will be exported, from left to right, with one
track per kind of thing - video (cuts, slow motion, freezes, cold open), subtitles, memes, effects,
sounds and music. Click to move the red line, drag a block to move it, drag its edges to make it
longer / shorter, drag the ends of the video to trim the clip. The video track is made of the parts the
user keeps: ✂ cuts it at the red line, a part can be picked, deleted, and its edges dragged."""
from __future__ import annotations

import math
import threading
from typing import Optional

from PySide6.QtCore import QObject, QPointF, QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QBrush, QColor, QFont, QImage, QLinearGradient, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import (QFrame, QHBoxLayout, QMenu, QScrollArea, QScrollBar, QSlider, QToolButton,
                               QVBoxLayout, QWidget)

from .. import bank, montage, preview
from ..i18n import tr
from ..util import fmt_time
from . import theme

TRACKS = [("video", "🎬"), ("subs", "💬"), ("memes", "😂"), ("fx", "✨"), ("sound", "🔊"), ("music", "🎵")]
KIND_TRACK = {"emoji": "memes", "image": "memes", "video": "memes", "text": "memes", "killcard": "memes",
              "zoom": "fx", "shake": "fx", "slowmo": "fx", "freeze": "fx", "bleep": "fx", "fx": "fx",
              "sound": "sound"}
TRACK_COLOR = {"video": "#3b4250", "subs": "#d8d8e0", "memes": theme.ACCENT, "fx": theme.PURPLE, "sound": "#2bb3c0",
               "music": "#3ecf8e"}
KIND_ICON = {"emoji": "", "image": "🖼", "video": "🎞", "text": "🅰", "killcard": "⚔", "zoom": "🔍", "shake": "📳",
             "slowmo": "🐢", "freeze": "❄", "bleep": "🔇", "sound": "🔊", "fx": ""}
HEAD = 96            # width of the track names
RULER = 24
LANE_H = 26
VIDEO_H = 46
MIME = "application/x-fireclips-item"


def element_label(e: dict) -> str:
    k = e["kind"]
    if k == "emoji":
        return bank.display_name(e.get("file", ""))
    if k in ("image", "video", "sound"):
        return f"{KIND_ICON[k]} {bank.display_name(e.get('file', ''))}"
    if k == "text":
        return f"🅰 {e.get('text', '')}"
    if k == "killcard":
        c = e.get("card") or {}
        return f"⚔ {c.get('other', '')}"
    if k == "fx":
        fx = preview.fxlib.EFFECTS.get(e.get("effect") or "", {})
        from ..i18n import language
        return f"{fx.get('icon', '✨')} {fx.get(language()) or fx.get('fr') or e.get('effect')}"
    if k == "slowmo" and float(e.get("speed") or 0.5) > 1.0:
        return "🐇 " + tr("st_kind_fast")
    return KIND_ICON.get(k, "?") + " " + tr("st_kind_" + k)


_wave_cache: dict = {}
_wave_lock = threading.Lock()


def sound_wave(ref: str, cfg, n: int = 48) -> Optional[list]:
    """Loudness of a sound in n steps (0..99): from the pack index, or measured once for the user's files."""
    if ref.startswith("web:"):
        from .. import memebank
        rec = memebank.load_index()["items"].get(ref) or {}
        w = rec.get("wave") or []
        if w:
            if len(w) != n:
                w = [w[min(len(w) - 1, int(i * len(w) / n))] for i in range(n)]
            return list(w)
    p = bank.resolve(ref, cfg)
    if p is None:
        return None
    key = (str(p), n)
    with _wave_lock:
        if key in _wave_cache:
            return _wave_cache[key]
    try:
        import numpy as np
        x = preview.sound_of(p, 0.0, 120.0)
        if not len(x):
            w = None
        else:
            m = np.abs(x).max(axis=1)
            chunks = np.array_split(m, n)
            pk = np.array([c.max() if len(c) else 0.0 for c in chunks])
            pk = pk / max(1e-9, pk.max())
            w = [int(round(v * 99)) for v in pk]
    except Exception:  # noqa: BLE001
        w = None
    with _wave_lock:
        _wave_cache[key] = w
    return w


class Block:
    """Something drawn on a track."""

    def __init__(self, track: str, o0: float, o1: float, label: str, eid: str = "", kind: str = "",
                 ghost: bool = False, color: Optional[str] = None, wave: Optional[list] = None,
                 auto: bool = False, extra: Optional[dict] = None):
        self.track, self.o0, self.o1 = track, o0, max(o0 + 0.05, o1)
        self.label, self.eid, self.kind = label, eid, kind
        self.ghost, self.color, self.wave, self.auto = ghost, color, wave, auto
        self.extra = extra or {}
        self.lane = 0


class _ThumbSig(QObject):
    done = Signal(object, int)


class TimelineCanvas(QWidget):
    seek = Signal(float)                    # clip time
    selected = Signal(str)                  # element id ("" = nothing; "subs" / "music" = those tracks)
    moved = Signal(str, float)              # element id, new start (clip time) - while dragging
    resized = Signal(str, float, float)     # element id, new start, new length (clip time) - while dragging
    edit_done = Signal(str)                 # the drag is over: one undo step
    trimmed = Signal(str, float)            # "start" | "end", how far (clip seconds, + = longer at that side)
    delete_requested = Signal(str)
    duplicate_requested = Signal(str)
    dropped = Signal(str, float, str)       # library item, clip time, track
    zoom_changed = Signal()
    selection_changed = Signal(str)         # what is picked on the timeline (by the mouse or the Studio)
    edit_subs = Signal()                    # double-click on the subtitles: correct their text
    cut_here = Signal()                     # ✂ cut the video at the red line
    segment_delete = Signal(int)            # remove a kept part of the video
    cut_side = Signal(str)                  # remove everything "before" | "after" the red line
    cuts_reset = Signal()                   # the whole clip again
    segment_trimmed = Signal(int, str, float)   # part, "left" | "right", how far it moved (clip seconds)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.comp: Optional[preview.Composition] = None
        self.cfg = None
        self.blocks: list[Block] = []
        self.lanes: dict[str, int] = {t: 1 for t, _i in TRACKS}
        self.playhead = 0.0
        self.sel = ""
        self.pps = 40.0              # pixels per second
        self.offset = 0.0            # seconds at the left edge
        self.fit = True
        self.thumbs: list[tuple[float, QImage]] = []
        self._thumb_by_vod: dict = {}
        self.src: Optional[dict] = None
        self.cuts: list[float] = []
        self.segs: list[Block] = []         # the kept parts of the video (eid "seg:<i>")
        self._drag: Optional[dict] = None
        self._hover = None
        self._thumb_ver = 0
        self._thumb_sig = _ThumbSig()
        self._thumb_sig.done.connect(self._thumbs_done)
        self.setMouseTracking(True)
        self.setAcceptDrops(True)
        self.setFocusPolicy(Qt.ClickFocus)
        self.setMinimumHeight(RULER + VIDEO_H + 5 * LANE_H + 12)

    # ---------------------------------------------------------------- data
    def set_comp(self, comp: Optional[preview.Composition], cfg=None) -> None:
        self.comp = comp
        self.cfg = cfg if cfg is not None else self.cfg
        self._build()
        if self.fit:
            self.fit_all()
        self.updateGeometry()
        self.update()

    def set_source(self, src: Optional[dict]) -> None:
        if (src or {}).get("path") != (self.src or {}).get("path"):
            self._thumb_by_vod = {}
        self.src = src
        self._start_thumbs()
        self.update()

    def set_playhead(self, o: float) -> None:
        if abs(o - self.playhead) > 1e-4:
            self.playhead = o
            # keep the red line in view while playing
            x = self._x(o)
            if not self.fit and (x > self.width() - 30 or x < HEAD):
                self.offset = max(0.0, o - (self.width() - HEAD) * 0.15 / self.pps)
                self.zoom_changed.emit()
                self.update()
            else:
                super().update()          # only the red line moved: the still picture is kept

    def set_selected(self, eid: str) -> None:
        self.sel = eid or ""
        self.selection_changed.emit(self.sel)
        self.update()

    def total(self) -> float:
        return self.comp.total if self.comp is not None else 1.0

    def fit_all(self) -> None:
        self.fit = True
        self.pps = max(4.0, (self.width() - HEAD - 16) / max(0.5, self.total()))
        self.offset = 0.0
        self.zoom_changed.emit()
        self.update()

    def set_zoom(self, pps: float, anchor_o: Optional[float] = None) -> None:
        anchor_o = self.playhead if anchor_o is None else anchor_o
        ax = self._x(anchor_o)
        self.pps = max(4.0, min(600.0, pps))
        self.fit = False
        self.offset = max(0.0, anchor_o - (ax - HEAD) / self.pps)
        self.zoom_changed.emit()
        self.update()

    def resizeEvent(self, e) -> None:  # noqa: N802
        super().resizeEvent(e)
        if self.fit:
            self.fit_all()

    def _build(self) -> None:
        comp = self.comp
        self.blocks = []
        self.cuts = []
        if comp is None:
            return
        pl = comp.pl
        total = comp.total
        # video: the parts the user keeps (one when nothing was cut)
        self.segs = []
        user_segs = montage.segments_in(pl.a, pl.b, comp.m.get("segments"))
        for i, (sa, sb) in enumerate(user_segs):
            ps = [p for p in pl.pieces if not p.hook and p.a >= sa - 1e-3 and p.b <= sb + 1e-3]
            if not ps:
                continue
            o0, o1 = min(p.out_a for p in ps), max(p.out_b for p in ps)
            self.segs.append(Block("video", o0, o1, "", eid=f"seg:{i}", kind="seg",
                                   extra={"a": sa, "b": sb, "i": i, "n": len(user_segs)}))
        # video: slow motion, freezes, the cold open
        prev_main = None
        for p in pl.pieces:
            if p.hook:
                self.blocks.append(Block("video", p.out_a, p.out_b, "🎬 " + tr("st_tl_cold"), kind="hook"))
                continue
            if p.kind == "freeze":
                self.blocks.append(Block("video", p.out_a, p.out_b, "❄", kind="freeze"))
            elif abs(p.speed - 1.0) > 0.001:
                self.blocks.append(Block("video", p.out_a, p.out_b, f"{'🐢' if p.speed < 1 else '🐇'} ×{p.speed:g}",
                                         kind="slow"))
            if prev_main is not None and p.kind == "play" and prev_main.kind == "play" and p.a - prev_main.b > 0.05:
                self.cuts.append(p.out_a)
            if p.kind == "play":
                prev_main = p
        # subtitles: one block per card
        subs = comp.subtitles()
        if subs.look is not None:
            cur = None
            for ev in subs.events:
                if ev.title:
                    continue
                new = cur is None or subs.look.mode in ("word", "plain") or ev.first
                if new:
                    if cur is not None:
                        self.blocks.append(cur)
                    cur = Block("subs", ev.start, ev.end, ev.text, eid="subs", kind="subs")
                else:
                    cur.o1 = max(cur.o1, ev.end)
            if cur is not None:
                self.blocks.append(cur)
        # elements
        for e in pl.els:
            track = KIND_TRACK.get(e["kind"])
            if track is None:
                continue
            occ = montage.map_time(pl.pieces, e["t"])
            if not occ:
                continue
            main_o = montage.map_first(pl.pieces, e["t"])
            for o in occ:
                ghost = main_o is not None and abs(o - main_o) > 1e-6
                ln = self._length(e, o)
                wave = sound_wave(e.get("file") or "", self.cfg) if e["kind"] == "sound" else None
                self.blocks.append(Block(track, o, min(total, o + ln), element_label(e), e["id"], e["kind"], ghost,
                                         wave=wave, auto=bool(e.get("auto"))))
        mus = comp.m.get("music")
        if mus:
            name = bank.display_name(mus)
            mp = bank.resolve(mus, self.cfg)
            self.blocks.append(Block("music", 0.0, total, f"🎵 {name}  ·  {comp.m.get('music_vol', 18)} %", "music",
                                     "music", wave=sound_wave(mus, self.cfg, 96),
                                     extra={"dur": (bank.duration(mp) if mp is not None else 0.0) or 30.0}))
        self._pack_lanes()
        self._start_thumbs()

    def _length(self, e: dict, o: float) -> float:
        comp = self.comp
        k = e["kind"]
        if k == "slowmo":
            end = montage.map_first(comp.pl.pieces, e["t"] + e["dur"])
            return (end - o) if end is not None and end > o else e["dur"] / max(0.1, float(e.get("speed") or 0.5))
        if k in ("sound", "video"):
            if e.get("dur"):
                return float(e["dur"])
            p = bank.resolve(e.get("file") or "", self.cfg)
            d = bank.duration(p) if p is not None else 0.0
            return min(30.0, d) if k == "video" else (d or 1.0)
        return float(e.get("dur") or montage.DEFAULT_DUR.get(k, 1.0) or 1.0)

    def _pack_lanes(self) -> None:
        self.lanes = {t: 1 for t, _i in TRACKS}
        for track in ("memes", "fx", "sound"):
            ends: list[float] = []
            for b in sorted((b for b in self.blocks if b.track == track), key=lambda b: (b.o0, b.o1)):
                for i, end in enumerate(ends):
                    if b.o0 >= end - 1e-6:
                        b.lane = i
                        ends[i] = b.o1
                        break
                else:
                    b.lane = len(ends)
                    ends.append(b.o1)
            self.lanes[track] = max(1, min(6, len(ends)))
            for b in self.blocks:
                if b.track == track:
                    b.lane = min(b.lane, self.lanes[track] - 1)

    # ---------------------------------------------------------------- thumbnails of the video track
    def _start_thumbs(self) -> None:
        """Small pictures of the video along the video track (read in a thread, kept by VOD time)."""
        comp = self.comp
        src = self.src
        if comp is None or not src or not src.get("path"):
            self.thumbs = []
            return
        self._thumb_ver += 1
        ver = self._thumb_ver
        n = int(min(90, max(6, comp.total / 1.0)))
        times = []
        for o in preview.thumb_times(comp.total, n):
            v = comp.vod_time(o)
            times.append((o, round(v if v is not None else comp.pl.a, 1)))
        known = self._thumb_by_vod
        self.thumbs = [(o, known[v]) for o, v in times if v in known]
        missing = sorted({v for _o, v in times if v not in known})
        if not missing:
            return
        path, s0 = src.get("path"), float(src.get("vod_start") or 0.0)

        def work():
            got_all = {}
            try:
                from .live_preview import bgra_to_qimage
                rd = preview.VideoReader(path, 160, 90)
                for v in missing:
                    if ver != self._thumb_ver:
                        break
                    got = rd.frame_at(v - s0)
                    if got is not None:
                        got_all[v] = bgra_to_qimage(got[1])
                rd.close()
            except Exception:  # noqa: BLE001
                pass
            try:
                self._thumb_sig.done.emit((got_all, times), ver)
            except RuntimeError:
                pass                         # the window was closed meanwhile
        threading.Thread(target=work, daemon=True, name="timeline-thumbs").start()

    def _thumbs_done(self, res, ver: int) -> None:
        got_all, times = res
        self._thumb_by_vod.update(got_all)
        if len(self._thumb_by_vod) > 400:
            self._thumb_by_vod = dict(list(self._thumb_by_vod.items())[-300:])
        if ver == self._thumb_ver:
            known = self._thumb_by_vod
            self.thumbs = [(o, known[v]) for o, v in times if v in known]
            self.update()

    # ---------------------------------------------------------------- geometry
    def _x(self, o: float) -> float:
        return HEAD + (o - self.offset) * self.pps

    def _o(self, x: float) -> float:
        return self.offset + (x - HEAD) / self.pps

    def track_rect(self, track: str) -> QRectF:
        y = RULER + 4
        for t, _i in TRACKS:
            h = VIDEO_H if t == "video" else LANE_H * self.lanes.get(t, 1)
            if t == track:
                return QRectF(0, y, self.width(), h)
            y += h + 3
        return QRectF(0, y, self.width(), LANE_H)

    def sizeHint(self):  # noqa: N802
        from PySide6.QtCore import QSize
        h = RULER + 8 + VIDEO_H + sum(LANE_H * self.lanes.get(t, 1) + 3 for t, _i in TRACKS if t != "video")
        return QSize(600, int(h))

    def minimumSizeHint(self):  # noqa: N802
        from PySide6.QtCore import QSize
        return QSize(200, self.sizeHint().height())     # all the tracks: the timeline scrolls when it is short

    def block_rect(self, b: Block) -> QRectF:
        tr_ = self.track_rect(b.track)
        x0, x1 = self._x(b.o0), self._x(b.o1)
        if b.track == "video":
            return QRectF(x0, tr_.y() + 2, max(3.0, x1 - x0), tr_.height() - 4)
        return QRectF(x0, tr_.y() + b.lane * LANE_H + 2, max(6.0, x1 - x0), LANE_H - 4)

    def _hit(self, pos: QPointF) -> Optional[Block]:
        for b in reversed(self.blocks):
            if b.ghost or b.track == "video":
                continue
            if self.block_rect(b).adjusted(-2, -1, 2, 1).contains(pos):
                return b
        return None

    def _trim_hit(self, pos: QPointF) -> Optional[str]:
        tr_ = self.track_rect("video")
        if not tr_.contains(pos) or self.comp is None:
            return None
        if abs(pos.x() - self._x(0.0)) < 8:
            return "start"
        if abs(pos.x() - self._x(self.total())) < 8:
            return "end"
        return None

    def _seg_hit(self, pos: QPointF) -> Optional[Block]:
        """The kept part of the video under the mouse."""
        if not self.track_rect("video").contains(pos):
            return None
        o = self._o(pos.x())
        for b in self.segs:
            if b.o0 - 1e-6 <= o <= b.o1 + 1e-6:
                return b
        return None

    def _seg_edge_hit(self, pos: QPointF) -> Optional[tuple]:
        """(part index, "left" | "right") when the mouse is on the inner edge of a kept part."""
        if not self.track_rect("video").contains(pos) or len(self.segs) < 2:
            return None
        sel = self.selected_segment()
        for b in self.segs:
            # the picked part gets its edges first (two parts meet on the same pixel)
            if b.extra["i"] == sel:
                if b.extra["i"] > 0 and abs(pos.x() - self._x(b.o0)) < 6:
                    return (sel, "left")
                if b.extra["i"] < b.extra["n"] - 1 and abs(pos.x() - self._x(b.o1)) < 6:
                    return (sel, "right")
        for b in self.segs:
            i = b.extra["i"]
            if i < b.extra["n"] - 1 and abs(pos.x() - self._x(b.o1)) < 6:
                return (i, "right") if pos.x() < self._x(b.o1) else (i + 1, "left")
        return None

    def selected_segment(self) -> Optional[int]:
        if self.sel.startswith("seg:"):
            try:
                return int(self.sel[4:])
            except ValueError:
                return None
        return None

    # ---------------------------------------------------------------- painting
    def update(self, *args) -> None:  # noqa: D401 - something else than the red line changed
        self._static = None
        super().update(*args)

    def paintEvent(self, _e) -> None:  # noqa: N802
        w, h = self.width(), self.height()
        key = (w, h, self.devicePixelRatioF())
        if getattr(self, "_static", None) is None or self._static[0] != key:
            from PySide6.QtGui import QPixmap
            dpr = self.devicePixelRatioF()
            pm = QPixmap(int(w * dpr), int(h * dpr))
            pm.setDevicePixelRatio(dpr)
            pm.fill(QColor(theme.PANEL))
            sp = QPainter(pm)
            self._paint_static(sp)
            sp.end()
            self._static = (key, pm)
        p = QPainter(self)
        p.drawPixmap(0, 0, self._static[1])
        p.setRenderHint(QPainter.Antialiasing)
        p.setClipRect(QRectF(HEAD, 0, w - HEAD, h))
        x = self._x(self.playhead)
        p.setPen(QPen(QColor(theme.BAD), 2))
        p.drawLine(QPointF(x, 2), QPointF(x, h))
        p.setBrush(QColor(theme.BAD))
        p.setPen(Qt.NoPen)
        tri = QPainterPath()
        tri.moveTo(x - 6, 2)
        tri.lineTo(x + 6, 2)
        tri.lineTo(x, 11)
        tri.closeSubpath()
        p.drawPath(tri)
        p.end()

    def _paint_static(self, p: QPainter) -> None:
        p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        p.fillRect(self.rect(), QColor(theme.PANEL))
        f = QFont(self.font())
        f.setPointSizeF(8)
        p.setFont(f)
        total = self.total()
        # ruler
        p.fillRect(QRectF(HEAD, 0, w - HEAD, RULER), QColor("#18181d"))
        span = (w - HEAD) / self.pps
        step = next((s for s in (0.5, 1, 2, 5, 10, 15, 30, 60, 120) if s * self.pps >= 64), 300)
        t = math.floor(self.offset / step) * step
        p.setPen(QColor(theme.MUTED))
        while t <= self.offset + span + step:
            x = self._x(t)
            if x >= HEAD - 1 and t <= total + 1e-6:
                p.drawLine(QPointF(x, RULER - 7), QPointF(x, RULER))
                p.drawText(QPointF(x + 3, RULER - 9), fmt_time(t, 1 if step < 1 else 0))
            for k in range(1, 5):
                xs = self._x(t + step * k / 5)
                if HEAD <= xs <= w and t + step * k / 5 <= total:
                    p.drawLine(QPointF(xs, RULER - 3), QPointF(xs, RULER))
            t += step
        # tracks
        for track, icon in TRACKS:
            r = self.track_rect(track)
            p.fillRect(QRectF(HEAD, r.y(), w - HEAD, r.height()), QColor("#1f1f26"))
            p.fillRect(QRectF(0, r.y(), HEAD - 4, r.height()), QColor("#191920"))
            p.setPen(QColor(theme.MUTED))
            p.drawText(QRectF(8, r.y(), HEAD - 12, min(r.height(), LANE_H if track != "video" else VIDEO_H)),
                       Qt.AlignVCenter | Qt.AlignLeft, f"{icon} {tr('st_track_' + track)}")
        p.setClipRect(QRectF(HEAD, 0, w - HEAD, h))
        # video track: thumbnails + pieces
        vr = self.track_rect("video")
        x_end = self._x(total)
        bodies = [(self._x(b.o0), self._x(b.o1), b) for b in self.segs] or [(self._x(0.0), x_end, None)]
        for bx0, bx1, sb in bodies:
            body = QRectF(bx0 + (1.5 if sb is not None and sb.extra["i"] > 0 else 0), vr.y() + 2,
                          max(2.0, bx1 - bx0 - (3 if sb is not None and sb.extra["n"] > 1 else 0)), vr.height() - 4)
            path = QPainterPath()
            path.addRoundedRect(body, 6, 6)
            p.save()
            p.setClipPath(path, Qt.IntersectClip)
            p.fillRect(body, QColor(TRACK_COLOR["video"]))
            if self.thumbs:
                th_h = body.height()
                th_w = th_h * 16 / 9
                o = self._o(max(HEAD, body.x()))
                while self._x(o) < min(w, body.right()):
                    best = min(self.thumbs, key=lambda it: abs(it[0] - (o + th_w / self.pps / 2)))
                    p.drawImage(QRectF(self._x(o), body.y(), th_w, th_h), best[1])
                    o += th_w / self.pps
                p.fillRect(body, QColor(0, 0, 0, 70))
            p.restore()
            if sb is not None and sb.eid == self.sel:
                p.setPen(QPen(QColor("#ffffff"), 2))
                p.setBrush(Qt.NoBrush)
                p.drawRoundedRect(body.adjusted(1, 1, -1, -1), 6, 6)
                p.setPen(QColor("#ffffff"))
                p.drawText(body.adjusted(6, 0, -4, -3), Qt.AlignBottom | Qt.AlignLeft,
                           p.fontMetrics().elidedText(tr("st_seg_n", i=sb.extra["i"] + 1, n=sb.extra["n"]),
                                                      Qt.ElideRight, int(max(0, body.width() - 10))))
        # the inner edges of the parts (drag them)
        for b in self.segs:
            if b.extra["n"] < 2:
                continue
            for side, x in (("left", self._x(b.o0)), ("right", self._x(b.o1))):
                i = b.extra["i"]
                if (side == "left" and i == 0) or (side == "right" and i == b.extra["n"] - 1):
                    continue
                hl = self._hover == ("seg", i, side) or (self._drag and self._drag.get("mode") == "segedge"
                                                         and (self._drag["i"], self._drag["side"]) == (i, side))
                p.setPen(Qt.NoPen)
                p.setBrush(QColor(theme.ACCENT if hl else "#c8c8d0"))
                hx = x - 3 if side == "right" else x
                p.drawRoundedRect(QRectF(hx, vr.y() + 6, 3, vr.height() - 12), 1.5, 1.5)
        if self._drag and self._drag.get("mode") == "segedge":
            d = self._drag
            p.setPen(QPen(QColor(theme.ACCENT), 2))
            p.drawLine(QPointF(d["x"], vr.y()), QPointF(d["x"], vr.bottom()))
            p.setPen(QColor("#ffffff"))
            p.drawText(QPointF(d["x"] + 4, vr.y() - 2), ("+" if d["delta"] >= 0 else "−") + fmt_time(abs(d["delta"]), 1))
        for b in self.blocks:
            if b.track != "video":
                continue
            r = self.block_rect(b)
            col = {"hook": QColor(theme.ACCENT_2), "freeze": QColor("#7fc8ff"), "slow": QColor("#a970ff")}.get(b.kind)
            if col is None:
                continue
            col.setAlpha(110)
            p.fillRect(r, QBrush(col, Qt.SolidPattern if b.kind != "slow" else Qt.Dense5Pattern))
            p.setPen(QColor("#ffffff"))
            p.drawText(r.adjusted(4, 0, -2, 0), Qt.AlignTop | Qt.AlignLeft,
                       p.fontMetrics().elidedText(b.label, Qt.ElideRight, int(max(0, r.width() - 6))))
        p.setPen(QPen(QColor(255, 255, 255, 200), 1.5))
        for c in self.cuts:
            x = self._x(c)
            p.drawLine(QPointF(x, vr.y() + 3), QPointF(x, vr.bottom() - 3))
            p.drawText(QPointF(x + 2, vr.bottom() - 5), "✂")
        # trim handles
        for side, x in (("start", self._x(0.0)), ("end", x_end)):
            hl = self._hover == ("trim", side) or (self._drag and self._drag.get("mode") == "trim"
                                                    and self._drag.get("side") == side)
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(theme.ACCENT if hl else "#e8e8ee"))
            hr = QRectF(x - (6 if side == "end" else 0), vr.y() + 2, 6, vr.height() - 4)
            p.drawRoundedRect(hr, 2, 2)
        if self._drag and self._drag.get("mode") == "trim":
            d = self._drag
            x = d["x"]
            p.fillRect(QRectF(min(x, d["x0"]), vr.y(), abs(x - d["x0"]), vr.height()),
                       QColor(255, 106, 61, 70 if d["delta"] > 0 else 140))
            p.setPen(QColor("#ffffff"))
            p.drawText(QPointF(x + 4, vr.y() - 2), ("+" if d["delta"] >= 0 else "−") + fmt_time(abs(d["delta"]), 1))
        # blocks
        for b in self.blocks:
            if b.track == "video":
                continue
            r = self.block_rect(b)
            if r.right() < HEAD or r.left() > w:
                continue
            base = QColor(b.color or TRACK_COLOR.get(b.track, theme.ACCENT))
            if b.track == "subs":
                base = QColor("#4a4a58")
            if b.ghost:
                base.setAlpha(70)
            elif b.auto:
                base.setAlpha(190)
            sel = (b.eid and b.eid == self.sel and not b.ghost)
            g = QLinearGradient(0, r.top(), 0, r.bottom())
            g.setColorAt(0, base.lighter(115))
            g.setColorAt(1, base)
            p.setBrush(QBrush(g))
            p.setPen(QPen(QColor("#ffffff") if sel else base.darker(140), 2 if sel else 1))
            p.drawRoundedRect(r, 5, 5)
            if b.wave and r.width() > 12:
                p.save()
                p.setClipRect(r.adjusted(1, 1, -1, -1), Qt.IntersectClip)
                p.setPen(Qt.NoPen)
                p.setBrush(QColor(255, 255, 255, 70 if not b.ghost else 30))
                n = len(b.wave)
                if b.track == "music":
                    seg_w = max(1.0, float(b.extra.get("dur") or 30.0)) * self.pps
                else:
                    seg_w = r.width()
                x0 = r.left()
                mid = r.center().y()
                while x0 < r.right():
                    for i, v in enumerate(b.wave):
                        bx = x0 + seg_w * i / n
                        if bx > r.right():
                            break
                        bh = (r.height() - 6) * max(0.06, v / 99.0)
                        p.drawRect(QRectF(bx, mid - bh / 2, max(1.0, seg_w / n - 1), bh))
                    x0 += seg_w
                    if b.track != "music":
                        break
                p.restore()
            txt_col = QColor("#101014") if b.track in ("memes", "sound", "music") else QColor("#ffffff")
            if b.track == "subs":
                txt_col = QColor("#e8e8ee")
            if b.ghost:
                txt_col.setAlpha(120)
            p.setPen(txt_col)
            label = b.label + ("  ✨" if b.auto and not b.ghost else "")
            p.drawText(r.adjusted(5, 0, -3, 0), Qt.AlignVCenter | Qt.AlignLeft,
                       p.fontMetrics().elidedText(label, Qt.ElideRight, int(max(0, r.width() - 8))))
            if sel and b.track != "subs" and b.kind not in ("music",):
                p.setPen(Qt.NoPen)
                p.setBrush(QColor("#ffffff"))
                p.drawRoundedRect(QRectF(r.left() - 1, r.top() + 4, 4, r.height() - 8), 2, 2)
                p.drawRoundedRect(QRectF(r.right() - 3, r.top() + 4, 4, r.height() - 8), 2, 2)
        # end of the clip
        p.setPen(QPen(QColor(theme.BORDER), 1, Qt.DashLine))
        p.drawLine(QPointF(x_end, RULER), QPointF(x_end, h))

    # ---------------------------------------------------------------- mouse
    def _snap(self, o: float, exclude: str = "") -> float:
        cands = [0.0, self.total(), self.playhead] + self.cuts + [x for b in self.segs for x in (b.o0, b.o1)]
        for b in self.blocks:
            if b.eid and b.eid != exclude and not b.ghost:
                cands += [b.o0, b.o1]
        best = min(cands, key=lambda c: abs(c - o)) if cands else o
        return best if abs(best - o) * self.pps < 7 else o

    def mousePressEvent(self, ev) -> None:  # noqa: N802
        pos = ev.position()
        if self.comp is None:
            return
        if ev.button() == Qt.RightButton:
            b = self._hit(pos)
            if b is not None and b.eid not in ("subs", "music"):
                self.sel = b.eid
                self.selected.emit(b.eid)
                self._menu(b, ev.globalPosition().toPoint())
                return
            sb = self._seg_hit(pos)
            if sb is not None:
                self.sel = sb.eid
                self.selected.emit(sb.eid)
                self.seek.emit(max(0.0, min(self.total(), self._o(pos.x()))))
                self.update()
                self._seg_menu(sb, ev.globalPosition().toPoint())
            return
        if ev.button() != Qt.LeftButton:
            return
        side = self._trim_hit(pos)
        if side:
            self._drag = {"mode": "trim", "side": side, "x0": pos.x(), "x": pos.x(), "delta": 0.0}
            self.update()
            return
        edge = self._seg_edge_hit(pos)
        if edge:
            self._drag = {"mode": "segedge", "i": edge[0], "side": edge[1], "x0": pos.x(), "x": pos.x(), "delta": 0.0}
            self.update()
            return
        sb = self._seg_hit(pos)
        if sb is not None:
            # a kept part of the video: pick it, the red line follows the mouse
            self.sel = sb.eid
            self.selected.emit(sb.eid)
            self._drag = {"mode": "scrub"}
            self.seek.emit(max(0.0, min(self.total(), self._o(pos.x()))))
            self.update()
            return
        if pos.y() < RULER:
            self._drag = {"mode": "scrub"}
            self.seek.emit(max(0.0, min(self.total(), self._o(pos.x()))))
            return
        b = self._hit(pos)
        if b is None:
            self.sel = ""
            self.selected.emit("")
            self._drag = {"mode": "scrub"}
            self.seek.emit(max(0.0, min(self.total(), self._o(pos.x()))))
            self.update()
            return
        self.sel = b.eid
        self.selected.emit(b.eid)
        if b.eid in ("subs", "music"):
            self.update()
            return
        r = self.block_rect(b)
        mode = "move"
        if pos.x() - r.left() < 7 and b.kind not in ("sound", "video") or pos.x() - r.left() < 5:
            mode = "left"
        elif r.right() - pos.x() < 7:
            mode = "right"
        self._drag = {"mode": mode, "id": b.eid, "x0": pos.x(), "o0": b.o0, "o1": b.o1, "moved": False}
        self.update()

    def mouseMoveEvent(self, ev) -> None:  # noqa: N802
        pos = ev.position()
        d = self._drag
        if d is None:
            side = self._trim_hit(pos)
            if side:
                self._hover = ("trim", side)
                self.setCursor(Qt.SizeHorCursor)
                self.setToolTip(tr("st_tl_trim_tip"))
                self.update()
                return
            edge = self._seg_edge_hit(pos)
            if edge:
                self._hover = ("seg", edge[0], edge[1])
                self.setCursor(Qt.SizeHorCursor)
                self.setToolTip(tr("st_seg_edge_tip"))
                self.update()
                return
            if self._hover is not None:
                self._hover = None
                self.update()
            b = self._hit(pos)
            if b is None:
                sb = self._seg_hit(pos)
                if sb is not None:
                    self.setCursor(Qt.PointingHandCursor)
                    self.setToolTip(tr("st_seg_tip", i=sb.extra["i"] + 1, n=sb.extra["n"],
                                       start=fmt_time(sb.extra["a"], 1), end=fmt_time(sb.extra["b"], 1)))
                    return
                self.setCursor(Qt.ArrowCursor if pos.y() > RULER else Qt.PointingHandCursor)
                self.setToolTip("")
                return
            r = self.block_rect(b)
            if b.eid in ("subs", "music"):
                self.setCursor(Qt.PointingHandCursor)
                if b.eid == "subs":
                    self.setToolTip(f"{b.label}\n{tr('st_tl_subs_tip')}")
                    return
            elif pos.x() - r.left() < 7 or r.right() - pos.x() < 7:
                self.setCursor(Qt.SizeHorCursor)
            else:
                self.setCursor(Qt.OpenHandCursor)
            self.setToolTip(f"{b.label}\n{fmt_time(b.o0, 1)} → {fmt_time(b.o1, 1)}")
            return
        if d["mode"] == "scrub":
            self.seek.emit(max(0.0, min(self.total(), self._o(pos.x()))))
            return
        if d["mode"] == "trim":
            d["x"] = pos.x()
            dx = (pos.x() - d["x0"]) / self.pps
            d["delta"] = -dx if d["side"] == "start" else dx
            self.update()
            return
        if d["mode"] == "segedge":
            d["x"] = pos.x()
            d["delta"] = (pos.x() - d["x0"]) / self.pps
            self.update()
            return
        dt = (pos.x() - d["x0"]) / self.pps
        if abs(pos.x() - d["x0"]) < 3 and not d["moved"]:
            return
        d["moved"] = True
        if d["mode"] == "move":
            o0 = self._snap(d["o0"] + dt, d["id"])
            ln = d["o1"] - d["o0"]
            o_end = self._snap(o0 + ln, d["id"])
            if abs(o_end - (o0 + ln)) > 1e-6 and abs(o0 - (d["o0"] + dt)) < 1e-6:
                o0 = o_end - ln
            o0 = max(0.0, min(self.total() - 0.1, o0))
            self.moved.emit(d["id"], o0)
        elif d["mode"] == "right":
            o1 = self._snap(d["o1"] + dt, d["id"])
            self.resized.emit(d["id"], d["o0"], max(0.1, o1 - d["o0"]))
        else:
            o0 = self._snap(d["o0"] + dt, d["id"])
            o0 = max(0.0, min(d["o1"] - 0.1, o0))
            self.resized.emit(d["id"], o0, d["o1"] - o0)

    def mouseReleaseEvent(self, _ev) -> None:  # noqa: N802
        d, self._drag = self._drag, None
        if d is None:
            return
        if d["mode"] == "trim":
            if abs(d["delta"]) * self.pps >= 3:
                self.trimmed.emit(d["side"], d["delta"])
            self.update()
            return
        if d["mode"] == "segedge":
            if abs(d["delta"]) * self.pps >= 3:
                self.segment_trimmed.emit(d["i"], d["side"], d["delta"])
            self.update()
            return
        if d.get("moved"):
            self.edit_done.emit(d["id"])
        self.update()

    def mouseDoubleClickEvent(self, ev) -> None:  # noqa: N802
        b = self._hit(ev.position())
        if b is not None and b.track == "subs":
            self.edit_subs.emit()
        elif b is not None:
            self.seek.emit(max(0.0, b.o0))

    def wheelEvent(self, ev) -> None:  # noqa: N802
        dy = ev.angleDelta().y() or ev.angleDelta().x()
        if ev.modifiers() & Qt.ControlModifier:
            o = self._o(ev.position().x())
            self.set_zoom(self.pps * (1.25 if dy > 0 else 0.8), o)
        else:
            if self.fit:
                ev.ignore()            # the whole clip is in view: the wheel scrolls the tracks up / down
                return
            self.offset = max(0.0, min(max(0.0, self.total() - 2.0), self.offset - dy / 120 * 60 / self.pps))
            self.zoom_changed.emit()
            self.update()
        ev.accept()

    def keyPressEvent(self, ev) -> None:  # noqa: N802
        if ev.key() in (Qt.Key_Delete, Qt.Key_Backspace) and self.sel and self.sel not in ("subs", "music"):
            i = self.selected_segment()
            if i is not None:
                self.segment_delete.emit(i)
            else:
                self.delete_requested.emit(self.sel)
            return
        super().keyPressEvent(ev)

    def _seg_menu(self, b: Block, gpos) -> None:
        m = QMenu(self)
        m.addAction("✂ " + tr("st_cut_here") + "  (S)", self.cut_here.emit)
        n = b.extra["n"]
        a = m.addAction("🗑 " + tr("st_seg_delete"), lambda: self.segment_delete.emit(b.extra["i"]))
        a.setEnabled(n > 1)
        m.addAction("⇤ " + tr("st_cut_before"), lambda: self.cut_side.emit("before"))
        m.addAction("⇥ " + tr("st_cut_after"), lambda: self.cut_side.emit("after"))
        m.addSeparator()
        a = m.addAction("↺ " + tr("st_cuts_reset"), self.cuts_reset.emit)
        a.setEnabled(n > 1)
        m.exec(gpos)

    def _menu(self, b: Block, gpos) -> None:
        m = QMenu(self)
        m.addAction("▶ " + tr("st_el_go"), lambda: self.seek.emit(max(0.0, b.o0)))
        m.addAction("⧉ " + tr("st_el_duplicate"), lambda: self.duplicate_requested.emit(b.eid))
        m.addSeparator()
        m.addAction("🗑 " + tr("st_el_delete"), lambda: self.delete_requested.emit(b.eid))
        m.exec(gpos)

    # ---------------------------------------------------------------- drop from the library
    def _track_at(self, y: float) -> str:
        for t, _i in TRACKS:
            if self.track_rect(t).contains(QPointF(10, y)):
                return t
        return ""

    def dragEnterEvent(self, e) -> None:  # noqa: N802
        if e.mimeData().hasFormat(MIME):
            e.acceptProposedAction()

    def dragMoveEvent(self, e) -> None:  # noqa: N802
        if e.mimeData().hasFormat(MIME):
            e.acceptProposedAction()

    def dropEvent(self, e) -> None:  # noqa: N802
        if not e.mimeData().hasFormat(MIME) or self.comp is None:
            return
        item = bytes(e.mimeData().data(MIME)).decode("utf-8")
        o = max(0.0, min(self.total() - 0.1, self._o(e.position().x())))
        self.dropped.emit(item, o, self._track_at(e.position().y()))
        e.acceptProposedAction()


class TimelinePanel(QWidget):
    """The timeline with its zoom buttons and scroll bar."""

    def __init__(self, parent=None):
        super().__init__(parent)
        v = QVBoxLayout(self)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(2)
        row = QHBoxLayout()
        row.setContentsMargins(6, 0, 6, 0)
        row.setSpacing(4)
        self.btn_fit = QToolButton()
        self.btn_fit.setText("↔ " + tr("st_tl_fit"))
        self.btn_fit.setObjectName("Flat")
        self.btn_fit.setToolTip(tr("st_tl_fit_tip"))
        self.btn_cut = QToolButton()
        self.btn_cut.setText("✂ " + tr("st_cut_here"))
        self.btn_cut.setObjectName("Flat")
        self.btn_cut.setToolTip(tr("st_cut_here_tip"))
        self.btn_seg_del = QToolButton()
        self.btn_seg_del.setText("🗑 " + tr("st_seg_delete_short"))
        self.btn_seg_del.setObjectName("Flat")
        self.btn_seg_del.setToolTip(tr("st_seg_delete_tip"))
        self.btn_seg_del.setEnabled(False)
        row.addWidget(self.btn_cut)
        row.addWidget(self.btn_seg_del)
        row.addStretch(1)
        b_out = QToolButton()
        b_out.setText("−")
        b_out.setObjectName("Flat")
        b_out.setToolTip(tr("st_tl_zoom_tip"))
        self.zoom = QSlider(Qt.Horizontal)
        self.zoom.setRange(0, 100)
        self.zoom.setFixedWidth(140)
        self.zoom.setToolTip(tr("st_tl_zoom_tip"))
        b_in = QToolButton()
        b_in.setText("+")
        b_in.setObjectName("Flat")
        b_in.setToolTip(tr("st_tl_zoom_tip"))
        row.addWidget(b_out)
        row.addWidget(self.zoom)
        row.addWidget(b_in)
        row.addWidget(self.btn_fit)
        self.canvas = TimelineCanvas()
        self.tracks = QScrollArea()             # up / down when the window is too short for all the tracks
        self.tracks.setWidget(self.canvas)
        self.tracks.setWidgetResizable(True)
        self.tracks.setFrameShape(QFrame.NoFrame)
        self.tracks.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.scroll = QScrollBar(Qt.Horizontal)
        v.addWidget(self.tracks, 1)
        v.addWidget(self.scroll)
        v.addLayout(row)
        self._row = row
        self._block = False
        self.btn_fit.clicked.connect(self.canvas.fit_all)
        self.btn_cut.clicked.connect(self.canvas.cut_here.emit)
        self.btn_seg_del.clicked.connect(self._delete_selected_segment)
        self.canvas.selection_changed.connect(lambda _e: self._sync_cut_buttons())
        b_out.clicked.connect(lambda: self.canvas.set_zoom(self.canvas.pps * 0.75))
        b_in.clicked.connect(lambda: self.canvas.set_zoom(self.canvas.pps * 1.33))
        self.zoom.valueChanged.connect(self._zoom_slider)
        self.scroll.valueChanged.connect(self._scrolled)
        self.canvas.zoom_changed.connect(self._sync)
        QTimer.singleShot(0, self._sync)

    def _delete_selected_segment(self) -> None:
        i = self.canvas.selected_segment()
        if i is not None:
            self.canvas.segment_delete.emit(i)

    def _sync_cut_buttons(self) -> None:
        self.btn_seg_del.setEnabled(self.canvas.selected_segment() is not None and len(self.canvas.segs) > 1)

    def wanted_height(self) -> int:
        """Height that shows every track without scrolling."""
        row_h = max(26, self.btn_fit.sizeHint().height())
        bar = self.scroll.sizeHint().height() if self.scroll.isVisible() else 0
        return self.canvas.sizeHint().height() + bar + row_h + 8

    def _fit_pps(self) -> float:
        c = self.canvas
        return max(4.0, (c.width() - HEAD - 16) / max(0.5, c.total()))

    def _zoom_slider(self, v: int) -> None:
        if self._block:
            return
        lo = self._fit_pps()
        if v <= 0:
            self.canvas.fit_all()
            return
        pps = lo * (600.0 / lo) ** (v / 100.0)
        self.canvas.set_zoom(pps)

    def _scrolled(self, v: int) -> None:
        if self._block:
            return
        self.canvas.offset = v / 100.0
        self.canvas.update()

    def _sync(self) -> None:
        c = self.canvas
        self._block = True
        lo = self._fit_pps()
        if c.fit or c.pps <= lo * 1.001:
            self.zoom.setValue(0)
        else:
            self.zoom.setValue(int(round(100 * math.log(c.pps / lo) / math.log(max(1.0001, 600.0 / lo)))))
        visible = (c.width() - HEAD) / max(1e-6, c.pps)
        hidden = max(0.0, c.total() - visible + 1.0)
        self.scroll.setRange(0, int(hidden * 100))
        self.scroll.setPageStep(int(visible * 100))
        self.scroll.setValue(int(c.offset * 100))
        self.scroll.setVisible(hidden > 0.05 and not c.fit)
        self._block = False
