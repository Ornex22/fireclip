"""The Studio live preview: the clip as it will be exported, drawn on screen while it plays - no render.

- Compositor draws the picture at a time (QPainter) from a preview.Composition and a stream frame;
- FrameWorker reads the stream frames (and the meme videos) ahead of time in a thread (PyAV);
- AudioEngine makes the sound of the clip (preview.mix_audio, in a thread) and plays it;
- PreviewPlayer keeps time (play / pause / seek on the clip timeline);
- PreviewCanvas shows the picture, and lets you pick / move / resize / turn the memes with the mouse."""
from __future__ import annotations

import logging
import math
import os
import threading
import time
from typing import Optional

from PySide6.QtCore import QElapsedTimer, QObject, QPointF, QRectF, QSize, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QFont, QImage, QPainter, QPen, QPolygonF, QTransform
from PySide6.QtWidgets import QSizePolicy, QWidget

from .. import preview
from ..preview import Composition
from . import theme

log = logging.getLogger("fireclips.preview_ui")


# =========================================================================== pictures


def pil_to_qimage(im) -> QImage:
    """PIL RGBA picture -> QImage (premultiplied, owns its memory)."""
    if im.mode != "RGBA":
        im = im.convert("RGBA")
    data = im.tobytes("raw", "BGRA")
    q = QImage(data, im.width, im.height, im.width * 4, QImage.Format_ARGB32)
    return q.convertToFormat(QImage.Format_ARGB32_Premultiplied)


def bgra_to_qimage(arr, fmt=QImage.Format_RGB32) -> QImage:
    """numpy (h, w, 4) BGRA -> QImage (a copy: owns its memory)."""
    h, w = arr.shape[:2]
    q = QImage(arr.data, w, h, int(arr.strides[0]), fmt)
    return q.copy()


def qimage_array(img: QImage):
    """numpy view (h, w, 4) BGRA of a 32-bit QImage (writable, shares the memory)."""
    import numpy as np
    w, h = img.width(), img.height()
    ptr = img.bits()
    arr = np.frombuffer(ptr, np.uint8, count=img.bytesPerLine() * h).reshape(h, img.bytesPerLine())
    return arr[:, : w * 4].reshape(h, w, 4)


def _box_blur(a, r: int):
    """Box blur of a float32 (h, w, c) array along both axes (edges repeated)."""
    import numpy as np
    if r <= 0:
        return a
    for axis in (0, 1):
        pad = [(0, 0)] * a.ndim
        pad[axis] = (r + 1, r)
        p = np.pad(a, pad, mode="edge")
        c = np.cumsum(p, axis=axis, dtype=np.float32)
        n = a.shape[axis]
        if axis == 0:
            a = (c[2 * r + 1: 2 * r + 1 + n] - c[:n]) / (2 * r + 1)
        else:
            a = (c[:, 2 * r + 1: 2 * r + 1 + n] - c[:, :n]) / (2 * r + 1)
    return a


def blurred_background(src: QImage, rect: tuple, W: int, H: int) -> QImage:
    """The 9:16 background of the export: the stream picture covering the clip, very blurred (gblur
    sigma 12 at a quarter size), a little darker and more saturated - made at an eighth of the size."""
    import numpy as np
    bw, bh = max(2, W // 8), max(2, H // 8)
    x, y, w, h = rect
    small = src.copy(int(x), int(y), max(1, int(w)), max(1, int(h))).scaled(bw, bh, Qt.IgnoreAspectRatio,
                                                                           Qt.SmoothTransformation)
    small = small.convertToFormat(QImage.Format_RGB32)
    a = qimage_array(small)[..., :3].astype(np.float32)
    for _ in range(3):
        a = _box_blur(a, 6)
    y_ = a.mean(axis=2, keepdims=True)
    a = y_ + (a - y_) * 1.1 - 18.0
    out = np.empty((bh, bw, 4), np.uint8)
    out[..., :3] = np.clip(a, 0, 255).astype(np.uint8)
    out[..., 3] = 255
    return bgra_to_qimage(out)


class Compositor:
    """Draws the clip picture at a time (W x H of the composition)."""

    def __init__(self):
        self.comp: Optional[Composition] = None
        self._q: dict = {}
        self.hits: list[tuple[str, QPolygonF, dict]] = []    # what is where on the last picture
        self._bg = (None, None)

    def set_comp(self, comp: Composition) -> None:
        if self.comp is not None and comp is not None and (comp.W, comp.H) != (self.comp.W, self.comp.H):
            self._q.clear()
        self.comp = comp
        if len(self._q) > 400:
            self._q.clear()

    def qimage(self, key, pil) -> QImage:
        got = self._q.get(key)
        if got is not None and got[0] is pil:
            return got[1]
        q = pil_to_qimage(pil)
        if len(self._q) > 600:
            self._q.clear()
        self._q[key] = (pil, q)
        return q

    def frame(self, o: float, src: Optional[QImage], videos: Optional[dict] = None,
              src_key=None) -> QImage:
        comp = self.comp
        W, H = comp.W, comp.H
        img = QImage(W, H, QImage.Format_RGB32)
        img.fill(QColor(0, 0, 0))
        p = QPainter(img)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)
        p.setRenderHint(QPainter.Antialiasing, True)
        z, cx, cy, dx, dy = comp.zoom(o)
        if src is not None and not src.isNull():
            rects = comp.layout_rects(src.width(), src.height())
            if rects.get("bg") is not None:
                # the blurred background barely changes: made again at most 15 times a second
                bkey = (src_key[0], round(src_key[1] * 15)) if isinstance(src_key, tuple) and len(src_key) == 2 \
                    else None
                if self._bg[0] != bkey or bkey is None:
                    self._bg = (bkey, blurred_background(src, rects["bg"], W, H))
                p.drawImage(QRectF(0, 0, W, H), self._bg[1])
            if rects.get("cam") is not None:
                s_, d_ = rects["cam"]
                p.drawImage(QRectF(*d_), src, QRectF(*s_))
            s_, d_ = rects["game"]
            p.drawImage(QRectF(*d_), src, QRectF(*preview.zoomed(s_, z, cx, cy, dx, dy)))
        effects = comp.filters(o)
        if effects:
            p.end()
            preview.filter_picture(qimage_array(img), effects, o, W)
            p = QPainter(img)
            p.setRenderHint(QPainter.SmoothPixmapTransform, True)
            p.setRenderHint(QPainter.Antialiasing, True)
        self.hits = []
        for ov in comp.overlays(o, slow_ok=False):
            if ov.kind == "video":
                q = (videos or {}).get(ov.eid)
                if q is None or q.isNull():
                    continue
                x, y, w, h = comp.video_box(ov.element, q.width(), q.height())
                if ov.element.get("full"):
                    p.fillRect(QRectF(0, 0, W, H), QColor(0, 0, 0))
                p.drawImage(QRectF(x, y, w, h), q)
                self.hits.append((ov.eid, QPolygonF(QRectF(x, y, w, h)), ov.element))
                continue
            q = self.qimage(ov.key[:3], ov.image)
            p.save()
            if ov.clip is not None:
                p.setClipRect(QRectF(*ov.clip))
            p.setOpacity(max(0.0, min(1.0, ov.alpha)))
            t = QTransform()
            t.translate(ov.cx, ov.cy)
            t.rotate(-ov.angle)
            t.scale(ov.scale, ov.scale)
            p.setTransform(t)
            r = QRectF(-q.width() / 2, -q.height() / 2, q.width(), q.height())
            p.drawImage(r, q)
            p.restore()
            if ov.kind != "fx":
                self.hits.append((ov.eid, t.map(QPolygonF(r)), ov.element))
            elif ov.element is not None and preview.fxlib.EFFECTS.get(ov.element.get("effect"), {}).get("pos"):
                gx, gy, gw, gh = comp.game
                ex = gx + float(ov.element.get("x") if ov.element.get("x") is not None else 0.5) * gw
                ey = gy + float(ov.element.get("y") if ov.element.get("y") is not None else 0.5) * gh
                rr = min(W, H) * 0.12 * float(ov.element.get("size") or 1.0)
                self.hits.append((ov.eid, QPolygonF(QRectF(ex - rr, ey - rr, 2 * rr, 2 * rr)), ov.element))
        subs = comp.subtitles()
        if subs.look is not None:
            for i, ev in subs.active(o):
                q = self.qimage(("sub", id(subs), i), subs.picture(i))
                x, y, s, ang, a = subs.state(ev, o)
                if a <= 0:
                    continue
                p.save()
                p.setOpacity(a)
                t = QTransform()
                t.translate(x, y)
                t.rotate(-ang)
                t.scale(s, s)
                p.setTransform(t)
                p.drawImage(QPointF(-q.width() / 2, -q.height() / 2), q)
                p.restore()
        wm = comp.watermark()
        if wm is not None:
            pic, X, Y = wm
            p.drawImage(QPointF(X, Y), self.qimage(("wm", id(comp)), pic))
        p.end()
        return img


# =========================================================================== reading frames ahead


class _Notifier(QObject):
    frame = Signal()


class FrameWorker(threading.Thread):
    """Reads the stream frames (and meme video frames) the preview needs, a little ahead of time."""

    AHEAD = 0.6            # seconds read ahead while playing

    def __init__(self):
        super().__init__(daemon=True, name="preview-frames")
        self.note = _Notifier()
        self.cond = threading.Condition()
        self.quit = False
        self.src: Optional[dict] = None
        self.reader: Optional[preview.VideoReader] = None
        self._reader_path = ""
        self.comp: Optional[Composition] = None
        self.gen = 0
        self.mode = "idle"          # idle | scrub | play
        self.scrub_o = 0.0
        self.next_k = 0
        self.clock_o = 0.0
        self.frames: dict[int, tuple] = {}        # k -> (gen, stream QImage, key, {eid: QImage})
        self.last: Optional[tuple] = None         # the last frame made (any time)
        self._memes: dict[str, preview.VideoReader] = {}
        self._meme_q: dict = {}

    # ---------------------------------------------------------------- GUI side
    def set_source(self, src: Optional[dict]) -> None:
        with self.cond:
            self.src = src
            self.gen += 1
            self.frames.clear()
            self.cond.notify_all()

    def set_comp(self, comp: Optional[Composition]) -> None:
        with self.cond:
            self.comp = comp
            self.gen += 1
            self.frames.clear()
            if self.mode == "play":
                self.next_k = int(self.clock_o * preview.FPS)
            self.cond.notify_all()

    def scrub(self, o: float) -> None:
        with self.cond:
            self.mode = "scrub"
            self.scrub_o = o
            self.gen += 1
            self.cond.notify_all()

    def play_from(self, o: float) -> None:
        with self.cond:
            self.mode = "play"
            self.clock_o = o
            self.next_k = int(o * preview.FPS)
            self.gen += 1
            self.frames.clear()
            self.cond.notify_all()

    def pause(self) -> None:
        with self.cond:
            self.mode = "idle"
            self.cond.notify_all()

    def tick(self, o: float) -> None:
        self.clock_o = o
        with self.cond:
            self.cond.notify_all()

    def take(self, o: float) -> Optional[tuple]:
        """The frame for clip time o: (stream QImage, key, {eid: meme video QImage}) or None."""
        k = int(o * preview.FPS + 1e-6)
        with self.cond:
            got = self.frames.get(k)
            if got is None:
                ks = [x for x in self.frames if x <= k]
                if ks:
                    got = self.frames[max(ks)]
            for old in [x for x in self.frames if x < k - 3]:
                del self.frames[old]
            if got is not None and got[0] == self.gen:
                return got[1:]
            return self.last[1:] if self.last is not None else None

    def stop(self) -> None:
        with self.cond:
            self.quit = True
            self.cond.notify_all()

    # ---------------------------------------------------------------- thread side
    def run(self) -> None:
        while True:
            with self.cond:
                while not self.quit and not self._has_work():
                    self.cond.wait(0.25)
                if self.quit:
                    break
                mode, gen, comp, src = self.mode, self.gen, self.comp, self.src
                o = self.scrub_o if mode == "scrub" else self.next_k / preview.FPS
                k = int(self.scrub_o * preview.FPS + 1e-6) if mode == "scrub" else self.next_k
            try:
                item = self._make(comp, src, o)
            except Exception as e:  # noqa: BLE001
                log.warning("preview frame: %s", e)
                item = None
                time.sleep(0.05)
            with self.cond:
                if gen != self.gen:
                    continue
                if item is not None:
                    entry = (gen,) + item
                    self.frames[k] = entry
                    self.last = entry
                if mode == "scrub":
                    self.mode = "idle"
                else:
                    self.next_k += 1
            self.note.frame.emit()
        self._close_all()

    def _has_work(self) -> bool:
        if self.comp is None or self.src is None:
            return False
        if self.mode == "scrub":
            return True
        if self.mode == "play":
            return self.next_k / preview.FPS < min(self.comp.total, self.clock_o + self.AHEAD)
        return False

    def _open(self, src: dict) -> Optional[preview.VideoReader]:
        path = src.get("path") or ""
        if self.reader is not None and self._reader_path == path:
            return self.reader
        if self.reader is not None:
            self.reader.close()
        self.reader = None
        try:
            self.reader = preview.VideoReader(path)
            self._reader_path = path
        except Exception as e:  # noqa: BLE001
            log.warning("preview video %s: %s", path, e)
        return self.reader

    def _make(self, comp: Composition, src: dict, o: float):
        rd = self._open(src)
        if rd is None:
            return None
        v = comp.vod_time(o)
        if v is None:
            v = comp.pl.a
        f = v - float(src.get("vod_start") or 0.0)
        got = rd.frame_at(f)
        if got is None:
            return None
        ft, arr = got
        key = (self._reader_path, round(ft, 4))
        last = self.last
        if last is not None and last[2] == key:
            qimg = last[1]
        else:
            qimg = bgra_to_qimage(arr)
        memes = {}
        for e, vt, _d in comp.videos(o):
            q = self._meme_frame(comp, e, vt)
            if q is not None:
                memes[e["id"]] = q
        # make the pictures of this moment now (effects, texts, subtitles): the screen finds them ready
        comp.overlays(o)
        subs = comp.subtitles()
        if subs.look is not None:
            for i, _ev in subs.active(o):
                subs.picture(i)
        return qimg, key, memes

    def _meme_frame(self, comp: Composition, e: dict, vt: float) -> Optional[QImage]:
        p = preview.bank.resolve(e.get("file") or "", comp.cfg)
        if p is None:
            return None
        rd = self._memes.get(str(p))
        if rd is None:
            try:
                rd = preview.VideoReader(str(p), 720, 720)
            except Exception as ex:  # noqa: BLE001
                log.info("meme video %s: %s", p, ex)
                return None
            self._memes[str(p)] = rd
        got = rd.frame_at(vt, convert=False)
        if got is None:
            return None
        x, y, w, h = comp.video_box(e, rd.src_w, rd.src_h)
        key = (str(p), round(got[0], 4), w, h, bool(e.get("chroma")))
        q = self._meme_q.get(key)
        if q is None:
            arr = rd._cur.to_ndarray(format="bgra", width=max(2, w), height=max(2, h))
            if e.get("chroma"):
                preview.chroma_key(arr)
                q = bgra_to_qimage(arr, QImage.Format_ARGB32_Premultiplied)
            else:
                q = bgra_to_qimage(arr)
            if len(self._meme_q) > 240:
                self._meme_q.clear()
            self._meme_q[key] = q
        return q

    def _close_all(self) -> None:
        if self.reader is not None:
            self.reader.close()
        for rd in self._memes.values():
            rd.close()


# =========================================================================== sound


class _MixDone(QObject):
    done = Signal(object, int)


class AudioEngine(QObject):
    """Makes the sound of the clip in a thread (like the export) and plays it."""
    mixing = Signal(bool)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.mix = None                 # float32 (n, 2)
        self._ver = 0
        self._sig = _MixDone()
        self._sig.done.connect(self._on_mixed)
        self._src_cache: dict = {}
        self.sink = None
        self.io = None
        self.pos = 0                    # next sample to write
        self.muted = False
        self.volume = 0.9
        self._timer = QTimer(self)
        self._timer.setInterval(15)
        self._timer.timeout.connect(self._feed)
        self.available = not os.environ.get("FIRECLIPS_NO_AUDIO")
        self._fmt = None
        self._rate, self._ch, self._sf, self._bpf = preview.RATE, 2, None, 4

    # ---------------------------------------------------------------- the mix
    def rebuild(self, comp: Composition, src: Optional[dict], moment: dict) -> None:
        self._ver += 1
        ver = self._ver
        self.mixing.emit(True)

        def work():
            try:
                stream, s0 = None, 0.0
                if src is not None and src.get("path"):
                    lo, ln = preview.stream_sound_range(moment, src)
                    key = (src["path"], round(lo, 2), round(ln, 2))
                    got = self._src_cache.get(key)
                    if got is None:
                        got = preview.decode_audio(src["path"], lo, ln)
                        self._src_cache.clear()
                        self._src_cache[key] = got
                    stream, s0 = got, lo
                mix = preview.mix_audio(comp, stream, s0, float(src.get("vod_start") or 0.0) if src else 0.0,
                                        cancel=lambda: ver != self._ver)
            except Exception as e:  # noqa: BLE001
                log.warning("preview sound: %s", e)
                mix = None
            self._sig.done.emit(mix, ver)
        threading.Thread(target=work, daemon=True, name="preview-mix").start()

    def _on_mixed(self, mix, ver: int) -> None:
        if ver != self._ver:
            return
        if mix is not None:
            self.mix = mix
        self.mixing.emit(False)

    # ---------------------------------------------------------------- playing
    def _make_sink(self) -> bool:
        if not self.available:
            return False
        if self.sink is not None:
            return True
        try:
            from PySide6.QtMultimedia import QAudioFormat, QAudioSink, QMediaDevices
            dev = QMediaDevices.defaultAudioOutput()
            if dev.isNull():
                self.available = False
                return False
            fmt = QAudioFormat()
            fmt.setSampleRate(preview.RATE)
            fmt.setChannelCount(2)
            fmt.setSampleFormat(QAudioFormat.Int16)
            if not dev.isFormatSupported(fmt):
                fmt.setSampleFormat(QAudioFormat.Float)
                if not dev.isFormatSupported(fmt):
                    fmt = dev.preferredFormat()          # the mix is converted to it when written
            self._fmt = fmt
            self._rate = int(fmt.sampleRate() or preview.RATE)
            self._ch = max(1, int(fmt.channelCount() or 2))
            self._sf = fmt.sampleFormat()
            self._bpf = max(1, int(fmt.bytesPerFrame() or 4))
            self.sink = QAudioSink(dev, fmt, self)
            self.sink.setBufferSize(int(self._rate * self._bpf * 0.09))
            return True
        except Exception as e:  # noqa: BLE001
            log.info("no sound output: %s", e)
            self.available = False
            return False

    def _convert(self, chunk):
        """float32 (n, 2) at 48 kHz -> bytes in the format of the sound card."""
        import numpy as np
        from PySide6.QtMultimedia import QAudioFormat
        x = chunk
        if self._ch == 1:
            x = x.mean(axis=1, keepdims=True)
        elif self._ch > 2:
            x = np.concatenate([x, np.zeros((len(x), self._ch - 2), np.float32)], axis=1)
        x = np.clip(x, -1.0, 1.0)
        if self._sf == QAudioFormat.Float:
            return x.astype("<f4").tobytes()
        if self._sf == QAudioFormat.Int32:
            return (x * 2147483647.0).astype("<i4").tobytes()
        if self._sf == QAudioFormat.UInt8:
            return ((x * 127.0) + 128.0).astype(np.uint8).tobytes()
        return (x * 32767.0).astype("<i2").tobytes()

    def start(self, o: float) -> None:
        self.pos = max(0, int(o * preview.RATE))
        if not self._make_sink():
            return
        try:
            self.sink.stop()
            self.sink.setVolume(0.0 if self.muted else self.volume)
            self.io = self.sink.start()
        except Exception as e:  # noqa: BLE001
            log.info("sound output: %s", e)
            self.io = None
            return
        self._feed()
        self._timer.start()

    def stop(self) -> None:
        self._timer.stop()
        if self.sink is not None:
            try:
                self.sink.stop()
            except Exception:  # noqa: BLE001
                pass
        self.io = None

    def set_muted(self, on: bool) -> None:
        self.muted = on
        if self.sink is not None:
            self.sink.setVolume(0.0 if on else self.volume)

    def _feed(self) -> None:
        if self.io is None or self.sink is None:
            return
        frames = self.sink.bytesFree() // self._bpf
        if frames <= 0:
            return
        import numpy as np
        need = int(round(frames * preview.RATE / self._rate)) if self._rate != preview.RATE else frames
        mix = self.mix
        chunk = np.zeros((need, 2), np.float32)
        if mix is not None and self.pos < len(mix):
            part = mix[self.pos: self.pos + need]
            chunk[: len(part)] = part
        self.pos += need
        if self._rate != preview.RATE and need > 1:
            idx = np.linspace(0, need - 1, frames)
            i0 = idx.astype(np.int64)
            i1 = np.minimum(i0 + 1, need - 1)
            f = (idx - i0)[:, None].astype(np.float32)
            chunk = chunk[i0] * (1 - f) + chunk[i1] * f
        self.io.write(self._convert(chunk))


# =========================================================================== time keeping


class PreviewPlayer(QObject):
    """Play / pause / seek on the clip timeline (clip time, after cuts, slow motion and freezes)."""
    position_changed = Signal(float)
    playing_changed = Signal(bool)
    frame_changed = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.worker = FrameWorker()
        self.worker.note.frame.connect(self._on_worker_frame)
        self.worker.start()
        self.audio = AudioEngine(self)
        self.comp: Optional[Composition] = None
        self.src: Optional[dict] = None
        self.moment: Optional[dict] = None
        self.pos = 0.0
        self.playing = False
        self.loop = True
        self._clock = QElapsedTimer()
        self._start_o = 0.0
        self._timer = QTimer(self)
        self._timer.setTimerType(Qt.PreciseTimer)
        self._timer.setInterval(15)
        self._timer.timeout.connect(self._tick)
        self._last_k = -1

    def close(self) -> None:
        self.pause()
        self.worker.stop()

    def set_source(self, src: Optional[dict]) -> None:
        self.src = src
        self.worker.set_source(src)
        if self.comp is not None:
            self.audio.rebuild(self.comp, src, self.moment or {})
            self.seek(self.pos)

    def set_comp(self, comp: Optional[Composition], moment: Optional[dict] = None, sound: bool = True) -> None:
        self.comp = comp
        self.moment = moment
        self.worker.set_comp(comp)
        if comp is None:
            return
        if self.pos > comp.total:
            self.pos = max(0.0, comp.total - 0.05)
        if sound:
            self.audio.rebuild(comp, self.src, moment or {})
        if not self.playing:
            self.worker.scrub(self.pos)

    def total(self) -> float:
        return self.comp.total if self.comp is not None else 0.0

    def position(self) -> float:
        if self.playing:
            return self._start_o + self._clock.elapsed() / 1000.0
        return self.pos

    def play(self) -> None:
        if self.comp is None or self.playing:
            return
        if self.pos >= self.comp.total - 0.05:
            self.pos = 0.0
        self.playing = True
        self._start_o = self.pos
        self._clock.start()
        self.worker.play_from(self.pos)
        self.audio.start(self.pos)
        self._timer.start()
        self.playing_changed.emit(True)

    def pause(self) -> None:
        if not self.playing:
            return
        self.pos = min(self.position(), self.total())
        self.playing = False
        self._timer.stop()
        self.audio.stop()
        self.worker.pause()
        self.worker.scrub(self.pos)
        self.playing_changed.emit(False)
        self.position_changed.emit(self.pos)

    def toggle(self) -> None:
        if self.playing:
            self.pause()
        else:
            self.play()

    def seek(self, o: float) -> None:
        o = max(0.0, min(o, max(0.0, self.total() - 0.01)))
        self.pos = o
        if self.playing:
            self._start_o = o
            self._clock.restart()
            self.worker.play_from(o)
            self.audio.start(o)
        else:
            self.worker.scrub(o)
        self.position_changed.emit(o)

    def _tick(self) -> None:
        o = self.position()
        total = self.total()
        if o >= total:
            if self.loop and total > 0.5:
                self.seek(0.0)
                return
            self.pos = total
            self.pause()
            return
        self.worker.tick(o)
        k = int(o * preview.FPS)
        if k != self._last_k:            # a new picture is due (30 per second)
            self._last_k = k
            self.position_changed.emit(o)
            self.frame_changed.emit()

    def _on_worker_frame(self) -> None:
        if not self.playing:
            self.frame_changed.emit()


# =========================================================================== the canvas


class PreviewCanvas(QWidget):
    """The clip picture, fitted in the widget. Click a meme to pick it, drag to move it, drag the corner
    to make it bigger / smaller, drag the round handle to turn it."""
    picked = Signal(str)                    # element id ("" = nothing)
    moved = Signal(str, float, float)       # element id, x, y (fractions of the game picture)
    resized = Signal(str, float)            # element id, size factor (relative to the start of the drag)
    turned = Signal(str, float)             # element id, angle (degrees)
    edit_done = Signal(str)                 # the drag is over (one undo step)
    clicked_empty = Signal()
    dropped = Signal(str, float, float)     # library item (mime text), x, y (fractions of the game picture)

    def __init__(self, player: PreviewPlayer, parent=None):
        super().__init__(parent)
        self.player = player
        self.compositor = Compositor()
        self.sel = ""
        self.img: Optional[QImage] = None
        self.message = ""
        self._drag: Optional[dict] = None
        self._busy_text = ""
        self.setMinimumSize(QSize(220, 220))
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setMouseTracking(True)
        self.setAcceptDrops(True)
        self.setFocusPolicy(Qt.ClickFocus)
        player.frame_changed.connect(self.refresh)

    # ---------------------------------------------------------------- drawing
    def set_comp(self, comp: Optional[Composition]) -> None:
        self.compositor.set_comp(comp)
        self.refresh()

    def set_message(self, text: str) -> None:
        self.message = text
        self.update()

    def set_selected(self, eid: str) -> None:
        self.sel = eid or ""
        self.update()

    def refresh(self) -> None:
        comp = self.compositor.comp
        if comp is None:
            self.img = None
            self.update()
            return
        o = self.player.position()
        got = self.player.worker.take(o)
        src, key, memes = (got if got is not None else (None, None, {}))
        try:
            self.img = self.compositor.frame(o, src, memes, key)
        except Exception as e:  # noqa: BLE001
            log.exception("preview picture: %s", e)
        self.update()

    def _fit(self) -> QRectF:
        comp = self.compositor.comp
        if comp is None:
            return QRectF(self.rect())
        W, H = comp.W, comp.H
        s = min(self.width() / W, self.height() / H)
        w, h = W * s, H * s
        return QRectF((self.width() - w) / 2, (self.height() - h) / 2, w, h)

    def _to_design(self, pos: QPointF) -> QPointF:
        r = self._fit()
        comp = self.compositor.comp
        return QPointF((pos.x() - r.x()) * comp.W / r.width(), (pos.y() - r.y()) * comp.H / r.height())

    def _to_widget(self, pt: QPointF) -> QPointF:
        r = self._fit()
        comp = self.compositor.comp
        return QPointF(r.x() + pt.x() * r.width() / comp.W, r.y() + pt.y() * r.height() / comp.H)

    def paintEvent(self, _e) -> None:  # noqa: N802
        p = QPainter(self)
        p.fillRect(self.rect(), QColor("#0b0b0e"))
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)
        p.setRenderHint(QPainter.Antialiasing, True)
        r = self._fit()
        if self.img is not None:
            p.drawImage(r, self.img)
            p.setPen(QPen(QColor(theme.BORDER), 1))
            p.setBrush(Qt.NoBrush)
            p.drawRect(r.adjusted(-0.5, -0.5, 0.5, 0.5))
            self._draw_selection(p)
        if self.message:
            p.setPen(QColor(theme.MUTED if self.img is None else "#ffffff"))
            f = QFont(self.font())
            f.setPointSizeF(10.5)
            p.setFont(f)
            box = self.rect().adjusted(20, 20, -20, -20)
            if self.img is not None:
                box = QRectF(r.x() + 10, r.bottom() - 60, r.width() - 20, 50).toRect()
                p.fillRect(box, QColor(0, 0, 0, 150))
            p.drawText(box, Qt.AlignCenter | Qt.TextWordWrap, self.message)
        p.end()

    def _hit_poly(self, eid: str) -> Optional[QPolygonF]:
        for hid, poly, _e in self.compositor.hits:
            if hid == eid:
                return poly
        return None

    def _handles(self, poly: QPolygonF) -> tuple[QPointF, QPointF, QPointF]:
        """Widget positions of: the centre, the resize corner (bottom right), the turn handle (above)."""
        pts = [self._to_widget(poly.at(i)) for i in range(min(4, poly.count()))]
        c = QPointF(sum(pt.x() for pt in pts) / len(pts), sum(pt.y() for pt in pts) / len(pts))
        corner = pts[2] if len(pts) > 2 else c
        top_mid = (pts[0] + pts[1]) / 2 if len(pts) > 1 else c
        v = top_mid - c
        ln = math.hypot(v.x(), v.y()) or 1.0
        turn = top_mid + QPointF(v.x() / ln * 22, v.y() / ln * 22)
        return c, corner, turn

    def _draw_selection(self, p: QPainter) -> None:
        if not self.sel:
            return
        poly = self._hit_poly(self.sel)
        if poly is None:
            return
        wpoly = QPolygonF([self._to_widget(poly.at(i)) for i in range(poly.count())])
        p.setPen(QPen(QColor(theme.ACCENT), 1.6, Qt.DashLine))
        p.setBrush(Qt.NoBrush)
        p.drawPolygon(wpoly)
        c, corner, turn = self._handles(poly)
        p.setPen(QPen(QColor("#ffffff"), 1.4))
        p.setBrush(QColor(theme.ACCENT))
        p.drawRect(QRectF(corner.x() - 6, corner.y() - 6, 12, 12))
        e = next((x for i, _p, x in self.compositor.hits if i == self.sel), None)
        if e is not None and e.get("kind") in ("emoji", "image", "text", "killcard") and wpoly.count() > 1:
            top_mid = (wpoly.at(0) + wpoly.at(1)) / 2
            p.setPen(QPen(QColor(theme.ACCENT), 1.2))
            p.drawLine(top_mid, turn)
            p.setPen(QPen(QColor("#ffffff"), 1.4))
            p.setBrush(QColor(theme.ACCENT_2))
            p.drawEllipse(turn, 7, 7)

    # ---------------------------------------------------------------- mouse
    def _pick(self, pos: QPointF) -> Optional[tuple]:
        if self.compositor.comp is None:
            return None
        d = self._to_design(pos)
        for eid, poly, e in reversed(self.compositor.hits):
            if poly.containsPoint(d, Qt.OddEvenFill):
                return eid, e
        return None

    def mousePressEvent(self, ev) -> None:  # noqa: N802
        if ev.button() != Qt.LeftButton or self.compositor.comp is None:
            return
        pos = ev.position()
        if self.sel:
            poly = self._hit_poly(self.sel)
            if poly is not None:
                c, corner, turn = self._handles(poly)
                e = next((x for _i, _p, x in self.compositor.hits if _i == self.sel), None)
                if e is not None and math.hypot(pos.x() - corner.x(), pos.y() - corner.y()) < 10:
                    self._drag = {"mode": "size", "id": self.sel, "c": c, "d0": max(4.0, math.hypot(
                        pos.x() - c.x(), pos.y() - c.y())), "moved": False}
                    return
                if e is not None and math.hypot(pos.x() - turn.x(), pos.y() - turn.y()) < 11 and \
                        e.get("kind") in ("emoji", "image", "text", "killcard"):
                    self._drag = {"mode": "turn", "id": self.sel, "c": c, "rot0": float(e.get("rot") or 0.0),
                                  "a0": math.degrees(math.atan2(-(pos.y() - c.y()), pos.x() - c.x())), "moved": False}
                    return
        hit = self._pick(pos)
        if hit is None:
            self.sel = ""
            self.picked.emit("")
            self.clicked_empty.emit()
            self.update()
            return
        eid, e = hit
        self.sel = eid
        self.picked.emit(eid)
        comp = self.compositor.comp
        gx, gy, gw, gh = comp.game
        ex = gx + float(e.get("x") if e.get("x") is not None else self._default_pos(e)[0]) * gw
        ey = gy + float(e.get("y") if e.get("y") is not None else self._default_pos(e)[1]) * gh
        d = self._to_design(pos)
        self._drag = {"mode": "move", "id": eid, "off": QPointF(ex - d.x(), ey - d.y()), "moved": False}
        self.update()

    @staticmethod
    def _default_pos(e: dict) -> tuple:
        from ..montage import DEFAULT_POS
        return DEFAULT_POS.get(e.get("kind"), (0.5, 0.5))

    def mouseMoveEvent(self, ev) -> None:  # noqa: N802
        pos = ev.position()
        d = self._drag
        if d is None:
            hit = self._pick(pos) if self.compositor.comp is not None else None
            cur = Qt.ArrowCursor
            if self.sel:
                poly = self._hit_poly(self.sel)
                if poly is not None:
                    c, corner, turn = self._handles(poly)
                    if math.hypot(pos.x() - corner.x(), pos.y() - corner.y()) < 10:
                        cur = Qt.SizeFDiagCursor
                    elif math.hypot(pos.x() - turn.x(), pos.y() - turn.y()) < 11:
                        cur = Qt.CrossCursor
            if cur == Qt.ArrowCursor and hit is not None:
                cur = Qt.OpenHandCursor
            self.setCursor(cur)
            return
        comp = self.compositor.comp
        if comp is None:
            return
        d["moved"] = True
        if d["mode"] == "move":
            p = self._to_design(pos) + d["off"]
            gx, gy, gw, gh = comp.game
            x = (p.x() - gx) / max(1, gw)
            y = (p.y() - gy) / max(1, gh)
            self.moved.emit(d["id"], round(min(1.5, max(-0.5, x)), 4), round(min(1.5, max(-0.5, y)), 4))
        elif d["mode"] == "size":
            c = d["c"]
            dist = max(4.0, math.hypot(pos.x() - c.x(), pos.y() - c.y()))
            self.resized.emit(d["id"], dist / d["d0"])
        elif d["mode"] == "turn":
            c = d["c"]
            a = math.degrees(math.atan2(-(pos.y() - c.y()), pos.x() - c.x()))
            rot = d["rot0"] + (a - d["a0"])
            rot = (rot + 180) % 360 - 180
            if abs(rot) < 3:
                rot = 0.0
            self.turned.emit(d["id"], round(rot, 1))

    def mouseReleaseEvent(self, _ev) -> None:  # noqa: N802
        d, self._drag = self._drag, None
        if d and d.get("moved"):
            self.edit_done.emit(d["id"])

    def mouseDoubleClickEvent(self, _ev) -> None:  # noqa: N802
        self.player.toggle()

    # ---------------------------------------------------------------- drop from the library
    def dragEnterEvent(self, e) -> None:  # noqa: N802
        if e.mimeData().hasFormat("application/x-fireclips-item"):
            e.acceptProposedAction()

    def dragMoveEvent(self, e) -> None:  # noqa: N802
        if e.mimeData().hasFormat("application/x-fireclips-item"):
            e.acceptProposedAction()

    def dropEvent(self, e) -> None:  # noqa: N802
        comp = self.compositor.comp
        if comp is None or not e.mimeData().hasFormat("application/x-fireclips-item"):
            return
        item = bytes(e.mimeData().data("application/x-fireclips-item")).decode("utf-8")
        d = self._to_design(e.position())
        gx, gy, gw, gh = comp.game
        self.dropped.emit(item, round((d.x() - gx) / max(1, gw), 4), round((d.y() - gy) / max(1, gh), 4))
        e.acceptProposedAction()
