"""Global keyboard shortcut (works while the game has the focus) to mark a moment during the stream.
Windows only (RegisterHotKey); a Stream Deck button can send the same keys."""
from __future__ import annotations

import logging
import sys
import threading
from typing import Optional

from PySide6.QtCore import QObject, Signal

log = logging.getLogger("fireclips.hotkey")

MODS = {"ctrl": 0x0002, "control": 0x0002, "alt": 0x0001, "shift": 0x0004, "win": 0x0008}
MOD_NOREPEAT = 0x4000
WM_HOTKEY = 0x0312
WM_QUIT = 0x0012


def parse(combo: str) -> Optional[tuple[int, int]]:
    """"Ctrl+Alt+M" -> (modifiers, virtual key code). None if it cannot be used."""
    parts = [p.strip().lower() for p in (combo or "").replace("-", "+").split("+") if p.strip()]
    if not parts:
        return None
    mods = 0
    key = None
    for p in parts:
        if p in MODS:
            mods |= MODS[p]
        else:
            key = p
    if key is None:
        return None
    if len(key) == 1 and key.isalnum():
        vk = ord(key.upper())
    elif key.startswith("f") and key[1:].isdigit() and 1 <= int(key[1:]) <= 24:
        vk = 0x70 + int(key[1:]) - 1
    elif key in ("pause", "break"):
        vk = 0x13
    elif key in ("insert", "ins"):
        vk = 0x2D
    elif key.startswith("num") and key[3:].isdigit() and len(key) == 4:
        vk = 0x60 + int(key[3])
    else:
        return None
    if mods == 0 and not (0x70 <= vk <= 0x87):
        return None                     # a plain letter would fire while typing in the chat
    return mods, vk


class GlobalHotkey(QObject):
    pressed = Signal()
    failed = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._thread: Optional[threading.Thread] = None
        self._tid = 0
        self.combo = ""

    def available(self) -> bool:
        return sys.platform == "win32"

    def start(self, combo: str) -> bool:
        self.stop()
        self.combo = combo
        parsed = parse(combo)
        if not parsed or not self.available():
            return False
        mods, vk = parsed
        ready = threading.Event()
        result = {"ok": False}

        def loop() -> None:
            import ctypes
            from ctypes import wintypes
            user32 = ctypes.windll.user32
            kernel32 = ctypes.windll.kernel32
            self._tid = kernel32.GetCurrentThreadId()
            ok = user32.RegisterHotKey(None, 1, mods | MOD_NOREPEAT, vk)
            result["ok"] = bool(ok)
            ready.set()
            if not ok:
                self.failed.emit(combo)
                return
            msg = wintypes.MSG()
            try:
                while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
                    if msg.message == WM_HOTKEY:
                        self.pressed.emit()
            finally:
                user32.UnregisterHotKey(None, 1)

        self._thread = threading.Thread(target=loop, name="fireclips-hotkey", daemon=True)
        self._thread.start()
        ready.wait(2.0)
        if not result["ok"]:
            log.warning("global shortcut %s not available (used by another program?)", combo)
        return result["ok"]

    def stop(self) -> None:
        if self._thread is not None and self._tid and self.available():
            try:
                import ctypes
                ctypes.windll.user32.PostThreadMessageW(self._tid, WM_QUIT, 0, 0)
            except Exception:  # noqa: BLE001
                pass
            self._thread.join(1.0)
        self._thread = None
        self._tid = 0
