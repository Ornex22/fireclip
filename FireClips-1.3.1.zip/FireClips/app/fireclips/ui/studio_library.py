"""The Studio library (left side): emojis, meme sounds, texts, effects, pictures and Twitch emotes, green screen
videos, music, and the ways to add your own memes. Click a thing to put it in the clip at the red line, or drag
it onto the picture / the timeline. Click a sound to hear it first.

The memes come from the internet (memebank.py): what is not downloaded yet shows with a ⬇ and is downloaded
when it is picked."""
from __future__ import annotations

import logging
import threading
from pathlib import Path
from typing import Optional

from PySide6.QtCore import QMimeData, QObject, QRect, QRectF, QSize, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QFont, QIcon, QImage, QPainter, QPen, QPixmap
from PySide6.QtWidgets import (QAbstractItemView, QButtonGroup, QComboBox, QFrame, QHBoxLayout, QLabel, QLineEdit,
                               QListWidget, QListWidgetItem, QPushButton, QScrollArea, QStackedWidget, QStyle,
                               QStyledItemDelegate, QToolButton, QVBoxLayout, QWidget)

from .. import bank, fxlib, memebank
from ..i18n import language, tr
from ..util import fmt_time, open_in_explorer
from . import theme
from .widgets import FlowLayout

log = logging.getLogger("fireclips.library")
MIME = "application/x-fireclips-item"
ROLE_ITEM = Qt.UserRole + 10        # the item string ("emoji:1f602", "sound:sfx:boom"...)
ROLE_SEARCH = Qt.UserRole + 11      # words to search in
ROLE_GROUP = Qt.UserRole + 12       # group / category ids (set)
ROLE_PATH = Qt.UserRole + 13
ROLE_WAVE = Qt.UserRole + 14
ROLE_DUR = Qt.UserRole + 15
ROLE_SUB = Qt.UserRole + 16         # small text under the name

EDIT_FX = [("zoom", "🔍"), ("shake", "📳"), ("slowmo", "🐢"), ("fast", "🐇"), ("freeze", "❄️"), ("bleep", "🔇"),
           ("killcard", "⚔️")]


def emoji_icon(char_or_code: str, px: int = 32) -> QIcon:
    """A Fluent emoji picture as an icon (the emoji font of Windows is flat and small)."""
    code = char_or_code if "-" in char_or_code or all(c in "0123456789abcdef" for c in char_or_code) \
        else fxlib.emoji_code_of(char_or_code)
    p = bank.emoji_path(code) if code else None
    if p is None:
        return QIcon()
    pm = QPixmap(str(p))
    if pm.isNull():
        return QIcon()
    return QIcon(pm.scaled(px, px, Qt.KeepAspectRatio, Qt.SmoothTransformation))


def _norm(s: str) -> str:
    from ..util import strip_accents
    return strip_accents((s or "").lower())


class ItemList(QListWidget):
    """A list / grid whose items can be dragged onto the picture or the timeline."""

    def __init__(self, grid: bool, icon: int = 40, cell: Optional[QSize] = None, parent=None):
        super().__init__(parent)
        self.setDragEnabled(True)
        self.setDragDropMode(QAbstractItemView.DragOnly)
        self.setSelectionMode(QAbstractItemView.SingleSelection)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)
        if grid:
            self.setViewMode(QListWidget.IconMode)
            self.setMovement(QListWidget.Static)
            self.setResizeMode(QListWidget.Adjust)
            self.setIconSize(QSize(icon, icon))
            self.setGridSize(cell or QSize(icon + 12, icon + 12))
            self.setUniformItemSizes(True)
            self.setWordWrap(True)
            self.setSpacing(0)

    def mimeTypes(self):  # noqa: N802
        return [MIME]

    def mimeData(self, items):  # noqa: N802
        md = QMimeData()
        if items:
            md.setData(MIME, (items[0].data(ROLE_ITEM) or "").encode("utf-8"))
        return md

    def filter(self, text: str = "", group: str = "") -> int:
        t = _norm(text).strip()
        shown = 0
        for i in range(self.count()):
            it = self.item(i)
            ok = True
            if t:
                ok = all(w in (it.data(ROLE_SEARCH) or "") for w in t.split())
            if ok and group:
                ok = group in (it.data(ROLE_GROUP) or ())
            it.setHidden(not ok)
            shown += ok
        return shown


class Tile(QToolButton):
    """A big button (icon + name) that adds its thing on click and can be dragged onto the clip."""
    picked = Signal(str)

    def __init__(self, item: str, icon: QIcon, text: str, tip: str = "", parent=None):
        super().__init__(parent)
        self.item = item
        self.setIcon(icon)
        self.setIconSize(QSize(34, 34))
        self.setText(text)
        self.setToolTip(tip or text)
        self.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
        self.setFixedSize(96, 78)
        self.setObjectName("Tile")
        self._press = None
        self.clicked.connect(lambda: self.picked.emit(self.item))

    def mousePressEvent(self, ev) -> None:  # noqa: N802
        self._press = ev.position().toPoint()
        super().mousePressEvent(ev)

    def mouseMoveEvent(self, ev) -> None:  # noqa: N802
        from PySide6.QtGui import QDrag
        from PySide6.QtWidgets import QApplication
        if self._press is not None and (ev.position().toPoint() - self._press).manhattanLength() >= \
                QApplication.startDragDistance():
            self._press = None
            self.setDown(False)
            md = QMimeData()
            md.setData(MIME, self.item.encode("utf-8"))
            drag = QDrag(self)
            drag.setMimeData(md)
            drag.setPixmap(self.icon().pixmap(34, 34))
            drag.exec(Qt.CopyAction)
            return
        super().mouseMoveEvent(ev)


class TileGrid(QScrollArea):
    """Sections of tiles, scrolling."""
    picked = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWidgetResizable(True)
        self.setFrameShape(QFrame.NoFrame)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        w = QWidget()
        self.v = QVBoxLayout(w)
        self.v.setContentsMargins(0, 0, 4, 0)
        self.v.setSpacing(6)
        self.v.addStretch(1)
        self.setWidget(w)
        self._flow = None
        self.tiles: list[Tile] = []

    def section(self, title: str) -> None:
        lab = QLabel(title)
        lab.setObjectName("Muted")
        lab.setStyleSheet("font-weight: 600; padding-top: 4px;")
        self.v.insertWidget(self.v.count() - 1, lab)
        box = QWidget()
        self._flow = FlowLayout(box, 4)
        self._flow.setContentsMargins(0, 0, 0, 0)
        self.v.insertWidget(self.v.count() - 1, box)

    def tile(self, item: str, icon: QIcon, text: str, tip: str = "") -> Tile:
        if self._flow is None:
            self.section("")
        t = Tile(item, icon, text, tip)
        t.picked.connect(self.picked)
        self._flow.addWidget(t)
        self.tiles.append(t)
        return t


def _chips(parent_layout, entries: list[tuple[str, str]], on_pick) -> QButtonGroup:
    """A row of small toggle buttons (only one on at a time)."""
    box = QWidget()
    fl = FlowLayout(box, 3)
    fl.setContentsMargins(0, 0, 0, 0)
    grp = QButtonGroup(box)
    grp.setExclusive(True)
    for i, (gid, text) in enumerate(entries):
        b = QToolButton()
        b.setText(text.replace("&", "&&"))       # (a single & would underline the next letter)
        b.setCheckable(True)
        b.setObjectName("Chip")
        b.setProperty("gid", gid)
        b.clicked.connect(lambda _c=False, g=gid: on_pick(g))
        grp.addButton(b, i)
        fl.addWidget(b)
        if i == 0:
            b.setChecked(True)
    parent_layout.addWidget(box)
    return grp


# =========================================================================== sounds list


class SoundDelegate(QStyledItemDelegate):
    """A sound: ▶ / ■, its name, a small picture of its loudness, its length, and a + to add it."""

    def __init__(self, lib: "Library", parent=None):
        super().__init__(parent)
        self.lib = lib

    def sizeHint(self, opt, idx) -> QSize:  # noqa: N802
        return QSize(200, 40)

    def paint(self, p: QPainter, opt, idx) -> None:
        p.save()
        p.setRenderHint(QPainter.Antialiasing)
        r = opt.rect.adjusted(2, 2, -2, -2)
        sel = bool(opt.state & QStyle.State_Selected)
        hover = bool(opt.state & QStyle.State_MouseOver)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor("#2c2730" if sel else "#222229" if hover else "#1f1f25"))
        p.drawRoundedRect(QRectF(r), 7, 7)
        playing = self.lib.playing_item and self.lib.playing_item == idx.data(ROLE_ITEM)
        loading = self.lib.loading_item and self.lib.loading_item == idx.data(ROLE_ITEM)
        missing = not idx.data(ROLE_PATH) and str(idx.data(ROLE_ITEM) or "").count("web:")
        # play button (⬇: not downloaded yet, it is downloaded on the first click)
        c = QRectF(r.left() + 6, r.center().y() - 12, 24, 24)
        p.setBrush(QColor(theme.ACCENT if playing or loading else "#33333d"))
        p.drawEllipse(c)
        p.setPen(QColor("#ffffff"))
        f = QFont(opt.font)
        f.setPointSizeF(8.5)
        p.setFont(f)
        p.drawText(c, Qt.AlignCenter, "…" if loading else "■" if playing else "⬇" if missing else "▶")
        # add button
        add = QRectF(r.right() - 28, r.center().y() - 11, 24, 22)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(theme.ACCENT if hover or sel else "#33333d"))
        p.drawRoundedRect(add, 6, 6)
        p.setPen(QColor("#ffffff"))
        f.setPointSizeF(11)
        f.setBold(True)
        p.setFont(f)
        p.drawText(add, Qt.AlignCenter, "+")
        # waveform
        wave = idx.data(ROLE_WAVE) or []
        wr = QRectF(r.right() - 28 - 8 - 56, r.top() + 8, 56, r.height() - 16)
        if wave:
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(255, 255, 255, 90))
            n = len(wave)
            for i, v in enumerate(wave):
                bh = max(1.5, wr.height() * v / 99.0)
                p.drawRect(QRectF(wr.left() + wr.width() * i / n, wr.center().y() - bh / 2, max(1.0, wr.width() / n - 0.6), bh))
        # name + details
        tx = QRectF(c.right() + 8, r.top() + 3, wr.left() - c.right() - 12, r.height() - 6)
        f.setPointSizeF(9.5)
        f.setBold(True)
        p.setFont(f)
        p.setPen(QColor(theme.TEXT))
        name = idx.data(Qt.DisplayRole) or ""
        p.drawText(QRectF(tx.left(), tx.top(), tx.width(), tx.height() / 2 + 2), Qt.AlignLeft | Qt.AlignVCenter,
                   p.fontMetrics().elidedText(name, Qt.ElideRight, int(tx.width())))
        f.setBold(False)
        f.setPointSizeF(8)
        p.setFont(f)
        p.setPen(QColor(theme.MUTED))
        sub = idx.data(ROLE_SUB) or ""
        p.drawText(QRectF(tx.left(), tx.center().y(), tx.width(), tx.height() / 2), Qt.AlignLeft | Qt.AlignVCenter,
                   p.fontMetrics().elidedText(sub, Qt.ElideRight, int(tx.width())))
        p.restore()


class SoundList(ItemList):
    """Click a sound to hear it, click + (or double-click) to put it in the clip."""
    listen = Signal(object)          # QListWidgetItem
    add = Signal(object)

    def __init__(self, lib: "Library", parent=None):
        super().__init__(False, parent=parent)
        self.setItemDelegate(SoundDelegate(lib, self))
        self.setMouseTracking(True)
        self.viewport().setMouseTracking(True)
        self.setUniformItemSizes(True)
        self.setSpacing(1)

    def mouseReleaseEvent(self, ev) -> None:  # noqa: N802
        it = self.itemAt(ev.position().toPoint())
        super().mouseReleaseEvent(ev)
        if it is None or ev.button() != Qt.LeftButton:
            return
        r = self.visualItemRect(it)
        if ev.position().x() > r.right() - 34:
            self.add.emit(it)
        else:
            self.listen.emit(it)

    def mouseDoubleClickEvent(self, ev) -> None:  # noqa: N802
        it = self.itemAt(ev.position().toPoint())
        if it is not None:
            self.add.emit(it)


# =========================================================================== the library


class _Thumbs(QObject):
    done = Signal(str, object)       # item string, QImage


class Library(QWidget):
    add = Signal(str)               # item string: put it in the clip at the red line
    listen = Signal(str, str)       # item string, file path (play it / "" = stop)
    use_music = Signal(str)         # music reference ("" = no music)
    import_requested = Signal(str)  # link | youtube | vod | mic | files | folder
    files_dropped = Signal(list)    # sound / picture / video files dropped from the PC: into the bank
    download_requested = Signal()   # "download the meme bank now" (what is missing)

    PAGES = [("emoji", "😂"), ("sound", "🔊"), ("text", "🅰"), ("fx", "✨"), ("image", "🖼"), ("video", "🎞"),
             ("music", "🎵"), ("add", "➕")]

    def __init__(self, cfg, parent=None):
        super().__init__(parent)
        self.cfg = cfg
        self.playing_item = ""
        self.loading_item = ""
        self.music_ref = ""
        self.has_cards = False
        self._web_items: dict[str, list] = {}       # web ref -> its list items (updated when it is downloaded)
        self._banners: list = []
        self._bank_state = {"done": 0, "total": 0, "running": False}
        self._built: dict[str, QWidget] = {}
        self._thumbs = _Thumbs()
        self._thumbs.done.connect(self._thumb_done)
        self._thumb_items: dict[str, QListWidgetItem] = {}
        self.setAcceptDrops(True)
        h = QHBoxLayout(self)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(6)
        nav = QFrame()
        nav.setObjectName("LibNav")
        nv = QVBoxLayout(nav)
        nv.setContentsMargins(4, 6, 4, 6)
        nv.setSpacing(4)
        self.nav_grp = QButtonGroup(self)
        self.nav_grp.setExclusive(True)
        self.stack = QStackedWidget()
        self.page_index: dict[str, int] = {}
        for i, (pid, icon) in enumerate(self.PAGES):
            b = QToolButton()
            b.setCheckable(True)
            b.setIcon(emoji_icon(icon, 26))
            b.setIconSize(QSize(24, 24))
            b.setText(tr("lib_" + pid))
            b.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
            b.setFixedSize(76, 54)
            b.setObjectName("LibNavBtn")
            b.setToolTip(tr("lib_" + pid + "_tip"))
            b.clicked.connect(lambda _c=False, p=pid: self.show_page(p))
            self.nav_grp.addButton(b, i)
            nv.addWidget(b)
            holder = QWidget()
            QVBoxLayout(holder).setContentsMargins(0, 0, 0, 0)
            self.page_index[pid] = self.stack.addWidget(holder)
        nv.addStretch(1)
        h.addWidget(nav)
        h.addWidget(self.stack, 1)
        self.setStyleSheet(f"""
            QFrame#LibNav {{ background: #18181d; border-radius: 10px; }}
            QToolButton#LibNavBtn {{ background: transparent; border: none; border-radius: 8px; font-size: 7.5pt;
                                     color: {theme.MUTED}; padding: 2px; }}
            QToolButton#LibNavBtn:checked {{ background: #2c2730; color: {theme.TEXT}; }}
            QToolButton#LibNavBtn:hover {{ background: #24242c; }}
            QToolButton#Chip {{ border-radius: 11px; padding: 3px 9px; font-size: 8.5pt; }}
            QToolButton#Tile {{ border-radius: 9px; background: #222229; font-size: 8.5pt; padding: 4px; }}
            QToolButton#Tile:hover {{ background: #2c2730; border-color: {theme.ACCENT}; }}
            QToolButton#Chip:checked {{ background: {theme.ACCENT}; border-color: {theme.ACCENT}; color: white; }}
            QListWidget::item {{ border-radius: 8px; }}
        """)
        self.show_page("emoji")

    # ---------------------------------------------------------------- pages
    def show_page(self, pid: str) -> None:
        i = self.page_index[pid]
        btn = self.nav_grp.button(i)
        if btn is not None and not btn.isChecked():
            btn.setChecked(True)
        if pid not in self._built:
            holder = self.stack.widget(i)
            page = getattr(self, "_page_" + pid)()
            holder.layout().addWidget(page)
            self._built[pid] = page
        self.stack.setCurrentIndex(i)

    def current_page(self) -> str:
        i = self.stack.currentIndex()
        return next((p for p, j in self.page_index.items() if j == i), "")

    def _page_frame(self, title: str, hint: str = "") -> tuple[QWidget, QVBoxLayout]:
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(2, 2, 2, 2)
        v.setSpacing(6)
        t = QLabel(title)
        t.setObjectName("Title")
        t.setStyleSheet("font-size: 11pt;")
        v.addWidget(t)
        if hint:
            hl = QLabel(hint)
            hl.setObjectName("Muted")
            hl.setWordWrap(True)
            hl.setStyleSheet("font-size: 8.5pt;")
            v.addWidget(hl)
        return w, v

    def _search_box(self, v: QVBoxLayout, on_text) -> QLineEdit:
        s = QLineEdit()
        s.setPlaceholderText(tr("lib_search"))
        s.setClearButtonEnabled(True)
        s.textChanged.connect(on_text)
        v.addWidget(s)
        return s

    # -- emojis
    def _page_emoji(self) -> QWidget:
        w, v = self._page_frame("😂 " + tr("lib_emoji_title"), tr("lib_emoji_hint"))
        lang = language()
        state = {"text": "", "group": "popular"}
        lst = ItemList(True, 40, QSize(50, 50))
        lst.setToolTip("")

        def refilter():
            n = lst.filter(state["text"], "" if state["text"] else state["group"])
            empty.setVisible(n == 0)
        search = self._search_box(v, lambda t: (state.__setitem__("text", t), refilter()))
        groups = [(g["id"], f"{g.get('icon', '')} {g.get(lang) or g.get('fr')}") for g in bank.emoji_groups()]
        if not groups:
            groups = [("", tr("lib_all"))]
        _chips(v, groups, lambda g: (state.__setitem__("group", g), search.clear() if search.text() else None,
                                     refilter()))
        items = []
        for e in bank.emojis():
            it = QListWidgetItem()
            it.setData(ROLE_ITEM, f"emoji:{e['code']}")
            name = e.get(lang) or e.get("fr") or e["char"]
            it.setToolTip(f"{e['char']}  {name}")
            it.setData(ROLE_SEARCH, _norm(" ".join([e.get("fr", ""), e.get("en", ""), e.get("tags", ""), e["char"]])))
            it.setData(ROLE_GROUP, {e.get("group"), e.get("group2")})
            it.setSizeHint(QSize(50, 50))
            lst.addItem(it)
            items.append((it, e["code"]))
        lst.itemClicked.connect(lambda it: self.add.emit(it.data(ROLE_ITEM)))
        v.addWidget(lst, 1)
        empty = QLabel(tr("lib_nothing"))
        empty.setObjectName("Muted")
        empty.hide()
        v.addWidget(empty)
        # icons: a few at a time (526 pictures)
        todo = list(items)

        def load_some():
            for _ in range(40):
                if not todo:
                    timer.stop()
                    return
                it, code = todo.pop(0)
                it.setIcon(emoji_icon(code, 40))
        timer = QTimer(w)
        timer.timeout.connect(load_some)
        timer.start(15)
        refilter()
        return w

    # -- the bank downloading (shown on the pages of internet memes)
    def _bank_banner(self, v: QVBoxLayout) -> None:
        box = QFrame()
        box.setObjectName("BankBanner")
        bl = QVBoxLayout(box)
        bl.setContentsMargins(8, 6, 8, 6)
        bl.setSpacing(4)
        row = QHBoxLayout()
        lab = QLabel("")
        lab.setWordWrap(True)
        lab.setStyleSheet("font-size: 8.5pt;")
        row.addWidget(lab, 1)
        btn = QPushButton("⬇ " + tr("lib_bank_download"))
        btn.setObjectName("Flat")
        btn.clicked.connect(self.download_requested)
        row.addWidget(btn)
        bl.addLayout(row)
        from PySide6.QtWidgets import QProgressBar
        bar = QProgressBar()
        bar.setRange(0, 1000)
        bar.setTextVisible(False)
        bar.setFixedHeight(5)
        bl.addWidget(bar)
        v.addWidget(box)
        self._banners.append((box, lab, btn, bar))
        self._update_banner(box, lab, btn, bar, counted=True)

    def _update_banner(self, box, lab, btn, bar, counted: bool = False) -> None:
        st = self._bank_state
        try:
            if st.get("running"):
                n, t = int(st.get("done") or 0), int(st.get("total") or 0)
                lab.setText("⬇ " + (tr("lib_bank_running", done=n, total=t) if t else tr("lib_bank_starting")))
                bar.setValue(int(1000 * n / max(1, t)))
                bar.show()
                btn.hide()
                box.show()
                return
            if counted:
                box.setProperty("missing", memebank.missing_count())
            missing = int(box.property("missing") or 0)
            bar.hide()
            if missing > 0:
                lab.setText(tr("lib_bank_missing_one") if missing == 1 else tr("lib_bank_missing", n=missing))
                btn.show()
                box.show()
            else:
                box.hide()
        except RuntimeError:
            pass                     # the page was rebuilt

    def bank_progress(self, state: dict) -> None:
        was = self._bank_state.get("running")
        self._bank_state = dict(state)
        done = was and not state.get("running")
        for b in list(self._banners):
            self._update_banner(*b, counted=done)

    def bank_item_ready(self, ref: str) -> None:
        """A meme was downloaded: its items get their file (and picture)."""
        if not ref:
            return
        p = memebank.path_of(ref)
        if p is None:
            return
        info = {}
        for e in memebank.entries(ref[4:].partition("/")[0]):
            if e.ref == ref:
                info = e.info
                break
        alive = []
        for it, kind in self._web_items.get(ref, []):
            try:
                it.setData(ROLE_PATH, str(p))
                if kind in ("sound", "music"):
                    it.setData(ROLE_WAVE, info.get("wave") or [])
                    sub = it.data(ROLE_SUB) or ""
                    if info.get("dur") and "·" in sub:
                        it.setData(ROLE_SUB, sub.split("·")[0].strip() + f"  ·  {fmt_time(float(info['dur']), 1)}")
                elif kind in ("image", "emote"):
                    it.setIcon(_file_icon(p, 64))
                elif kind == "green":
                    self._thumb_items[it.data(ROLE_ITEM)] = it
                    self._video_thumb(it.data(ROLE_ITEM), str(p))
                alive.append((it, kind))
            except RuntimeError:
                pass
        self._web_items[ref] = alive

    def _track(self, ref: str, it: QListWidgetItem, kind: str) -> None:
        self._web_items.setdefault(ref, []).append((it, kind))

    # -- sounds
    def _page_sound(self) -> QWidget:
        w, v = self._page_frame("🔊 " + tr("lib_sound_title"), tr("lib_sound_hint"))
        self._bank_banner(v)
        lang = language()
        state = {"text": "", "group": ""}
        lst = SoundList(self)

        def refilter():
            n = lst.filter(state["text"], state["group"])
            empty.setVisible(n == 0)
        # search + family on one line (10 families as chips would hide half of the list)
        row = QHBoxLayout()
        row.setSpacing(6)
        sv = QVBoxLayout()
        sv.setContentsMargins(0, 0, 0, 0)
        self._search_box(sv, lambda t: (state.__setitem__("text", t), refilter()))
        row.addLayout(sv, 1)
        sounds = memebank.entries("sound")
        count: dict = {}
        for e in sounds:
            count[e.group] = count.get(e.group, 0) + 1
        fam = QComboBox()
        fam.setToolTip(tr("lib_sound_family_tip"))
        fam.addItem(tr("lib_all_sounds", n=len(sounds)), "")
        fam.addItem("⭐ " + tr("lib_mine"), "mine")
        cats = memebank.sound_cats()
        for c in cats:
            fam.addItem(f"{c.get('icon', '')} {c.get(lang) or c.get('fr')} ({count.get(c['id'], 0)})", c["id"])
        fam.setMaxVisibleItems(14)
        fam.currentIndexChanged.connect(lambda i: (state.__setitem__("group", fam.itemData(i) or ""), refilter()))
        fam.setMinimumWidth(120)
        row.addWidget(fam, 1)
        v.addLayout(row)
        self._sound_family = fam
        cat_names = {c["id"]: c.get(lang) or c.get("fr") for c in cats}
        self._sound_list = lst
        self._fill_sounds(lst, cat_names, sounds)
        lst.listen.connect(self._on_listen)
        lst.add.connect(lambda it: self.add.emit(it.data(ROLE_ITEM)))
        v.addWidget(lst, 1)
        empty = QLabel(tr("lib_nothing"))
        empty.setObjectName("Muted")
        empty.hide()
        v.addWidget(empty)
        row = QHBoxLayout()
        b = QPushButton("📂 " + tr("lib_open_folder"))
        b.setObjectName("Flat")
        b.clicked.connect(lambda: self._open_bank("sound"))
        row.addWidget(b)
        b = QPushButton("⟳ " + tr("lib_reload"))
        b.setObjectName("Flat")
        b.clicked.connect(lambda: (self._fill_sounds(lst, cat_names, memebank.entries("sound")), refilter()))
        row.addWidget(b)
        row.addStretch(1)
        v.addLayout(row)
        refilter()
        return w

    def _fill_sounds(self, lst: SoundList, cat_names: dict, sounds: list) -> None:
        lst.clear()
        mine = []
        try:
            bank.ensure(self.cfg)
            mine = bank.list_items(self.cfg, "sound")
        except Exception as e:  # noqa: BLE001
            log.info("bank: %s", e)
        for it_ in mine:
            it = QListWidgetItem(it_.name)
            it.setData(ROLE_ITEM, f"sound:{it_.ref}")
            it.setData(ROLE_PATH, str(it_.path))
            d = bank.duration(it_.path)
            it.setData(ROLE_SUB, "⭐ " + tr("lib_mine") + (f"  ·  {fmt_time(d, 1)}" if d else ""))
            it.setData(ROLE_SEARCH, _norm(it_.name))
            it.setData(ROLE_GROUP, {"mine"})
            lst.addItem(it)
        for e in sounds:
            it = QListWidgetItem(e.name)
            it.setData(ROLE_ITEM, f"sound:{e.ref}")
            it.setData(ROLE_PATH, str(e.path) if e.path else "")
            it.setData(ROLE_WAVE, e.info.get("wave") or [])
            cat = cat_names.get(e.group, "")
            it.setData(ROLE_SUB, f"{cat}  ·  " + (fmt_time(float(e.info['dur']), 1) if e.info.get("dur")
                                                   else tr("lib_to_download")))
            it.setData(ROLE_SEARCH, _norm(" ".join([e.name, e.id.replace("-", " "), cat])))
            it.setData(ROLE_GROUP, {e.group})
            it.setToolTip(tr("lib_sound_tip"))
            lst.addItem(it)
            self._track(e.ref, it, "sound")

    def _on_listen(self, it: QListWidgetItem) -> None:
        item = it.data(ROLE_ITEM)
        if self.playing_item == item:
            self.listen.emit(item, "")
        else:
            self.listen.emit(item, it.data(ROLE_PATH) or "")

    # -- files dropped from the PC (Explorer): they go into the bank
    @staticmethod
    def _media_files(e) -> list:
        md = e.mimeData()
        if not md.hasUrls():
            return []
        exts = bank.EXTS["sound"] | bank.EXTS["image"] | bank.EXTS["video"]
        out = []
        for u in md.urls():
            f = u.toLocalFile()
            if f and Path(f).suffix.lower() in exts and Path(f).is_file():
                out.append(f)
        return out

    def dragEnterEvent(self, e) -> None:  # noqa: N802
        if self._media_files(e):
            e.acceptProposedAction()

    def dragMoveEvent(self, e) -> None:  # noqa: N802
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e) -> None:  # noqa: N802
        files = self._media_files(e)
        if files:
            e.acceptProposedAction()
            self.files_dropped.emit(files)

    def set_playing(self, item: str) -> None:
        self.playing_item = item or ""
        for lst in (getattr(self, "_sound_list", None), getattr(self, "_music_list", None)):
            if _alive(lst):
                lst.viewport().update()

    # -- texts
    def _page_text(self) -> QWidget:
        w, v = self._page_frame("🅰 " + tr("lib_text_title"), tr("lib_text_hint"))
        b = QPushButton("➕ " + tr("lib_text_free"))
        b.setObjectName("Primary")
        b.clicked.connect(lambda: self.add.emit("text:classic||" + tr("lib_text_default")))
        v.addWidget(b)
        lst = ItemList(True, 0, QSize(150, 64))
        lst.setIconSize(QSize(140, 54))
        en = language() == "en"
        todo = []
        for text, style, color in fxlib.TEXT_PRESETS:
            if en:
                text = fxlib.TEXT_PRESETS_EN.get(text, text)
            it = QListWidgetItem()
            item = f"text:{style}|{color or ''}|{text}"
            it.setData(ROLE_ITEM, item)
            it.setToolTip(f"{text}  ·  {tr('txstyle_' + style)}")
            it.setSizeHint(QSize(150, 64))
            lst.addItem(it)
            todo.append((it, text, style, color))
        lst.itemClicked.connect(lambda it: self.add.emit(it.data(ROLE_ITEM)))
        v.addWidget(lst, 1)

        def load_some():
            for _ in range(3):
                if not todo:
                    timer.stop()
                    return
                it, text, style, color = todo.pop(0)
                try:
                    im = fxlib.text_picture(text, 600, 600, 0.75, color, style, language())
                    q = _pil_icon(im, QSize(140, 54))
                    it.setIcon(QIcon(q))
                except Exception as e:  # noqa: BLE001
                    log.info("text preset %s: %s", text, e)
        timer = QTimer(w)
        timer.timeout.connect(load_some)
        timer.start(10)
        return w

    # -- effects (the editing ones: zoom, slow motion, freeze frame, shake, bleep, kill card)
    def _page_fx(self) -> QWidget:
        w, v = self._page_frame("✨ " + tr("lib_fx_title"), tr("lib_fx_hint"))
        grid = TileGrid()
        grid.section("")
        self._killcard_tile = None
        for kind, icon in EDIT_FX:
            t = grid.tile(f"edit:{kind}", emoji_icon(icon, 34), tr("st_kind_" + kind), tr("st_fx_tip_" + kind))
            if kind == "killcard":
                self._killcard_tile = t
        grid.picked.connect(self.add)
        v.addWidget(grid, 1)
        more = QLabel(tr("lib_fx_more"))
        more.setObjectName("Muted")
        more.setWordWrap(True)
        more.setStyleSheet("font-size: 8.5pt;")
        v.addWidget(more)
        b = QPushButton("🎞 " + tr("lib_fx_to_greens"))
        b.clicked.connect(lambda: self.show_page("video"))
        v.addWidget(b)
        self.set_cards(self.has_cards)
        return w

    def set_cards(self, on: bool) -> None:
        """The kill card button only works for clips with an Albion kill."""
        self.has_cards = on
        t = getattr(self, "_killcard_tile", None)
        if _alive(t):
            t.setVisible(on)

    # -- pictures: Twitch emotes and meme pictures from the internet, and the user's own pictures
    def _page_image(self) -> QWidget:
        w, v = self._page_frame("🖼 " + tr("lib_image_title"), tr("lib_image_hint"))
        self._bank_banner(v)
        lst = ItemList(True, 64, QSize(84, 92))
        self._image_list = lst
        state = {"text": "", "group": ""}
        icons_todo: list = []

        def fill():
            lst.clear()
            icons_todo.clear()
            groups_seen = set()
            for e in memebank.entries("emote") + memebank.entries("image"):
                it = QListWidgetItem(e.name)
                item = f"image:{e.ref}"
                it.setData(ROLE_ITEM, item)
                it.setData(ROLE_PATH, str(e.path) if e.path else "")
                g = ("mine_e" if e.group == "mine" else e.group) if e.kind == "emote" else "imgflip"
                groups_seen.add(g)
                it.setData(ROLE_SEARCH, _norm(e.name))
                it.setData(ROLE_GROUP, {g, "web"})
                it.setToolTip(e.name + ("" if e.path else "  ·  " + tr("lib_to_download")))
                it.setSizeHint(QSize(84, 92))
                it.setTextAlignment(Qt.AlignHCenter | Qt.AlignTop)
                it.setIcon(_missing_icon(64))
                lst.addItem(it)
                self._track(e.ref, it, e.kind)
                if e.path is not None:
                    icons_todo.append((it, e.path))
            try:
                bank.ensure(self.cfg)
                mine = bank.list_items(self.cfg, "image")
            except Exception:  # noqa: BLE001
                mine = []
            for b_ in mine:
                it = QListWidgetItem(b_.name)
                it.setData(ROLE_ITEM, f"image:{b_.ref}")
                it.setData(ROLE_PATH, str(b_.path))
                it.setData(ROLE_SEARCH, _norm(b_.name))
                it.setData(ROLE_GROUP, {"mine"})
                it.setToolTip(str(b_.path))
                it.setSizeHint(QSize(84, 92))
                it.setTextAlignment(Qt.AlignHCenter | Qt.AlignTop)
                lst.addItem(it)
                icons_todo.append((it, b_.path))
            for gid, chip in self._image_chips.items():
                chip.setVisible(gid in ("", "mine") or gid in groups_seen)
            lst.filter(state["text"], state["group"])
            timer.start(10)

        def load_some():
            for _ in range(10):
                if not icons_todo:
                    timer.stop()
                    return
                it, path = icons_todo.pop(0)
                try:
                    it.setIcon(_file_icon(path, 64))
                except RuntimeError:
                    pass
        timer = QTimer(w)
        timer.timeout.connect(load_some)
        self._search_box(v, lambda t: (state.__setitem__("text", t), lst.filter(t, state["group"])))
        grp = _chips(v, [("", tr("lib_all")), ("mine_emotes", "📺 " + tr("lib_img_mine_emotes")),
                         ("top", "🔥 " + tr("lib_img_top")), ("classic", "🐸 " + tr("lib_img_classic")),
                         ("imgflip", "🖼 " + tr("lib_img_memes")), ("mine", "⭐ " + tr("lib_mine"))],
                     lambda g: (state.__setitem__("group", "mine_e" if g == "mine_emotes" else g),
                                lst.filter(state["text"], state["group"])))
        self._image_chips = {b.property("gid"): b for b in grp.buttons()}
        self._image_chips["mine_e"] = self._image_chips.pop("mine_emotes")
        lst.itemClicked.connect(lambda it: self.add.emit(it.data(ROLE_ITEM)))
        v.addWidget(lst, 1)
        row = QHBoxLayout()
        b = QPushButton("📂 " + tr("lib_open_folder"))
        b.setObjectName("Flat")
        b.clicked.connect(lambda: self._open_bank("image"))
        row.addWidget(b)
        b = QPushButton("⟳ " + tr("lib_reload"))
        b.setObjectName("Flat")
        b.clicked.connect(fill)
        row.addWidget(b)
        row.addStretch(1)
        v.addLayout(row)
        self._fill_images = fill
        fill()
        return w

    # -- videos: green screen memes from the internet, and the user's own videos
    def _page_video(self) -> QWidget:
        w, v = self._page_frame("🎞 " + tr("lib_video_title"), tr("lib_video_hint"))
        self._bank_banner(v)
        lst = ItemList(True, 96, QSize(112, 92))
        lst.setIconSize(QSize(100, 56))
        self._video_list = lst

        def fill():
            lst.clear()
            try:
                bank.ensure(self.cfg)
                mine = bank.list_items(self.cfg, "video")
            except Exception:  # noqa: BLE001
                mine = []
            for b_ in mine:
                it = QListWidgetItem(b_.name)
                item = f"video:{b_.ref}"
                it.setData(ROLE_ITEM, item)
                it.setData(ROLE_PATH, str(b_.path))
                it.setData(ROLE_SEARCH, _norm(b_.name))
                it.setData(ROLE_GROUP, {"mine"})
                d = bank.duration(b_.path)
                it.setToolTip(f"{b_.name}  ·  {fmt_time(d, 1)}")
                it.setSizeHint(QSize(112, 92))
                it.setTextAlignment(Qt.AlignHCenter | Qt.AlignTop)
                lst.addItem(it)
                self._thumb_items[item] = it
                self._video_thumb(item, str(b_.path))
            for e in memebank.entries("green"):
                it = QListWidgetItem(e.name)
                item = f"video:{e.ref}"
                it.setData(ROLE_ITEM, item)
                it.setData(ROLE_PATH, str(e.path) if e.path else "")
                it.setData(ROLE_SEARCH, _norm(e.name + " " + e.src.get("q", "")))
                it.setData(ROLE_GROUP, {"green"})
                it.setToolTip(e.name + ("" if e.path else "  ·  " + tr("lib_to_download")))
                it.setSizeHint(QSize(112, 92))
                it.setTextAlignment(Qt.AlignHCenter | Qt.AlignTop)
                it.setIcon(_missing_icon(100, 56))
                lst.addItem(it)
                self._track(e.ref, it, "green")
                if e.path is not None:
                    self._thumb_items[item] = it
                    self._video_thumb(item, str(e.path))
            lst.filter(state["text"], state["group"])
        state = {"text": "", "group": ""}
        self._search_box(v, lambda t: (state.__setitem__("text", t), lst.filter(t, state["group"])))
        _chips(v, [("", tr("lib_all")), ("green", "🟩 " + tr("lib_greens")), ("mine", "⭐ " + tr("lib_mine"))],
               lambda g: (state.__setitem__("group", g), lst.filter(state["text"], g)))
        lst.itemClicked.connect(lambda it: self.add.emit(it.data(ROLE_ITEM)))
        v.addWidget(lst, 1)
        row = QHBoxLayout()
        b = QPushButton("➕ " + tr("lib_video_add"))
        b.clicked.connect(lambda: self.show_page("add"))
        row.addWidget(b)
        b = QPushButton("📂")
        b.setObjectName("Flat")
        b.setToolTip(tr("lib_open_folder"))
        b.clicked.connect(lambda: self._open_bank("video"))
        row.addWidget(b)
        b = QPushButton("⟳")
        b.setObjectName("Flat")
        b.setToolTip(tr("lib_reload"))
        b.clicked.connect(fill)
        row.addWidget(b)
        row.addStretch(1)
        v.addLayout(row)
        self._fill_videos = fill
        fill()
        return w

    def _video_thumb(self, item: str, path: str) -> None:
        def work():
            q = None
            try:
                from .. import preview
                from .live_preview import bgra_to_qimage
                rd = preview.VideoReader(path, 200, 112)
                got = rd.frame_at(min(0.5, max(0.0, rd.duration * 0.2)))
                rd.close()
                if got is not None:
                    q = bgra_to_qimage(got[1])
                    if looks_green(got[1]):
                        q = _badge(q)
            except Exception:  # noqa: BLE001
                q = None
            self._thumbs.done.emit(item, q)
        threading.Thread(target=work, daemon=True, name="video-thumb").start()

    def _thumb_done(self, item: str, q) -> None:
        it = self._thumb_items.get(item)
        if it is not None and q is not None:
            try:
                it.setIcon(QIcon(QPixmap.fromImage(q)))
            except RuntimeError:
                pass

    # the widgets of a page the library keeps a hand on (forgotten when the page is thrown away)
    PAGE_ATTRS = {"sound": ("_sound_list", "_sound_family"), "image": ("_image_list", "_image_chips", "_fill_images"),
                  "video": ("_video_list", "_fill_videos"), "music": ("_music_list", "cur_music"),
                  "fx": ("_killcard_tile",)}

    def reload_bank(self, web: bool = False) -> None:
        """Files were added to the bank (an import, or the internet download finished): show them. The pages are
        built again when they are shown (a page that is not shown is simply forgotten)."""
        self._web_items.clear()
        self._banners = []
        self._thumb_items.clear()
        for pid in ("sound", "image", "video", "music"):
            if pid in self._built:
                page = self._built.pop(pid)
                for name in self.PAGE_ATTRS.get(pid, ()):
                    if hasattr(self, name):
                        delattr(self, name)
                page.setParent(None)
                page.deleteLater()
                if self.current_page() == pid:
                    self.show_page(pid)

    # -- music
    def _page_music(self) -> QWidget:
        w, v = self._page_frame("🎵 " + tr("lib_music_title"), tr("lib_music_hint"))
        self._bank_banner(v)
        lang = language()
        lst = SoundList(self)
        self._music_list = lst
        it = QListWidgetItem("🚫 " + tr("st_music_none"))
        it.setData(ROLE_ITEM, "music:")
        it.setData(ROLE_SUB, tr("lib_music_none_sub"))
        lst.addItem(it)
        for e in memebank.entries("music"):
            it = QListWidgetItem(e.name)
            it.setData(ROLE_ITEM, f"music:{e.ref}")
            it.setData(ROLE_PATH, str(e.path) if e.path else "")
            it.setData(ROLE_WAVE, e.info.get("wave") or [])
            mood = e.info.get(lang) or e.info.get("fr") or ""
            it.setData(ROLE_SUB, f"Kevin MacLeod  ·  {mood}  ·  " + (fmt_time(float(e.info['dur']), 0)
                                                                      if e.info.get("dur") else tr("lib_to_download")))
            it.setData(ROLE_SEARCH, _norm(f"{e.name} {mood} kevin macleod"))
            lst.addItem(it)
            self._track(e.ref, it, "music")
        try:
            bank.ensure(self.cfg)
            mine = bank.list_items(self.cfg, "music")
        except Exception:  # noqa: BLE001
            mine = []
        for b_ in mine:
            it = QListWidgetItem(b_.name)
            it.setData(ROLE_ITEM, f"music:{b_.ref}")
            it.setData(ROLE_PATH, str(b_.path))
            d = bank.duration(b_.path)
            it.setData(ROLE_SUB, "⭐ " + tr("lib_mine") + (f"  ·  {fmt_time(d, 0)}" if d else ""))
            lst.addItem(it)
        lst.listen.connect(lambda it: self._on_listen(it) if (it.data(ROLE_ITEM) or "") != "music:" else None)
        lst.add.connect(lambda it: self.use_music.emit((it.data(ROLE_ITEM) or "music:")[6:]))
        lst.setToolTip(tr("lib_music_tip"))
        v.addWidget(lst, 1)
        self.cur_music = QLabel("")
        self.cur_music.setObjectName("Muted")
        self.cur_music.setWordWrap(True)
        v.addWidget(self.cur_music)
        hint = QLabel(tr("lib_music_rights"))
        hint.setObjectName("Muted")
        hint.setWordWrap(True)
        hint.setStyleSheet("font-size: 8pt;")
        v.addWidget(hint)
        self.set_music(self.music_ref)
        return w

    def set_music(self, ref: str) -> None:
        self.music_ref = ref or ""
        lab = getattr(self, "cur_music", None)
        if _alive(lab):
            lab.setText(tr("lib_music_current", name=bank.display_name(ref)) if ref else tr("lib_music_current_none"))

    # -- add your own memes
    def _page_add(self) -> QWidget:
        w, v = self._page_frame("➕ " + tr("lib_add_title"), tr("lib_add_hint"))
        for key, icon in (("link", "🔗"), ("youtube", "🔎"), ("vod", "✂️"), ("mic", "🎙️"), ("files", "📁")):
            b = QPushButton(f"  {tr('lib_add_' + key)}")
            b.setMinimumWidth(10)
            b.setIcon(emoji_icon(icon, 22))
            b.setIconSize(QSize(22, 22))
            b.setStyleSheet("text-align: left; padding: 10px 12px;")
            b.setToolTip(tr("lib_add_" + key + "_tip"))
            b.clicked.connect(lambda _c=False, k=key: self.import_requested.emit(k))
            v.addWidget(b)
            d = QLabel(tr("lib_add_" + key + "_tip"))
            d.setObjectName("Muted")
            d.setWordWrap(True)
            d.setStyleSheet("font-size: 8pt; padding: 0 0 4px 6px;")
            v.addWidget(d)
        b = QPushButton("📂 " + tr("lib_open_bank"))
        b.setObjectName("Flat")
        b.clicked.connect(lambda: self.import_requested.emit("folder"))
        v.addWidget(b)
        v.addStretch(1)
        sc = QScrollArea()
        sc.setWidgetResizable(True)
        sc.setFrameShape(QFrame.NoFrame)
        sc.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        sc.setWidget(w)
        return sc

    def _open_bank(self, kind: str) -> None:
        try:
            root = bank.ensure(self.cfg)
            open_in_explorer(root / bank.FOLDERS[kind])
        except Exception as e:  # noqa: BLE001
            log.info("open bank: %s", e)


def _missing_icon(w: int, h: int = 0) -> QIcon:
    """Not downloaded yet: a grey box with ⬇."""
    h = h or w
    pm = QPixmap(w, h)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing)
    p.setPen(Qt.NoPen)
    p.setBrush(QColor("#2a2a33"))
    p.drawRoundedRect(QRectF(1, 1, w - 2, h - 2), 8, 8)
    p.setPen(QColor(theme.MUTED))
    f = QFont()
    f.setPointSizeF(max(9.0, min(w, h) * 0.28))
    p.setFont(f)
    p.drawText(QRect(0, 0, w, h), Qt.AlignCenter, "⬇")
    p.end()
    return QIcon(pm)


def _alive(w) -> bool:
    """A widget the library still holds may have been thrown away with its page."""
    if w is None:
        return False
    try:
        import shiboken6
        return shiboken6.isValid(w)
    except Exception:  # noqa: BLE001
        return True


def _file_icon(path, px: int) -> QIcon:
    """A picture file (first frame of a GIF / WebP) as an icon."""
    pm = QPixmap(str(path))
    if pm.isNull():
        try:
            from PIL import Image
            with Image.open(path) as im:
                im.seek(0)
                return QIcon(_pil_icon(im.convert("RGBA"), QSize(px, px)))
        except Exception:  # noqa: BLE001
            return _missing_icon(px)
    return QIcon(pm.scaled(px, px, Qt.KeepAspectRatio, Qt.SmoothTransformation))


def _pil_icon(im, box: QSize) -> QPixmap:
    from .live_preview import pil_to_qimage
    q = pil_to_qimage(im)
    q = q.scaled(box, Qt.KeepAspectRatio, Qt.SmoothTransformation)
    pm = QPixmap(box)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.drawImage((box.width() - q.width()) // 2, (box.height() - q.height()) // 2, q)
    p.end()
    return pm


def _badge(q: QImage) -> QImage:
    """A small "GS" (green screen) mark in the corner of a video picture."""
    out = q.convertToFormat(QImage.Format_ARGB32_Premultiplied)
    p = QPainter(out)
    p.setRenderHint(QPainter.Antialiasing)
    r = QRect(out.width() - 26, 4, 22, 18)
    p.setPen(Qt.NoPen)
    p.setBrush(QColor(0, 0, 0, 150))
    p.drawRoundedRect(r, 5, 5)
    p.setPen(QPen(QColor("#7CFF6B")))
    f = QFont()
    f.setPointSizeF(8)
    p.setFont(f)
    p.drawText(r, Qt.AlignCenter, "GS")
    p.end()
    return out


def looks_green(bgra) -> bool:
    """A meme video on a green background (green screen) is cut out by itself."""
    try:
        import numpy as np
        a = bgra[::4, ::4, :3].astype(np.int32)
        b, g, r = a[..., 0], a[..., 1], a[..., 2]
        green = (g > 120) & (g > r * 1.5) & (g > b * 1.5)
        return float(green.mean()) > 0.35
    except Exception:  # noqa: BLE001
        return False


def looks_green_file(path: Optional[Path]) -> bool:
    if path is None:
        return False
    try:
        from .. import preview
        rd = preview.VideoReader(str(path), 160, 90)
        got = rd.frame_at(0.3)
        rd.close()
        return got is not None and looks_green(got[1])
    except Exception:  # noqa: BLE001
        return False
