"""Dark theme (fire orange accent) for the whole app."""
from __future__ import annotations

from PySide6.QtGui import QColor, QFont, QIcon, QPalette
from PySide6.QtWidgets import QApplication, QStyleFactory

from .. import paths

BG = "#141418"
PANEL = "#1c1c22"
PANEL_2 = "#24242c"
BORDER = "#2f2f39"
TEXT = "#ececf1"
MUTED = "#9a9aa8"
ACCENT = "#ff6a3d"
ACCENT_2 = "#ffb02e"
GOOD = "#3ecf8e"
WARN = "#f5b83d"
BAD = "#ff5c6c"
PURPLE = "#a970ff"


def score_color(score: float) -> QColor:
    """0 -> grey-blue, 50 -> orange, 100 -> bright yellow-red."""
    s = max(0.0, min(100.0, score)) / 100.0
    if s < 0.35:
        return QColor("#5d6075")
    if s < 0.55:
        return QColor("#c9773a")
    if s < 0.75:
        return QColor(ACCENT)
    return QColor("#ff3d3d") if s >= 0.9 else QColor("#ff5232")


QSS = f"""
QWidget {{ color: {TEXT}; font-size: 10pt; }}
QMainWindow, QDialog {{ background: {BG}; }}
QToolTip {{ background: {PANEL_2}; color: {TEXT}; border: 1px solid {BORDER}; padding: 6px; }}
QFrame#Panel, QWidget#Panel {{ background: {PANEL}; border: 1px solid {BORDER}; border-radius: 10px; }}
QLabel#Title {{ font-size: 13pt; font-weight: 600; }}
QLabel#Muted {{ color: {MUTED}; }}
QLabel#Brand {{ font-size: 15pt; font-weight: 800; color: {ACCENT}; }}
QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox, QPlainTextEdit, QTextEdit, QTextBrowser {{
    background: {PANEL_2}; border: 1px solid {BORDER}; border-radius: 7px; padding: 5px 8px;
    selection-background-color: {ACCENT};
}}
QLineEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus, QComboBox:focus, QPlainTextEdit:focus {{
    border: 1px solid {ACCENT};
}}
QLineEdit#BigInput {{ font-size: 11pt; padding: 9px 12px; border-radius: 9px; }}
QComboBox QAbstractItemView {{ background: {PANEL_2}; border: 1px solid {BORDER}; selection-background-color: {ACCENT}; }}
QPushButton {{
    background: {PANEL_2}; border: 1px solid {BORDER}; border-radius: 8px; padding: 6px 14px;
}}
QPushButton:hover {{ border-color: {ACCENT}; }}
QPushButton:pressed {{ background: {BORDER}; }}
QPushButton:disabled {{ color: #5c5c68; border-color: #26262e; }}
QPushButton#Primary {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #ff7a3d, stop:1 #ff4f3d);
    border: none; color: white; font-weight: 700; padding: 8px 18px;
}}
QPushButton#Primary:hover {{ background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #ff8d55, stop:1 #ff6450); }}
QPushButton#Primary:disabled {{ background: #4a3a36; color: #a99; }}
QPushButton#Flat, QToolButton#Flat {{ background: transparent; border: none; padding: 4px 8px; color: {MUTED}; }}
QPushButton#Flat:hover, QToolButton#Flat:hover {{ color: {TEXT}; }}
QPushButton#Flat:checked, QToolButton#Flat:checked {{ color: {ACCENT}; }}
QToolButton {{ background: {PANEL_2}; border: 1px solid {BORDER}; border-radius: 7px; padding: 4px 8px; }}
QToolButton:hover {{ border-color: {ACCENT}; }}
QToolButton:checked {{ background: #3b2620; border-color: {ACCENT}; }}
QToolButton#Seg:checked {{ background: {ACCENT}; border-color: {ACCENT}; color: white; font-weight: 700; }}
QCheckBox::indicator {{ width: 16px; height: 16px; border-radius: 4px; border: 1px solid #555563; background: {PANEL_2}; }}
QCheckBox::indicator:checked {{ background: {ACCENT}; border-color: {ACCENT}; image: none; }}
QRadioButton::indicator {{ width: 14px; height: 14px; border-radius: 8px; border: 2px solid #6a6a78; background: {PANEL_2}; }}
QRadioButton::indicator:checked {{ background: {ACCENT}; border: 2px solid {ACCENT}; }}
QRadioButton {{ font-weight: 600; spacing: 8px; }}
QProgressBar {{ background: {PANEL_2}; border: none; border-radius: 4px; height: 8px; text-align: center; color: transparent; }}
QProgressBar::chunk {{ border-radius: 4px; background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 {ACCENT_2}, stop:1 {ACCENT}); }}
QProgressBar#Big {{ height: 14px; color: white; font-size: 8pt; }}
QListWidget {{ background: transparent; border: none; outline: none; }}
QListWidget::item {{ border-radius: 8px; margin: 2px 0px; }}
QListWidget::item:selected {{ background: #2c2730; border: 1px solid {ACCENT}; }}
QListWidget::item:hover:!selected {{ background: #222229; }}
QTableView {{
    background: {PANEL}; alternate-background-color: #202027; border: none; gridline-color: transparent;
    selection-background-color: #3a2a26; selection-color: {TEXT}; outline: none;
}}
QTableView::item {{ padding: 4px; border: none; }}
QTableView::indicator {{ width: 16px; height: 16px; border-radius: 4px; border: 1px solid #6a6a78; background: {PANEL_2}; }}
QTableView::indicator:checked {{ background: {ACCENT}; border-color: {ACCENT}; image: none; }}
QHeaderView::section {{ background: {PANEL}; color: {MUTED}; border: none; border-bottom: 1px solid {BORDER}; padding: 6px; font-weight: 600; }}
QTabWidget::pane {{ border: 1px solid {BORDER}; border-radius: 8px; top: -1px; background: {PANEL}; }}
QTabBar::tab {{ background: transparent; color: {MUTED}; padding: 8px 14px; border: none; }}
QTabBar::tab:selected {{ color: {TEXT}; border-bottom: 2px solid {ACCENT}; }}
QTabWidget#SettingsTabs QTabBar::tab {{ padding: 8px 9px; }}
QTabBar QToolButton {{ background: {PANEL_2}; border: 1px solid {BORDER}; border-radius: 4px; padding: 0px; margin: 2px 1px; }}
QScrollBar:vertical {{ background: transparent; width: 10px; margin: 2px; }}
QScrollBar::handle:vertical {{ background: #3a3a46; border-radius: 4px; min-height: 30px; }}
QScrollBar:horizontal {{ background: transparent; height: 10px; margin: 2px; }}
QScrollBar::handle:horizontal {{ background: #3a3a46; border-radius: 4px; min-width: 30px; }}
QScrollBar::add-line, QScrollBar::sub-line {{ width: 0; height: 0; }}
QSlider::groove:horizontal {{ height: 6px; background: {PANEL_2}; border-radius: 3px; }}
QSlider::sub-page:horizontal {{ background: {ACCENT}; border-radius: 3px; }}
QSlider::handle:horizontal {{ background: white; width: 14px; height: 14px; margin: -5px 0; border-radius: 7px; }}
QSplitter::handle {{ background: transparent; }}
QGroupBox {{ border: 1px solid {BORDER}; border-radius: 8px; margin-top: 14px; padding: 10px 8px 8px 8px; }}
QGroupBox::title {{ subcontrol-origin: margin; left: 10px; padding: 0 4px; color: {MUTED}; }}
QStatusBar {{ background: {BG}; color: {MUTED}; }}
QMenu {{ background: {PANEL_2}; border: 1px solid {BORDER}; padding: 4px; }}
QMenu::item {{ padding: 6px 18px; border-radius: 5px; }}
QMenu::item:selected {{ background: {ACCENT}; color: white; }}
QFrame#Banner {{ background: #3a2f17; border: 1px solid #6b5420; border-radius: 8px; }}
QFrame#ErrorBox {{ background: #3a1d22; border: 1px solid #7a2b36; border-radius: 10px; }}
"""


def apply(app: QApplication) -> None:
    app.setStyle(QStyleFactory.create("Fusion"))
    pal = QPalette()
    pal.setColor(QPalette.Window, QColor(BG))
    pal.setColor(QPalette.WindowText, QColor(TEXT))
    pal.setColor(QPalette.Base, QColor(PANEL_2))
    pal.setColor(QPalette.AlternateBase, QColor(PANEL))
    pal.setColor(QPalette.Text, QColor(TEXT))
    pal.setColor(QPalette.Button, QColor(PANEL_2))
    pal.setColor(QPalette.ButtonText, QColor(TEXT))
    pal.setColor(QPalette.Highlight, QColor(ACCENT))
    pal.setColor(QPalette.HighlightedText, QColor("white"))
    pal.setColor(QPalette.ToolTipBase, QColor(PANEL_2))
    pal.setColor(QPalette.ToolTipText, QColor(TEXT))
    pal.setColor(QPalette.PlaceholderText, QColor(MUTED))
    pal.setColor(QPalette.Link, QColor(ACCENT_2))
    app.setPalette(pal)
    f = QFont("Segoe UI")
    f.setPointSizeF(10)
    app.setFont(f)
    app.setStyleSheet(QSS)
    icon_path = paths.ASSETS / "icon.png"
    if icon_path.exists():
        app.setWindowIcon(QIcon(str(icon_path)))


def app_icon() -> QIcon:
    for name in ("icon.ico", "icon.png"):
        p = paths.ASSETS / name
        if p.exists():
            return QIcon(str(p))
    return QIcon()
