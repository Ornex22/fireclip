"""Small reusable widgets."""
from __future__ import annotations

from typing import Optional

from PySide6.QtCore import QPoint, QRect, QRectF, QSize, Qt, Signal
from PySide6.QtGui import QBrush, QColor, QFont, QLinearGradient, QPainter, QPainterPath
from PySide6.QtWidgets import (QAbstractSpinBox, QDoubleSpinBox, QFrame, QHBoxLayout, QLabel, QLayout, QProgressBar,
                               QPushButton, QSizePolicy, QSplitter, QSplitterHandle, QStyle, QStyledItemDelegate,
                               QStyleOptionViewItem, QVBoxLayout, QWidget)

from ..i18n import tr
from ..util import fmt_time, parse_time
from . import theme


class TimeSpinBox(QDoubleSpinBox):
    """Seconds shown as H:MM:SS.s, arrows move by 0.5 s."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setDecimals(2)
        self.setRange(0, 24 * 3600)
        self.setSingleStep(0.5)
        self.setKeyboardTracking(False)
        self.setButtonSymbols(QAbstractSpinBox.UpDownArrows)
        self.setMinimumWidth(110)

    def textFromValue(self, v: float) -> str:  # noqa: N802
        return fmt_time(v, 1)

    def valueFromText(self, text: str) -> float:  # noqa: N802
        v = parse_time(text)
        return float(v) if v is not None else self.value()

    def validate(self, text: str, pos: int):
        from PySide6.QtGui import QValidator
        t = text.strip()
        if not t or all(c in "0123456789:.,hms " for c in t):
            return (QValidator.Acceptable if parse_time(t) is not None else QValidator.Intermediate), text, pos
        return QValidator.Invalid, text, pos


class ScoreDelegate(QStyledItemDelegate):
    """Draws the score as a coloured bar with the number."""

    def paint(self, p: QPainter, opt: QStyleOptionViewItem, idx) -> None:
        val = idx.data(Qt.UserRole)
        if val is None:
            return super().paint(p, opt, idx)
        p.save()
        p.setRenderHint(QPainter.Antialiasing)
        r = opt.rect.adjusted(6, 9, -6, -9)
        if opt.state & QStyle.State_Selected:
            p.fillRect(opt.rect, QColor("#3a2a26"))
        p.setPen(Qt.NoPen)
        p.setBrush(QColor("#2b2b34"))
        p.drawRoundedRect(QRectF(r), 4, 4)
        w = max(4.0, r.width() * max(0.0, min(100.0, float(val))) / 100.0)
        col = theme.score_color(float(val))
        g = QLinearGradient(r.left(), 0, r.left() + w, 0)
        g.setColorAt(0, col.darker(130))
        g.setColorAt(1, col)
        p.setBrush(QBrush(g))
        p.drawRoundedRect(QRectF(r.left(), r.top(), w, r.height()), 4, 4)
        p.setPen(QColor("white"))
        f = QFont(opt.font)
        f.setBold(True)
        p.setFont(f)
        p.drawText(opt.rect, Qt.AlignCenter, f"{float(val):.0f}")
        p.restore()

    def sizeHint(self, opt, idx) -> QSize:  # noqa: N802
        return QSize(70, 30)


class TimelineWidget(QWidget):
    """Whole-VOD overview: the combined score over time, with the moments marked. Click a
    marker to select that moment."""
    clicked = Signal(float)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.values: list[float] = []
        self.step = 10.0
        self.duration = 1.0
        self.moments: list[tuple[float, float, int]] = []
        self.events: list = []
        self.current: Optional[tuple[float, float]] = None
        self.setMinimumHeight(46)
        self.setMaximumHeight(46)
        self.setMouseTracking(True)
        self.setToolTip(tr("timeline_tip"))

    def set_data(self, values, step, duration, moments, events=None) -> None:
        self.values = list(values or [])
        self.step = float(step or 10)
        self.duration = max(1.0, float(duration or 1))
        self.moments = moments
        self.events = list(events or [])
        self.update()

    def set_current(self, span: Optional[tuple[float, float]]) -> None:
        self.current = span
        self.update()

    def _x(self, t: float) -> float:
        return 8 + (self.width() - 16) * max(0.0, min(1.0, t / self.duration))

    def paintEvent(self, _e) -> None:  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(theme.PANEL))
        p.drawRoundedRect(QRectF(0, 0, w, h), 8, 8)
        base = h - 10
        if self.values:
            path = QPainterPath()
            path.moveTo(self._x(0), base)
            for i, v in enumerate(self.values):
                x = self._x(i * self.step)
                path.lineTo(x, base - (base - 8) * min(1.0, v / 100.0))
            path.lineTo(self._x(len(self.values) * self.step), base)
            path.closeSubpath()
            g = QLinearGradient(0, 8, 0, base)
            g.setColorAt(0, QColor(255, 106, 61, 200))
            g.setColorAt(1, QColor(255, 106, 61, 25))
            p.setBrush(QBrush(g))
            p.drawPath(path)
        for a, b, rank in self.moments:
            x1, x2 = self._x(a), max(self._x(b), self._x(a) + 3)
            p.setBrush(QColor(255, 176, 46, 150))
            p.drawRect(QRectF(x1, base + 2, x2 - x1, 6))
        colors = {"kill": theme.GOOD, "assist": theme.ACCENT_2, "death": theme.BAD}
        for t, role in self.events:
            p.setBrush(QColor(colors.get(role, theme.GOOD)))
            x = self._x(float(t))
            p.drawRect(QRectF(x - 1.5, 2, 3, 9))
        if self.current:
            a, b = self.current
            x1, x2 = self._x(a), max(self._x(b), self._x(a) + 3)
            p.setBrush(QColor(255, 255, 255, 40))
            p.drawRect(QRectF(x1, 2, x2 - x1, h - 4))
            p.setBrush(QColor("white"))
            p.drawRect(QRectF(x1, base + 2, x2 - x1, 6))
        p.setPen(QColor(theme.MUTED))
        f = p.font()
        f.setPointSizeF(7.5)
        p.setFont(f)
        p.drawText(QRectF(10, 2, 80, 14), Qt.AlignLeft, "0:00")
        p.drawText(QRectF(w - 90, 2, 80, 14), Qt.AlignRight, fmt_time(self.duration))
        p.end()

    def mousePressEvent(self, e) -> None:  # noqa: N802
        x = e.position().x()
        t = (x - 8) / max(1, self.width() - 16) * self.duration
        self.clicked.emit(max(0.0, t))


class VodItemWidget(QWidget):
    """One VOD in the left list."""

    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(10, 8, 10, 8)
        lay.setSpacing(3)
        self.title = QLabel()
        self.title.setStyleSheet("font-weight: 600;")
        self.sub = QLabel()
        self.sub.setObjectName("Muted")
        self.sub.setStyleSheet("font-size: 8.5pt;")
        self.status = QLabel()
        self.status.setStyleSheet("font-size: 8.5pt;")
        self.bar = QProgressBar()
        self.bar.setRange(0, 1000)
        self.bar.setFixedHeight(5)
        self.bar.hide()
        lay.addWidget(self.title)
        lay.addWidget(self.sub)
        lay.addWidget(self.status)
        lay.addWidget(self.bar)

    def set(self, title: str, sub: str, status: str, color: str, progress: Optional[float]) -> None:
        fm = self.title.fontMetrics()
        self.title.setText(fm.elidedText(title, Qt.ElideRight, max(120, self.width() - 24)))
        self.title.setToolTip(title)
        self.sub.setText(sub)
        self.status.setText(status)
        self.status.setStyleSheet(f"font-size: 8.5pt; color: {color};")
        if progress is None:
            self.bar.hide()
        else:
            self.bar.show()
            self.bar.setValue(int(progress * 1000))

    def sizeHint(self) -> QSize:  # noqa: N802
        return QSize(200, 84)


class Banner(QFrame):
    """Yellow information strip (warnings)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("Banner")
        lay = QHBoxLayout(self)
        lay.setContentsMargins(10, 6, 10, 6)
        self.label = QLabel()
        self.label.setWordWrap(True)
        self.label.setStyleSheet(f"color: {theme.WARN};")
        lay.addWidget(self.label, 1)
        self.btn = QPushButton()
        self.btn.setObjectName("Flat")
        self.btn.hide()
        lay.addWidget(self.btn)
        self.hide()

    def show_text(self, text: str, button: str = "") -> None:
        self.label.setText(text)
        self.btn.setVisible(bool(button))
        self.btn.setText(button)
        self.setVisible(bool(text))


def h_line() -> QFrame:
    f = QFrame()
    f.setFrameShape(QFrame.HLine)
    f.setStyleSheet(f"color: {theme.BORDER};")
    return f


class FlowLayout(QLayout):
    """Puts the widgets on a line and goes to the next line when there is no room left."""

    def __init__(self, parent=None, spacing: int = 4):
        super().__init__(parent)
        self._items = []
        self._spacing = spacing
        self.setContentsMargins(0, 0, 0, 0)

    def addItem(self, item) -> None:  # noqa: N802
        self._items.append(item)

    def count(self) -> int:
        return len(self._items)

    def itemAt(self, i):  # noqa: N802
        return self._items[i] if 0 <= i < len(self._items) else None

    def takeAt(self, i):  # noqa: N802
        return self._items.pop(i) if 0 <= i < len(self._items) else None

    def expandingDirections(self):  # noqa: N802
        return Qt.Orientation(0)

    def hasHeightForWidth(self) -> bool:  # noqa: N802
        return True

    def heightForWidth(self, w: int) -> int:  # noqa: N802
        return self._do_layout(QRect(0, 0, w, 0), True)

    def setGeometry(self, rect) -> None:  # noqa: N802
        super().setGeometry(rect)
        self._do_layout(rect, False)

    def sizeHint(self) -> QSize:  # noqa: N802
        return self.minimumSize()

    def minimumSize(self) -> QSize:  # noqa: N802
        size = QSize()
        for it in self._items:
            size = size.expandedTo(it.minimumSize())
        m = self.contentsMargins()
        return size + QSize(m.left() + m.right(), m.top() + m.bottom())

    def _do_layout(self, rect, test: bool) -> int:
        m = self.contentsMargins()
        r = rect.adjusted(m.left(), m.top(), -m.right(), -m.bottom())
        x, y, line_h = r.x(), r.y(), 0
        for it in self._items:
            w = it.widget()
            if w is not None and w.isHidden():
                continue
            hint = it.sizeHint()
            nx = x + hint.width() + self._spacing
            if nx - self._spacing > r.right() + 1 and line_h > 0:
                x = r.x()
                y += line_h + self._spacing
                nx = x + hint.width() + self._spacing
                line_h = 0
            if not test:
                it.setGeometry(QRect(QPoint(x, y), hint))
            x = nx
            line_h = max(line_h, hint.height())
        return y + line_h - rect.y() + m.bottom()


class ElidedLabel(QLabel):
    """One line of text that ends with "…" when there is not enough room (full text in the tooltip),
    instead of pushing the other widgets of the row out of the window on small screens."""

    def __init__(self, text: str = "", parent=None):
        super().__init__(parent)
        self._full = ""
        self.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)
        self.setText(text)

    def setText(self, text: str) -> None:  # noqa: N802
        self._full = text or ""
        self.setToolTip(self._full if self._full else "")
        self._elide()

    def text(self) -> str:
        return self._full

    def _elide(self) -> None:
        fm = self.fontMetrics()
        QLabel.setText(self, fm.elidedText(self._full, Qt.ElideRight, max(12, self.width() - 2)))

    def resizeEvent(self, e) -> None:  # noqa: N802
        super().resizeEvent(e)
        self._elide()

    def sizeHint(self) -> QSize:  # noqa: N802
        return QSize(self.fontMetrics().horizontalAdvance(self._full) + 4, super().sizeHint().height())

    def minimumSizeHint(self) -> QSize:  # noqa: N802
        return QSize(30, super().minimumSizeHint().height())


class _GripHandle(QSplitterHandle):
    """Splitter handle drawn as a small rounded grip, so people see they can drag it."""

    def __init__(self, orientation, parent):
        super().__init__(orientation, parent)
        self.setAttribute(Qt.WA_Hover, True)

    def enterEvent(self, e) -> None:  # noqa: N802
        self.update()
        super().enterEvent(e)

    def leaveEvent(self, e) -> None:  # noqa: N802
        self.update()
        super().leaveEvent(e)

    def paintEvent(self, _e) -> None:  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setPen(Qt.NoPen)
        c = QColor(theme.ACCENT if self.underMouse() else theme.MUTED)
        if not self.underMouse():
            c.setAlpha(120)
        p.setBrush(c)
        if self.orientation() == Qt.Vertical:
            w, h = 46, 4
        else:
            w, h = 4, 46
        p.drawRoundedRect(QRectF((self.width() - w) / 2, (self.height() - h) / 2, w, h), 2, 2)


class GripSplitter(QSplitter):
    def __init__(self, orientation, parent=None):
        super().__init__(orientation, parent)
        self.setHandleWidth(10)

    def createHandle(self):  # noqa: N802
        return _GripHandle(self.orientation(), self)
