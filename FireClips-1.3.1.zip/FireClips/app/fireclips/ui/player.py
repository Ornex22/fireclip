"""Right panel: built-in video player + start/end adjustment + details of the selected moment."""
from __future__ import annotations

import logging
import os
from typing import Optional

from PySide6.QtCore import Qt, QTimer, QUrl, Signal
from PySide6.QtWidgets import (QFrame, QGridLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
                               QSizePolicy, QSlider, QStackedLayout, QTabWidget, QTextBrowser, QToolButton, QVBoxLayout,
                               QWidget)

from ..i18n import tr
from ..scoring import reason_label
from ..util import fmt_time
from . import theme
from .widgets import GripSplitter, TimeSpinBox

log = logging.getLogger("fireclips.player")

try:
    from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
    from PySide6.QtMultimediaWidgets import QVideoWidget
    HAVE_MM = True
except Exception:  # noqa: BLE001
    HAVE_MM = False


class PlayerPanel(QWidget):
    range_changed = Signal(float, float)       # start, end (VOD time)
    title_changed = Signal(str)
    need_segment = Signal(float, float)        # ask the window to fetch a preview piece
    edit_subs = Signal()                       # the user wants to correct the subtitles
    position_vod = Signal(float)               # where the player is (VOD time), source video only
    render_closed = Signal()                   # back from the montage preview to the stream video
    studio_requested = Signal()                # "Edit this clip" (opens the Studio window)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.moment: Optional[dict] = None
        self.src: Optional[dict] = None        # {"path", "vod_start", "duration", "full"}
        self.duration_vod = 0.0
        self._clip_mode = False
        self._block = False
        self._pending_seek: Optional[float] = None
        self._autoplay = False
        self.render_mode = False               # playing the montage preview instead of the stream video
        self._saved_src: Optional[dict] = None

        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(8)
        # video + transport on top, the tabs (clip / Studio) below: the line between them can be dragged
        self.vsplit = GripSplitter(Qt.Vertical)
        self.vsplit.setChildrenCollapsible(False)
        top = QWidget()
        tl = QVBoxLayout(top)
        tl.setContentsMargins(0, 0, 0, 0)
        tl.setSpacing(8)

        # ---- "montage preview" bar (shown while the preview render plays)
        self.render_bar = QFrame()
        self.render_bar.setObjectName("Panel")
        rb = QHBoxLayout(self.render_bar)
        rb.setContentsMargins(10, 4, 6, 4)
        self.render_lbl = QLabel("👁 " + tr("player_render_mode"))
        self.render_lbl.setStyleSheet(f"color: {theme.ACCENT_2}; font-weight: 600;")
        rb.addWidget(self.render_lbl, 1)
        b = QPushButton("✕ " + tr("player_render_back"))
        b.setObjectName("Flat")
        b.clicked.connect(self.exit_render)
        rb.addWidget(b)
        self.render_bar.hide()
        tl.addWidget(self.render_bar)

        # ---- video area
        self.video_box = QFrame()
        self.video_box.setObjectName("Panel")
        self.video_box.setMinimumHeight(150)
        self.video_box.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        stack = QStackedLayout(self.video_box)
        stack.setStackingMode(QStackedLayout.StackOne)
        self.overlay = QLabel(tr("player_pick"))
        self.overlay.setAlignment(Qt.AlignCenter)
        self.overlay.setWordWrap(True)
        self.overlay.setStyleSheet(f"color: {theme.MUTED}; background: transparent; padding: 20px;")
        if HAVE_MM:
            self.video = QVideoWidget()
            self.video.setStyleSheet("background: black;")
            self.video.setFocusPolicy(Qt.NoFocus)     # the lists keep the keyboard (G / X / Space…)
            self.player = QMediaPlayer(self)
            self.audio = None
            if not os.environ.get("FIRECLIPS_NO_AUDIO"):   # (test machines without a sound card)
                self.audio = QAudioOutput(self)
                self.audio.setVolume(0.8)
                self.player.setAudioOutput(self.audio)
            self.player.setVideoOutput(self.video)
            self.player.positionChanged.connect(self._on_position)
            self.player.durationChanged.connect(self._on_duration)
            self.player.mediaStatusChanged.connect(self._on_status)
            self.player.playbackStateChanged.connect(self._on_state)
            self.player.errorOccurred.connect(self._on_error)
            stack.addWidget(self.overlay)
            stack.addWidget(self.video)
            stack.setCurrentWidget(self.overlay)
            self._stack = stack
        else:
            self.player = None
            self.overlay.setText(tr("player_unavailable"))
            stack.addWidget(self.overlay)
            self._stack = stack
        tl.addWidget(self.video_box, 1)

        # ---- transport
        tr_row = QHBoxLayout()
        self.btn_play = QToolButton()
        self.btn_play.setText("▶")
        self.btn_play.setToolTip(tr("player_playpause"))
        self.btn_play.clicked.connect(self.toggle_play)
        self.btn_clip = QPushButton(tr("player_play_clip"))
        self.btn_clip.setToolTip(tr("player_play_clip_tip"))
        self.btn_clip.clicked.connect(self.play_clip)
        self.slider = QSlider(Qt.Horizontal)
        self.slider.setRange(0, 1000)
        self.slider.sliderMoved.connect(self._on_slider)
        self.time_lbl = QLabel("--:--")
        self.time_lbl.setObjectName("Muted")
        self.time_lbl.setMinimumWidth(70)
        self.chk_loop = QToolButton()          # compact: the panel can be narrow on small screens
        self.chk_loop.setText("🔁")
        self.chk_loop.setCheckable(True)
        self.chk_loop.setToolTip(tr("player_loop"))
        self.btn_mute = QToolButton()
        self.btn_mute.setText("🔊")
        self.btn_mute.setCheckable(True)
        self.btn_mute.toggled.connect(self._on_mute)
        tr_row.addWidget(self.btn_play)
        tr_row.addWidget(self.btn_clip)
        tr_row.addWidget(self.slider, 1)
        tr_row.addWidget(self.time_lbl)
        tr_row.addWidget(self.btn_mute)
        tr_row.addWidget(self.chk_loop)
        tl.addLayout(tr_row)
        self.vsplit.addWidget(top)

        # ---- tabs under the video: the clip (start / end, title, why) and the Studio (montage)
        self.tabs = QTabWidget()
        self.tabs.setDocumentMode(True)
        clip_page = QWidget()
        cl = QVBoxLayout(clip_page)
        cl.setContentsMargins(0, 6, 0, 0)
        cl.setSpacing(8)
        self.tabs.addTab(clip_page, "✂ " + tr("player_tab_clip"))
        self.tabs.tabBar().setVisible(False)
        self.vsplit.addWidget(self.tabs)
        self.vsplit.setStretchFactor(0, 1)
        self.vsplit.setStretchFactor(1, 1)
        self._auto_split = True                 # until the user drags the line: video sized for a 16:9 picture
        self.vsplit.splitterMoved.connect(self._split_dragged)
        lay.addWidget(self.vsplit, 1)

        # ---- the Studio
        self.btn_studio = QPushButton("🎬  " + tr("player_studio"))
        self.btn_studio.setObjectName("Primary")
        self.btn_studio.setToolTip(tr("player_studio_tip"))
        self.btn_studio.clicked.connect(self.studio_requested)
        cl.addWidget(self.btn_studio)

        # ---- start / end
        box = QFrame()
        box.setObjectName("Panel")
        g = QGridLayout(box)
        g.setContentsMargins(10, 8, 10, 8)
        g.setHorizontalSpacing(6)
        self.start_edit = TimeSpinBox()
        self.end_edit = TimeSpinBox()
        self.start_edit.valueChanged.connect(self._on_range_edit)
        self.end_edit.valueChanged.connect(self._on_range_edit)
        self.len_lbl = QLabel("")
        self.len_lbl.setObjectName("Muted")
        g.addWidget(QLabel(tr("player_start")), 0, 0)
        g.addWidget(self.start_edit, 0, 1)
        g.addWidget(self._nudge("−1 s", lambda: self._shift("start", -1)), 0, 2)
        g.addWidget(self._nudge("+1 s", lambda: self._shift("start", +1)), 0, 3)
        b = self._nudge(tr("player_here"), lambda: self._set_here("start"))
        b.setToolTip(tr("player_here_start_tip"))
        g.addWidget(b, 0, 4)
        g.addWidget(QLabel(tr("player_end")), 1, 0)
        g.addWidget(self.end_edit, 1, 1)
        g.addWidget(self._nudge("−1 s", lambda: self._shift("end", -1)), 1, 2)
        g.addWidget(self._nudge("+1 s", lambda: self._shift("end", +1)), 1, 3)
        b = self._nudge(tr("player_here"), lambda: self._set_here("end"))
        b.setToolTip(tr("player_here_end_tip"))
        g.addWidget(b, 1, 4)
        self.btn_reset = QPushButton(tr("player_reset"))
        self.btn_reset.setObjectName("Flat")
        self.btn_reset.setToolTip(tr("player_reset_tip"))
        self.btn_reset.clicked.connect(self._reset_range)
        self._range_grid = g
        self._narrow: Optional[bool] = None
        self._place_range_extras(False)
        g.setColumnStretch(5, 1)
        cl.addWidget(box)

        # ---- title + why + transcript
        trow = QHBoxLayout()
        self.title_edit = QLineEdit()
        self.title_edit.setPlaceholderText(tr("player_title_ph"))
        self.title_edit.editingFinished.connect(self._on_title)
        trow.addWidget(self.title_edit, 1)
        self.btn_subs = QToolButton()
        self.btn_subs.setText("✏ " + tr("player_subs"))
        self.btn_subs.setToolTip(tr("player_subs_tip"))
        self.btn_subs.clicked.connect(self.edit_subs)
        trow.addWidget(self.btn_subs)
        cl.addLayout(trow)
        self.why = QLabel()
        self.why.setWordWrap(True)
        self.why.setTextFormat(Qt.RichText)
        self.why.setStyleSheet("font-size: 9pt;")
        cl.addWidget(self.why)
        self.text = QTextBrowser()
        self.text.setMinimumHeight(70)
        self.text.setPlaceholderText(tr("player_transcript_ph"))
        cl.addWidget(self.text, 1)
        self._seg_timer = QTimer(self)
        self._seg_timer.setSingleShot(True)
        self._seg_timer.setInterval(700)
        self._seg_timer.timeout.connect(self._request_segment)
        self.set_enabled(False)

    # ------------------------------------------------------------------ helpers
    def _place_range_extras(self, narrow: bool) -> None:
        """Length + "Reset" on the right of start / end, or under them when the panel is narrow."""
        if narrow == self._narrow:
            return
        self._narrow = narrow
        g = self._range_grid
        g.removeWidget(self.len_lbl)
        g.removeWidget(self.btn_reset)
        if narrow:
            g.addWidget(self.len_lbl, 2, 0, 1, 3)
            g.addWidget(self.btn_reset, 2, 3, 1, 2, Qt.AlignRight)
        else:
            g.addWidget(self.len_lbl, 0, 5)
            g.addWidget(self.btn_reset, 1, 5)

    def resizeEvent(self, e) -> None:  # noqa: N802
        super().resizeEvent(e)
        self._place_range_extras(self.width() < 480)
        if self._auto_split:
            QTimer.singleShot(0, self._apply_auto_split)

    def _split_dragged(self, *_a) -> None:
        self._auto_split = False

    def set_split(self, sizes: list) -> None:
        """Heights chosen by the user last time (video, tabs)."""
        self._auto_split = False
        self.vsplit.setSizes([int(x) for x in sizes])

    def _apply_auto_split(self) -> None:
        if not self._auto_split:
            return
        total = sum(self.vsplit.sizes())
        if total <= 0:
            return
        extra = self.vsplit.widget(0).height() - self.video_box.height()   # transport row (+ preview bar)
        if extra <= 0 or extra > 200:
            extra = 50
        want = int(self.video_box.width() * 9 / 16) + extra
        top = max(self.video_box.minimumHeight() + extra, min(want, int(total * 0.6)))
        self.vsplit.setSizes([top, max(100, total - top)])

    def _nudge(self, text, fn) -> QToolButton:
        b = QToolButton()
        b.setText(text)
        b.clicked.connect(fn)
        return b

    def set_enabled(self, on: bool) -> None:
        for w in (self.btn_play, self.btn_clip, self.slider, self.start_edit, self.end_edit, self.title_edit,
                  self.btn_reset, self.chk_loop, self.btn_subs, self.btn_studio):
            w.setEnabled(on)

    def vod_pos(self) -> float:
        if not self.player or not self.src:
            return 0.0
        return float(self.src["vod_start"]) + self.player.position() / 1000.0

    def playhead(self) -> Optional[float]:
        """VOD time under the playhead (None while the montage preview plays)."""
        if self.render_mode or not self.src:
            return None
        return self.vod_pos()

    def add_tab(self, widget: QWidget, title: str) -> int:
        i = self.tabs.addTab(widget, title)
        self.tabs.tabBar().setVisible(self.tabs.count() > 1)
        return i

    # ------------------------------------------------------------------ montage preview
    def play_render(self, path: str, duration: float = 0.0) -> None:
        """Play the rendered montage preview (clip time, not VOD time)."""
        if not self.player:
            return
        if not self.render_mode:
            self._saved_src = self.src
        self.render_mode = True
        self._clip_mode = False
        self.src = {"path": path, "vod_start": 0.0, "duration": duration, "full": True}
        self.render_bar.show()
        self._pending_seek = None
        self._autoplay = False
        self.player.setSource(QUrl.fromLocalFile(path))
        self._show_video()
        self.player.play()

    def exit_render(self) -> None:
        if not self.render_mode:
            return
        self.render_mode = False
        self.render_bar.hide()
        if self.player:
            self.player.stop()
        src, self._saved_src = self._saved_src, None
        self.src = None
        if src:
            self.set_source(src)
        elif self.moment:
            self.need_segment.emit(self.moment["start"], self.moment["end"])
        self.render_closed.emit()

    # ------------------------------------------------------------------ public API
    def show_moment(self, m: Optional[dict], vod_duration: float = 0.0, autoplay: bool = False) -> None:
        if self.render_mode:
            self.render_mode = False
            self.render_bar.hide()
            if self.player:
                self.player.stop()
            self.src, self._saved_src = self._saved_src, None
            if self.src and self.player:
                self.player.setSource(QUrl.fromLocalFile(self.src["path"]))
        self.moment = m
        self.duration_vod = vod_duration or self.duration_vod
        if self.player:
            self.player.pause()
        if m is None:
            self.set_enabled(False)
            self.title_edit.clear()
            self.why.clear()
            self.text.clear()
            self._show_overlay(tr("player_pick"))
            return
        self.set_enabled(True)
        self._block = True
        top = max(self.duration_vod, m["end"] + 60)
        self.start_edit.setRange(0, top)
        self.end_edit.setRange(0, top)
        self.start_edit.setValue(m["start"])
        self.end_edit.setValue(m["end"])
        self._block = False
        self._update_len()
        self.title_edit.setText(m.get("title") or "")
        self.refresh_details(m)
        self.text.setPlainText(m.get("transcript") or "")
        if self.src and self._covers(m["start"], m["end"]):
            if autoplay:
                self.play_clip()
            else:
                self.seek(m["start"])
        else:
            self._autoplay = autoplay
            self._show_overlay(tr("player_loading"))
            self.need_segment.emit(m["start"], m["end"])

    def refresh_details(self, m: Optional[dict] = None) -> None:
        m = m or self.moment
        if not m:
            return
        reasons = "".join(f"<div>• {reason_label(r, tr)}</div>" for r in m.get("reasons", []))
        src = ", ".join(tr("src_" + s) for s in m.get("sources", []))
        extra = ""
        if m.get("subs_text") is not None:
            extra = f"<div style='color:{theme.ACCENT_2}'>✏ {tr('player_subs_edited') if m['subs_text'] else tr('player_subs_off')}</div>"
        self.why.setText(f"<div style='color:{theme.MUTED}'>{tr('player_found_by')} {src}</div>{reasons}{extra}")

    def grab_frame(self):
        """The picture shown right now (QImage) or None: used to place the webcam frame."""
        if not self.player or not self.src:
            return None
        try:
            sink = self.video.videoSink()
            frame = sink.videoFrame() if sink is not None else None
            if frame is not None and frame.isValid():
                img = frame.toImage()
                if not img.isNull():
                    return img
        except Exception:  # noqa: BLE001
            pass
        # fall back to ffmpeg on the preview file
        try:
            import subprocess
            from PySide6.QtGui import QImage
            from .. import tools
            from ..util import no_window_flags
            ff = tools.find("ffmpeg")
            if not ff:
                return None
            rel = max(0.0, self.player.position() / 1000.0)
            res = subprocess.run([str(ff), "-v", "error", "-ss", f"{rel:.2f}", "-i", self.src["path"], "-frames:v", "1",
                                  "-f", "image2pipe", "-vcodec", "png", "-"], capture_output=True, timeout=20,
                                 stdin=subprocess.DEVNULL, creationflags=no_window_flags())
            if res.returncode == 0 and res.stdout:
                img = QImage.fromData(res.stdout, "PNG")
                return img if not img.isNull() else None
        except Exception:  # noqa: BLE001
            return None
        return None

    def set_source(self, src: dict, autoplay: bool = False) -> None:
        if not self.player:
            return
        same = self.src and self.src.get("path") == src.get("path")
        self.src = src
        self._autoplay = autoplay
        if not same:
            self.player.setSource(QUrl.fromLocalFile(src["path"]))
        if self.moment:
            self._pending_seek = self.moment["start"]
            if same:
                self.seek(self.moment["start"])
        self._show_video()

    def preview_failed(self, msg: str) -> None:
        self._show_overlay(msg)

    def seek(self, vod_t: float) -> None:
        if self.render_mode:
            self.exit_render()
            self._pending_seek = vod_t
            return
        if not self.player or not self.src:
            return
        rel = max(0.0, vod_t - float(self.src["vod_start"]))
        self.player.setPosition(int(rel * 1000))
        self._show_video()

    def stop(self) -> None:
        if self.player:
            self.player.stop()

    def release(self) -> None:
        """Let go of the file (so that it can be deleted)."""
        if self.player:
            self.player.stop()
            self.player.setSource(QUrl())
        self.src = None
        self._saved_src = None
        self.render_mode = False
        self.render_bar.hide()

    # ------------------------------------------------------------------ playback
    def toggle_play(self) -> None:
        if not self.player:
            return
        if self.player.playbackState() == QMediaPlayer.PlayingState:
            self.player.pause()
        else:
            self._clip_mode = False
            self.player.play()

    def toggle_clip(self) -> None:
        """Space in the lists: play the clip (from its start the first time), pause, go on."""
        if not self.player or not self.moment:
            return
        if self.player.playbackState() == QMediaPlayer.PlayingState:
            self.player.pause()
            return
        t = self.vod_pos() if self.src else None
        if self.render_mode or (t is not None and self.start_edit.value() <= t < self.end_edit.value() - 0.3):
            self._clip_mode = not self.render_mode
            self.player.play()
        else:
            self.play_clip()

    def nudge(self, which: str, delta: float) -> None:
        self._shift(which, delta)

    def play_clip(self) -> None:
        if not self.player or not self.moment:
            return
        if self.render_mode:
            self.player.setPosition(0)
            self.player.play()
            return
        if not self.src or not self._covers(self.start_edit.value(), self.end_edit.value()):
            self._autoplay = True
            self._request_segment()
            return
        self._clip_mode = True
        self.seek(self.start_edit.value())
        self.player.play()

    def _covers(self, a: float, b: float) -> bool:
        if not self.src:
            return False
        if self.src.get("full"):
            return True
        s0 = float(self.src["vod_start"])
        return s0 <= a + 0.05 and s0 + float(self.src["duration"]) >= b - 0.05

    def _on_position(self, ms: int) -> None:
        if not self.src:
            return
        dur = self.player.duration() or 1
        if not self.slider.isSliderDown():
            self.slider.setValue(int(1000 * ms / dur))
        if self.render_mode:
            self.time_lbl.setText(fmt_time(ms / 1000.0, 1) + " / " + fmt_time(dur / 1000.0, 1))
            if ms >= dur - 60 and self.chk_loop.isChecked():
                self.player.setPosition(0)
            return
        t = self.vod_pos()
        self.position_vod.emit(t)
        clip_t = t - self.start_edit.value()
        self.time_lbl.setText(fmt_time(t) + (f"  ({fmt_time(clip_t, 1)})" if self.moment else ""))
        if self._clip_mode and t >= self.end_edit.value():
            if self.chk_loop.isChecked():
                self.seek(self.start_edit.value())
            else:
                self.player.pause()
                self._clip_mode = False

    def _on_duration(self, _d: int) -> None:
        pass

    def _on_status(self, status) -> None:
        if status in (QMediaPlayer.LoadedMedia, QMediaPlayer.BufferedMedia) and self._pending_seek is not None:
            t = self._pending_seek
            self._pending_seek = None
            self.seek(t)
            if self._autoplay:
                self._autoplay = False
                self._clip_mode = True
                self.player.play()
            else:
                # show the first frame of the clip
                self.player.play()
                QTimer.singleShot(120, self.player.pause)

    def _on_state(self, state) -> None:
        self.btn_play.setText("⏸" if state == QMediaPlayer.PlayingState else "▶")

    def _on_error(self, _err, msg="") -> None:
        log.warning("player error: %s", msg)
        self._show_overlay(tr("player_error") + (f"\n{msg}" if msg else ""))

    def _on_slider(self, v: int) -> None:
        if self.player and self.player.duration():
            self._clip_mode = False
            self.player.setPosition(int(self.player.duration() * v / 1000))

    def _on_mute(self, on: bool) -> None:
        if self.player and self.audio is not None:
            self.audio.setMuted(on)
            self.btn_mute.setText("🔇" if on else "🔊")

    def _show_overlay(self, text: str) -> None:
        self.overlay.setText(text)
        self._stack.setCurrentWidget(self.overlay)

    def _show_video(self) -> None:
        had = self.window().focusWidget() if self.window() else None
        self._stack.setCurrentWidget(self.video)
        self._no_focus_video()
        if had is not None and had is not self.window().focusWidget() and not self.isAncestorOf(had):
            had.setFocus()

    def _no_focus_video(self) -> None:
        """The video surface (a native window inside the widget) must not take the keyboard."""
        if self.player:
            for w in self.video.findChildren(QWidget):
                w.setFocusPolicy(Qt.NoFocus)

    # ------------------------------------------------------------------ range editing
    def _update_len(self) -> None:
        d = self.end_edit.value() - self.start_edit.value()
        self.len_lbl.setText(tr("player_len", len=fmt_time(max(0, d), 1)))
        self.len_lbl.setStyleSheet(f"color: {theme.BAD if d <= 1 else theme.MUTED};")

    def _on_range_edit(self, _v=None) -> None:
        if self._block or not self.moment:
            return
        a, b = self.start_edit.value(), self.end_edit.value()
        if b <= a + 1:
            self._block = True
            if self.sender() is self.start_edit:
                self.start_edit.setValue(b - 1)
            else:
                self.end_edit.setValue(a + 1)
            self._block = False
            a, b = self.start_edit.value(), self.end_edit.value()
        self._update_len()
        self.range_changed.emit(a, b)
        if self.src and self._covers(a, b):
            self.seek(a if self.sender() is self.start_edit else max(a, b - 3))
        else:
            self._seg_timer.start()

    def _shift(self, which: str, delta: float) -> None:
        ed = self.start_edit if which == "start" else self.end_edit
        ed.setValue(max(0.0, ed.value() + delta))

    def _set_here(self, which: str) -> None:
        if not self.src:
            return
        t = self.vod_pos()
        (self.start_edit if which == "start" else self.end_edit).setValue(t)

    def _reset_range(self) -> None:
        if not self.moment:
            return
        orig = self.moment.get("orig")
        if orig:
            self._block = True
            self.start_edit.setValue(orig[0])
            self.end_edit.setValue(orig[1])
            self._block = False
            self._on_range_edit()

    def _request_segment(self) -> None:
        if self.moment:
            self.need_segment.emit(self.start_edit.value(), self.end_edit.value())

    def _on_title(self) -> None:
        if self.moment and self.title_edit.text().strip() != (self.moment.get("title") or ""):
            self.title_changed.emit(self.title_edit.text().strip())
