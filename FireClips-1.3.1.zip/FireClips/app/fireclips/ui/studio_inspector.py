"""The Studio settings panel (right side): the settings of what is picked (a meme, a text, a sound, an
effect...), or of the whole clip when nothing is picked (title, start / end, subtitles, cuts, music)."""
from __future__ import annotations

from typing import Optional

from PySide6.QtCore import QSize, Qt, Signal
from PySide6.QtGui import QColor, QIcon, QPixmap
from PySide6.QtWidgets import (QButtonGroup, QCheckBox, QColorDialog, QComboBox, QDoubleSpinBox, QFrame, QGridLayout,
                               QHBoxLayout, QLabel, QLineEdit, QPlainTextEdit, QPushButton, QScrollArea, QSlider,
                               QStackedWidget, QToolButton, QVBoxLayout, QWidget)

from .. import bank, fxlib, montage, subtitles
from ..i18n import language, tr
from ..util import fmt_time
from . import theme
from .studio_library import emoji_icon
from .studio_timeline import element_label
from .widgets import FlowLayout, TimeSpinBox

POS_GRID = [(0.2, 0.22), (0.5, 0.22), (0.8, 0.22), (0.2, 0.5), (0.5, 0.5), (0.8, 0.5), (0.2, 0.78), (0.5, 0.78),
            (0.8, 0.78)]
POS_ARROWS = ["↖", "↑", "↗", "←", "•", "→", "↙", "↓", "↘"]
SWATCHES = ["#FFFFFF", "#FFD23F", "#FF7A00", "#E53935", "#FF4FA3", "#9146FF", "#00E5FF", "#7CFF6B", "#2EAD4B",
            "#111111"]
SIZED = ("emoji", "image", "video", "text", "killcard")
TURNS = ("emoji", "image", "text", "killcard")
POS_FX = {k for k, v in fxlib.EFFECTS.items() if v.get("pos")}


def _dec(v: float, n: int = 1) -> str:
    s = f"{v:.{n}f}"
    return s.replace(".", ",") if language() == "fr" else s


class Section(QFrame):
    def __init__(self, title: str, parent=None):
        super().__init__(parent)
        self.setObjectName("Panel")
        self.v = QVBoxLayout(self)
        self.v.setContentsMargins(10, 8, 10, 10)
        self.v.setSpacing(6)
        t = QLabel(title)
        t.setStyleSheet(f"color: {theme.MUTED}; font-weight: 600; font-size: 8.5pt;")
        self.v.addWidget(t)


class SliderRow(QWidget):
    """A label, a slider and its value."""
    moved = Signal(int)

    def __init__(self, label: str, lo: int, hi: int, fmt, parent=None):
        super().__init__(parent)
        self.fmt = fmt
        h = QHBoxLayout(self)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(6)
        self.lab = QLabel(label)
        self.lab.setMinimumWidth(70)
        h.addWidget(self.lab)
        self.s = QSlider(Qt.Horizontal)
        self.s.setRange(lo, hi)
        h.addWidget(self.s, 1)
        self.val = QLabel("")
        self.val.setObjectName("Muted")
        self.val.setMinimumWidth(48)
        self.val.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        h.addWidget(self.val)
        self.s.valueChanged.connect(self._on)

    def set(self, v: int) -> None:
        self.s.blockSignals(True)
        self.s.setValue(int(v))
        self.s.blockSignals(False)
        self.val.setText(self.fmt(int(v)))

    def _on(self, v: int) -> None:
        self.val.setText(self.fmt(v))
        self.moved.emit(v)


class Inspector(QWidget):
    changed = Signal(str)              # something of the picked element changed (undo grouping key)
    clip_changed = Signal(str)         # a setting of the clip changed (undo grouping key)
    delete_requested = Signal(str)
    duplicate_requested = Signal(str)
    seek_to = Signal(float)            # clip time
    nudge = Signal(str, float)         # element id, seconds (+/-)
    range_edit = Signal(float, float)  # new start / end of the clip (VOD time)
    range_reset = Signal()
    title_edit = Signal(str)
    hook_here = Signal()
    edit_subs = Signal()
    show_music = Signal()
    pick_emoji = Signal(str)           # element id: choose the emoji of an effect (emoji rain)
    listen = Signal(str)               # file path
    seg_cut_here = Signal()            # ✂ cut the video at the red line
    seg_delete = Signal(int)           # remove this kept part
    seg_cut_side = Signal(str)         # remove everything "before" | "after" the red line
    seg_reset = Signal()               # the whole clip again
    seg_speed = Signal(int, float)     # the speed of a kept part (1 = normal)
    seg_go = Signal(int)               # the red line to the start of a part

    def __init__(self, cfg, parent=None):
        super().__init__(parent)
        self.cfg = cfg
        self.e: Optional[dict] = None
        self.m: Optional[dict] = None
        self.moment: Optional[dict] = None
        self._block = False
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        self.stack = QStackedWidget()
        outer.addWidget(self.stack)
        self._clip_page = self._scroll(self._build_clip())
        self.stack.addWidget(self._clip_page)
        self.el_holder = QWidget()
        self.el_v = QVBoxLayout(self.el_holder)
        self.el_v.setContentsMargins(2, 2, 2, 2)
        self.el_v.setSpacing(8)
        self._el_page = self._scroll(self.el_holder)
        self.stack.addWidget(self._el_page)
        self._seg_page = self._scroll(self._build_segment())
        self.stack.addWidget(self._seg_page)
        self.seg_i: Optional[int] = None
        self.setStyleSheet(f"""
            QToolButton#Chip {{ border-radius: 10px; padding: 3px 8px; font-size: 8.5pt; }}
            QToolButton#Chip:checked {{ background: {theme.ACCENT}; border-color: {theme.ACCENT}; color: white; }}
            QToolButton#Swatch {{ border-radius: 11px; padding: 0; }}
            QToolButton#Swatch:checked {{ border: 2px solid white; }}
        """)

    @staticmethod
    def _scroll(w: QWidget) -> QScrollArea:
        sc = QScrollArea()
        sc.setWidgetResizable(True)
        sc.setFrameShape(QFrame.NoFrame)
        sc.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        sc.setWidget(w)
        return sc

    # =================================================================== the clip
    def _build_clip(self) -> QWidget:
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(2, 2, 2, 2)
        v.setSpacing(8)
        hint = QLabel(tr("insp_clip_hint"))
        hint.setObjectName("Muted")
        hint.setWordWrap(True)
        hint.setStyleSheet("font-size: 8.5pt;")
        v.addWidget(hint)
        s = Section("🎬 " + tr("insp_clip"))
        self.c_title = QLineEdit()
        self.c_title.setPlaceholderText(tr("player_title_ph"))
        self.c_title.editingFinished.connect(lambda: self.title_edit.emit(self.c_title.text().strip()))
        s.v.addWidget(self.c_title)
        g = QGridLayout()
        g.setHorizontalSpacing(4)
        self.c_start = TimeSpinBox()
        self.c_end = TimeSpinBox()
        for row, (lab, ed) in enumerate(((tr("player_start"), self.c_start), (tr("player_end"), self.c_end))):
            g.addWidget(QLabel(lab), row, 0)
            g.addWidget(ed, row, 1)
            for col, d in ((2, -1.0), (3, 1.0)):
                b = QToolButton()
                b.setText(("−" if d < 0 else "+") + "1 s")
                b.clicked.connect(lambda _c=False, ed=ed, d=d: ed.setValue(max(0.0, ed.value() + d)))
                g.addWidget(b, row, col)
            ed.valueChanged.connect(self._on_range)
        s.v.addLayout(g)
        row = QHBoxLayout()
        self.c_len = QLabel("")
        self.c_len.setObjectName("Muted")
        row.addWidget(self.c_len, 1)
        b = QPushButton(tr("player_reset"))
        b.setObjectName("Flat")
        b.setToolTip(tr("player_reset_tip"))
        b.clicked.connect(self.range_reset)
        row.addWidget(b)
        s.v.addLayout(row)
        v.addWidget(s)

        s = Section("💬 " + tr("insp_subs"))
        self.c_subs = QComboBox()
        self.c_subs.addItem(tr("insp_subs_default"), None)
        self.c_subs.addItem(tr("insp_subs_on"), True)
        self.c_subs.addItem(tr("insp_subs_off"), False)
        self.c_subs.currentIndexChanged.connect(lambda _i: self._clip_opt("subs"))
        s.v.addWidget(self.c_subs)
        box = QWidget()
        fl = FlowLayout(box, 3)
        fl.setContentsMargins(0, 0, 0, 0)
        self.c_style_grp = QButtonGroup(self)
        self.c_style_grp.setExclusive(True)
        for i, sid in enumerate([""] + subtitles.STYLE_ORDER):
            b = QToolButton()
            b.setObjectName("Chip")
            b.setCheckable(True)
            b.setText(tr("st_style_default") if not sid else tr("substyle_" + sid))
            b.setProperty("sid", sid)
            b.clicked.connect(lambda _c=False: self._clip_opt("sub_style"))
            self.c_style_grp.addButton(b, i)
            fl.addWidget(b)
        s.v.addWidget(box)
        row = QHBoxLayout()
        b = QPushButton("✏ " + tr("player_subs"))
        b.setToolTip(tr("player_subs_tip"))
        b.clicked.connect(self.edit_subs)
        row.addWidget(b)
        row.addStretch(1)
        s.v.addLayout(row)
        self.c_bleep = QCheckBox("🤬 " + tr("st_bleep"))
        self.c_bleep.setToolTip(tr("st_bleep_tip"))
        self.c_bleep.toggled.connect(lambda _b: self._clip_opt("bleep"))
        s.v.addWidget(self.c_bleep)
        v.addWidget(s)

        s = Section("✂ " + tr("insp_edit"))
        self.c_cuts = QCheckBox("✂ " + tr("st_jumpcuts"))
        self.c_cuts.setToolTip(tr("st_jumpcuts_tip"))
        self.c_cuts.toggled.connect(lambda _b: self._clip_opt("jumpcuts"))
        s.v.addWidget(self.c_cuts)
        row = QHBoxLayout()
        self.c_cold = QCheckBox("🎬 " + tr("st_cold"))
        self.c_cold.setToolTip(tr("st_cold_tip"))
        self.c_cold.toggled.connect(lambda _b: self._clip_opt("cold_open"))
        row.addWidget(self.c_cold)
        b = QToolButton()
        b.setText("🎯 " + tr("st_hook_here"))
        b.setToolTip(tr("st_hook_here_tip"))
        b.clicked.connect(self.hook_here)
        row.addWidget(b)
        row.addStretch(1)
        s.v.addLayout(row)
        v.addWidget(s)

        s = Section("🎵 " + tr("st_music"))
        self.c_music = QLabel("")
        self.c_music.setWordWrap(True)
        s.v.addWidget(self.c_music)
        self.c_mvol = SliderRow(tr("st_music_vol"), 0, 60, lambda x: f"{x} %")
        self.c_mvol.moved.connect(lambda _v: self._clip_opt("music_vol"))
        s.v.addWidget(self.c_mvol)
        row = QHBoxLayout()
        b = QPushButton("🎵 " + tr("insp_music_pick"))
        b.clicked.connect(self.show_music)
        row.addWidget(b)
        self.c_mdel = QPushButton("✕")
        self.c_mdel.setObjectName("Flat")
        self.c_mdel.setToolTip(tr("insp_music_off"))
        self.c_mdel.clicked.connect(lambda: self._set_music(""))
        row.addWidget(self.c_mdel)
        row.addStretch(1)
        s.v.addLayout(row)
        v.addWidget(s)
        v.addStretch(1)
        return w

    def set_clip(self, moment: Optional[dict], m: Optional[dict]) -> None:
        """Show the settings of the clip (nothing picked)."""
        self.moment, self.m = moment, m
        self.e = None
        self.seg_i = None
        self._block = True
        if moment is not None and m is not None:
            self.c_title.setText(moment.get("title") or "")
            self.c_start.setValue(float(moment["start"]))
            self.c_end.setValue(float(moment["end"]))
            self._len_label()
            i = self.c_subs.findData(m.get("subs"))
            self.c_subs.setCurrentIndex(max(0, i))
            for b in self.c_style_grp.buttons():
                b.setChecked((b.property("sid") or "") == (m.get("sub_style") or ""))
            self.c_bleep.setChecked(bool(m.get("bleep")))
            self.c_cuts.setChecked(bool(m.get("jumpcuts")))
            self.c_cold.setChecked(bool(m.get("cold_open")))
            mus = m.get("music") or ""
            self.c_music.setText(("🎵 " + bank.display_name(mus)) if mus else tr("lib_music_current_none"))
            self.c_mvol.set(int(m.get("music_vol", 18)))
            self.c_mvol.setEnabled(bool(mus))
            self.c_mdel.setEnabled(bool(mus))
        self._block = False
        self.stack.setCurrentWidget(self._clip_page)

    # =================================================================== a kept part of the video (cuts)
    def _build_segment(self) -> QWidget:
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(2, 2, 2, 2)
        v.setSpacing(8)
        self.s_title = QLabel("")
        self.s_title.setStyleSheet("font-weight: 600; font-size: 11pt;")
        v.addWidget(self.s_title)
        self.s_info = QLabel("")
        self.s_info.setObjectName("Muted")
        self.s_info.setWordWrap(True)
        v.addWidget(self.s_info)
        s = Section("✂ " + tr("st_cut_title"))
        hint = QLabel(tr("st_cut_hint"))
        hint.setObjectName("Muted")
        hint.setWordWrap(True)
        hint.setStyleSheet("font-size: 8.5pt;")
        s.v.addWidget(hint)
        b = QPushButton("✂ " + tr("st_cut_here") + "  (S)")
        b.setObjectName("Primary")
        b.setToolTip(tr("st_cut_here_tip"))
        b.clicked.connect(self.seg_cut_here)
        s.v.addWidget(b)
        self.s_del = QPushButton("🗑 " + tr("st_seg_delete"))
        self.s_del.setToolTip(tr("st_seg_delete_tip"))
        self.s_del.clicked.connect(lambda: self.seg_i is not None and self.seg_delete.emit(self.seg_i))
        s.v.addWidget(self.s_del)
        row = QHBoxLayout()
        for side, icon, key in (("before", "⇤", "st_cut_before"), ("after", "⇥", "st_cut_after")):
            b = QPushButton(f"{icon} " + tr(key))
            b.setToolTip(tr(key + "_tip"))
            b.clicked.connect(lambda _c=False, sd=side: self.seg_cut_side.emit(sd))
            row.addWidget(b)
        s.v.addLayout(row)
        self.s_reset = QPushButton("↺ " + tr("st_cuts_reset"))
        self.s_reset.setObjectName("Flat")
        self.s_reset.clicked.connect(self.seg_reset)
        s.v.addWidget(self.s_reset)
        v.addWidget(s)
        s = Section("⏩ " + tr("st_seg_speed"))
        self.s_speed = QComboBox()
        for sp, key in ((0.5, "st_speed_half"), (0.75, "st_speed_3q"), (1.0, "st_speed_normal"), (1.5, "st_speed_15"),
                        (2.0, "st_speed_2"), (3.0, "st_speed_3")):
            self.s_speed.addItem(tr(key), sp)
        self.s_speed.currentIndexChanged.connect(self._on_seg_speed)
        s.v.addWidget(self.s_speed)
        hint = QLabel(tr("st_seg_speed_hint"))
        hint.setObjectName("Muted")
        hint.setWordWrap(True)
        hint.setStyleSheet("font-size: 8.5pt;")
        s.v.addWidget(hint)
        v.addWidget(s)
        b = QPushButton("▶ " + tr("st_el_go"))
        b.setObjectName("Flat")
        b.clicked.connect(lambda: self.seg_i is not None and self.seg_go.emit(self.seg_i))
        v.addWidget(b)
        v.addStretch(1)
        return w

    def set_segment(self, i: int, segs: list, speed: float) -> None:
        """Show a kept part of the video: its number, its span, what can be done with it."""
        self.e = None
        self.seg_i = i
        self._block = True
        n = len(segs)
        k0, k1 = segs[i]
        self.s_title.setText("🎬 " + tr("st_seg_n", i=i + 1, n=n))
        self.s_info.setText(tr("st_seg_span", start=fmt_time(k0, 1), end=fmt_time(k1, 1), len=fmt_time(k1 - k0, 1)))
        self.s_del.setEnabled(n > 1)
        self.s_reset.setEnabled(n > 1)
        j = self.s_speed.findData(speed)
        if j < 0:
            j = self.s_speed.findData(1.0)
        self.s_speed.setCurrentIndex(max(0, j))
        self._block = False
        self.stack.setCurrentWidget(self._seg_page)

    def _on_seg_speed(self, _i: int) -> None:
        if self._block or self.seg_i is None:
            return
        self.seg_speed.emit(self.seg_i, float(self.s_speed.currentData() or 1.0))

    def _len_label(self) -> None:
        d = self.c_end.value() - self.c_start.value()
        self.c_len.setText(tr("player_len", len=fmt_time(max(0.0, d), 1)))

    def _on_range(self, _v=None) -> None:
        if self._block:
            return
        a, b = self.c_start.value(), self.c_end.value()
        if b <= a + 1:
            self._block = True
            if self.sender() is self.c_start:
                self.c_start.setValue(b - 1)
            else:
                self.c_end.setValue(a + 1)
            self._block = False
            a, b = self.c_start.value(), self.c_end.value()
        self._len_label()
        self.range_edit.emit(a, b)

    def _clip_opt(self, key: str) -> None:
        if self._block or self.m is None:
            return
        m = self.m
        if key == "subs":
            m["subs"] = self.c_subs.currentData()
        elif key == "sub_style":
            b = self.c_style_grp.checkedButton()
            m["sub_style"] = (b.property("sid") if b is not None else "") or ""
        elif key == "bleep":
            m["bleep"] = self.c_bleep.isChecked()
        elif key == "jumpcuts":
            m["jumpcuts"] = self.c_cuts.isChecked()
        elif key == "cold_open":
            cold = self.c_cold.isChecked()
            if cold and m.get("hook") is None and self.moment is not None:
                h = montage.hook_time(self.moment)
                if h is not None:
                    m["hook"] = round(h, 2)
            m["cold_open"] = cold
        elif key == "music_vol":
            m["music_vol"] = self.c_mvol.s.value()
        self.clip_changed.emit(key)

    def _set_music(self, ref: str) -> None:
        if self.m is None:
            return
        self.m["music"] = ref
        self.clip_changed.emit("music")

    # =================================================================== an element
    def set_element(self, e: Optional[dict], o_start: Optional[float] = None) -> None:
        self.e = e
        self.seg_i = None
        if e is None:
            self.stack.setCurrentWidget(self._clip_page)
            return
        self._block = True
        while self.el_v.count():
            it = self.el_v.takeAt(0)
            w = it.widget()
            if w is not None:
                w.hide()
                w.setParent(None)            # gone at once (deleteLater only acts later)
                w.deleteLater()
        k = e["kind"]
        # ---- header
        head = QHBoxLayout()
        icon = QLabel()
        if k == "emoji":
            icon.setPixmap(emoji_icon((e.get("file") or "")[6:], 36).pixmap(36, 36))
        title = QLabel(element_label(e) if k != "emoji" else tr("st_kind_emoji"))
        title.setWordWrap(True)
        title.setStyleSheet("font-weight: 700; font-size: 11pt;")
        head.addWidget(icon)
        head.addWidget(title, 1)
        b = QToolButton()
        b.setText("⧉")
        b.setToolTip(tr("st_el_duplicate"))
        b.clicked.connect(lambda: self.duplicate_requested.emit(e["id"]))
        head.addWidget(b)
        b = QToolButton()
        b.setText("🗑")
        b.setToolTip(tr("st_el_delete") + " (Suppr)")
        b.clicked.connect(lambda: self.delete_requested.emit(e["id"]))
        head.addWidget(b)
        hw = QWidget()
        hw.setLayout(head)
        self.el_v.addWidget(hw)
        if e.get("auto"):
            a = QLabel("✨ " + tr("insp_auto"))
            a.setObjectName("Muted")
            a.setWordWrap(True)
            a.setStyleSheet("font-size: 8.5pt;")
            self.el_v.addWidget(a)
        # ---- when
        s = Section("⏱ " + tr("insp_when"))
        row = QHBoxLayout()
        self.t_lbl = QLabel(tr("insp_at", t=fmt_time(o_start or 0.0, 1)))
        row.addWidget(self.t_lbl, 1)
        for d in (-0.1, 0.1):
            b = QToolButton()
            b.setText(("−" if d < 0 else "+") + _dec(abs(d)) + " s")
            b.setToolTip(tr("insp_nudge_tip"))
            b.clicked.connect(lambda _c=False, d=d: self.nudge.emit(e["id"], d))
            row.addWidget(b)
        b = QToolButton()
        b.setText("▶")
        b.setToolTip(tr("st_el_go"))
        b.clicked.connect(lambda: self.seek_to.emit(max(0.0, (o_start or 0.0) - 0.8)))
        row.addWidget(b)
        s.v.addLayout(row)
        if True:
            row = QHBoxLayout()
            row.addWidget(QLabel(tr("st_el_dur")))
            sp = QDoubleSpinBox()
            sp.setDecimals(1)
            sp.setSingleStep(0.1 if k in ("bleep", "zoom", "shake") else 0.5)
            sp.setSuffix(" s")
            if k in ("sound", "video"):
                sp.setRange(0.0, 60.0)
                sp.setSpecialValueText(tr("insp_whole"))
            else:
                sp.setRange(0.1, 60.0)
            sp.setValue(float(e.get("dur") or 0.0))
            sp.valueChanged.connect(lambda v: self._set("dur", round(float(v), 2), "dur"))
            row.addWidget(sp, 1)
            s.v.addLayout(row)
        self.el_v.addWidget(s)
        # ---- kind specific
        if k == "text":
            self._text_section(e)
        if k in SIZED or k == "zoom" or (k == "fx" and e.get("effect") in POS_FX):
            self._place_section(e)
        if k in TURNS:
            self._anim_section(e)
        if k in ("sound", "video"):
            self._sound_section(e)
        if k == "zoom":
            self._slider_section("🔍 " + tr("st_kind_zoom"), tr("st_el_zoom"), 110, 200,
                                 int(100 * float(e.get("amount", 1.35))), lambda x: f"× {_dec(x / 100, 2)}",
                                 lambda x: self._set("amount", round(x / 100, 2), "amount"))
        elif k == "shake":
            self._slider_section("📳 " + tr("st_kind_shake"), tr("st_el_strength"), 20, 300,
                                 int(100 * float(e.get("amount", 1.0))), lambda x: f"{x} %",
                                 lambda x: self._set("amount", round(x / 100, 2), "amount"))
        elif k == "slowmo":
            fast = float(e.get("speed", 0.5)) > 1.0
            self._slider_section(("🐇 " if fast else "🐢 ") + tr("st_kind_fast" if fast else "st_kind_slowmo"),
                                 tr("st_el_speed"), 20, 300,
                                 int(100 * float(e.get("speed", 0.5))), lambda x: f"× {_dec(x / 100, 2)}",
                                 lambda x: self._set("speed", round(x / 100, 2), "speed"))
        elif k == "fx":
            self._fx_section(e)
        self.el_v.addStretch(1)
        self._block = False
        self.stack.setCurrentWidget(self._el_page)

    def set_time(self, o_start: float) -> None:
        lab = getattr(self, "t_lbl", None)
        if self.e is not None and lab is not None:
            try:
                lab.setText(tr("insp_at", t=fmt_time(o_start, 1)))
            except RuntimeError:
                pass

    def _set(self, key: str, value, group: str = "") -> None:
        if self._block or self.e is None:
            return
        if value is None:
            self.e.pop(key, None)
        else:
            self.e[key] = value
        self.e.pop("auto", None)
        self.changed.emit(f"{self.e['id']}:{group or key}")

    # ---- sections
    def _text_section(self, e: dict) -> None:
        s = Section("🅰 " + tr("insp_text"))
        ed = QPlainTextEdit(e.get("text") or "")
        ed.setMaximumHeight(70)
        ed.setPlaceholderText(tr("st_text_ask"))
        ed.textChanged.connect(lambda: ed.toPlainText().strip() and self._set("text", ed.toPlainText().strip()[:300],
                                                                               "text"))
        s.v.addWidget(ed)
        s.v.addWidget(QLabel(tr("insp_style")))
        box = QWidget()
        fl = FlowLayout(box, 3)
        fl.setContentsMargins(0, 0, 0, 0)
        grp = QButtonGroup(box)
        grp.setExclusive(True)
        cur = e.get("style") or "classic"
        for sid in fxlib.TEXT_STYLE_ORDER:
            b = QToolButton()
            b.setObjectName("Chip")
            b.setCheckable(True)
            b.setChecked(sid == cur)
            b.setIcon(_style_icon(sid))
            b.setIconSize(QSize(44, 22))
            b.setText(tr("txstyle_" + sid))
            b.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
            b.clicked.connect(lambda _c=False, sid=sid: self._set("style", sid, "style"))
            grp.addButton(b)
            fl.addWidget(b)
        s.v.addWidget(box)
        s.v.addWidget(QLabel(tr("insp_color")))
        s.v.addWidget(self._swatches(e))
        self.el_v.addWidget(s)

    def _swatches(self, e: dict) -> QWidget:
        box = QWidget()
        fl = FlowLayout(box, 4)
        fl.setContentsMargins(0, 0, 0, 0)
        grp = QButtonGroup(box)
        grp.setExclusive(True)
        cur = (e.get("color") or "").upper()
        b = QToolButton()
        b.setObjectName("Chip")
        b.setCheckable(True)
        b.setText(tr("insp_color_auto"))
        b.setChecked(not cur)
        b.clicked.connect(lambda: self._set("color", None, "color"))
        grp.addButton(b)
        fl.addWidget(b)
        for c in SWATCHES:
            b = QToolButton()
            b.setObjectName("Swatch")
            b.setCheckable(True)
            b.setFixedSize(22, 22)
            b.setStyleSheet(f"QToolButton {{ background: {c}; border: 1px solid #555; border-radius: 11px; }}"
                            f"QToolButton:checked {{ border: 2px solid white; }}")
            b.setChecked(cur == c)
            b.clicked.connect(lambda _c=False, c=c: self._set("color", c, "color"))
            grp.addButton(b)
            fl.addWidget(b)
        b = QToolButton()
        b.setText("🎨")
        b.setToolTip(tr("insp_color_custom"))

        def custom():
            col = QColorDialog.getColor(QColor(e.get("color") or "#FFFFFF"), self, tr("insp_color"))
            if col.isValid():
                self._set("color", col.name().upper(), "color")
        b.clicked.connect(custom)
        fl.addWidget(b)
        return box

    def _place_section(self, e: dict) -> None:
        k = e["kind"]
        s = Section("📐 " + tr("insp_place"))
        if k in SIZED or k == "fx":
            base = montage.DEFAULT_SIZE.get(k, 1.0)
            row = SliderRow(tr("st_el_size"), 20, 300, lambda x: f"{x} %")
            row.set(int(round(100 * float(e.get("size") or base) / base)))
            row.moved.connect(lambda x: self._set("size", round(base * x / 100, 4), "size"))
            s.v.addWidget(row)
        if k in TURNS:
            rrow = QHBoxLayout()
            rot = SliderRow(tr("insp_turn"), -180, 180, lambda x: f"{x}°")
            rot.set(int(round(float(e.get("rot") or 0))))
            rot.moved.connect(lambda x: self._set("rot", float(x) if x else None, "rot"))
            rrow.addWidget(rot, 1)
            b = QToolButton()
            b.setText("0°")
            b.setToolTip(tr("insp_turn_reset"))
            b.clicked.connect(lambda: (rot.set(0), self._set("rot", None, "rot")))
            rrow.addWidget(b)
            s.v.addLayout(rrow)
        if k != "video" or not e.get("full"):
            g = QGridLayout()
            g.setSpacing(2)
            x = e.get("x", 0.5)
            y = e.get("y", 0.5 if k != "killcard" else 0.1)
            best = min(range(9), key=lambda i: (POS_GRID[i][0] - x) ** 2 + (POS_GRID[i][1] - y) ** 2)
            grp = QButtonGroup(self)
            grp.setExclusive(True)
            for i, arrow in enumerate(POS_ARROWS):
                b = QToolButton()
                b.setText(arrow)
                b.setFixedSize(30, 24)
                b.setCheckable(True)
                b.setChecked(i == best and (e.get("x") is not None or k != "killcard"))
                b.clicked.connect(lambda _c=False, i=i: self._set_pos(i))
                grp.addButton(b)
                g.addWidget(b, i // 3, i % 3)
            row = QHBoxLayout()
            row.addLayout(g)
            hint = QLabel(tr("insp_place_hint"))
            hint.setObjectName("Muted")
            hint.setWordWrap(True)
            hint.setStyleSheet("font-size: 8pt;")
            row.addWidget(hint, 1)
            s.v.addLayout(row)
        self.el_v.addWidget(s)

    def _set_pos(self, i: int) -> None:
        if self.e is None:
            return
        self.e["x"], self.e["y"] = POS_GRID[i]
        self.e.pop("auto", None)
        self.changed.emit(f"{self.e['id']}:pos{i}")

    def _anim_section(self, e: dict) -> None:
        k = e["kind"]
        s = Section("🎞 " + tr("insp_anim"))
        box = QWidget()
        fl = FlowLayout(box, 3)
        fl.setContentsMargins(0, 0, 0, 0)
        grp = QButtonGroup(box)
        grp.setExclusive(True)
        cur = e.get("anim") or montage.DEFAULT_ANIM.get(k, "pop")
        lang = language()
        for a in fxlib.ANIMS:
            if a == "typewriter" and k != "text":
                continue
            b = QToolButton()
            b.setObjectName("Chip")
            b.setCheckable(True)
            b.setChecked(a == cur)
            names = fxlib.ANIM_NAMES.get(a, (a, a))
            b.setText(names[0] if lang == "fr" else names[1])
            b.clicked.connect(lambda _c=False, a=a: self._set("anim", a, "anim"))
            grp.addButton(b)
            fl.addWidget(b)
        s.v.addWidget(box)
        self.el_v.addWidget(s)

    def _sound_section(self, e: dict) -> None:
        k = e["kind"]
        s = Section(("🔊 " + tr("insp_sound")) if k == "sound" else ("🎞 " + tr("insp_video")))
        row = SliderRow(tr("st_el_vol"), 0, 200, lambda x: f"{x} %")
        row.set(int(e.get("vol", 100)))
        row.moved.connect(lambda x: self._set("vol", int(x), "vol"))
        s.v.addWidget(row)
        if k == "video":
            c = QCheckBox("🟩 " + tr("st_el_chroma"))
            c.setChecked(bool(e.get("chroma")))
            c.setToolTip(tr("insp_chroma_tip"))
            c.toggled.connect(lambda on: self._set("chroma", bool(on), "chroma"))
            s.v.addWidget(c)
            c = QCheckBox("⛶ " + tr("insp_full"))
            c.setChecked(bool(e.get("full")))
            c.toggled.connect(lambda on: self._set("full", bool(on), "full"))
            s.v.addWidget(c)
        c = QCheckBox(tr("st_el_duck"))
        c.setChecked(bool(e.get("duck", k == "video")))
        c.setToolTip(tr("insp_duck_tip"))
        c.toggled.connect(lambda on: self._set("duck", bool(on), "duck"))
        s.v.addWidget(c)
        if k == "sound":
            p = bank.resolve(e.get("file") or "", self.cfg)
            if p is not None:
                b = QPushButton("▶ " + tr("st_bank_listen"))
                b.clicked.connect(lambda: self.listen.emit(str(p)))
                s.v.addWidget(b)
        self.el_v.addWidget(s)

    def _slider_section(self, title: str, label: str, lo: int, hi: int, val: int, fmt, on) -> None:
        s = Section(title)
        row = SliderRow(label, lo, hi, fmt)
        row.set(val)
        row.moved.connect(on)
        s.v.addWidget(row)
        self.el_v.addWidget(s)

    def _fx_section(self, e: dict) -> None:
        eid = e.get("effect") or ""
        fx = fxlib.EFFECTS.get(eid, {})
        s = Section(f"{fx.get('icon', '✨')} {fxlib.effect_name(eid, language())}")
        d = QLabel(tr("fxtip_" + eid))
        d.setWordWrap(True)
        d.setObjectName("Muted")
        d.setStyleSheet("font-size: 8.5pt;")
        s.v.addWidget(d)
        if fx.get("text"):
            ed = QPlainTextEdit(e.get("text") or fxlib.default_effect_text(eid, language()))
            ed.setMaximumHeight(60)
            ed.textChanged.connect(lambda: self._set("text", ed.toPlainText().strip()[:120] or None, "text"))
            s.v.addWidget(ed)
        if fx.get("emoji"):
            row = QHBoxLayout()
            row.addWidget(QLabel(tr("insp_fx_emoji")))
            code = (e.get("file") or "emoji:1f480").split(":", 1)[-1]
            b = QToolButton()
            b.setIcon(emoji_icon(code, 28))
            b.setIconSize(QSize(28, 28))
            b.setToolTip(tr("insp_fx_emoji_tip"))
            b.clicked.connect(lambda: self.pick_emoji.emit(e["id"]))
            row.addWidget(b)
            row.addStretch(1)
            s.v.addLayout(row)
        if fx.get("freeze"):
            f = QLabel("❄ " + tr("insp_fx_freeze"))
            f.setObjectName("Muted")
            f.setWordWrap(True)
            f.setStyleSheet("font-size: 8.5pt;")
            s.v.addWidget(f)
        self.el_v.addWidget(s)


_style_icons: dict = {}


def _style_icon(sid: str) -> QIcon:
    if sid not in _style_icons:
        try:
            from .studio_library import _pil_icon
            im = fxlib.text_picture("Aa", 400, 400, 0.9, None, sid, language())
            _style_icons[sid] = QIcon(_pil_icon(im, QSize(44, 22)))
        except Exception:  # noqa: BLE001
            _style_icons[sid] = QIcon(QPixmap(1, 1))
    return _style_icons[sid]
