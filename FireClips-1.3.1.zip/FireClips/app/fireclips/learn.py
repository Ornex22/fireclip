"""FireClips learns what you keep: each "keep" (G) / "throw away" (X) is written down with the
signals of the moment (AI score, chat, laughs, kills...). After enough choices, a small logistic
regression says which signals really matter for you and proposes new weights."""
from __future__ import annotations

import json
import logging
import threading
import time
from pathlib import Path
from typing import Optional

import numpy as np

from . import paths
from .config import SIGNALS

log = logging.getLogger("fireclips.learn")
MIN_CHOICES = 30
_lock = threading.Lock()


def log_file() -> Path:
    return paths.ROOT / "learn" / "choices.jsonl"


def record(vod_key: str, moment: dict, decision: str) -> None:
    """decision: keep | reject | "" (undo)."""
    row = {"t": round(time.time(), 1), "vod": vod_key, "id": moment.get("id"), "d": decision,
           "signals": {k: float(v) for k, v in (moment.get("signals") or {}).items() if k in SIGNALS},
           "sources": list(moment.get("sources") or []), "cat": moment.get("category") or "",
           "len": round(float(moment.get("end", 0)) - float(moment.get("start", 0)), 1),
           "kill": str(moment.get("id", "")).startswith("k")}
    f = log_file()
    with _lock:
        try:
            f.parent.mkdir(parents=True, exist_ok=True)
            with f.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(row, ensure_ascii=False) + "\n")
        except OSError as e:
            log.warning("could not note the choice: %s", e)


def load() -> list[dict]:
    """The latest choice for each clip (pressing G then X counts as X)."""
    f = log_file()
    latest: dict = {}
    try:
        with f.open(encoding="utf-8") as fh:
            for line in fh:
                try:
                    r = json.loads(line)
                except ValueError:
                    continue
                latest[(r.get("vod"), r.get("id"))] = r
    except OSError:
        return []
    return [r for r in latest.values() if r.get("d") in ("keep", "reject")]


def counts() -> tuple[int, int]:
    rows = load()
    keep = sum(1 for r in rows if r["d"] == "keep")
    return keep, len(rows) - keep


def fit(rows: list[dict], keys=SIGNALS, l2: float = 0.5, iters: int = 800) -> Optional[dict]:
    """Logistic regression keep ~ signals. Returns {signal: coefficient} or None (too few choices)."""
    rows = [r for r in rows if not r.get("kill")]          # kill clips are chosen by fame, not by signals
    if len(rows) < MIN_CHOICES:
        return None
    y = np.array([1.0 if r["d"] == "keep" else 0.0 for r in rows])
    if y.min() == y.max():
        return None
    used = [k for k in keys if any(r["signals"].get(k, 0) > 0 for r in rows)]
    if not used:
        return None
    X = np.array([[float(r["signals"].get(k, 0.0)) for k in used] for r in rows])
    w = np.zeros(len(used))
    b = 0.0
    lr = 0.5
    n = len(rows)
    for _ in range(iters):
        z = X @ w + b
        p = 1.0 / (1.0 + np.exp(-np.clip(z, -30, 30)))
        g = p - y
        w -= lr * (X.T @ g / n + l2 * w / n)
        b -= lr * float(g.mean())
    out = {k: float(c) for k, c in zip(used, w)}
    out["__b"] = float(b)
    return out


def suggest_weights(cfg) -> dict:
    """{"n": choices, "keep": n, "reject": n, "weights": {...} or None}: weights on the same total
    as the current ones, signals that do not help you get a small weight."""
    rows = load()
    keep = sum(1 for r in rows if r["d"] == "keep")
    out = {"n": len(rows), "keep": keep, "reject": len(rows) - keep, "weights": None}
    coefs = fit(rows)
    if not coefs:
        return out
    current = dict(cfg.get("weights") or {})
    total = sum(float(v) for v in current.values()) or 100.0
    pos = {k: max(0.0, c) for k, c in coefs.items() if k != "__b"}
    s = sum(pos.values())
    if s <= 1e-6:
        return out
    new = {}
    for k in current:
        if k in pos:
            # half what the user's choices say, half the current weight: no brutal change
            new[k] = 0.5 * total * pos[k] / s + 0.5 * float(current[k])
        else:
            new[k] = float(current[k])
    t2 = sum(new.values()) or 1.0
    out["weights"] = {k: int(round(v * total / t2)) for k, v in new.items()}
    out["coefs"] = {k: round(v, 3) for k, v in coefs.items() if k != "__b"}
    return out


def accuracy(rows: Optional[list] = None) -> Optional[float]:
    """How often the learned model agrees with the choices (for the settings page)."""
    rows = [r for r in (rows if rows is not None else load()) if not r.get("kill")]
    coefs = fit(rows)
    if not coefs:
        return None
    keys = [k for k in coefs if k != "__b"]
    ok = 0
    for r in rows:
        z = coefs["__b"] + sum(coefs[k] * float(r["signals"].get(k, 0)) for k in keys)
        ok += int((z > 0) == (r["d"] == "keep"))
    return ok / max(1, len(rows))
